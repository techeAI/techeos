cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 conteneur",
  "$0 conteneurs"
 ],
 "$0 image total, $1": [
  null,
  "$0 image total, $1",
  "$0 images total, $1"
 ],
 "$0 second": [
  null,
  "$0 seconde",
  "$0 secondes"
 ],
 "$0 unused image, $1": [
  null,
  "$0 image non utilisée, $1",
  "$0 images non utilisées, $1"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  ""
 ],
 "Add port mapping": [
  null,
  "Ajouter un mappage de port"
 ],
 "Add variable": [
  null,
  "Ajouter une variable"
 ],
 "Add volume": [
  null,
  "Ajouter volume"
 ],
 "All": [
  null,
  "Tous"
 ],
 "All registries": [
  null,
  "Tous les registres"
 ],
 "Always": [
  null,
  "Toujours"
 ],
 "An error occurred": [
  null,
  "Une erreur s’est produite"
 ],
 "Author": [
  null,
  "Auteur"
 ],
 "Automatically start podman on boot": [
  null,
  "Démarrer automatiquement podman au démarrage"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "Assistance CPU Shares"
 ],
 "CPU shares": [
  null,
  "Parts de CPU"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU Shares déterminent la priorité des conteneurs en cours d'exécution. La priorité par défaut est de 1024. Un nombre plus élevé donne la priorité à ce conteneur. Un nombre inférieur diminue la priorité."
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Checking health": [
  null,
  "Contrôle de fonctionnement"
 ],
 "Checkpoint": [
  null,
  "Point de contrôle"
 ],
 "Checkpoint container $0": [
  null,
  "Point de contrôle du conteneur $0"
 ],
 "Click to see published ports": [
  null,
  "Cliquez pour voir les ports publiés"
 ],
 "Click to see volumes": [
  null,
  "Cliquez pour voir les volumes"
 ],
 "Command": [
  null,
  "Commande"
 ],
 "Comments": [
  null,
  "Commentaires"
 ],
 "Commit": [
  null,
  "Valider"
 ],
 "Commit container": [
  null,
  "Valider conteneur"
 ],
 "Configured": [
  null,
  "Configuré"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Container": [
  null,
  "Conteneur"
 ],
 "Container failed to be created": [
  null,
  "Le conteneur n’a pas pu être créé"
 ],
 "Container failed to be started": [
  null,
  "Le conteneur n’a pas pu être démarré"
 ],
 "Container is not running": [
  null,
  "Le conteneur n’est pas en cours d’exécution"
 ],
 "Container name": [
  null,
  "Nom du conteneur"
 ],
 "Container name is required.": [
  null,
  "Le nom du conteneur est obligatoire."
 ],
 "Container path": [
  null,
  "Chemin du conteneur"
 ],
 "Container port": [
  null,
  "Port du conteneur"
 ],
 "Containers": [
  null,
  "Conteneurs"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Créer une nouvelle image basée sur l'état actuel du conteneur $0."
 ],
 "Create and run": [
  null,
  "Créer et démarrer"
 ],
 "Create container": [
  null,
  "Créer un conteneur"
 ],
 "Create container in $0": [
  null,
  "Créer un conteneur dans $0"
 ],
 "Create container in pod": [
  null,
  "Créer un conteneur dans un pod"
 ],
 "Create pod": [
  null,
  "Créer un pod"
 ],
 "Created": [
  null,
  "Créé"
 ],
 "Created by": [
  null,
  "Créé par"
 ],
 "Decrease CPU shares": [
  null,
  "Diminution des parts de CPU"
 ],
 "Decrease interval": [
  null,
  "Diminution de l'intervalle"
 ],
 "Decrease maximum retries": [
  null,
  "Diminuer le nombre maximum de tentatives"
 ],
 "Decrease memory": [
  null,
  "Diminution de la mémoire"
 ],
 "Decrease retries": [
  null,
  "Diminuer les tentatives"
 ],
 "Decrease start period": [
  null,
  "Diminution de la période de démarrage"
 ],
 "Decrease timeout": [
  null,
  "Diminuer le délai d'attente"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Delete $0": [
  null,
  "Supprimer $0"
 ],
 "Delete $0?": [
  null,
  "Supprimer $0 ?"
 ],
 "Delete pod $0?": [
  null,
  "Supprimer le pod $0 ?"
 ],
 "Delete tagged images": [
  null,
  "Supprimer les images taguées"
 ],
 "Delete unused system images:": [
  null,
  "Supprimer les images système non utilisées :"
 ],
 "Delete unused user images:": [
  null,
  "Supprimer les images utilisateur non utilisées :"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Supprimer un conteneur va effacer toutes les données qu’il contient."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "La suppression d'un conteneur en cours d'exécution efface toutes les données qu'il contient."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "La suppression de ce pod entraînera celle des conteneurs suivants :"
 ],
 "Details": [
  null,
  "Détails"
 ],
 "Disk space": [
  null,
  "Espace disque"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Le format Docker est utile pour partager l'image avec Docker ou Moby Engine"
 ],
 "Download": [
  null,
  "Télécharger"
 ],
 "Download new image": [
  null,
  "Télécharger la nouvelle image"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Le pod vide $0 sera définitivement supprimé."
 ],
 "Entrypoint": [
  null,
  "Point d’entrée"
 ],
 "Environment variables": [
  null,
  "Variables d’environnement"
 ],
 "Error": [
  null,
  "Erreur"
 ],
 "Error message": [
  null,
  "Message d’erreur"
 ],
 "Error occurred while connecting console": [
  null,
  "Une erreur s’est produite lors de la connexion à la console"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Exemple, votre nom <yourname@example.com>"
 ],
 "Example: $0": [
  null,
  "Exemple : $0"
 ],
 "Exited": [
  null,
  "Quittés"
 ],
 "Failed health run": [
  null,
  "Échec de l’exécution du bilan de fonctionnement"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Échec de la création du point de contrôle du conteneur $0"
 ],
 "Failed to clean up container": [
  null,
  "Échec du nettoyage du conteneur"
 ],
 "Failed to commit container $0": [
  null,
  "Échec de la validation du conteneur $0"
 ],
 "Failed to create container $0": [
  null,
  "Échec de la création du conteneur $0"
 ],
 "Failed to download image $0:$1": [
  null,
  "Échec du téléchargement de l’image $0 : $1"
 ],
 "Failed to force remove container $0": [
  null,
  "Échec de la suppression forcée du conteneur $0"
 ],
 "Failed to force remove image $0": [
  null,
  "Échec de la suppression forcée de l’image $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "Échec du redémarrage forcé du pod $0"
 ],
 "Failed to force stop pod $0": [
  null,
  "Échec de l'arrêt forcé du pod $0"
 ],
 "Failed to pause container $0": [
  null,
  "Échec de la mise en pause du conteneur $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Échec de la mise en pause du pod $0"
 ],
 "Failed to prune unused images": [
  null,
  "Échec de la suppression des images non utilisées"
 ],
 "Failed to pull image $0": [
  null,
  "Échec d’extraction de l’image $0"
 ],
 "Failed to remove container $0": [
  null,
  "Échec de la suppression du conteneur $0"
 ],
 "Failed to remove image $0": [
  null,
  "Échec de la suppression de l’image $0"
 ],
 "Failed to rename container $0": [
  null,
  "Échec du renommage du conteneur $0"
 ],
 "Failed to restart container $0": [
  null,
  "Échec du redémarrage du conteneur $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Échec du redémarrage du pod $0"
 ],
 "Failed to restore container $0": [
  null,
  "Échec de la restauration du conteneur $0"
 ],
 "Failed to resume container $0": [
  null,
  "Échec de la reprise conteneur $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Échec de la reprise pod $0"
 ],
 "Failed to run container $0": [
  null,
  "Échec du démarrage du conteneur $0"
 ],
 "Failed to run health check on container $0": [
  null,
  "Échec de l'exécution du contrôle de fonctionnement du conteneur $0"
 ],
 "Failed to search for images.": [
  null,
  "Échec de la recherche d'images."
 ],
 "Failed to search for images: $0": [
  null,
  "Échec de la recherche de l'image : $0"
 ],
 "Failed to search for new images": [
  null,
  "Échec de la recherche de nouvelles images"
 ],
 "Failed to start container $0": [
  null,
  "Échec du démarrage du conteneur $0"
 ],
 "Failed to start pod $0": [
  null,
  "Échec du démarrage du pod $0"
 ],
 "Failed to stop container $0": [
  null,
  "Échec de l’arrêt du conteneur $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Échec de l’arrêt du pod $0"
 ],
 "Failing streak": [
  null,
  "Une série d'échecs"
 ],
 "Failure action": [
  null,
  ""
 ],
 "Force commit": [
  null,
  "Validation forcée"
 ],
 "Force delete": [
  null,
  "Suppression forcée"
 ],
 "Force delete pod $0?": [
  null,
  "Forcer la suppression du pod $0 ?"
 ],
 "Force restart": [
  null,
  "Redémarrage forcé"
 ],
 "Force stop": [
  null,
  "Arrêt forcé"
 ],
 "GB": [
  null,
  "Go"
 ],
 "Gateway": [
  null,
  "Passerelle"
 ],
 "Health check": [
  null,
  "Bilan de fonctionnement"
 ],
 "Health check interval help": [
  null,
  "Aide à l'intervalle du bilan de fonctionnement"
 ],
 "Health check retries help": [
  null,
  "Aide pour les tentatives de contrôle de fonctionnement"
 ],
 "Health check start period help": [
  null,
  "Aide pour la période de démarrage du bilan de fonctionnement"
 ],
 "Health check timeout help": [
  null,
  "Aide sur le délai d'exécution du bilan de fonctionnement"
 ],
 "Healthy": [
  null,
  "Fonctions intactes"
 ],
 "Hide images": [
  null,
  "Cacher les images"
 ],
 "Hide intermediate images": [
  null,
  "Cacher les images intermédiaires"
 ],
 "History": [
  null,
  "Historique"
 ],
 "Host path": [
  null,
  "Chemin vers l’hôte"
 ],
 "Host port": [
  null,
  "Port de l’hôte"
 ],
 "Host port help": [
  null,
  "Assistance Port d’hôte"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "Adresse IP"
 ],
 "IP address help": [
  null,
  "Assistance Adresse IP"
 ],
 "Ideal for development": [
  null,
  ""
 ],
 "Ideal for running services": [
  null,
  ""
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Si l’IP de l’hôte est définie ainsi 0.0.0.0 ou si elle n’est pas dutout définie, le port sera relié à tous les IP de l’hôte."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Si le port de l’hôte n’est pas défini, le port du conteneur sera assigné au hasard sur l’hôte."
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorer l'adresse IP si définie statiquement"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorer l'adresse MAC si définie statiquement"
 ],
 "Image": [
  null,
  "Image"
 ],
 "Image name is not unique": [
  null,
  "Le nom de l'image n'est pas unique"
 ],
 "Image name is required": [
  null,
  "Le nom de l'image est obligatoire"
 ],
 "Image selection help": [
  null,
  "Aide à la sélection d'images"
 ],
 "Images": [
  null,
  "Images"
 ],
 "Increase CPU shares": [
  null,
  "Augmenter les parts de CPU"
 ],
 "Increase interval": [
  null,
  "Augmenter l'intervalle"
 ],
 "Increase maximum retries": [
  null,
  "Augmenter le nombre maximum de tentatives"
 ],
 "Increase memory": [
  null,
  "Augmenter la mémoire"
 ],
 "Increase retries": [
  null,
  "Augmenter les tentatives"
 ],
 "Increase start period": [
  null,
  "Augmenter la période de démarrage"
 ],
 "Increase timeout": [
  null,
  "Augmenter le délai d'attente"
 ],
 "Integration": [
  null,
  "Intégration"
 ],
 "Interval": [
  null,
  "Intervalle"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervalle à partir duquel le contrôle de fonctionnement est exécuté."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Caractères non valides. Le nom ne peut contenir que des lettres, des chiffres et certains signes de ponctuation (_ . -)."
 ],
 "KB": [
  null,
  "Ko"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Conserver tous les fichiers de points de contrôle temporaires"
 ],
 "Key": [
  null,
  "Clé"
 ],
 "Last 5 runs": [
  null,
  "Les 5 dernières exécutions"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Conserver actif après la création du point de contrôle sur le disque"
 ],
 "Loading details...": [
  null,
  "Chargement des détails..."
 ],
 "Loading logs...": [
  null,
  "Chargement des logs..."
 ],
 "Loading...": [
  null,
  "Chargement..."
 ],
 "Local": [
  null,
  "Local"
 ],
 "Local images": [
  null,
  "Aucune image"
 ],
 "Logs": [
  null,
  "Journaux"
 ],
 "MAC address": [
  null,
  "Adresse MAC"
 ],
 "MB": [
  null,
  "Mo"
 ],
 "Maximum retries": [
  null,
  "Nombre max de nouvellles tentatives"
 ],
 "Memory": [
  null,
  "Mémoire"
 ],
 "Memory limit": [
  null,
  "Limite mémoire"
 ],
 "Memory unit": [
  null,
  "Unité de mémoire"
 ],
 "Mode": [
  null,
  "Mode"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Plusieurs tags existent pour cette image. Sélectionnez les images marquées à supprimer."
 ],
 "Name": [
  null,
  "Nom"
 ],
 "New container name": [
  null,
  "Nouveau nom du conteneur"
 ],
 "New image name": [
  null,
  "Nom de la nouvelle image"
 ],
 "No": [
  null,
  "Non"
 ],
 "No action": [
  null,
  ""
 ],
 "No containers": [
  null,
  "Aucun conteneur"
 ],
 "No containers are using this image": [
  null,
  "Aucun conteneur n’utilise cette image"
 ],
 "No containers in this pod": [
  null,
  "Aucun conteneur dans ce pod"
 ],
 "No containers that match the current filter": [
  null,
  "Aucun conteneur ne correspond au filtre actuel"
 ],
 "No environment variables specified": [
  null,
  "Aucune variables d’environnement spécifiée"
 ],
 "No images": [
  null,
  "Aucune image"
 ],
 "No images found": [
  null,
  "Aucune image trouvée"
 ],
 "No images that match the current filter": [
  null,
  "Aucune image ne correspond au filtre actuel"
 ],
 "No label": [
  null,
  "Pas de label"
 ],
 "No ports exposed": [
  null,
  "Aucuns ports exposés"
 ],
 "No results for $0": [
  null,
  "Aucun résultat pour $0"
 ],
 "No running containers": [
  null,
  "Aucun conteneur en cours d’exécution"
 ],
 "No volumes specified": [
  null,
  "Aucuns volumes spécifiés"
 ],
 "On failure": [
  null,
  "En cas d’échec"
 ],
 "Only running": [
  null,
  "En cours d’exécution seulement"
 ],
 "Options": [
  null,
  "Options"
 ],
 "Owner": [
  null,
  "Propriétaire"
 ],
 "Passed health run": [
  null,
  "Bilan de fonctionnement réussi"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Collez une ou plusieurs lignes de paires clé=valeur dans n'importe quel champ pour une importation en masse"
 ],
 "Pause": [
  null,
  "Pause"
 ],
 "Pause container when creating image": [
  null,
  "Mettre le conteneur en pause lors de la création de l’image"
 ],
 "Paused": [
  null,
  "En pause"
 ],
 "Pod failed to be created": [
  null,
  "Échec de la création du pod"
 ],
 "Pod name": [
  null,
  "Nom du pod"
 ],
 "Podman containers": [
  null,
  "Conteneurs Podman"
 ],
 "Podman service is not active": [
  null,
  "Le service Podman n’est pas actif"
 ],
 "Port mapping": [
  null,
  "Mappage de port"
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Ports under 1024 can be mapped": [
  null,
  ""
 ],
 "Private": [
  null,
  "Privé"
 ],
 "Protocol": [
  null,
  "Protocole"
 ],
 "Prune": [
  null,
  "Suppression de certaines images"
 ],
 "Prune unused images": [
  null,
  "Suppression d’images non utilisées"
 ],
 "Pruning images": [
  null,
  "Suppression de certaines images"
 ],
 "Pull latest image": [
  null,
  "Extraire la dernière image"
 ],
 "Pulling": [
  null,
  "Extraction"
 ],
 "Read-only access": [
  null,
  "Accès en lecture seule"
 ],
 "Read-write access": [
  null,
  "Accès en lecture-écriture"
 ],
 "Remove item": [
  null,
  "Supprimer l'élément"
 ],
 "Removing": [
  null,
  "En cours de suppression"
 ],
 "Rename": [
  null,
  "Renommer"
 ],
 "Rename container $0": [
  null,
  "Renommer le conteneur $0"
 ],
 "Resource limits can be set": [
  null,
  ""
 ],
 "Restart": [
  null,
  "Redémarrer"
 ],
 "Restart policy": [
  null,
  "Redémarrer la stratégie"
 ],
 "Restart policy help": [
  null,
  "Assistance pour la politique de redémarrage"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Politique de redémarrage à suivre lors de la sortie des conteneurs."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Politique de redémarrage à suivre lorsque les conteneurs se terminent. L'utilisation de linger pour le démarrage automatique des conteneurs peut ne pas fonctionner dans certaines circonstances, comme lorsque ecryptfs, systemd-homed, NFS ou 2FA sont utilisés sur un compte utilisateur."
 ],
 "Restore": [
  null,
  "Restaurer"
 ],
 "Restore container $0": [
  null,
  "Restaurer le conteneur $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Restaurer avec les connexions TCP établies"
 ],
 "Restricted by user account permissions": [
  null,
  ""
 ],
 "Resume": [
  null,
  "Reprendre"
 ],
 "Retries": [
  null,
  "Tentatives"
 ],
 "Retry another term.": [
  null,
  "Nouvelle tentative sur autre term."
 ],
 "Run health check": [
  null,
  "Exécuter le bilan de fonctionnement"
 ],
 "Running": [
  null,
  "En fonctionnement"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Rechercher par nom ou description"
 ],
 "Search by registry": [
  null,
  "Recherche par registre"
 ],
 "Search for": [
  null,
  "Rechercher"
 ],
 "Search for an image": [
  null,
  "Chercher une image"
 ],
 "Search string or container location": [
  null,
  "Chaîne de recherche ou emplacement du conteneur"
 ],
 "Searching...": [
  null,
  "Recherche en cours..."
 ],
 "Searching: $0": [
  null,
  "Recherche en cours : $0"
 ],
 "Shared": [
  null,
  "Partagé"
 ],
 "Show": [
  null,
  "Afficher"
 ],
 "Show images": [
  null,
  "Afficher les images"
 ],
 "Show intermediate images": [
  null,
  "Afficher les images intermédiaires"
 ],
 "Show less": [
  null,
  "Afficher moins de détails"
 ],
 "Show more": [
  null,
  "Montrer plus"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "Start": [
  null,
  "Démarrer"
 ],
 "Start period": [
  null,
  "Période de démarrage"
 ],
 "Start podman": [
  null,
  "Démarrer podman"
 ],
 "Start typing to look for images.": [
  null,
  "Commencez à saisir les données pour rechercher des images."
 ],
 "Started at": [
  null,
  "Commencé à"
 ],
 "State": [
  null,
  "État"
 ],
 "Status": [
  null,
  "Statut"
 ],
 "Stop": [
  null,
  "Arrêter"
 ],
 "Stopped": [
  null,
  "Arrêté"
 ],
 "Support preserving established TCP connections": [
  null,
  "Prendre en charge le maintien des connexions TCP établies"
 ],
 "System": [
  null,
  "Système"
 ],
 "System Podman service is also available": [
  null,
  "Le service Podman est également disponible"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Tag"
 ],
 "Tags": [
  null,
  "Étiquettes"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Le temps d'initialisation nécessaire à l'amorçage d'un conteneur."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Le temps maximum autorisé pour compléter le contrôle de fonctionnement avant qu'un intervalle soit considéré comme ayant échoué."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Le nombre de tentatives autorisées avant qu'un contrôle de fonctionnement ne soit considéré non acceptable."
 ],
 "Timeout": [
  null,
  "Délai d'attente"
 ],
 "Troubleshoot": [
  null,
  "Dépannage"
 ],
 "Type to filter…": [
  null,
  "Entrez pour filtrer…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Impossible de charger l'historique des images"
 ],
 "Unhealthy": [
  null,
  "Non acceptable"
 ],
 "Up since $0": [
  null,
  "En cours d’exécution depuis $0"
 ],
 "Use legacy Docker format": [
  null,
  "Utiliser l'ancien format Docker"
 ],
 "Used by": [
  null,
  "Utilisé par"
 ],
 "User": [
  null,
  "Utilisateur"
 ],
 "User Podman service is also available": [
  null,
  "Le service utilisateur Podman est également disponible"
 ],
 "User:": [
  null,
  "Utilisateur :"
 ],
 "Value": [
  null,
  "Valeur"
 ],
 "Volumes": [
  null,
  "Volumes"
 ],
 "With terminal": [
  null,
  "Avec le terminal"
 ],
 "Writable": [
  null,
  "Accessible en écriture"
 ],
 "container": [
  null,
  "conteneur"
 ],
 "downloading": [
  null,
  "En cours de téléchargement"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:port]/[user]/container[:tag]"
 ],
 "image": [
  null,
  "image"
 ],
 "in": [
  null,
  "dans"
 ],
 "n/a": [
  null,
  "n. d."
 ],
 "not available": [
  null,
  "non disponible"
 ],
 "pod group": [
  null,
  "groupe pod"
 ],
 "podman": [
  null,
  "podman"
 ],
 "ports": [
  null,
  "ports"
 ],
 "seconds": [
  null,
  "secondes"
 ],
 "select all": [
  null,
  "tout sélectionner"
 ],
 "system": [
  null,
  "système"
 ],
 "unused": [
  null,
  "non utilisé"
 ],
 "user:": [
  null,
  "utilisateur :"
 ],
 "volumes": [
  null,
  "volumes"
 ]
});
