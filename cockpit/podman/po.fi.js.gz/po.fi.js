cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "fi",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 kontti",
  "$0 konttia"
 ],
 "$0 image total, $1": [
  null,
  "$0 levykuva yhteensä, $1",
  "$0 levykuvaa yhteensä, $1"
 ],
 "$0 second": [
  null,
  "$0 sekunti",
  "$0 sekuntia"
 ],
 "$0 unused image, $1": [
  null,
  "$0 käyttämätön levykuva, $1",
  "$0 käyttämätöntä levykuvaa, $1"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Toimenpiteet, kun kontti siirtyy epäterveelliseen tilaan."
 ],
 "Add port mapping": [
  null,
  "Lisää porttiassosiaatio"
 ],
 "Add variable": [
  null,
  "Lisää muuttuja"
 ],
 "Add volume": [
  null,
  "Lisää taltio"
 ],
 "All": [
  null,
  "Kaikki"
 ],
 "All registries": [
  null,
  "Kaikki rekisterit"
 ],
 "Always": [
  null,
  "Aina"
 ],
 "An error occurred": [
  null,
  "Tapahtui virhe"
 ],
 "Author": [
  null,
  "Tekijä"
 ],
 "Automatically start podman on boot": [
  null,
  "Käynnistä podman automaattisesti käynnistyksen yhteydessä"
 ],
 "CPU": [
  null,
  "Suoritin"
 ],
 "CPU Shares help": [
  null,
  "Ohjeita CPU-osuuksista"
 ],
 "CPU shares": [
  null,
  "Suoritinosuus"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU-osuudet määrittävät käynnissä olevien konttien prioriteetin. Oletusprioriteetti on 1024. Suurempi numero priorisoi tätä konttia. Pienempi numero laskee prioriteettia."
 ],
 "Cancel": [
  null,
  "Peru"
 ],
 "Checking health": [
  null,
  "Tarkistetaan tilaa"
 ],
 "Checkpoint": [
  null,
  "Tarkistuspiste"
 ],
 "Checkpoint and restore support": [
  null,
  "Tarkistuspisteen ja palautuksen tuki"
 ],
 "Checkpoint container $0": [
  null,
  "Luo tarkistuspiste kontista $0"
 ],
 "Click to see published ports": [
  null,
  "Napsauta nähdäksesi julkaistut portit"
 ],
 "Click to see volumes": [
  null,
  "Napsauta nähdäksesi taltiot"
 ],
 "Command": [
  null,
  "Komento"
 ],
 "Comments": [
  null,
  "Kommentit"
 ],
 "Commit": [
  null,
  "Kommitoi"
 ],
 "Commit container": [
  null,
  "Kommitoi kontti"
 ],
 "Configured": [
  null,
  "Asetukset asetettu"
 ],
 "Console": [
  null,
  "Konsoli"
 ],
 "Container": [
  null,
  "Kontti"
 ],
 "Container failed to be created": [
  null,
  "Kontin luonti epäonnistui"
 ],
 "Container failed to be started": [
  null,
  "Kontin käynnistys epäonnistui"
 ],
 "Container is not running": [
  null,
  "Kontti ei ole käynnissä"
 ],
 "Container name": [
  null,
  "Kontin nimi"
 ],
 "Container name is required.": [
  null,
  "Kontin nimi vaaditaan."
 ],
 "Container path": [
  null,
  "Kontin polku"
 ],
 "Container port": [
  null,
  "Kontin portti"
 ],
 "Containers": [
  null,
  "Kontit"
 ],
 "Create": [
  null,
  "Luo"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Luo uusi levykuva $0-kontin nykyisen tilan perusteella."
 ],
 "Create and run": [
  null,
  "Luo ja suorita"
 ],
 "Create container": [
  null,
  "Luo kontti"
 ],
 "Create container in $0": [
  null,
  "Luo kontti kohteeseen $0"
 ],
 "Create container in pod": [
  null,
  "Luo kontti podiin"
 ],
 "Create pod": [
  null,
  "Luo podi"
 ],
 "Created": [
  null,
  "Luotu"
 ],
 "Created by": [
  null,
  "Tekijä"
 ],
 "Decrease CPU shares": [
  null,
  "Vähennä suoritinosuuksia"
 ],
 "Decrease interval": [
  null,
  "Pienennä väliä"
 ],
 "Decrease maximum retries": [
  null,
  "Pienennä uudelleenyritysten enimmäismäärää"
 ],
 "Decrease memory": [
  null,
  "Vähennä muistia"
 ],
 "Decrease retries": [
  null,
  "Vähennä uudelleenyrityksiä"
 ],
 "Decrease start period": [
  null,
  "Pienennä aloitusaikaa"
 ],
 "Decrease timeout": [
  null,
  "Pienennä aikakatkaisua"
 ],
 "Delete": [
  null,
  "Poista"
 ],
 "Delete $0": [
  null,
  "Poista $0"
 ],
 "Delete $0?": [
  null,
  "Poista $0?"
 ],
 "Delete pod $0?": [
  null,
  "Poista podi $0?"
 ],
 "Delete tagged images": [
  null,
  "Poista merkityt kuvat"
 ],
 "Delete unused system images:": [
  null,
  "Poista käyttämättömät järjestelmälevykuvat:"
 ],
 "Delete unused user images:": [
  null,
  "Poista käyttämättömät käyttäjän levykuvat:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Kontin poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Käynnissä olevan kontin poistaminen tuhoaa kaiken sillä olevan datan."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Tämän podin poisto poistaa seuraavat kontit:"
 ],
 "Details": [
  null,
  "Yksityiskohdat"
 ],
 "Disk space": [
  null,
  "Levytila"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker-muoto on hyödyllinen, kun levykuvaa jaetaan Dockerin tai Moby Enginen kanssa"
 ],
 "Download": [
  null,
  "Lataa"
 ],
 "Download new image": [
  null,
  "Lataa uusi levykuva"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Tyhjä podi $0 poistetaan pysyvästi."
 ],
 "Entrypoint": [
  null,
  "Sisääntulokohta"
 ],
 "Environment variables": [
  null,
  "Ympäristömuuttujat"
 ],
 "Error": [
  null,
  "Virhe"
 ],
 "Error message": [
  null,
  "Virheviesti"
 ],
 "Error occurred while connecting console": [
  null,
  "Virhe konsolia liitettäessä"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Esimerkki: Nimesi <nimesi@esimerkki.fi>"
 ],
 "Example: $0": [
  null,
  "Esimerkki: $0"
 ],
 "Exited": [
  null,
  "Päättyi"
 ],
 "Failed health run": [
  null,
  "Epäonnistunut eheysajo"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Kontin $0 tarkistuspisteen luominen epäonnistui"
 ],
 "Failed to clean up container": [
  null,
  "Kontin poistaminen epäonnistui"
 ],
 "Failed to commit container $0": [
  null,
  "Kontin $0 kommitointi epäonnistui"
 ],
 "Failed to create container $0": [
  null,
  "Kontin $0 luominen epäonnistui"
 ],
 "Failed to download image $0:$1": [
  null,
  "Levykuvan lataaminen epäonnistui $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "Kontin $0 pakotettu poistaminen epäonnistui"
 ],
 "Failed to force remove image $0": [
  null,
  "Levykuvan $0 pakotettu poistaminen epäonnistui"
 ],
 "Failed to force restart pod $0": [
  null,
  "Podin $0 pakotettu uudelleenkäynnistäminen epäonnistui"
 ],
 "Failed to force stop pod $0": [
  null,
  "Podin $0 pakotettu pysäyttäminen epäonnistui"
 ],
 "Failed to pause container $0": [
  null,
  "Kontin $0 keskeyttäminen epäonnistui"
 ],
 "Failed to pause pod $0": [
  null,
  "Podin $0 keskeyttäminen epäonnistui"
 ],
 "Failed to prune unused images": [
  null,
  "Käyttämättömien levykuvien karsiminen epäonnistui"
 ],
 "Failed to pull image $0": [
  null,
  "Levykuvan $0 hakeminen epäonnistui"
 ],
 "Failed to remove container $0": [
  null,
  "Kontin $0 poistaminen epäonnistui"
 ],
 "Failed to remove image $0": [
  null,
  "Levykuvan $0 poistaminen epäonnistui"
 ],
 "Failed to rename container $0": [
  null,
  "Kontin $0 uudelleennimeäminen epäonnistui"
 ],
 "Failed to restart container $0": [
  null,
  "Kontin $0 uudelleenkäynnistäminen epäonnistui"
 ],
 "Failed to restart pod $0": [
  null,
  "Podin $0 uudelleenkäynnistäminen epäonnistui"
 ],
 "Failed to restore container $0": [
  null,
  "Kontin $0 palauttaminen epäonnistui"
 ],
 "Failed to resume container $0": [
  null,
  "Kontin $0 palauttaminen epäonnistui"
 ],
 "Failed to resume pod $0": [
  null,
  "Podin $0 käytön jatkaminen epäonnistui"
 ],
 "Failed to run container $0": [
  null,
  "Kontin $0 suorittaminen epäonnistui"
 ],
 "Failed to run health check on container $0": [
  null,
  "Kontin $0 eheystarkastus epäonnistui"
 ],
 "Failed to search for images.": [
  null,
  "Levykuvien etsintä epäonnistui."
 ],
 "Failed to search for images: $0": [
  null,
  "Levykuvien etsintä epäonnistui: $0"
 ],
 "Failed to search for new images": [
  null,
  "Uusien levykuvien etsintä epäonnistui"
 ],
 "Failed to start container $0": [
  null,
  "Kontin $0 käynnistäminen epäonnistui"
 ],
 "Failed to start pod $0": [
  null,
  "Podin $0 käynnistäminen epäonnistui"
 ],
 "Failed to stop container $0": [
  null,
  "Kontin $0 pysäyttäminen epäonnistui"
 ],
 "Failed to stop pod $0": [
  null,
  "Podin $0 pysäyttäminen epäonnistui"
 ],
 "Failing streak": [
  null,
  "Epäonnistunut sarja"
 ],
 "Failure action": [
  null,
  "virhetilan toimenpiteet"
 ],
 "Force commit": [
  null,
  "Pakota kommitti"
 ],
 "Force delete": [
  null,
  "Pakota poisto"
 ],
 "Force delete pod $0?": [
  null,
  "Pakota podin $0 poisto?"
 ],
 "Force restart": [
  null,
  "Pakota uudelleenkäynnistys"
 ],
 "Force stop": [
  null,
  "Pakota pysäytys"
 ],
 "GB": [
  null,
  "Gt"
 ],
 "Gateway": [
  null,
  "Yhdyskäytävä"
 ],
 "Health check": [
  null,
  "Eheystarkistus"
 ],
 "Health check interval help": [
  null,
  "Tietoa eheystarkistuksen aikavälistä"
 ],
 "Health check retries help": [
  null,
  "Tietoa eheystarkistuksen uudelleenyrityksistä"
 ],
 "Health check start period help": [
  null,
  "Tietoa eheystarkistuksen aloitusjaksosta"
 ],
 "Health check timeout help": [
  null,
  "Tietoa eheystarkistuksen aikakatkaisusta"
 ],
 "Health failure check action help": [
  null,
  "Tietoa terveystarkistuksen virhetilan toimenpiteistä"
 ],
 "Healthy": [
  null,
  "Ehjä"
 ],
 "Hide images": [
  null,
  "Piilota levykuvat"
 ],
 "Hide intermediate images": [
  null,
  "Piilota välivaiheen levykuvat"
 ],
 "History": [
  null,
  "Historia"
 ],
 "Host path": [
  null,
  "Koneen polku"
 ],
 "Host port": [
  null,
  "Koneen portti"
 ],
 "Host port help": [
  null,
  "Ohjeita koneen portista"
 ],
 "ID": [
  null,
  "TUNNISTE"
 ],
 "IP address": [
  null,
  "IP-osoite"
 ],
 "IP address help": [
  null,
  "Ohjeita IP-osoitteesta"
 ],
 "Ideal for development": [
  null,
  "Ihanteellinen kehittämiseen"
 ],
 "Ideal for running services": [
  null,
  "Ihanteellinen palvelujen suorittamiseen"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Jos isäntäkoneen IP-osoitteeksi on asetettu 0.0.0.0 tai sitä ei ole määritetty lainkaan, portti sidotaan kaikkiin isäntäkoneen IP-osoitteisiin."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Jos isäntäporttia ei ole asetettu, konttiportille määritetään satunnainen isäntäportti."
 ],
 "Ignore IP address if set statically": [
  null,
  "Ohita IP-osoite, jos se on asetettu staattisesti"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ohita MAC-osoite, jos se on asetettu staattisesti"
 ],
 "Image": [
  null,
  "Levykuva"
 ],
 "Image name is not unique": [
  null,
  "Kevykuvan nimi ei ole ainutlaatuinen"
 ],
 "Image name is required": [
  null,
  "Levykuvan nimi vaaditaan"
 ],
 "Image selection help": [
  null,
  "Ohjeita levykuvan valintaan"
 ],
 "Images": [
  null,
  "Levykuvat"
 ],
 "Increase CPU shares": [
  null,
  "Lisää suoritinosuuksia"
 ],
 "Increase interval": [
  null,
  "Suurenna väliä"
 ],
 "Increase maximum retries": [
  null,
  "Lisää uudelleenyritysten enimmäismäärää"
 ],
 "Increase memory": [
  null,
  "Lisää muistia"
 ],
 "Increase retries": [
  null,
  "Lisää uudelleenyrityksiä"
 ],
 "Increase start period": [
  null,
  "Pidennä aloitusjaksoa"
 ],
 "Increase timeout": [
  null,
  "Nosta aikakatkaisua"
 ],
 "Integration": [
  null,
  "Integraatio"
 ],
 "Interval": [
  null,
  "Aikaväli"
 ],
 "Interval how often health check is run.": [
  null,
  "Eheystarkistusten aikaväli."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Virheellisiä merkkejä. Nimi voi sisältää vain kirjaimia, numeroita ja tiettyjä välimerkkejä (_ . -)."
 ],
 "KB": [
  null,
  "Kt"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Säilytä kaikki väliaikaiset tarkistuspistetiedostot"
 ],
 "Key": [
  null,
  "Avain"
 ],
 "Last 5 runs": [
  null,
  "Viimeiset 5 ajoa"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Jätä käyntiin tarkistuspisteen levylle kirjoittamisen jälkeen"
 ],
 "Loading details...": [
  null,
  "Ladataan tietoja..."
 ],
 "Loading logs...": [
  null,
  "Ladataan lokeja..."
 ],
 "Loading...": [
  null,
  "Ladataan..."
 ],
 "Local": [
  null,
  "Paikallinen"
 ],
 "Local images": [
  null,
  "Paikallisia levykuvia"
 ],
 "Logs": [
  null,
  "Lokit"
 ],
 "MAC address": [
  null,
  "MAC-osoite"
 ],
 "MB": [
  null,
  "Mt"
 ],
 "Maximum retries": [
  null,
  "Uudelleenyritysten enimmäismäärä"
 ],
 "Memory": [
  null,
  "Muisti"
 ],
 "Memory limit": [
  null,
  "Muistiraja"
 ],
 "Memory unit": [
  null,
  "Muistiyksikkö"
 ],
 "Mode": [
  null,
  "Tila"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Tälle levykuvalle on useita tunnisteita. Valitse tunnisteelliset levykuvat jotka poistetaan."
 ],
 "Name": [
  null,
  "Nimi"
 ],
 "New container name": [
  null,
  "Kontin uusi nimi"
 ],
 "New image name": [
  null,
  "Uusi levykuvan nimi"
 ],
 "No": [
  null,
  "Ei"
 ],
 "No action": [
  null,
  "Ei toimintoa"
 ],
 "No containers": [
  null,
  "Ei kontteja"
 ],
 "No containers are using this image": [
  null,
  "Yksikään kontti ei käytä tätä levykuvaa"
 ],
 "No containers in this pod": [
  null,
  "Tässä podissa ei ole kontteja"
 ],
 "No containers that match the current filter": [
  null,
  "Ei nykyistä suodatusta vastaavia kontteja"
 ],
 "No environment variables specified": [
  null,
  "Ympäristömuuttujia ei ole määritetty"
 ],
 "No images": [
  null,
  "Ei levykuvia"
 ],
 "No images found": [
  null,
  "Levykuvia ei löytynyt"
 ],
 "No images that match the current filter": [
  null,
  "Ei nykyistä suodatusta vastaavia levykuvia"
 ],
 "No label": [
  null,
  "Ei nimiötä"
 ],
 "No ports exposed": [
  null,
  "Ei paljastettuja portteja"
 ],
 "No results for $0": [
  null,
  "Ei tuloksia hakusanalle $0"
 ],
 "No running containers": [
  null,
  "Ei käynnissä olevia kontteja"
 ],
 "No volumes specified": [
  null,
  "Taltiota ei ole määritelty"
 ],
 "On failure": [
  null,
  "Epäonnistumisesta"
 ],
 "Only running": [
  null,
  "Vain käynnissä olevat"
 ],
 "Options": [
  null,
  "Valinnat"
 ],
 "Owner": [
  null,
  "omistaja"
 ],
 "Owner help": [
  null,
  "Omistajan ohjeet"
 ],
 "Passed health run": [
  null,
  "Onnistunut eheysajo"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Liitä yksi tai useampi rivi avain=arvo-pareja mihin tahansa kenttään joukkotuontia varten"
 ],
 "Pause": [
  null,
  "Keskeytä"
 ],
 "Pause container when creating image": [
  null,
  "Pysäytä kontti levykuvan luomisen ajaksi"
 ],
 "Paused": [
  null,
  "Keskeytetty"
 ],
 "Pod failed to be created": [
  null,
  "Podin luonti epäonnistui"
 ],
 "Pod name": [
  null,
  "Podin nimi"
 ],
 "Podman containers": [
  null,
  "Podman-kontit"
 ],
 "Podman service is not active": [
  null,
  "Podman-palvelu ei ole aktiivinen"
 ],
 "Port mapping": [
  null,
  "Porttiassosiaatio"
 ],
 "Ports": [
  null,
  "Portit"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Portit alle 1024 voidaan kartoittaa"
 ],
 "Private": [
  null,
  "Yksityinen"
 ],
 "Protocol": [
  null,
  "Protokolla"
 ],
 "Prune": [
  null,
  "Karsi"
 ],
 "Prune unused images": [
  null,
  "Karsi käyttämättömät levykuvat"
 ],
 "Pruning images": [
  null,
  "Karsitaan levykuvia"
 ],
 "Pull latest image": [
  null,
  "Hae viimeisin levykuva"
 ],
 "Pulling": [
  null,
  "Haetaan"
 ],
 "Read-only access": [
  null,
  "Vain luku-käyttöoikeus"
 ],
 "Read-write access": [
  null,
  "Luku-kirjoitusoikeus"
 ],
 "Remove item": [
  null,
  "Poista kohde"
 ],
 "Removing": [
  null,
  "Poistetaan"
 ],
 "Rename": [
  null,
  "Nimeä uudelleen"
 ],
 "Rename container $0": [
  null,
  "Nimeä kontti $0 uudelleen"
 ],
 "Resource limits can be set": [
  null,
  "Resurssirajoja voidaan asettaa"
 ],
 "Restart": [
  null,
  "Käynnistä uudelleen"
 ],
 "Restart policy": [
  null,
  "Uudelleenkäynnistyksen käytäntö"
 ],
 "Restart policy help": [
  null,
  "Ohjeita uudelleenkäynnistyksen käytännöstä"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Noudata uudelleenkäynnistyskäytäntöä, kun kontit poistuvat."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Käytettävä uudelleenkäynnistyskäytäntö, kun kontit poistuvat. Viivyttämisen käyttäminen konttien automaattiseen käynnistykseen ei välttämättä toimi joissain olosuhteissa, kuten kun käyttäjätilillä on käytössä ecryptfs, systemd-homed, NFS tai 2FA."
 ],
 "Restore": [
  null,
  "Palauta"
 ],
 "Restore container $0": [
  null,
  "Palauta kontti $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Palauta käyttäen luotuja TCP-yhteyksiä"
 ],
 "Restricted by user account permissions": [
  null,
  "Rajoitettu käyttäjätilin käyttöoikeuksilla"
 ],
 "Resume": [
  null,
  "Jatka"
 ],
 "Retries": [
  null,
  "Uudelleenyritykset"
 ],
 "Retry another term.": [
  null,
  "Yritä toisella termillä uudelleen."
 ],
 "Run health check": [
  null,
  "Aja eheystarkistus"
 ],
 "Running": [
  null,
  "Käynnissä"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Hae nimen tai kuvauksen perusteella"
 ],
 "Search by registry": [
  null,
  "Haku rekisterin perusteella"
 ],
 "Search for": [
  null,
  "Etsittävä"
 ],
 "Search for an image": [
  null,
  "Etsi levykuvaa"
 ],
 "Search string or container location": [
  null,
  "Hae merkkijonon tai kontin sijaintia"
 ],
 "Searching...": [
  null,
  "Etsitään..."
 ],
 "Searching: $0": [
  null,
  "Etsitään: $0"
 ],
 "Shared": [
  null,
  "Jaettu"
 ],
 "Show": [
  null,
  "Näytä"
 ],
 "Show images": [
  null,
  "Näytä levykuvat"
 ],
 "Show intermediate images": [
  null,
  "Näytä välivaiheen levykuvat"
 ],
 "Show less": [
  null,
  "Näytä vähemmän"
 ],
 "Show more": [
  null,
  "Näytä lisää"
 ],
 "Size": [
  null,
  "Koko"
 ],
 "Start": [
  null,
  "Käynnistä"
 ],
 "Start period": [
  null,
  "Aloitusjakso"
 ],
 "Start podman": [
  null,
  "Käynnistä podman"
 ],
 "Start typing to look for images.": [
  null,
  "Aloita kirjoittaminen etsiäksesi levykuvia."
 ],
 "Started at": [
  null,
  "Käynnistetty klo"
 ],
 "State": [
  null,
  "Tila"
 ],
 "Status": [
  null,
  "Tila"
 ],
 "Stop": [
  null,
  "Pysäytä"
 ],
 "Stopped": [
  null,
  "Pysäytetty"
 ],
 "Support preserving established TCP connections": [
  null,
  "Tue jo luotujen TCP -yhteyksien säilyttämistä"
 ],
 "System": [
  null,
  "Järjestelmä"
 ],
 "System Podman service is also available": [
  null,
  "Järjestelmän Podman-palvelu on myös saatavilla"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Tunniste"
 ],
 "Tags": [
  null,
  "Tunnisteet"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Alustusaika, joka tarvitaan kontin käynnistymiseen."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Enimmäisaika, joka on sallittu eheystarkastuksen suorittamiseen ennen kuin se katsotaan epäonnistuneeksi."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Yritysten enimmäismäärä, joka on sallittu eheystarkastuksen suorittamiseen ennen kuin se katsotaan epäonnistuneeksi."
 ],
 "Timeout": [
  null,
  "Aikakatkaisu"
 ],
 "Troubleshoot": [
  null,
  "Vianetsintä"
 ],
 "Type to filter…": [
  null,
  "Kirjoita suodattaaksesi…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Levykuvan historian lataaminen epäonnistui"
 ],
 "Unhealthy": [
  null,
  "Rikki"
 ],
 "Up since $0": [
  null,
  "Käynnissä $0 lähtien"
 ],
 "Use legacy Docker format": [
  null,
  "Käytä vanhaa Docker-muotoa"
 ],
 "Used by": [
  null,
  "Käyttää"
 ],
 "User": [
  null,
  "Käyttäjä"
 ],
 "User Podman service is also available": [
  null,
  "Käyttäjän Podman-palvelu on myös saatavilla"
 ],
 "User:": [
  null,
  "Käyttäjä:"
 ],
 "Value": [
  null,
  "Arvo"
 ],
 "Volumes": [
  null,
  "Taltiot"
 ],
 "With terminal": [
  null,
  "Päätteen kanssa"
 ],
 "Writable": [
  null,
  "Kirjoitettavissa"
 ],
 "container": [
  null,
  "kontti"
 ],
 "downloading": [
  null,
  "ladataan"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:port]/[user]/container[:tag]"
 ],
 "image": [
  null,
  "levykuva"
 ],
 "in": [
  null,
  "sijainnissa"
 ],
 "n/a": [
  null,
  "ei sovellu"
 ],
 "not available": [
  null,
  "ei käytettävissä"
 ],
 "pod group": [
  null,
  "podiryhmä"
 ],
 "podman": [
  null,
  "podman"
 ],
 "ports": [
  null,
  "portit"
 ],
 "seconds": [
  null,
  "sekuntia"
 ],
 "select all": [
  null,
  "valitse kaikki"
 ],
 "system": [
  null,
  "järjestelmä"
 ],
 "unused": [
  null,
  "ei käytössä"
 ],
 "user:": [
  null,
  "käyttäjä:"
 ],
 "volumes": [
  null,
  "taltiot"
 ]
});
