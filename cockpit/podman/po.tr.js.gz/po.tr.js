cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 kapsayıcı",
  "$0 kapsayıcı"
 ],
 "$0 image total, $1": [
  null,
  "$0 kalıp toplam, $1",
  "$0 kalıp toplam, $1"
 ],
 "$0 second": [
  null,
  "$0 saniye",
  "$0 saniye"
 ],
 "$0 unused image, $1": [
  null,
  "$0 kullanılmayan kalıp, $1",
  "$0 kullanılmayan kalıp, $1"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Kapsayıcı sağlıksız bir duruma geçtikten sonra gerçekleştirilecek eylem."
 ],
 "Add port mapping": [
  null,
  "Bağlantı noktası eşlemesi ekle"
 ],
 "Add variable": [
  null,
  "Değişken ekle"
 ],
 "Add volume": [
  null,
  "Birim ekle"
 ],
 "All": [
  null,
  "Tümü"
 ],
 "All registries": [
  null,
  "Tüm kayıtlar"
 ],
 "Always": [
  null,
  "Her zaman"
 ],
 "An error occurred": [
  null,
  "Bir hata meydana geldi"
 ],
 "Author": [
  null,
  "Hazırlayan"
 ],
 "Automatically start podman on boot": [
  null,
  "Podman'ı önyüklemede otomatik olarak başlat"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "CPU Paylaşımları yardımı"
 ],
 "CPU shares": [
  null,
  "CPU paylaşımları"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU paylaşımları, kapsayıcıları çalıştırmanın önceliğini belirler. Varsayılan öncelik 1024'dür. Daha yüksek bir sayı bu kapsayıcıya öncelik verir. Daha düşük bir sayı önceliği azaltır."
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Checking health": [
  null,
  "Sağlık denetleniyor"
 ],
 "Checkpoint": [
  null,
  "Denetim noktası"
 ],
 "Checkpoint and restore support": [
  null,
  "Denetim noktası ve geri yükleme desteği"
 ],
 "Checkpoint container $0": [
  null,
  "$0 kapsayıcısı denetim noktası"
 ],
 "Click to see published ports": [
  null,
  "Yayınlanan bağlantı noktalarını görmek için tıklayın"
 ],
 "Click to see volumes": [
  null,
  "Birimleri görmek için tıklayın"
 ],
 "Command": [
  null,
  "Komut"
 ],
 "Comments": [
  null,
  "Açıklamalar"
 ],
 "Commit": [
  null,
  "İşle"
 ],
 "Commit container": [
  null,
  "Kapsayıcı işle"
 ],
 "Configured": [
  null,
  "Yapılandırıldı"
 ],
 "Console": [
  null,
  "Konsol"
 ],
 "Container": [
  null,
  "Kapsayıcı"
 ],
 "Container failed to be created": [
  null,
  "Kapsayıcının oluşturulması başarısız oldu"
 ],
 "Container failed to be started": [
  null,
  "Kapsayıcının başlatılması başarısız oldu"
 ],
 "Container is not running": [
  null,
  "Kapsayıcı çalışmıyor"
 ],
 "Container name": [
  null,
  "Kapsayıcı adı"
 ],
 "Container name is required.": [
  null,
  "Kapsayıcı adı gerekli."
 ],
 "Container path": [
  null,
  "Kapsayıcı yolu"
 ],
 "Container port": [
  null,
  "Kapsayıcı bağlantı noktası"
 ],
 "Containers": [
  null,
  "Kapsayıcılar"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "$0 kapsayıcısının şu anki durumuna göre yeni bir kalıp oluşturun."
 ],
 "Create and run": [
  null,
  "Oluştur ve çalıştır"
 ],
 "Create container": [
  null,
  "Kapsayıcı oluştur"
 ],
 "Create container in $0": [
  null,
  "$0 içinde kapsayıcı oluştur"
 ],
 "Create container in pod": [
  null,
  "Bölme içinde kapsayıcı oluştur"
 ],
 "Create pod": [
  null,
  "Bölme oluştur"
 ],
 "Created": [
  null,
  "Oluşturuldu"
 ],
 "Created by": [
  null,
  "Oluşturan"
 ],
 "Decrease CPU shares": [
  null,
  "CPU paylaşımlarını azalt"
 ],
 "Decrease interval": [
  null,
  "Aralığı azalt"
 ],
 "Decrease maximum retries": [
  null,
  "En fazla yeniden denemeyi azalt"
 ],
 "Decrease memory": [
  null,
  "Belleği azalt"
 ],
 "Decrease retries": [
  null,
  "Yeniden denemeleri azalt"
 ],
 "Decrease start period": [
  null,
  "Başlangıç süresini azalt"
 ],
 "Decrease timeout": [
  null,
  "Zaman aşımını azalt"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Delete $0": [
  null,
  "$0 sil"
 ],
 "Delete $0?": [
  null,
  "$0 silinsin mi?"
 ],
 "Delete pod $0?": [
  null,
  "$0 bölmesi silinsin mi?"
 ],
 "Delete tagged images": [
  null,
  "Etiketli kalıpları sil"
 ],
 "Delete unused system images:": [
  null,
  "Kullanılmayan sistem kalıplarını sil:"
 ],
 "Delete unused user images:": [
  null,
  "Kullanılmayan kullanıcı kalıplarını sil:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Bir kapsayıcıyı silmek içindeki tüm verileri silecek."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Çalışan bir kapsayıcıyı silmek içindeki tüm verileri silecek."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Bu bölmeyi silmek aşağıdaki kapsayıcıları kaldıracak:"
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Disk space": [
  null,
  "Disk alanı"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker biçimi, kalıbı Docker veya Moby Engine ile paylaşırken kullanışlıdır"
 ],
 "Download": [
  null,
  "İndir"
 ],
 "Download new image": [
  null,
  "Yeni kalıbı indir"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Boş bölme $0 kalıcı olarak kaldırılacaktır."
 ],
 "Entrypoint": [
  null,
  "Giriş noktası"
 ],
 "Environment variables": [
  null,
  "Ortam değişkenleri"
 ],
 "Error": [
  null,
  "Hata"
 ],
 "Error message": [
  null,
  "Hata iletisi"
 ],
 "Error occurred while connecting console": [
  null,
  "Konsola bağlanırken hata meydana geldi"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Örnek, Adınız <adiniz@ornek.com>"
 ],
 "Example: $0": [
  null,
  "Örnek: $0"
 ],
 "Exited": [
  null,
  "Çıkıldı"
 ],
 "Failed health run": [
  null,
  "Sağlık işlemini çalıştırma başarısız oldu"
 ],
 "Failed to checkpoint container $0": [
  null,
  "$0 kapsayıcısını denetleme noktası başarısız oldu"
 ],
 "Failed to clean up container": [
  null,
  "Kapsayıcıyı temizleme başarısız oldu"
 ],
 "Failed to commit container $0": [
  null,
  "$0 kapsayıcısını işleme başarısız oldu"
 ],
 "Failed to create container $0": [
  null,
  "$0 kapsayıcısını geri yükleme başarısız oldu"
 ],
 "Failed to download image $0:$1": [
  null,
  "$0:$1 kalıbını indirme başarısız oldu"
 ],
 "Failed to force remove container $0": [
  null,
  "$0 kapsayıcısını zorla kaldırma başarısız oldu"
 ],
 "Failed to force remove image $0": [
  null,
  "$0 kalıbını zorla kaldırma başarısız oldu"
 ],
 "Failed to force restart pod $0": [
  null,
  "$0 bölmesini yeniden başlatmaya zorlama başarısız oldu"
 ],
 "Failed to force stop pod $0": [
  null,
  "$0 bölmesini zorla durdurma başarısız oldu"
 ],
 "Failed to pause container $0": [
  null,
  "$0 kapsayıcısını duraklatma başarısız oldu"
 ],
 "Failed to pause pod $0": [
  null,
  "$0 bölmesini duraklatma başarısız oldu"
 ],
 "Failed to prune unused images": [
  null,
  "Kullanılmayan kalıpları ayıklama başarısız oldu"
 ],
 "Failed to pull image $0": [
  null,
  "$0 kalıbını çekme başarısız oldu"
 ],
 "Failed to remove container $0": [
  null,
  "$0 kapsayıcısını kaldırma başarısız oldu"
 ],
 "Failed to remove image $0": [
  null,
  "$0 kalıbını kaldırma başarısız oldu"
 ],
 "Failed to rename container $0": [
  null,
  "$0 kapsayıcısını yeniden adlandırma başarısız oldu"
 ],
 "Failed to restart container $0": [
  null,
  "$0 kapsayıcısını yeniden başlatma başarısız oldu"
 ],
 "Failed to restart pod $0": [
  null,
  "$0 bölmesini yeniden başlatma başarısız oldu"
 ],
 "Failed to restore container $0": [
  null,
  "$0 kapsayıcısını geri yükleme başarısız oldu"
 ],
 "Failed to resume container $0": [
  null,
  "$0 kapsayıcısını sürdürme başarısız oldu"
 ],
 "Failed to resume pod $0": [
  null,
  "$0 bölmesini sürdürme başarısız oldu"
 ],
 "Failed to run container $0": [
  null,
  "$0 kapsayıcısını çalıştırma başarısız oldu"
 ],
 "Failed to run health check on container $0": [
  null,
  "$0 kapsayıcısında sağlık denetimi çalıştırma başarısız oldu"
 ],
 "Failed to search for images.": [
  null,
  "Kalıpları arama başarısız oldu."
 ],
 "Failed to search for images: $0": [
  null,
  "Kalıpları arama başarısız oldu: $0"
 ],
 "Failed to search for new images": [
  null,
  "Yeni kalıpları arama başarısız oldu"
 ],
 "Failed to start container $0": [
  null,
  "$0 kapsayıcısını başlatma başarısız oldu"
 ],
 "Failed to start pod $0": [
  null,
  "$0 bölmesini başlatma başarısız oldu"
 ],
 "Failed to stop container $0": [
  null,
  "$0 kapsayıcısını durdurma başarısız oldu"
 ],
 "Failed to stop pod $0": [
  null,
  "$0 bölmesini durdurma başarısız oldu"
 ],
 "Failing streak": [
  null,
  "Başarısız olan seri"
 ],
 "Failure action": [
  null,
  "Başarısız eylem"
 ],
 "Force commit": [
  null,
  "İşlemeye zorla"
 ],
 "Force delete": [
  null,
  "Silmeye zorla"
 ],
 "Force delete pod $0?": [
  null,
  "$0 bölmesi silmeye zorlansın mı?"
 ],
 "Force restart": [
  null,
  "Yeniden başlatmaya zorla"
 ],
 "Force stop": [
  null,
  "Durdurmaya zorla"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "Ağ geçidi"
 ],
 "Health check": [
  null,
  "Sağlık denetimi"
 ],
 "Health check interval help": [
  null,
  "Sağlık denetimi aralığı yardımı"
 ],
 "Health check retries help": [
  null,
  "Sağlık denetimi yeniden denemeleri yardımı"
 ],
 "Health check start period help": [
  null,
  "Sağlık denetimi başlangıç dönemi yardımı"
 ],
 "Health check timeout help": [
  null,
  "Sağlık denetimi zaman aşımı yardımı"
 ],
 "Health failure check action help": [
  null,
  "Sağlık denetimi hatası eylem yardımı"
 ],
 "Healthy": [
  null,
  "Sağlıklı"
 ],
 "Hide images": [
  null,
  "Kalıpları gizle"
 ],
 "Hide intermediate images": [
  null,
  "Ara kalıpları gizle"
 ],
 "History": [
  null,
  "Geçmiş"
 ],
 "Host path": [
  null,
  "Anamakine yolu"
 ],
 "Host port": [
  null,
  "Anamakine bağlantı noktası"
 ],
 "Host port help": [
  null,
  "Anamakine b.noktası yardım"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "IP address": [
  null,
  "IP adresi"
 ],
 "IP address help": [
  null,
  "IP adresi yardım"
 ],
 "Ideal for development": [
  null,
  "Geliştirme için ideal"
 ],
 "Ideal for running services": [
  null,
  "Çalışan hizmetler için ideal"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Eğer anamakine IP'si 0.0.0.0 olarak ayarlanırsa veya hiç ayarlanmazsa, bağlantı noktası anamakinedeki tüm IP'lere bağlanır."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Eğer anamakine bağlantı noktası ayarlanmazsa, kapsayıcı bağlantı noktası anamakinede rastgele bir bağlantı noktasına atanacaktır."
 ],
 "Ignore IP address if set statically": [
  null,
  "Sabit olarak ayarlanmışsa IP adresini yoksay"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Sabit olarak ayarlanmışsa MAC adresini yoksay"
 ],
 "Image": [
  null,
  "Kalıp"
 ],
 "Image name is not unique": [
  null,
  "Kalıp adı benzersiz değil"
 ],
 "Image name is required": [
  null,
  "Kalıp adı gerekli"
 ],
 "Image selection help": [
  null,
  "Kalıp seçim yardımı"
 ],
 "Images": [
  null,
  "Kalıplar"
 ],
 "Increase CPU shares": [
  null,
  "CPU paylaşımlarını artır"
 ],
 "Increase interval": [
  null,
  "Aralığı artır"
 ],
 "Increase maximum retries": [
  null,
  "En fazla yeniden denemeyi artır"
 ],
 "Increase memory": [
  null,
  "Zaman aşımını artır"
 ],
 "Increase retries": [
  null,
  "Yeniden denemeleri artır"
 ],
 "Increase start period": [
  null,
  "Başlangıç süresini artır"
 ],
 "Increase timeout": [
  null,
  "Zaman aşımını artır"
 ],
 "Integration": [
  null,
  "Bütünleştirme"
 ],
 "Interval": [
  null,
  "Aralık"
 ],
 "Interval how often health check is run.": [
  null,
  "Sağlık denetiminin ne sıklıkta çalıştırıldığı aralığı."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Geçersiz karakterler. Ad sadece harf, sayı ve belirli noktalama işaretlerini (_ . -) içerebilir."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Tüm geçici denetim noktası dosyalarını sakla"
 ],
 "Key": [
  null,
  "Anahtar"
 ],
 "Last 5 runs": [
  null,
  "Son 5 çalıştırma"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Denetim noktasını diske yazdıktan sonra çalışır durumda bırak"
 ],
 "Loading details...": [
  null,
  "Ayrıntılar yükleniyor..."
 ],
 "Loading logs...": [
  null,
  "Günlükler yükleniyor..."
 ],
 "Loading...": [
  null,
  "Yükleniyor..."
 ],
 "Local": [
  null,
  "Yerel"
 ],
 "Local images": [
  null,
  "Yerel kalıplar"
 ],
 "Logs": [
  null,
  "Günlükler"
 ],
 "MAC address": [
  null,
  "MAC adresi"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "En fazla yeniden deneme"
 ],
 "Memory": [
  null,
  "Bellek"
 ],
 "Memory limit": [
  null,
  "Bellek sınırı"
 ],
 "Memory unit": [
  null,
  "Bellek birimi"
 ],
 "Mode": [
  null,
  "Mod"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Bu kalıp için birden fazla etiket var. Silinecek etiketlenmiş kalıpları seçin."
 ],
 "Name": [
  null,
  "Ad"
 ],
 "New container name": [
  null,
  "Yeni kapsayıcı adı"
 ],
 "New image name": [
  null,
  "Yeni kalıp adı"
 ],
 "No": [
  null,
  "Hayır"
 ],
 "No action": [
  null,
  "Eylem yok"
 ],
 "No containers": [
  null,
  "Kapsayıcılar yok"
 ],
 "No containers are using this image": [
  null,
  "Bu kalıbı hiçbir kapsayıcı kullanmıyor"
 ],
 "No containers in this pod": [
  null,
  "Bu bölmede kapsayıcılar yok"
 ],
 "No containers that match the current filter": [
  null,
  "Şu anki süzgeçle eşleşen kapsayıcılar yok"
 ],
 "No environment variables specified": [
  null,
  "Belirtilen ortam değişkenleri yok"
 ],
 "No images": [
  null,
  "Kalıplar yok"
 ],
 "No images found": [
  null,
  "Bulunan kalıplar yok"
 ],
 "No images that match the current filter": [
  null,
  "Şu anki süzgeçle eşleşen kalıplar yok"
 ],
 "No label": [
  null,
  "Etiket yok"
 ],
 "No ports exposed": [
  null,
  "Açığa çıkan bağlantı noktaları yok"
 ],
 "No results for $0": [
  null,
  "$0 için sonuçlar yok"
 ],
 "No running containers": [
  null,
  "Çalışan kapsayıcılar yok"
 ],
 "No volumes specified": [
  null,
  "Belirtilen birimler yok"
 ],
 "On failure": [
  null,
  "Başarısızlıkla"
 ],
 "Only running": [
  null,
  "Sadece çalışanlar"
 ],
 "Options": [
  null,
  "Seçenekler"
 ],
 "Owner": [
  null,
  "Sahibi"
 ],
 "Owner help": [
  null,
  "Sahibi yardımı"
 ],
 "Passed health run": [
  null,
  "Sağlık çalıştırması geçti"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Toplu içe aktarma için herhangi bir alana bir veya daha fazla anahtar=değer çifti satırı yapıştırın"
 ],
 "Pause": [
  null,
  "Duraklat"
 ],
 "Pause container when creating image": [
  null,
  "Kalıp oluştururken kapsayıcıyı duraklatın"
 ],
 "Paused": [
  null,
  "Duraklatıldı"
 ],
 "Pod failed to be created": [
  null,
  "Bölmenin oluşturulması başarısız oldu"
 ],
 "Pod name": [
  null,
  "Bölme adı"
 ],
 "Podman containers": [
  null,
  "Podman kapsayıcıları"
 ],
 "Podman service is not active": [
  null,
  "Podman hizmeti etkin değil"
 ],
 "Port mapping": [
  null,
  "Bağlantı noktası eşleme"
 ],
 "Ports": [
  null,
  "Bağlantı noktaları"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "1024 altındaki bağlantı noktaları eşlenebilir"
 ],
 "Private": [
  null,
  "Özel"
 ],
 "Protocol": [
  null,
  "Protokol"
 ],
 "Prune": [
  null,
  "Ayıkla"
 ],
 "Prune unused images": [
  null,
  "Kullanılmayan kalıpları ayıkla"
 ],
 "Pruning images": [
  null,
  "Kalıplar ayıklanıyor"
 ],
 "Pull latest image": [
  null,
  "Son kalıbı çek"
 ],
 "Pulling": [
  null,
  "Çekiliyor"
 ],
 "Read-only access": [
  null,
  "Salt-okunur erişim"
 ],
 "Read-write access": [
  null,
  "Okuma-yazma erişimi"
 ],
 "Remove item": [
  null,
  "Öğeyi kaldır"
 ],
 "Removing": [
  null,
  "Kaldırılıyor"
 ],
 "Rename": [
  null,
  "Yeniden adlandır"
 ],
 "Rename container $0": [
  null,
  "$0 kapsayıcısını yeniden adlandır"
 ],
 "Resource limits can be set": [
  null,
  "Kaynak sınırları ayarlanabilir"
 ],
 "Restart": [
  null,
  "Yeniden başlat"
 ],
 "Restart policy": [
  null,
  "Yeniden başlatma ilkesi"
 ],
 "Restart policy help": [
  null,
  "Yeniden başlatma ilkesi yardımı"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Kapsayıcılardan çıkıldığında izlenecek ilkeyi yeniden başlatın."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Kapsayıcılar çıktığında izlenecek ilkeyi yeniden başlatın. Otomatik başlatma kapsayıcıları için geciktirme kullanılması, bir kullanıcı hesabında ecryptfs, systemd-homed, NFS veya 2FA kullanıldığında olduğu gibi bazı durumlarda çalışmayabilir."
 ],
 "Restore": [
  null,
  "Geri yükle"
 ],
 "Restore container $0": [
  null,
  "$0 kapsayıcısını geri yükle"
 ],
 "Restore with established TCP connections": [
  null,
  "Kurulu TCP bağlantıları ile geri yükle"
 ],
 "Restricted by user account permissions": [
  null,
  "Kullanıcı hesabı izinleri tarafından kısıtlanmış"
 ],
 "Resume": [
  null,
  "Sürdür"
 ],
 "Retries": [
  null,
  "Yeniden denemeler"
 ],
 "Retry another term.": [
  null,
  "Başka bir terimi yeniden deneyin."
 ],
 "Run health check": [
  null,
  "Sağlık denetimini çalıştır"
 ],
 "Running": [
  null,
  "Çalışıyor"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Ada veya açıklamaya göre ara"
 ],
 "Search by registry": [
  null,
  "Kayıt defterine göre ara"
 ],
 "Search for": [
  null,
  "Ara"
 ],
 "Search for an image": [
  null,
  "Kalıp ara"
 ],
 "Search string or container location": [
  null,
  "Arama dizgisi veya kapsayıcı konumu"
 ],
 "Searching...": [
  null,
  "Aranıyor..."
 ],
 "Searching: $0": [
  null,
  "Aranan: $0"
 ],
 "Shared": [
  null,
  "Paylaşılan"
 ],
 "Show": [
  null,
  "Göster"
 ],
 "Show images": [
  null,
  "Kalıpları göster"
 ],
 "Show intermediate images": [
  null,
  "Ara kalıpları göster"
 ],
 "Show less": [
  null,
  "Daha az göster"
 ],
 "Show more": [
  null,
  "Daha fazlasını göster"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "Start": [
  null,
  "Başlat"
 ],
 "Start period": [
  null,
  "Başlangıç süresi"
 ],
 "Start podman": [
  null,
  "Podman'ı başlat"
 ],
 "Start typing to look for images.": [
  null,
  "Kalıpları aramak için yazmaya başlayın."
 ],
 "Started at": [
  null,
  "Başlama zamanı"
 ],
 "State": [
  null,
  "Durum"
 ],
 "Status": [
  null,
  "Durum"
 ],
 "Stop": [
  null,
  "Durdur"
 ],
 "Stopped": [
  null,
  "Durduruldu"
 ],
 "Support preserving established TCP connections": [
  null,
  "Kurulu TCP bağlantılarını korumayı destekle"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "System Podman service is also available": [
  null,
  "Sistem Podman hizmeti de kullanılabilir"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Etiket"
 ],
 "Tags": [
  null,
  "Etiketler"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Bir kapsayıcının önyükleme yapması için gereken başlatma süresi."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Bir aralığın başarısız olduğu kabul edilmeden önce sağlık denetimini tamamlanması için izin verilen en fazla süre."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Bir sağlık denetiminden önce izin verilen yeniden deneme sayısı sağlıksız olarak kabul edilir."
 ],
 "Timeout": [
  null,
  "Zaman aşımı"
 ],
 "Troubleshoot": [
  null,
  "Sorun Giderme"
 ],
 "Type to filter…": [
  null,
  "Süzmek için yazın…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Kalıp geçmişini yükleme başarısız oldu"
 ],
 "Unhealthy": [
  null,
  "Sağlıksız"
 ],
 "Up since $0": [
  null,
  "$0'dan beri aktif"
 ],
 "Use legacy Docker format": [
  null,
  "Eski Docker biçimini kullan"
 ],
 "Used by": [
  null,
  "Kullanan"
 ],
 "User": [
  null,
  "Kullanıcı"
 ],
 "User Podman service is also available": [
  null,
  "Kullanıcı Podman hizmeti de kullanılabilir"
 ],
 "User:": [
  null,
  "Kullanıcı:"
 ],
 "Value": [
  null,
  "Değer"
 ],
 "Volumes": [
  null,
  "Birimler"
 ],
 "With terminal": [
  null,
  "Terminal ile"
 ],
 "Writable": [
  null,
  "Yazılabilir"
 ],
 "container": [
  null,
  "kapsayıcı"
 ],
 "downloading": [
  null,
  "indiriliyor"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "anamakine[:b.noktası]/[kullanıcı]/kapsayıcı[:etiket]"
 ],
 "image": [
  null,
  "kalıp"
 ],
 "in": [
  null,
  "şurada"
 ],
 "n/a": [
  null,
  "yok"
 ],
 "not available": [
  null,
  "kullanılabilir değil"
 ],
 "pod group": [
  null,
  "bölme grubu"
 ],
 "podman": [
  null,
  "podman"
 ],
 "ports": [
  null,
  "bağlantı noktaları"
 ],
 "seconds": [
  null,
  "saniye"
 ],
 "select all": [
  null,
  "tümünü seç"
 ],
 "system": [
  null,
  "sistem"
 ],
 "unused": [
  null,
  "kullanılmayan"
 ],
 "user:": [
  null,
  "kullanıcı:"
 ],
 "volumes": [
  null,
  "birimler"
 ]
});
