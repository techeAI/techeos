cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ja",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 コンテナー"
 ],
 "$0 image total, $1": [
  null,
  "$0 イメージ合計、$1"
 ],
 "$0 second": [
  null,
  "$0 2 番目"
 ],
 "$0 unused image, $1": [
  null,
  "$0 の未使用イメージ、$1"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  ""
 ],
 "Add port mapping": [
  null,
  "ポートマッピングの追加"
 ],
 "Add variable": [
  null,
  "変数の追加"
 ],
 "Add volume": [
  null,
  "ボリュームの追加"
 ],
 "All": [
  null,
  "すべて"
 ],
 "All registries": [
  null,
  "すべてのレジストリー"
 ],
 "Always": [
  null,
  "常時"
 ],
 "An error occurred": [
  null,
  "エラーが発生しました"
 ],
 "Author": [
  null,
  "作成者"
 ],
 "Automatically start podman on boot": [
  null,
  "起動時に podman を自動的に起動する"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "CPU share のヘルプ"
 ],
 "CPU shares": [
  null,
  "CPU 共有"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU 共有は実行中のコンテナーの優先度を決定します。デフォルトの優先度は 1024 です。数値が高いほど、このコンテナーの優先度が高くなります。数値が低いほど優先度が低くなります。"
 ],
 "Cancel": [
  null,
  "取り消し"
 ],
 "Checking health": [
  null,
  "ヘルスチェック"
 ],
 "Checkpoint": [
  null,
  "チェックポイント"
 ],
 "Checkpoint container $0": [
  null,
  "チェックポイントコンテナー $0"
 ],
 "Click to see published ports": [
  null,
  "クリックして公開されたポートを表示します"
 ],
 "Click to see volumes": [
  null,
  "クリックしてボリュームを表示します"
 ],
 "Command": [
  null,
  "コマンド"
 ],
 "Comments": [
  null,
  "コメント"
 ],
 "Commit": [
  null,
  "コミット"
 ],
 "Commit container": [
  null,
  "コンテナーのコミット"
 ],
 "Configured": [
  null,
  "設定済み"
 ],
 "Console": [
  null,
  "コンソール"
 ],
 "Container": [
  null,
  "コンテナー"
 ],
 "Container failed to be created": [
  null,
  "コンテナーの作成に失敗しました"
 ],
 "Container failed to be started": [
  null,
  "コンテナーの開始に失敗しました"
 ],
 "Container is not running": [
  null,
  "コンテナーが実行されていません"
 ],
 "Container name": [
  null,
  "コンテナー名"
 ],
 "Container name is required.": [
  null,
  "コンテナー名が必要です。"
 ],
 "Container path": [
  null,
  "コンテナーパス"
 ],
 "Container port": [
  null,
  "コンテナーポート"
 ],
 "Containers": [
  null,
  "コンテナー"
 ],
 "Create": [
  null,
  "作成"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "$0 コンテナーの現在の状態に基づいて、新しいイメージを作成します。"
 ],
 "Create and run": [
  null,
  "作成して実行する"
 ],
 "Create container": [
  null,
  "コンテナーの作成"
 ],
 "Create container in $0": [
  null,
  "$0 でのコンテナーの作成"
 ],
 "Create container in pod": [
  null,
  "Pod でのコンテナーの作成"
 ],
 "Create pod": [
  null,
  "Pod の作成"
 ],
 "Created": [
  null,
  "作成済み"
 ],
 "Created by": [
  null,
  "作成元"
 ],
 "Decrease CPU shares": [
  null,
  "CPU 共有を減らす"
 ],
 "Decrease interval": [
  null,
  "間隔を縮小する"
 ],
 "Decrease maximum retries": [
  null,
  "最大再試行回数を減らす"
 ],
 "Decrease memory": [
  null,
  "メモリーを減らす"
 ],
 "Decrease retries": [
  null,
  "再試行回数を減らす"
 ],
 "Decrease start period": [
  null,
  "開始期間を縮小する"
 ],
 "Decrease timeout": [
  null,
  "タイムアウトを縮小する"
 ],
 "Delete": [
  null,
  "削除"
 ],
 "Delete $0": [
  null,
  "$0 の削除"
 ],
 "Delete $0?": [
  null,
  "$0 を削除しますか?"
 ],
 "Delete pod $0?": [
  null,
  "Pod $0 を削除しますか?"
 ],
 "Delete tagged images": [
  null,
  "タグ付けされたイメージの削除"
 ],
 "Delete unused system images:": [
  null,
  "使用されていないシステムイメージの削除:"
 ],
 "Delete unused user images:": [
  null,
  "使用されていないユーザーイメージの削除:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "コンテナーを削除すると、コンテナー内のすべてのデータが削除されます。"
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "実行中のコンテナーを削除すると、その中のすべてのデータが削除されます。"
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "この Pod を削除すると、以下のコンテナーが削除されます:"
 ],
 "Details": [
  null,
  "詳細"
 ],
 "Disk space": [
  null,
  "ディスクの空き容量"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Dockerフォーマットは、イメージをDockerまたはMoby Engineで共有する時に便利です"
 ],
 "Download": [
  null,
  "ダウンロード"
 ],
 "Download new image": [
  null,
  "新規イメージのダウンロード"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "空の Pod $0 は完全に削除されます。"
 ],
 "Entrypoint": [
  null,
  "エントリーポイント"
 ],
 "Environment variables": [
  null,
  "環境変数"
 ],
 "Error": [
  null,
  "エラー"
 ],
 "Error message": [
  null,
  "エラーメッセージ"
 ],
 "Error occurred while connecting console": [
  null,
  "コンソールへの接続中にエラーが発生しました"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "例: 名前 <yourname@example.com>"
 ],
 "Example: $0": [
  null,
  "例: $0"
 ],
 "Exited": [
  null,
  "終了"
 ],
 "Failed health run": [
  null,
  "失敗したヘルスの実行"
 ],
 "Failed to checkpoint container $0": [
  null,
  "コンテナー $0 のチェックポイントに失敗しました"
 ],
 "Failed to clean up container": [
  null,
  "コンテナーのクリーンアップに失敗しました"
 ],
 "Failed to commit container $0": [
  null,
  "コンテナー $0 のコミットに失敗しました"
 ],
 "Failed to create container $0": [
  null,
  "コンテナー $0 の作成に失敗しました"
 ],
 "Failed to download image $0:$1": [
  null,
  "イメージ $0 のダウンロードに失敗しました: $1"
 ],
 "Failed to force remove container $0": [
  null,
  "コンテナー $0 を強制的に削除できませんでした"
 ],
 "Failed to force remove image $0": [
  null,
  "イメージ $0 の強制削除に失敗しました"
 ],
 "Failed to force restart pod $0": [
  null,
  "Pod $0 の強制再起動に失敗しました"
 ],
 "Failed to force stop pod $0": [
  null,
  "Pod $0 の強制停止に失敗しました"
 ],
 "Failed to pause container $0": [
  null,
  "コンテナー $0 の一時停止に失敗しました"
 ],
 "Failed to pause pod $0": [
  null,
  "Pod $0 の一時停止に失敗しました"
 ],
 "Failed to prune unused images": [
  null,
  "使用されていないイメージのpruneに失敗しました"
 ],
 "Failed to pull image $0": [
  null,
  "イメージ $0 のpullに失敗しました"
 ],
 "Failed to remove container $0": [
  null,
  "コンテナー $0 の削除に失敗しました"
 ],
 "Failed to remove image $0": [
  null,
  "イメージ $0 の削除に失敗しました"
 ],
 "Failed to rename container $0": [
  null,
  "コンテナーの名前変更に失敗しました $0"
 ],
 "Failed to restart container $0": [
  null,
  "コンテナー $0 の再起動に失敗しました"
 ],
 "Failed to restart pod $0": [
  null,
  "Pod $0 の再起動に失敗しました"
 ],
 "Failed to restore container $0": [
  null,
  "コンテナー $0 の復元に失敗しました"
 ],
 "Failed to resume container $0": [
  null,
  "コンテナー $0 のレジュームに失敗しました"
 ],
 "Failed to resume pod $0": [
  null,
  "Pod $0 の再開に失敗しました"
 ],
 "Failed to run container $0": [
  null,
  "コンテナー $0 の実行に失敗しました"
 ],
 "Failed to run health check on container $0": [
  null,
  "コンテナーでのヘルスチェックの実行に失敗しました $0"
 ],
 "Failed to search for images.": [
  null,
  "イメージの検索に失敗しました。"
 ],
 "Failed to search for images: $0": [
  null,
  "イメージの検索に失敗しました: $0"
 ],
 "Failed to search for new images": [
  null,
  "新規イメージの検索に失敗しました"
 ],
 "Failed to start container $0": [
  null,
  "コンテナー $0 の起動に失敗しました"
 ],
 "Failed to start pod $0": [
  null,
  "Pod $0 の起動に失敗しました"
 ],
 "Failed to stop container $0": [
  null,
  "コンテナー $0 の停止に失敗しました"
 ],
 "Failed to stop pod $0": [
  null,
  "Pod $0 の停止に失敗しました"
 ],
 "Failing streak": [
  null,
  "失敗の連続"
 ],
 "Failure action": [
  null,
  ""
 ],
 "Force commit": [
  null,
  "強制コミット"
 ],
 "Force delete": [
  null,
  "削除の強制"
 ],
 "Force delete pod $0?": [
  null,
  "Pod $0 を強制的に削除しますか?"
 ],
 "Force restart": [
  null,
  "再起動の強制"
 ],
 "Force stop": [
  null,
  "停止の強制"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "ゲートウェイ"
 ],
 "Health check": [
  null,
  "ヘルスチェック"
 ],
 "Health check interval help": [
  null,
  "ヘルスチェックの間隔のヘルプ"
 ],
 "Health check retries help": [
  null,
  "ヘルスチェックの再試行のヘルプ"
 ],
 "Health check start period help": [
  null,
  "ヘルスチェックの開始期間のヘルプ"
 ],
 "Health check timeout help": [
  null,
  "ヘルスチェックのタイムアウトのヘルプ"
 ],
 "Healthy": [
  null,
  "健全"
 ],
 "Hide images": [
  null,
  "イメージを非表示"
 ],
 "Hide intermediate images": [
  null,
  "中間イメージを非表示"
 ],
 "History": [
  null,
  "履歴"
 ],
 "Host path": [
  null,
  "ホストパス"
 ],
 "Host port": [
  null,
  "ホストポート"
 ],
 "Host port help": [
  null,
  "ホストポートヘルプ"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "IP アドレス"
 ],
 "IP address help": [
  null,
  "IP アドレスヘルプ"
 ],
 "Ideal for development": [
  null,
  ""
 ],
 "Ideal for running services": [
  null,
  ""
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "ホスト IP が 0.0.0.0 に設定されているか、全く設定されていない場合、ポートはホスト上のすべての IP　にバインドされます。"
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "ホストポートが設定されていない場合、コンテナーポートにはホストのポートがランダムに割り当てられます。"
 ],
 "Ignore IP address if set statically": [
  null,
  "静的に設定された場合は IP アドレスを無視"
 ],
 "Ignore MAC address if set statically": [
  null,
  "静的に設定された場合は MAC アドレスを無視"
 ],
 "Image": [
  null,
  "イメージ"
 ],
 "Image name is not unique": [
  null,
  "イメージ名は一意ではありません"
 ],
 "Image name is required": [
  null,
  "イメージ名が必要です"
 ],
 "Image selection help": [
  null,
  "イメージ選択のヘルプ"
 ],
 "Images": [
  null,
  "イメージ"
 ],
 "Increase CPU shares": [
  null,
  "CPU 共有を増やす"
 ],
 "Increase interval": [
  null,
  "間隔を増やす"
 ],
 "Increase maximum retries": [
  null,
  "最大再試行回数を増やす"
 ],
 "Increase memory": [
  null,
  "メモリーを増やす"
 ],
 "Increase retries": [
  null,
  "再試行を増やす"
 ],
 "Increase start period": [
  null,
  "開始期間を拡大する"
 ],
 "Increase timeout": [
  null,
  "タイムアウトを拡大する"
 ],
 "Integration": [
  null,
  "インテグレーション"
 ],
 "Interval": [
  null,
  "間隔"
 ],
 "Interval how often health check is run.": [
  null,
  "ヘルスチェックの実行頻度 (間隔)。"
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "無効な文字です。名前には文字、数字、および特定の句読点 (_ . -) のみを使用できます。"
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "すべての一時的なチェックポイントファイルを維持"
 ],
 "Key": [
  null,
  "キー"
 ],
 "Last 5 runs": [
  null,
  "過去 5 回の実行"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "チェックポイントをディスクに書き込む後もそのまま実行したままにする"
 ],
 "Loading details...": [
  null,
  "詳細をロード中..."
 ],
 "Loading logs...": [
  null,
  "ログをロード中..."
 ],
 "Loading...": [
  null,
  "ロード中..."
 ],
 "Local": [
  null,
  "ローカル"
 ],
 "Local images": [
  null,
  "ローカルのイメージ"
 ],
 "Logs": [
  null,
  "ログ"
 ],
 "MAC address": [
  null,
  "MAC アドレス"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "最大施行数"
 ],
 "Memory": [
  null,
  "メモリ"
 ],
 "Memory limit": [
  null,
  "メモリー制限"
 ],
 "Memory unit": [
  null,
  "メモリーユニット"
 ],
 "Mode": [
  null,
  "モード"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "このイメージには、複数のタグが存在します。削除するタグ付けされたイメージを選択します。"
 ],
 "Name": [
  null,
  "名前"
 ],
 "New container name": [
  null,
  "新しいコンテナー名"
 ],
 "New image name": [
  null,
  "新しいイメージ名"
 ],
 "No": [
  null,
  "いいえ"
 ],
 "No action": [
  null,
  ""
 ],
 "No containers": [
  null,
  "コンテナーなし"
 ],
 "No containers are using this image": [
  null,
  "このイメージを使用するコンテナーはありません"
 ],
 "No containers in this pod": [
  null,
  "この Pod 内のコンテナーはありません"
 ],
 "No containers that match the current filter": [
  null,
  "現在のフィルターに一致するコンテナーがありません"
 ],
 "No environment variables specified": [
  null,
  "環境変数が指定されていません"
 ],
 "No images": [
  null,
  "イメージなし"
 ],
 "No images found": [
  null,
  "イメージが見つかりません"
 ],
 "No images that match the current filter": [
  null,
  "現在のフィルターに一致するイメージがありません"
 ],
 "No label": [
  null,
  "ラベルなし"
 ],
 "No ports exposed": [
  null,
  "開放されているポートはありません"
 ],
 "No results for $0": [
  null,
  "$0 の結果なし"
 ],
 "No running containers": [
  null,
  "実行中のコンテナーはありません"
 ],
 "No volumes specified": [
  null,
  "指定されているボリュームはありません"
 ],
 "On failure": [
  null,
  "障害発生時"
 ],
 "Only running": [
  null,
  "実行のみ"
 ],
 "Options": [
  null,
  "オプション"
 ],
 "Owner": [
  null,
  "所有者"
 ],
 "Passed health run": [
  null,
  "合格したヘルスの実行"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "一括インポートのために、キー=値ペアからなる 1 つまたは複数の行を任意のフィールドに貼り付けます"
 ],
 "Pause": [
  null,
  "一時停止"
 ],
 "Pause container when creating image": [
  null,
  "イメージの作成時にコンテナーを一時停止します"
 ],
 "Paused": [
  null,
  "一時停止"
 ],
 "Pod failed to be created": [
  null,
  "Pod の作成に失敗しました"
 ],
 "Pod name": [
  null,
  "Pod 名"
 ],
 "Podman containers": [
  null,
  "Podman コンテナー"
 ],
 "Podman service is not active": [
  null,
  "Podman サービスがアクティブではありません"
 ],
 "Port mapping": [
  null,
  "ポートマッピング"
 ],
 "Ports": [
  null,
  "ポート"
 ],
 "Ports under 1024 can be mapped": [
  null,
  ""
 ],
 "Private": [
  null,
  "プライベート"
 ],
 "Protocol": [
  null,
  "プロトコル"
 ],
 "Prune": [
  null,
  "削除"
 ],
 "Prune unused images": [
  null,
  "未使用イメージの削除"
 ],
 "Pruning images": [
  null,
  "イメージを削除中"
 ],
 "Pull latest image": [
  null,
  "最新イメージのプル"
 ],
 "Pulling": [
  null,
  "プル中"
 ],
 "Read-only access": [
  null,
  "読み取り専用アクセス"
 ],
 "Read-write access": [
  null,
  "読み書きアクセス"
 ],
 "Remove item": [
  null,
  "アイテムの削除"
 ],
 "Removing": [
  null,
  "削除中"
 ],
 "Rename": [
  null,
  "名前変更"
 ],
 "Rename container $0": [
  null,
  "コンテナーの名前変更 $0"
 ],
 "Resource limits can be set": [
  null,
  ""
 ],
 "Restart": [
  null,
  "再起動"
 ],
 "Restart policy": [
  null,
  "再起動ポリシー"
 ],
 "Restart policy help": [
  null,
  "再起動ポリシーのヘルプ"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "コンテナーの終了時に従う再起動ポリシー。"
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "コンテナーの終了時に従う再起動ポリシー。コンテナーの自動起動に linger を使用すると、ユーザーアカウントで ecryptfs、systemd-homed、NFS、または 2FA が使用されている場合など、一部の状況では機能しない場合があります。"
 ],
 "Restore": [
  null,
  "復元"
 ],
 "Restore container $0": [
  null,
  "コンテナー $0 の復元"
 ],
 "Restore with established TCP connections": [
  null,
  "確立された TCP 接続での復元"
 ],
 "Restricted by user account permissions": [
  null,
  ""
 ],
 "Resume": [
  null,
  "再開"
 ],
 "Retries": [
  null,
  "再試行回数"
 ],
 "Retry another term.": [
  null,
  "別の用語を再試行します。"
 ],
 "Run health check": [
  null,
  "ヘルスチェックを実行する"
 ],
 "Running": [
  null,
  "実行中"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "名前または説明による検索"
 ],
 "Search by registry": [
  null,
  "レジストリーで検索"
 ],
 "Search for": [
  null,
  "検索"
 ],
 "Search for an image": [
  null,
  "イメージの検索"
 ],
 "Search string or container location": [
  null,
  "検索文字列またはコンテナーのロケーション"
 ],
 "Searching...": [
  null,
  "検索中..."
 ],
 "Searching: $0": [
  null,
  "検索中: $0"
 ],
 "Shared": [
  null,
  "共有"
 ],
 "Show": [
  null,
  "表示"
 ],
 "Show images": [
  null,
  "イメージの表示"
 ],
 "Show intermediate images": [
  null,
  "中間イメージの表示"
 ],
 "Show less": [
  null,
  "簡易表示"
 ],
 "Show more": [
  null,
  "詳細表示"
 ],
 "Size": [
  null,
  "サイズ"
 ],
 "Start": [
  null,
  "開始"
 ],
 "Start period": [
  null,
  "開始期間"
 ],
 "Start podman": [
  null,
  "Podman を起動"
 ],
 "Start typing to look for images.": [
  null,
  "イメージを検索するために入力を開始します。"
 ],
 "Started at": [
  null,
  "開始日時"
 ],
 "State": [
  null,
  "状態"
 ],
 "Status": [
  null,
  "ステータス"
 ],
 "Stop": [
  null,
  "停止"
 ],
 "Stopped": [
  null,
  "停止中"
 ],
 "Support preserving established TCP connections": [
  null,
  "確立された TCP 接続の保持サポート"
 ],
 "System": [
  null,
  "システム"
 ],
 "System Podman service is also available": [
  null,
  "システム Podman サービスも利用できます"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "タグ"
 ],
 "Tags": [
  null,
  "タグ"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "コンテナーのブートストラップに必要な初期化時間。"
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "間隔が失敗したとみなされる前に、ヘルスチェックを完了するために許容される最大時間。"
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "ヘルスチェックが異常であると見なされるまでに許可される再試行の回数。"
 ],
 "Timeout": [
  null,
  "タイムアウト"
 ],
 "Troubleshoot": [
  null,
  "トラブルシュート"
 ],
 "Type to filter…": [
  null,
  "フィルターのために入力します…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "イメージ履歴をロードできません"
 ],
 "Unhealthy": [
  null,
  "異常"
 ],
 "Up since $0": [
  null,
  "$0 から稼働中"
 ],
 "Use legacy Docker format": [
  null,
  "レガシーの Docker フォーマットの使用"
 ],
 "Used by": [
  null,
  "使用中"
 ],
 "User": [
  null,
  "ユーザー"
 ],
 "User Podman service is also available": [
  null,
  "ユーザーの Podman サービスも利用できます"
 ],
 "User:": [
  null,
  "ユーザー:"
 ],
 "Value": [
  null,
  "値"
 ],
 "Volumes": [
  null,
  "ボリューム"
 ],
 "With terminal": [
  null,
  "端末の使用"
 ],
 "Writable": [
  null,
  "書き込み可能"
 ],
 "container": [
  null,
  "コンテナー"
 ],
 "downloading": [
  null,
  "ダウンロード中"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:port]/[user]/container[:tag]"
 ],
 "image": [
  null,
  "イメージ"
 ],
 "in": [
  null,
  "内"
 ],
 "n/a": [
  null,
  "N/A"
 ],
 "not available": [
  null,
  "利用できません"
 ],
 "pod group": [
  null,
  "Pod グループ"
 ],
 "podman": [
  null,
  "Podman"
 ],
 "ports": [
  null,
  "ポート"
 ],
 "seconds": [
  null,
  "秒"
 ],
 "select all": [
  null,
  "すべて選択"
 ],
 "system": [
  null,
  "システム"
 ],
 "unused": [
  null,
  "未使用"
 ],
 "user:": [
  null,
  "ユーザー:"
 ],
 "volumes": [
  null,
  "ボリューム"
 ]
});
