cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 컨테이너"
 ],
 "$0 image total, $1": [
  null,
  "$0 이미지 총계, $1"
 ],
 "$0 second": [
  null,
  "$0 초"
 ],
 "$0 unused image, $1": [
  null,
  "$0 미사용 이미지, $1"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "컨테이너가 비정상 상태로 전이되면 수행 할 작업."
 ],
 "Add port mapping": [
  null,
  "포트 대응을 추가합니다"
 ],
 "Add variable": [
  null,
  "변수를 추가합니다"
 ],
 "Add volume": [
  null,
  "볼륨 추가"
 ],
 "All": [
  null,
  "모두"
 ],
 "All registries": [
  null,
  "모든 레지스터리"
 ],
 "Always": [
  null,
  "항상"
 ],
 "An error occurred": [
  null,
  "오류가 발생했습니다"
 ],
 "Author": [
  null,
  "작성자"
 ],
 "Automatically start podman on boot": [
  null,
  "부트시 자동으로 podman 시작"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "CPU 공유 도움말"
 ],
 "CPU shares": [
  null,
  "CPU 공유"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU 공유는 동작 중인 콘테이너 우선 순위를 결정합니다. 기본 우선순위는 1024입니다. 숫자가 클 수록 이 컨테이너 우선순위를 갖습니다. 낮은 번호는 우선 순위가 낮아집니다."
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Checking health": [
  null,
  "상태 점검 중"
 ],
 "Checkpoint": [
  null,
  "점검점"
 ],
 "Checkpoint and restore support": [
  null,
  "점검점과 복구 지원"
 ],
 "Checkpoint container $0": [
  null,
  "점검점 컨테이너 $0"
 ],
 "Click to see published ports": [
  null,
  "공개된 포트를 보려면 누르세요"
 ],
 "Click to see volumes": [
  null,
  "볼륨을 보려면 누르세요"
 ],
 "Command": [
  null,
  "명령"
 ],
 "Comments": [
  null,
  "주석"
 ],
 "Commit": [
  null,
  "수행"
 ],
 "Commit container": [
  null,
  "컨테이너 커밋"
 ],
 "Configured": [
  null,
  "구성됨"
 ],
 "Console": [
  null,
  "콘솔"
 ],
 "Container": [
  null,
  "컨테이너"
 ],
 "Container failed to be created": [
  null,
  "컨테이너 생성에 실패했습니다"
 ],
 "Container failed to be started": [
  null,
  "컨테이너 시작에 실패했습니다"
 ],
 "Container is not running": [
  null,
  "컨테이너가 동작 중이 아닙니다"
 ],
 "Container name": [
  null,
  "컨테이너 이름"
 ],
 "Container name is required.": [
  null,
  "컨테이너 이름이 필요합니다."
 ],
 "Container path": [
  null,
  "컨테이너 경로"
 ],
 "Container port": [
  null,
  "컨테이너 포트"
 ],
 "Containers": [
  null,
  "컨테이너들"
 ],
 "Create": [
  null,
  "생성"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "$0 컨테이너의 현재 상태에서 기반된 새로운 이미지를 생성합니다."
 ],
 "Create and run": [
  null,
  "생성과 실행"
 ],
 "Create container": [
  null,
  "컨테이너 생성"
 ],
 "Create container in $0": [
  null,
  "$0에서 컨테이너 생성"
 ],
 "Create container in pod": [
  null,
  "포드에서 컨테이너 생성"
 ],
 "Create pod": [
  null,
  "포드 생성"
 ],
 "Created": [
  null,
  "생성일"
 ],
 "Created by": [
  null,
  "생성됨"
 ],
 "Decrease CPU shares": [
  null,
  "CPU 공유 감소"
 ],
 "Decrease interval": [
  null,
  "간격 감소"
 ],
 "Decrease maximum retries": [
  null,
  "최대 재시도 감소"
 ],
 "Decrease memory": [
  null,
  "메모리 감소"
 ],
 "Decrease retries": [
  null,
  "재시도 감소"
 ],
 "Decrease start period": [
  null,
  "시작 기간 감소"
 ],
 "Decrease timeout": [
  null,
  "시간종료 감소"
 ],
 "Delete": [
  null,
  "삭제"
 ],
 "Delete $0": [
  null,
  "$0 삭제"
 ],
 "Delete $0?": [
  null,
  "$0 삭제?"
 ],
 "Delete pod $0?": [
  null,
  "pod $0 삭제?"
 ],
 "Delete tagged images": [
  null,
  "태그가 지정된 이미지 삭제"
 ],
 "Delete unused system images:": [
  null,
  "사용하지 않는 시스템 이미지 삭제:"
 ],
 "Delete unused user images:": [
  null,
  "사용하지 않는 사용자 이미지 삭제:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "컨테이너를 삭제는 내부의 모든 자료도 제거됩니다."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "동작 중인 컨테이너 삭제는 내부의 모든 자료도 제거됩니다."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "이 pod의 삭제는 다음 컨테이너도 제거될 것입니다:"
 ],
 "Details": [
  null,
  "상세정보"
 ],
 "Disk space": [
  null,
  "디스크 공간"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "도커 형식은 도커 또는 모비 엔진과 같은 이미지를 공유 할 때에 유용합니다"
 ],
 "Download": [
  null,
  "내려받기"
 ],
 "Download new image": [
  null,
  "신규 이미지 내려받기"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "빈 pod $0는 영구적으로 제거됩니다."
 ],
 "Entrypoint": [
  null,
  "시작점"
 ],
 "Environment variables": [
  null,
  "환경 변수"
 ],
 "Error": [
  null,
  "오류"
 ],
 "Error message": [
  null,
  "오류 메시지"
 ],
 "Error occurred while connecting console": [
  null,
  "오류가 콘솔 연결 중에 발생했습니다"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "예제, 당신의 이름 <yourname@example.com>"
 ],
 "Example: $0": [
  null,
  "예제: $0"
 ],
 "Exited": [
  null,
  "종료됨"
 ],
 "Failed health run": [
  null,
  "상태 실행에 실패함"
 ],
 "Failed to checkpoint container $0": [
  null,
  "컨테이너 $0 점검점에 실패"
 ],
 "Failed to clean up container": [
  null,
  "컨테이너를 정리하는데 실패"
 ],
 "Failed to commit container $0": [
  null,
  "컨테이너 $0 수행에 실패"
 ],
 "Failed to create container $0": [
  null,
  "컨테이너 $0 생성에 실패"
 ],
 "Failed to download image $0:$1": [
  null,
  "이미지 $0:$1 내려받기에 실패"
 ],
 "Failed to force remove container $0": [
  null,
  "컨테이너 $0 강제 제거에 실패"
 ],
 "Failed to force remove image $0": [
  null,
  "이미지 $0 강제 제거에 실패"
 ],
 "Failed to force restart pod $0": [
  null,
  "pod $0 강제로 재시작 하는데 실패"
 ],
 "Failed to force stop pod $0": [
  null,
  "pod $0 강제 멈춤에 실패"
 ],
 "Failed to pause container $0": [
  null,
  "컨테이너 $0를 일시 중지 하는 데 실패"
 ],
 "Failed to pause pod $0": [
  null,
  "pod $0 일시정지에 실패"
 ],
 "Failed to prune unused images": [
  null,
  "사용하지 않는 이미지 정리 실패"
 ],
 "Failed to pull image $0": [
  null,
  "이미지 $0를 가져오는 데 실패"
 ],
 "Failed to remove container $0": [
  null,
  "컨테이너 $0 제거에 실패"
 ],
 "Failed to remove image $0": [
  null,
  "이미지 $0 제거에 실패"
 ],
 "Failed to rename container $0": [
  null,
  "컨테이너 $0의 이름을 변경하는데 실패함"
 ],
 "Failed to restart container $0": [
  null,
  "컨테이너 $0 재시작에 실패"
 ],
 "Failed to restart pod $0": [
  null,
  "pod $0 재시작에 실패"
 ],
 "Failed to restore container $0": [
  null,
  "컨테이너 $0 복구에 실패"
 ],
 "Failed to resume container $0": [
  null,
  "컨테이너 $0를 다시 시작 하는 데 실패"
 ],
 "Failed to resume pod $0": [
  null,
  "pod $0 재개에 실패"
 ],
 "Failed to run container $0": [
  null,
  "컨테이너 $0를 실행하는 데 실패"
 ],
 "Failed to run health check on container $0": [
  null,
  "컨테이너 $0에서 상태를 점검하는데 실패함"
 ],
 "Failed to search for images.": [
  null,
  "이미지 검색을 실패함."
 ],
 "Failed to search for images: $0": [
  null,
  "이미지를 위한 검색 실패: $0"
 ],
 "Failed to search for new images": [
  null,
  "새로운 이미지 검색 실패"
 ],
 "Failed to start container $0": [
  null,
  "컨테이너 $0 시작에 실패"
 ],
 "Failed to start pod $0": [
  null,
  "pod $0를 시작하는 데 실패"
 ],
 "Failed to stop container $0": [
  null,
  "컨테이너 $0 멈춤에 실패"
 ],
 "Failed to stop pod $0": [
  null,
  "pod $0 멈춤에 실패"
 ],
 "Failing streak": [
  null,
  "연속 실패"
 ],
 "Failure action": [
  null,
  "장애 작용"
 ],
 "Force commit": [
  null,
  "강제 커밋"
 ],
 "Force delete": [
  null,
  "강제 삭제"
 ],
 "Force delete pod $0?": [
  null,
  "pod $0 강제 삭제?"
 ],
 "Force restart": [
  null,
  "강제 재시작"
 ],
 "Force stop": [
  null,
  "강제 멈춤"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "게이트웨이"
 ],
 "Health check": [
  null,
  "상태 점검"
 ],
 "Health check interval help": [
  null,
  "상태 점검 간격 도움말"
 ],
 "Health check retries help": [
  null,
  "상태 점검 재시도 도움말"
 ],
 "Health check start period help": [
  null,
  "상태 점검 시작 기간 도움말"
 ],
 "Health check timeout help": [
  null,
  "상태 점검 시간종료 도움말"
 ],
 "Health failure check action help": [
  null,
  "상태 장애 점검 작용 도움말"
 ],
 "Healthy": [
  null,
  "상태좋음"
 ],
 "Hide images": [
  null,
  "이미지 숨김"
 ],
 "Hide intermediate images": [
  null,
  "중간 이미지 숨기기"
 ],
 "History": [
  null,
  "기록"
 ],
 "Host path": [
  null,
  "호스트 경로"
 ],
 "Host port": [
  null,
  "호스트 포트"
 ],
 "Host port help": [
  null,
  "호스트 포트 도움말"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "IP 주소"
 ],
 "IP address help": [
  null,
  "IP 주소 도움말"
 ],
 "Ideal for development": [
  null,
  "개발을 위해 이상적인"
 ],
 "Ideal for running services": [
  null,
  "실행 중인 서비스에 이상적인"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "만약 호스트 IP가 0.0.0.0으로 설정되거나 또는 전혀 설정되지 않으면, 포트는 호스트의 모든 IP에서 묶이게 됩니다."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "만약 호스트 포트가 컨테이너에 설정되어 있지 않으면, 포트는 호스트에서 임의 지정된 포트가 됩니다."
 ],
 "Ignore IP address if set statically": [
  null,
  "정적인 상태라면 IP 주소 무시"
 ],
 "Ignore MAC address if set statically": [
  null,
  "정적인 상태라면 맥 주소 무시"
 ],
 "Image": [
  null,
  "이미지"
 ],
 "Image name is not unique": [
  null,
  "이미지 이름은 독특하지 않습니다"
 ],
 "Image name is required": [
  null,
  "이미지 이름이 필요합니다"
 ],
 "Image selection help": [
  null,
  "이미지 선택 도움말"
 ],
 "Images": [
  null,
  "이미지"
 ],
 "Increase CPU shares": [
  null,
  "CPU 공유 증가"
 ],
 "Increase interval": [
  null,
  "간격 증가"
 ],
 "Increase maximum retries": [
  null,
  "최대 재시도 증가"
 ],
 "Increase memory": [
  null,
  "메모리 증가"
 ],
 "Increase retries": [
  null,
  "재시도 증가"
 ],
 "Increase start period": [
  null,
  "시작 기간 증가"
 ],
 "Increase timeout": [
  null,
  "시간종료 증가"
 ],
 "Integration": [
  null,
  "통합"
 ],
 "Interval": [
  null,
  "간격"
 ],
 "Interval how often health check is run.": [
  null,
  "얼마나 자주 상태 점검을 실행하는 간격."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "잘못된 문자. 이름은 문자, 수자와 특정 구두점(_ . -)만 포함 될 수 있습니다."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "모든 임시 점검점 파일을 유지합니다"
 ],
 "Key": [
  null,
  "키"
 ],
 "Last 5 runs": [
  null,
  "최근 5회 실행"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "점검점을 디스크에 쓰기 후에 계속 진행"
 ],
 "Loading details...": [
  null,
  "세부정보 적재 중..."
 ],
 "Loading logs...": [
  null,
  "기록 적재 중..."
 ],
 "Loading...": [
  null,
  "적재 중..."
 ],
 "Local": [
  null,
  "로컬"
 ],
 "Local images": [
  null,
  "로컬 이미지"
 ],
 "Logs": [
  null,
  "기록"
 ],
 "MAC address": [
  null,
  "맥(mac) 주소"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "최대 재시도"
 ],
 "Memory": [
  null,
  "메모리"
 ],
 "Memory limit": [
  null,
  "메모리 제한"
 ],
 "Memory unit": [
  null,
  "메모리 장치"
 ],
 "Mode": [
  null,
  "모드"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "다중 태그는 이 이미지에 존재합니다. 삭제에 태그된 이미지를 선택합니다."
 ],
 "Name": [
  null,
  "이름"
 ],
 "New container name": [
  null,
  "신규 컨테이너 이름"
 ],
 "New image name": [
  null,
  "새로운 이미지 이름"
 ],
 "No": [
  null,
  "아니오"
 ],
 "No action": [
  null,
  "반응 없음"
 ],
 "No containers": [
  null,
  "컨테이너 없음"
 ],
 "No containers are using this image": [
  null,
  "이 이미지에 사용 중인 컨테이너가 없습니다"
 ],
 "No containers in this pod": [
  null,
  "이 포드에는 컨테이너가 없습니다"
 ],
 "No containers that match the current filter": [
  null,
  "현재 필터에 일치하는 컨테이너가 없습니다"
 ],
 "No environment variables specified": [
  null,
  "지정된 환경 변수가 없습니다"
 ],
 "No images": [
  null,
  "이미지 없음"
 ],
 "No images found": [
  null,
  "이미지를 찾지 못했습니다"
 ],
 "No images that match the current filter": [
  null,
  "현재 필터에 일치하는 이미지가 없습니다"
 ],
 "No label": [
  null,
  "이름표가 없습니다"
 ],
 "No ports exposed": [
  null,
  "노출된 포트가 없습니다"
 ],
 "No results for $0": [
  null,
  "$0의 결과를 찾을 수 없습니다"
 ],
 "No running containers": [
  null,
  "실행 중인 컨테이너가 없습니다"
 ],
 "No volumes specified": [
  null,
  "지정된 볼륨이 없습니다"
 ],
 "On failure": [
  null,
  "실패한 경우"
 ],
 "Only running": [
  null,
  "실행 만"
 ],
 "Options": [
  null,
  "옵션"
 ],
 "Owner": [
  null,
  "소유자"
 ],
 "Owner help": [
  null,
  "소유자 도움말"
 ],
 "Passed health run": [
  null,
  "상태 실행 통과됨"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "대량으로 가져오기 위해 키=값 쌍의 하나 이상의 행에 입력부분에 붙여 넣습니다"
 ],
 "Pause": [
  null,
  "일시정지"
 ],
 "Pause container when creating image": [
  null,
  "이미지에 생성 중인 컨테이너를 일시 중지합니다"
 ],
 "Paused": [
  null,
  "일시정지됨"
 ],
 "Pod failed to be created": [
  null,
  "포드 생성에 실패했습니다"
 ],
 "Pod name": [
  null,
  "포드 이름"
 ],
 "Podman containers": [
  null,
  "포드맨 컨테이너"
 ],
 "Podman service is not active": [
  null,
  "포드맨 서비스가 동작하지 않습니다"
 ],
 "Port mapping": [
  null,
  "포트 대응"
 ],
 "Ports": [
  null,
  "포트"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "1024 이하 포트는 대응 될 수 있습니다"
 ],
 "Private": [
  null,
  "비공개"
 ],
 "Protocol": [
  null,
  "통신규약"
 ],
 "Prune": [
  null,
  "프룬"
 ],
 "Prune unused images": [
  null,
  "프룬 사용하지 않은 이미지"
 ],
 "Pruning images": [
  null,
  "프루닝 이미지"
 ],
 "Pull latest image": [
  null,
  "최신 이미지 가져오기"
 ],
 "Pulling": [
  null,
  "당기기"
 ],
 "Read-only access": [
  null,
  "읽기-전용 접근"
 ],
 "Read-write access": [
  null,
  "읽기-쓰기 접근"
 ],
 "Remove item": [
  null,
  "항목 제거"
 ],
 "Removing": [
  null,
  "제거 중"
 ],
 "Rename": [
  null,
  "이름변경"
 ],
 "Rename container $0": [
  null,
  "컨테이너 $0 이름변경"
 ],
 "Resource limits can be set": [
  null,
  "자원 한계가 설정 될 수 있습니다"
 ],
 "Restart": [
  null,
  "재시작"
 ],
 "Restart policy": [
  null,
  "재시작 정책"
 ],
 "Restart policy help": [
  null,
  "정책 도움말 재시작"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "컨테이너를 종료 할 경우에 따라야 할 정책을 재시작 합니다."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "컨테이너가 종료 될 때 따라야 할 정책을 재시작합니다. 자동으로 시작하는 컨테이너를 위한 linger를 사용은 ecryptfs, systemd-homed, NFS, 또는 2FA가 사용자 계정에서 사용되는 것과 같이 특정 상황에서 작동하지 않을 수 있습니다."
 ],
 "Restore": [
  null,
  "복구"
 ],
 "Restore container $0": [
  null,
  "컨테이너$0에서 복구"
 ],
 "Restore with established TCP connections": [
  null,
  "설정된 TCP 연결로 복구"
 ],
 "Restricted by user account permissions": [
  null,
  "사용자 계졍 권한에 의해 제한됨"
 ],
 "Resume": [
  null,
  "다시 시작"
 ],
 "Retries": [
  null,
  "재시도"
 ],
 "Retry another term.": [
  null,
  "다른 용어를 재시도."
 ],
 "Run health check": [
  null,
  "상태 점검을 실행"
 ],
 "Running": [
  null,
  "작동중"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "이름 또는 설명으로 찾기"
 ],
 "Search by registry": [
  null,
  "레지스터리로 검색"
 ],
 "Search for": [
  null,
  "찾기"
 ],
 "Search for an image": [
  null,
  "이미지로 찾기"
 ],
 "Search string or container location": [
  null,
  "문자열 또는 컨테이너 위치 검색"
 ],
 "Searching...": [
  null,
  "검색 중..."
 ],
 "Searching: $0": [
  null,
  "검색 중: $0"
 ],
 "Shared": [
  null,
  "공유됨"
 ],
 "Show": [
  null,
  "보기"
 ],
 "Show images": [
  null,
  "이미지 보여주기"
 ],
 "Show intermediate images": [
  null,
  "중간 이미지 보기"
 ],
 "Show less": [
  null,
  "덜 보기"
 ],
 "Show more": [
  null,
  "더 보여주기"
 ],
 "Size": [
  null,
  "크기"
 ],
 "Start": [
  null,
  "시작"
 ],
 "Start period": [
  null,
  "시작 주기"
 ],
 "Start podman": [
  null,
  "포드맨 시작"
 ],
 "Start typing to look for images.": [
  null,
  "이미지를 찾으려면 입력을 시작하세요."
 ],
 "Started at": [
  null,
  "시작 시간"
 ],
 "State": [
  null,
  "상태"
 ],
 "Status": [
  null,
  "상태"
 ],
 "Stop": [
  null,
  "중지"
 ],
 "Stopped": [
  null,
  "정지됨"
 ],
 "Support preserving established TCP connections": [
  null,
  "설정된 TCP 연결 유지 지원"
 ],
 "System": [
  null,
  "시스템"
 ],
 "System Podman service is also available": [
  null,
  "시스템 포드맨 서비스도 사용 할 수 있습니다"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "태그"
 ],
 "Tags": [
  null,
  "태그"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "부트스트랩에서 컨테이너를 위해 필요한 초기화 시간."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "간격이 실패한 것으로 간주되기 전에 상태 점검을 완료하도록 허용되는 최대 시간."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "상태점검이 좋지 않은 것으로 고려되기 전에 허용되는 재시도 수."
 ],
 "Timeout": [
  null,
  "시간종료"
 ],
 "Troubleshoot": [
  null,
  "문제 해결"
 ],
 "Type to filter…": [
  null,
  "필터 입력…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "이미지 기록을 적재 할 수 없음"
 ],
 "Unhealthy": [
  null,
  "상태나쁨"
 ],
 "Up since $0": [
  null,
  "$0 이후 상승"
 ],
 "Use legacy Docker format": [
  null,
  "레거시 도커 형식을 사용합니다"
 ],
 "Used by": [
  null,
  "사용되었습니다"
 ],
 "User": [
  null,
  "사용자"
 ],
 "User Podman service is also available": [
  null,
  "사용자 포드맨 서비스가 사용 할 수 없습니다"
 ],
 "User:": [
  null,
  "사용자:"
 ],
 "Value": [
  null,
  "값"
 ],
 "Volumes": [
  null,
  "볼륨"
 ],
 "With terminal": [
  null,
  "터미널 포함"
 ],
 "Writable": [
  null,
  "쓰기 가능"
 ],
 "container": [
  null,
  "컨테이너"
 ],
 "downloading": [
  null,
  "내려받기 중"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "host[:포트]/[사용자]/컨테이너[:태그]"
 ],
 "image": [
  null,
  "이미지"
 ],
 "in": [
  null,
  "in"
 ],
 "n/a": [
  null,
  "해당 없음"
 ],
 "not available": [
  null,
  "사용할 수 없음"
 ],
 "pod group": [
  null,
  "포드 그룹"
 ],
 "podman": [
  null,
  "포드맨"
 ],
 "ports": [
  null,
  "포트"
 ],
 "seconds": [
  null,
  "초"
 ],
 "select all": [
  null,
  "모두 선택"
 ],
 "system": [
  null,
  "systemd"
 ],
 "unused": [
  null,
  "미사용"
 ],
 "user:": [
  null,
  "사용자:"
 ],
 "volumes": [
  null,
  "볼륨"
 ]
});
