cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "sk",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 kontajner",
  "$0 kontajnery",
  "$0 kontajnerov"
 ],
 "$0 image total, $1": [
  null,
  "$0 obrazov dohromady, $1",
  "$0 obrazy dohromady, $1",
  "$0 obrazov dohromady, $1"
 ],
 "$0 second": [
  null,
  "",
  "",
  ""
 ],
 "$0 unused image, $1": [
  null,
  "$0 nepoužitých obrazov, $1",
  "$0 nepoužité obrazy, $1",
  "$0 nepoužitých obrazov, $1"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  ""
 ],
 "Add port mapping": [
  null,
  "Pridať mapovanie portov"
 ],
 "Add variable": [
  null,
  "Pridať premennú"
 ],
 "Add volume": [
  null,
  "Pridať zväzok"
 ],
 "All": [
  null,
  "Všetky"
 ],
 "All registries": [
  null,
  "Všetky registre"
 ],
 "Always": [
  null,
  "Vždy"
 ],
 "An error occurred": [
  null,
  "Vyskytla sa chyba"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "Automatically start podman on boot": [
  null,
  "Spúšťať podman pri zavádzaní systému"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU shares": [
  null,
  "CPU podiely"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  ""
 ],
 "Cancel": [
  null,
  "Zrušiť"
 ],
 "Checkpoint": [
  null,
  "Vytvoriť kontrolný bod"
 ],
 "Checkpoint container $0": [
  null,
  "Vytvoriť kontrolný bod pre kontajner $0"
 ],
 "Click to see published ports": [
  null,
  ""
 ],
 "Click to see volumes": [
  null,
  ""
 ],
 "Command": [
  null,
  "Príkaz"
 ],
 "Commit": [
  null,
  "Vytvoriť"
 ],
 "Configured": [
  null,
  "Nakonfigurovaný"
 ],
 "Console": [
  null,
  "Konzola"
 ],
 "Container": [
  null,
  "Kontajner"
 ],
 "Container failed to be created": [
  null,
  "Kontajner sa nepodarilo vytvoriť"
 ],
 "Container failed to be started": [
  null,
  "Kontajner sa nepodarilo spustiť"
 ],
 "Container is not running": [
  null,
  "Kontajner nebeží"
 ],
 "Container name": [
  null,
  "Názov kontajneru"
 ],
 "Container path": [
  null,
  "Cesta v kontajneri"
 ],
 "Container port": [
  null,
  "Port kontajneru"
 ],
 "Containers": [
  null,
  "Kontajnery"
 ],
 "Create": [
  null,
  "Vytvoriť"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  ""
 ],
 "Create and run": [
  null,
  "Vytvoriť a spustiť"
 ],
 "Create container": [
  null,
  "Vytvoriť kontajner"
 ],
 "Create container in $0": [
  null,
  "Vytvoriť kontajner v $0"
 ],
 "Create container in pod": [
  null,
  "Vytvoriť kontajner v skupine"
 ],
 "Created": [
  null,
  "Vytvorený"
 ],
 "Decrease interval": [
  null,
  ""
 ],
 "Decrease memory": [
  null,
  ""
 ],
 "Decrease retries": [
  null,
  ""
 ],
 "Decrease timeout": [
  null,
  ""
 ],
 "Delete": [
  null,
  "Odstrániť"
 ],
 "Delete $0": [
  null,
  "Odstrániť $0"
 ],
 "Delete tagged images": [
  null,
  "Zmazať označené obrazy"
 ],
 "Delete unused system images:": [
  null,
  "Zmazať nepoužívané systémové obrazy:"
 ],
 "Delete unused user images:": [
  null,
  "Zmazať nepoužívané užívateľské obrazy:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Zmazaním kontajneru sa zmažú všetky dáta v ňom."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Zmazanie tohto podu zmaže nasledujúce kontajnery:"
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Disk space": [
  null,
  ""
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  ""
 ],
 "Download": [
  null,
  "Stiahnuť"
 ],
 "Download new image": [
  null,
  "Stiahnuť nový obraz"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  ""
 ],
 "Entrypoint": [
  null,
  "Vstupný bod"
 ],
 "Environment variables": [
  null,
  "Premenné prostredia"
 ],
 "Error": [
  null,
  "Chyba"
 ],
 "Error message": [
  null,
  "Chybová správa"
 ],
 "Error occurred while connecting console": [
  null,
  ""
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Príklad, Vaše Meno <vasemeno@priklad.sk>"
 ],
 "Example: $0": [
  null,
  "Príklad: $0"
 ],
 "Exited": [
  null,
  "Skončený"
 ],
 "Failed health run": [
  null,
  ""
 ],
 "Failed to checkpoint container $0": [
  null,
  "Nepodarilo sa vytvoriť kontrolný bod pre kontajner $0"
 ],
 "Failed to clean up container": [
  null,
  "Nepodarilo sa zmazať kontajner"
 ],
 "Failed to commit container $0": [
  null,
  ""
 ],
 "Failed to create container $0": [
  null,
  "Nepodarilo sa vytvoriť kontajner $0"
 ],
 "Failed to download image $0:$1": [
  null,
  "Nepodarilo sa stiahnuť obraz $0:$1"
 ],
 "Failed to force remove container $0": [
  null,
  "Nepodarilo sa vynútiť zmazanie kontajneru $0"
 ],
 "Failed to force remove image $0": [
  null,
  "Nepodarilo sa vynútiť zmazanie obrazu $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "Nepodarilo sa nútene reštartovať pod $0"
 ],
 "Failed to force stop pod $0": [
  null,
  "Nepodarilo sa vynútiť zmazanie podu $0"
 ],
 "Failed to pause container $0": [
  null,
  "Nepodarilo sa zastaviť kontajner $0"
 ],
 "Failed to pause pod $0": [
  null,
  "Nepodarilo sa zastaviť pod $0"
 ],
 "Failed to pull image $0": [
  null,
  "Nepodarilo sa stiahnuť obraz $0"
 ],
 "Failed to remove container $0": [
  null,
  "Nepodarilo sa zmazať kontajner $0"
 ],
 "Failed to remove image $0": [
  null,
  "Nepodarilo sa zmazať obraz $0"
 ],
 "Failed to restart container $0": [
  null,
  "Nepodarilo sa reštartovať kontajner $0"
 ],
 "Failed to restart pod $0": [
  null,
  "Nepodarilo sa reštartovať pod $0"
 ],
 "Failed to restore container $0": [
  null,
  "Nepodarilo sa obnoviť kontajner $0"
 ],
 "Failed to resume container $0": [
  null,
  "Nepodarilo sa spustiť kontajner $0"
 ],
 "Failed to resume pod $0": [
  null,
  "Nepodarilo sa znovuspustiť pod $0"
 ],
 "Failed to run container $0": [
  null,
  "Nepodarilo sa spustiť kontajner $0"
 ],
 "Failed to search for images: $0": [
  null,
  "Nepodarilo sa nájsť obrazy: $0"
 ],
 "Failed to search for new images": [
  null,
  "Nepodarilo sa nájsť nové obrazy"
 ],
 "Failed to start container $0": [
  null,
  "Nepodarilo sa spustiť kontajner $0"
 ],
 "Failed to start pod $0": [
  null,
  "Nepodarilo sa spustiť pod $0"
 ],
 "Failed to stop container $0": [
  null,
  "Nepodarilo sa zastaviť kontajner $0"
 ],
 "Failed to stop pod $0": [
  null,
  "Nepodarilo sa zastaviť pod $0"
 ],
 "Failing streak": [
  null,
  ""
 ],
 "Failure action": [
  null,
  ""
 ],
 "Force delete": [
  null,
  "Vynútiť odstránenie"
 ],
 "Force restart": [
  null,
  "Vynútiť reštartovanie"
 ],
 "Force stop": [
  null,
  "Vynútiť zastavenie"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "Brána"
 ],
 "Health check": [
  null,
  ""
 ],
 "Health check interval help": [
  null,
  ""
 ],
 "Health check retries help": [
  null,
  ""
 ],
 "Health check start period help": [
  null,
  ""
 ],
 "Health check timeout help": [
  null,
  ""
 ],
 "Health failure check action help": [
  null,
  ""
 ],
 "Healthy": [
  null,
  ""
 ],
 "Hide images": [
  null,
  "Skryť obrazy"
 ],
 "Hide intermediate images": [
  null,
  "Skryť dočasné obrazy"
 ],
 "History": [
  null,
  ""
 ],
 "Host path": [
  null,
  "Cesta na hostiteľovi"
 ],
 "Host port": [
  null,
  "Port na hostiteľovi"
 ],
 "Host port help": [
  null,
  "Nápoveda k portu na hostiteľovi"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "IP adresa"
 ],
 "IP address help": [
  null,
  "Nápoveda k IP adrese"
 ],
 "Ideal for development": [
  null,
  ""
 ],
 "Ideal for running services": [
  null,
  ""
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  ""
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  ""
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorovať staticky nastavené IP adresy"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorovať staticky nastavené MAC adresy"
 ],
 "Image": [
  null,
  "Obraz"
 ],
 "Image name is not unique": [
  null,
  ""
 ],
 "Image selection help": [
  null,
  "Nápoveda k výberu obrazu"
 ],
 "Images": [
  null,
  "Obrazy"
 ],
 "Increase memory": [
  null,
  ""
 ],
 "Increase retries": [
  null,
  ""
 ],
 "Increase timeout": [
  null,
  ""
 ],
 "Integration": [
  null,
  "Integrácia"
 ],
 "Interval how often health check is run.": [
  null,
  ""
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  ""
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  ""
 ],
 "Key": [
  null,
  "Kľúč"
 ],
 "Last 5 runs": [
  null,
  ""
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  ""
 ],
 "Loading logs...": [
  null,
  "Načítanie záznamov udalostí..."
 ],
 "Loading...": [
  null,
  "Načítanie..."
 ],
 "Local": [
  null,
  "Miestne"
 ],
 "Local images": [
  null,
  "Miestne obrazy"
 ],
 "Logs": [
  null,
  "Záznamy udalostí"
 ],
 "MAC address": [
  null,
  "MAC adresa"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "Maximum pokusov"
 ],
 "Memory": [
  null,
  "Pamäť"
 ],
 "Memory limit": [
  null,
  "Pamäťový limit"
 ],
 "Memory unit": [
  null,
  "Pamäťová jednotka"
 ],
 "Mode": [
  null,
  "Mód"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  ""
 ],
 "Name": [
  null,
  "Názov"
 ],
 "New image name": [
  null,
  "Názov nového obrazu"
 ],
 "No": [
  null,
  "Nie"
 ],
 "No action": [
  null,
  ""
 ],
 "No containers": [
  null,
  "Žiadne kontajnery"
 ],
 "No containers are using this image": [
  null,
  "Tento obraz nepoužívajú žiadne kontajnery"
 ],
 "No containers in this pod": [
  null,
  "V tomto pode nie sú žiadne kontajnery"
 ],
 "No containers that match the current filter": [
  null,
  "Žiadne kontajneri nevyhovujú danému filtru"
 ],
 "No environment variables specified": [
  null,
  "Neboli definované žiadne premenné prostredia"
 ],
 "No images": [
  null,
  "Žiadne obrazy"
 ],
 "No images found": [
  null,
  "Žiadne obrazy neboli nájdené"
 ],
 "No images that match the current filter": [
  null,
  "Žiadne obrazy nevyhovujú danému filtru"
 ],
 "No label": [
  null,
  ""
 ],
 "No ports exposed": [
  null,
  ""
 ],
 "No results for $0": [
  null,
  "Žiaden výsledok pre $0"
 ],
 "No running containers": [
  null,
  "Žiadne spustené kontajnery"
 ],
 "No volumes specified": [
  null,
  "Žiadne špecifikované zväzky"
 ],
 "On failure": [
  null,
  "Pri chybe"
 ],
 "Only running": [
  null,
  "Iba bežiace"
 ],
 "Options": [
  null,
  "Možnosti"
 ],
 "Owner": [
  null,
  "Vlastník"
 ],
 "Passed health run": [
  null,
  ""
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  ""
 ],
 "Pause": [
  null,
  "Pozastaviť"
 ],
 "Pause container when creating image": [
  null,
  "Zastaviť kontajner keď sa vytvára obraz"
 ],
 "Paused": [
  null,
  "Pozastavený"
 ],
 "Pod name": [
  null,
  ""
 ],
 "Podman containers": [
  null,
  "Podman kontajnery"
 ],
 "Podman service is not active": [
  null,
  "Služba Podman nie je aktívna"
 ],
 "Port mapping": [
  null,
  "Mapovanie portov"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Ports under 1024 can be mapped": [
  null,
  ""
 ],
 "Private": [
  null,
  "Súkromný"
 ],
 "Protocol": [
  null,
  "Protokol"
 ],
 "Prune": [
  null,
  "Prerezať"
 ],
 "Prune unused images": [
  null,
  "Prerezať nepoužívané obrazy"
 ],
 "Pruning images": [
  null,
  "Prerezávanie obrazov"
 ],
 "Pull latest image": [
  null,
  "Stiahnúť najnovší obraz"
 ],
 "Pulling": [
  null,
  "Sťahuje sa"
 ],
 "Read-only access": [
  null,
  ""
 ],
 "Read-write access": [
  null,
  ""
 ],
 "Remove item": [
  null,
  "Odstrániť položku"
 ],
 "Removing": [
  null,
  "Odstraňuje sa"
 ],
 "Rename": [
  null,
  ""
 ],
 "Resource limits can be set": [
  null,
  ""
 ],
 "Restart": [
  null,
  "Reštartovať"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  ""
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  ""
 ],
 "Restore": [
  null,
  "Obnoviť"
 ],
 "Restore container $0": [
  null,
  "Obnovenie kontajneru $0"
 ],
 "Restore with established TCP connections": [
  null,
  ""
 ],
 "Restricted by user account permissions": [
  null,
  ""
 ],
 "Resume": [
  null,
  ""
 ],
 "Retries": [
  null,
  ""
 ],
 "Run health check": [
  null,
  ""
 ],
 "Running": [
  null,
  ""
 ],
 "SELinux": [
  null,
  ""
 ],
 "Search by name or description": [
  null,
  "Hľadať podľa mena alebo popisu"
 ],
 "Search by registry": [
  null,
  ""
 ],
 "Search for": [
  null,
  ""
 ],
 "Search for an image": [
  null,
  "Hľadanie obrazu"
 ],
 "Search string or container location": [
  null,
  ""
 ],
 "Searching...": [
  null,
  "Hľadá sa..."
 ],
 "Shared": [
  null,
  "Zdielaný"
 ],
 "Show": [
  null,
  ""
 ],
 "Show images": [
  null,
  "Zobraziť obrazy"
 ],
 "Show intermediate images": [
  null,
  ""
 ],
 "Show more": [
  null,
  "Zobraziť viac"
 ],
 "Size": [
  null,
  "Veľkosť"
 ],
 "Start": [
  null,
  "Spustiť"
 ],
 "Start podman": [
  null,
  "Spustiť podman"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Stop": [
  null,
  "Zastaviť"
 ],
 "Stopped": [
  null,
  "Zastavený"
 ],
 "Support preserving established TCP connections": [
  null,
  ""
 ],
 "System": [
  null,
  "Systém"
 ],
 "System Podman service is also available": [
  null,
  "Systémový podman je tiež dostupný"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Tag"
 ],
 "Tags": [
  null,
  "Tagy"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  ""
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  ""
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  ""
 ],
 "Timeout": [
  null,
  ""
 ],
 "Troubleshoot": [
  null,
  "Riešiť problém"
 ],
 "Type to filter…": [
  null,
  ""
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unhealthy": [
  null,
  ""
 ],
 "Up since $0": [
  null,
  "Aktívny od $0"
 ],
 "Use legacy Docker format": [
  null,
  ""
 ],
 "Used by": [
  null,
  "Využívaný s"
 ],
 "User": [
  null,
  ""
 ],
 "User Podman service is also available": [
  null,
  "Užívateľský podman je tiež dostupný"
 ],
 "User:": [
  null,
  "Používateľ:"
 ],
 "Value": [
  null,
  "Hodnota"
 ],
 "Volumes": [
  null,
  "Zväzky"
 ],
 "With terminal": [
  null,
  "S terminálom"
 ],
 "Writable": [
  null,
  ""
 ],
 "container": [
  null,
  "kontajner"
 ],
 "downloading": [
  null,
  "sťahuje sa"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  ""
 ],
 "image": [
  null,
  "obraz"
 ],
 "in": [
  null,
  ""
 ],
 "n/a": [
  null,
  "Nedostupné"
 ],
 "not available": [
  null,
  "nedostupné"
 ],
 "pod group": [
  null,
  ""
 ],
 "podman": [
  null,
  "podman"
 ],
 "seconds": [
  null,
  ""
 ],
 "select all": [
  null,
  ""
 ],
 "system": [
  null,
  "systém"
 ],
 "unused": [
  null,
  "nepoužitý"
 ],
 "user:": [
  null,
  "používateľ:"
 ]
});
