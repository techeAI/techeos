cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 Container",
  "$0 Container"
 ],
 "$0 image total, $1": [
  null,
  "$0 Abbild insgesamt, $1",
  "$0 Abbilder insgesamt, $1"
 ],
 "$0 second": [
  null,
  "$0 Sekunde",
  "$0 Sekunden"
 ],
 "$0 unused image, $1": [
  null,
  "$0 ungenutztes Abbild, $1",
  "$0 ungenutzte Abbilder, $1"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Zu ergreifende Maßnahmen, wenn der Container in einen ungesunden Zustand übergeht."
 ],
 "Add port mapping": [
  null,
  "Port-Zuordnung hinzufügen"
 ],
 "Add variable": [
  null,
  "Variable hinzufügen"
 ],
 "Add volume": [
  null,
  "Volumen hinzufügen"
 ],
 "All": [
  null,
  "Alle"
 ],
 "All registries": [
  null,
  "Alle Registries"
 ],
 "Always": [
  null,
  "Immer"
 ],
 "An error occurred": [
  null,
  "Ein Fehler ist aufgetreten"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "Automatically start podman on boot": [
  null,
  "Podman automatisch beim Hochfahren starten"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU Shares help": [
  null,
  "CPU Shares Hilfe"
 ],
 "CPU shares": [
  null,
  "CPU-Shares"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU Shares legt die Priorität laufender Container fest. Standardwert ist 1024. Ein höherer Wert priorisiert den Container. Ein niedrigerer Wert senkt dessen Priorität."
 ],
 "Cancel": [
  null,
  "Abbruch"
 ],
 "Checking health": [
  null,
  "Überprüfung der Gesundheit"
 ],
 "Checkpoint": [
  null,
  "Kontrollpunkt"
 ],
 "Checkpoint and restore support": [
  null,
  "Unterstützung von Kontrollpunkten und Wiederherstellung"
 ],
 "Checkpoint container $0": [
  null,
  "Kontrollpunkt für Container $0"
 ],
 "Click to see published ports": [
  null,
  ""
 ],
 "Click to see volumes": [
  null,
  ""
 ],
 "Command": [
  null,
  "Befehl"
 ],
 "Comments": [
  null,
  "Kommentare"
 ],
 "Commit": [
  null,
  "Committen"
 ],
 "Commit container": [
  null,
  "Container übergeben"
 ],
 "Configured": [
  null,
  "Konfiguriert"
 ],
 "Console": [
  null,
  "Konsole"
 ],
 "Container": [
  null,
  "Container"
 ],
 "Container failed to be created": [
  null,
  "Container konnte nicht erstellt werden"
 ],
 "Container failed to be started": [
  null,
  "Container konnte nicht erstellt werden"
 ],
 "Container is not running": [
  null,
  "Container läuft nicht"
 ],
 "Container name": [
  null,
  "Container-Name"
 ],
 "Container name is required.": [
  null,
  "Containername ist erforderlich."
 ],
 "Container path": [
  null,
  "Container-Pfad"
 ],
 "Container port": [
  null,
  "Container-Port"
 ],
 "Containers": [
  null,
  "Container"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Ein neues Abbild auf der Grundlage des aktuellen Zustands des Containers $0 erstellen."
 ],
 "Create and run": [
  null,
  "Erstellen und ausführen"
 ],
 "Create container": [
  null,
  "Container erstellen"
 ],
 "Create container in $0": [
  null,
  "Container in $0 erstellen"
 ],
 "Create container in pod": [
  null,
  "Container in Pod erstellen"
 ],
 "Created": [
  null,
  "Erstellt"
 ],
 "Created by": [
  null,
  "Erstellt von"
 ],
 "Decrease CPU shares": [
  null,
  "CPU-Anteile verringern"
 ],
 "Decrease interval": [
  null,
  "Intervall verringern"
 ],
 "Decrease maximum retries": [
  null,
  "Maximale Wiederholungsversuche verringern"
 ],
 "Decrease memory": [
  null,
  "Speicher verringern"
 ],
 "Decrease retries": [
  null,
  "Wiederholungsversuche verringern"
 ],
 "Decrease start period": [
  null,
  "Startzeitraum verringern"
 ],
 "Decrease timeout": [
  null,
  "Zeitüberschreitung verringern"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Delete $0": [
  null,
  "$0 löschen"
 ],
 "Delete $0?": [
  null,
  "$0 löschen?"
 ],
 "Delete tagged images": [
  null,
  "Markierte Image löschen"
 ],
 "Delete unused system images:": [
  null,
  "Nicht verwendete Systemabbilder löschen:"
 ],
 "Delete unused user images:": [
  null,
  "Nicht verwendete Benutzerabbilder löschen:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Beim Löschen des Containers werden alle Daten darin verloren gehen."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Das Löschen eines laufenden Containers führt dazu, dass alle darin enthaltenen Daten gelöscht werden."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Löschen des Pods wird die folgenden Container entfernen:"
 ],
 "Details": [
  null,
  "Details"
 ],
 "Disk space": [
  null,
  "Speicherplatz"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker-Format ist hilfreich, wenn das Image mit Docker oder Moby Engine geteilt wird"
 ],
 "Download": [
  null,
  "Herunterladen"
 ],
 "Download new image": [
  null,
  "Neues Abbild herunterladen"
 ],
 "Entrypoint": [
  null,
  "Einsprungspunkt"
 ],
 "Environment variables": [
  null,
  "Umgebungsvariablen"
 ],
 "Error": [
  null,
  "Fehler"
 ],
 "Error message": [
  null,
  "Fehlermeldung"
 ],
 "Error occurred while connecting console": [
  null,
  "Beim Verbinden der Konsole ist ein Fehler aufgetreten"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Beispiel, Ihr Name <yourname@example.com>"
 ],
 "Example: $0": [
  null,
  "Beispiel: $0"
 ],
 "Exited": [
  null,
  "Beendet"
 ],
 "Failed health run": [
  null,
  ""
 ],
 "Failed to checkpoint container $0": [
  null,
  "Überprüfung von Container $0 fehlgeschlagen"
 ],
 "Failed to clean up container": [
  null,
  "Fehler bei der Bereinigung des Containers"
 ],
 "Failed to commit container $0": [
  null,
  "Konnte Container $0 nicht committen"
 ],
 "Failed to create container $0": [
  null,
  "Fehler bei der Erstellung des Containers $0"
 ],
 "Failed to download image $0:$1": [
  null,
  "Konnte Image $0 nicht herunterladen: $1"
 ],
 "Failed to force remove container $0": [
  null,
  "Konnte Container $0 nicht neu entfernen"
 ],
 "Failed to force remove image $0": [
  null,
  "Fehler bei der erzwungenen Entfernung des Abbilds $0"
 ],
 "Failed to force restart pod $0": [
  null,
  "Konnte Pod $0 nicht neu starten"
 ],
 "Failed to force stop pod $0": [
  null,
  "Konnte Pod $0 nicht stoppen"
 ],
 "Failed to pause container $0": [
  null,
  "Konnte Container $0 nicht pausieren"
 ],
 "Failed to pause pod $0": [
  null,
  "Konnte Pod $0 nicht pausieren"
 ],
 "Failed to prune unused images": [
  null,
  "Reduzierung nicht gebrauchter Abbilder fehlgeschlagen"
 ],
 "Failed to pull image $0": [
  null,
  "Image $0 konnte nicht gepullt werden"
 ],
 "Failed to remove container $0": [
  null,
  "Konnte Container $0 nicht neu entfernen"
 ],
 "Failed to remove image $0": [
  null,
  "Fehler bei der Entfernung von Abbild $0"
 ],
 "Failed to rename container $0": [
  null,
  "Fehler beim Umbenennen des Containers $0"
 ],
 "Failed to restart container $0": [
  null,
  "Konnte Container $0 nicht neu starten"
 ],
 "Failed to restart pod $0": [
  null,
  "Konnte Pod $0 nicht neu starten"
 ],
 "Failed to restore container $0": [
  null,
  "Konnte Container $0 nicht wiederherstellen"
 ],
 "Failed to resume container $0": [
  null,
  "Konnte Container $0 nicht wieder starten"
 ],
 "Failed to resume pod $0": [
  null,
  "Konnte Pod $0 nicht wieder starten"
 ],
 "Failed to run container $0": [
  null,
  "Konnte Container $0 nicht starten"
 ],
 "Failed to run health check on container $0": [
  null,
  ""
 ],
 "Failed to search for images: $0": [
  null,
  "Konnte nicht nach Images suchen: $0"
 ],
 "Failed to search for new images": [
  null,
  "Konnte nicht nach neuen Images suchen"
 ],
 "Failed to start container $0": [
  null,
  "Konnte Container $0 nicht starten"
 ],
 "Failed to start pod $0": [
  null,
  "Konnte Pod $0 nicht starten"
 ],
 "Failed to stop container $0": [
  null,
  "Konnte Container $0 nicht stoppen"
 ],
 "Failed to stop pod $0": [
  null,
  "Konnte Pod $0 nicht stoppen"
 ],
 "Failing streak": [
  null,
  ""
 ],
 "Failure action": [
  null,
  ""
 ],
 "Force commit": [
  null,
  "Übergabe erzwingen"
 ],
 "Force delete": [
  null,
  "Löschen erzwingen"
 ],
 "Force restart": [
  null,
  "Neustart erzwingen"
 ],
 "Force stop": [
  null,
  "Stoppen erzwingen"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "Gateway"
 ],
 "Health check": [
  null,
  "Gesundheitsprüfung"
 ],
 "Health check interval help": [
  null,
  "Hilfe zum Gesundheitsprüfungsintervall"
 ],
 "Health check retries help": [
  null,
  ""
 ],
 "Health check start period help": [
  null,
  ""
 ],
 "Health check timeout help": [
  null,
  ""
 ],
 "Healthy": [
  null,
  "Gesund"
 ],
 "Hide images": [
  null,
  "Abbilder ausblenden"
 ],
 "Hide intermediate images": [
  null,
  "Intermediate Images verstecken"
 ],
 "History": [
  null,
  "Verlauf"
 ],
 "Host path": [
  null,
  "Host-Pfad"
 ],
 "Host port": [
  null,
  "Host-Port"
 ],
 "Host port help": [
  null,
  "Hilfe zum Host-Port"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "IP-Adresse"
 ],
 "IP address help": [
  null,
  "Hilfe zur IP-Adresse"
 ],
 "Ideal for development": [
  null,
  ""
 ],
 "Ideal for running services": [
  null,
  ""
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Wenn die Host-IP auf 0.0.0.0 oder gar nicht gesetzt ist, wird der Port an alle IPs des Hosts gebunden."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Wenn der Host-Port nicht gesetzt ist, wird dem Container-Port ein zufälliger Port auf dem Host zugewiesen."
 ],
 "Ignore IP address if set statically": [
  null,
  "IP-Adresse ignorieren, wenn statisch festgelegt"
 ],
 "Ignore MAC address if set statically": [
  null,
  "MAC-Adresse ignorieren, wenn statisch festgelegt"
 ],
 "Image": [
  null,
  "Image"
 ],
 "Image name is not unique": [
  null,
  "Abbildname ist nicht eindeutig"
 ],
 "Image name is required": [
  null,
  "Abbildname ist erforderlich"
 ],
 "Image selection help": [
  null,
  "Abbildauswahl-Hilfe"
 ],
 "Images": [
  null,
  "Images"
 ],
 "Increase CPU shares": [
  null,
  "CPU-Anteile erhöhen"
 ],
 "Increase interval": [
  null,
  "Intervall erhöhen"
 ],
 "Increase maximum retries": [
  null,
  "Maximale Wiederholungsversuche erhöhen"
 ],
 "Increase memory": [
  null,
  "Speicher erhöhen"
 ],
 "Increase retries": [
  null,
  "Wiederholungsversuche erhöhen"
 ],
 "Increase start period": [
  null,
  "Startzeitraum erhöhen"
 ],
 "Increase timeout": [
  null,
  "Zeitüberschreitung erhöhen"
 ],
 "Integration": [
  null,
  "Integration"
 ],
 "Interval": [
  null,
  "Intervall"
 ],
 "Interval how often health check is run.": [
  null,
  "Intervall, in dem die Gesundheitsprüfung durchgeführt wird."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Ungültige Zeichen. Der Name darf nur Buchstaben, Zahlen und bestimmte Satzzeichen (_ . -) enthalten."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Alle temporären Kontrollpunktdateien behalten"
 ],
 "Key": [
  null,
  "Schlüssel"
 ],
 "Last 5 runs": [
  null,
  "Letzte 5 Durchläufe"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Nach dem Schreiben des Kontrollpunkts auf die Festplatte weiterlaufen lassen"
 ],
 "Loading details...": [
  null,
  "Details werden geladen ..."
 ],
 "Loading logs...": [
  null,
  "Protokolle werden geladen ..."
 ],
 "Loading...": [
  null,
  "Wird geladen ..."
 ],
 "Local": [
  null,
  "Lokal"
 ],
 "Local images": [
  null,
  "Lokale Abbilder"
 ],
 "Logs": [
  null,
  "Protokolle"
 ],
 "MAC address": [
  null,
  "MAC-Adresse"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "Maximale Versuche"
 ],
 "Memory": [
  null,
  "Speicher"
 ],
 "Memory limit": [
  null,
  "Speicher-Limit"
 ],
 "Memory unit": [
  null,
  "Speichereinheit"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Mehrere Tags für dieses Image vorhanden. Getagte Images zum Löschen auswählen."
 ],
 "Name": [
  null,
  "Name"
 ],
 "New container name": [
  null,
  "Neuer Containername"
 ],
 "New image name": [
  null,
  "Neuer Abbildname"
 ],
 "No": [
  null,
  "Nein"
 ],
 "No action": [
  null,
  ""
 ],
 "No containers": [
  null,
  "Keine Container"
 ],
 "No containers are using this image": [
  null,
  "Keine Container benutzen dieses Abbild"
 ],
 "No containers in this pod": [
  null,
  "Keine Container in diesem Pod"
 ],
 "No containers that match the current filter": [
  null,
  "Aktueller Filter passt auf keinen Container"
 ],
 "No environment variables specified": [
  null,
  "Keine Umgebungsvariablen angegeben"
 ],
 "No images": [
  null,
  "Keine Images"
 ],
 "No images found": [
  null,
  "Keine Abbilder gefunden"
 ],
 "No images that match the current filter": [
  null,
  "Aktueller Filter passt auf kein Image"
 ],
 "No label": [
  null,
  "Keine Bezeichnung"
 ],
 "No ports exposed": [
  null,
  "Keine offenen Ports"
 ],
 "No results for $0": [
  null,
  "Keine Ergebnisse für $0"
 ],
 "No running containers": [
  null,
  "Keine laufenden Container"
 ],
 "No volumes specified": [
  null,
  "Keine Volumen angegeben"
 ],
 "On failure": [
  null,
  "Bei einem Ausfall"
 ],
 "Only running": [
  null,
  "Nur laufenlassen"
 ],
 "Options": [
  null,
  "Optionen"
 ],
 "Owner": [
  null,
  "Eigentümer"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Fügen Sie eine oder mehrere Zeilen mit key=value Paaren in irgendein Feld ein für multiplen Import"
 ],
 "Pause": [
  null,
  "Anhalten"
 ],
 "Pause container when creating image": [
  null,
  "Container bei der Abbilderstellung pausieren"
 ],
 "Paused": [
  null,
  "Pausiert"
 ],
 "Podman containers": [
  null,
  "Podman-Container"
 ],
 "Podman service is not active": [
  null,
  "Podman-Service ist nicht aktiv"
 ],
 "Port mapping": [
  null,
  "Portzuordnung"
 ],
 "Ports": [
  null,
  "Ports"
 ],
 "Ports under 1024 can be mapped": [
  null,
  ""
 ],
 "Private": [
  null,
  "Privat"
 ],
 "Protocol": [
  null,
  "Protokoll"
 ],
 "Prune": [
  null,
  "Reduzieren"
 ],
 "Prune unused images": [
  null,
  "Reduzierung nicht benötigter Abbilder"
 ],
 "Pruning images": [
  null,
  "Reduziere Abbilder"
 ],
 "Pull latest image": [
  null,
  "Neuestes Image pullen"
 ],
 "Pulling": [
  null,
  "Herunterladen"
 ],
 "Read-only access": [
  null,
  "Nur-Lese-Zugriff"
 ],
 "Read-write access": [
  null,
  "Lese-/Schreibzugriff"
 ],
 "Remove item": [
  null,
  "Element entfernen"
 ],
 "Removing": [
  null,
  "Wird entfernt"
 ],
 "Rename": [
  null,
  "Umbenennen"
 ],
 "Rename container $0": [
  null,
  "Container $0 umbenennen"
 ],
 "Resource limits can be set": [
  null,
  ""
 ],
 "Restart": [
  null,
  "Neustart"
 ],
 "Restart policy": [
  null,
  "Neustartrichtlinie"
 ],
 "Restart policy help": [
  null,
  "Neustartrichtlinien-Hilfe"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Neustart-Richtlinie, die beim Beenden von Containern befolgt werden soll."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  ""
 ],
 "Restore": [
  null,
  "Wiederherstellen"
 ],
 "Restore container $0": [
  null,
  "Container $0 wiederherstellen"
 ],
 "Restore with established TCP connections": [
  null,
  "Wiederherstellung mit bestehenden TCP-Verbindungen"
 ],
 "Restricted by user account permissions": [
  null,
  ""
 ],
 "Resume": [
  null,
  "Fotfahren"
 ],
 "Retries": [
  null,
  "Wiederholungsversuche"
 ],
 "Retry another term.": [
  null,
  "Versuchen Sie einen anderen Begriff."
 ],
 "Run health check": [
  null,
  "Gesundheitsprüfung durchführen"
 ],
 "Running": [
  null,
  "Läuft"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Nach Name oder Beschreibung suchen"
 ],
 "Search by registry": [
  null,
  "Nach Registry suchen"
 ],
 "Search for": [
  null,
  "Suchen nach"
 ],
 "Search for an image": [
  null,
  "Nach einem Abbild suchen"
 ],
 "Search string or container location": [
  null,
  "Suchbegriff oder Containerort"
 ],
 "Searching...": [
  null,
  "Wird gesucht ..."
 ],
 "Searching: $0": [
  null,
  "Wird gesucht: $0"
 ],
 "Shared": [
  null,
  "Freigegeben"
 ],
 "Show": [
  null,
  "Anzeigen"
 ],
 "Show images": [
  null,
  "Abbilder anzeigen"
 ],
 "Show intermediate images": [
  null,
  "Zwischenabbilder anzeigen"
 ],
 "Show less": [
  null,
  "Weniger anzeigen"
 ],
 "Show more": [
  null,
  "Mehr anzeigen"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "Start": [
  null,
  "Starten"
 ],
 "Start period": [
  null,
  "Startzeitraum"
 ],
 "Start podman": [
  null,
  "Podman starten"
 ],
 "Start typing to look for images.": [
  null,
  "Zum Suchen nach Abbildern mit dem Tippen beginnen."
 ],
 "Started at": [
  null,
  "Gestartet am"
 ],
 "State": [
  null,
  "Zustand"
 ],
 "Status": [
  null,
  "Status"
 ],
 "Stop": [
  null,
  "Stoppen"
 ],
 "Stopped": [
  null,
  "Angehalten"
 ],
 "Support preserving established TCP connections": [
  null,
  "Unterstützung der Aufrechterhaltung bestehender TCP-Verbindungen"
 ],
 "System": [
  null,
  "System"
 ],
 "System Podman service is also available": [
  null,
  "System-Podman ist auch verfügbar"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Etikett"
 ],
 "Tags": [
  null,
  "Etiketten"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  ""
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Die maximal zulässige Zeit für den Abschluss der Gesundheitsprüfung, bevor ein Intervall als fehlgeschlagen gilt."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Die Anzahl der zulässigen Wiederholungsversuche, bevor eine Gesundheitsprüfung als ungesund gilt."
 ],
 "Timeout": [
  null,
  "Zeitüberschreitung"
 ],
 "Troubleshoot": [
  null,
  "Fehler suchen"
 ],
 "Type to filter…": [
  null,
  "Tippen zum filtern…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Abbildverlauf kann nicht geladen werden"
 ],
 "Unhealthy": [
  null,
  "Ungesund"
 ],
 "Up since $0": [
  null,
  "Läuft seit $0"
 ],
 "Use legacy Docker format": [
  null,
  "Veraltetes Docker-Format verwenden"
 ],
 "Used by": [
  null,
  "Benutzt von"
 ],
 "User": [
  null,
  "Benutzer"
 ],
 "User Podman service is also available": [
  null,
  "Benutzer Podman ist auch verfügbar"
 ],
 "User:": [
  null,
  "Benutzer:"
 ],
 "Value": [
  null,
  "Wert"
 ],
 "Volumes": [
  null,
  "Datenträger"
 ],
 "With terminal": [
  null,
  "Mit Terminal"
 ],
 "Writable": [
  null,
  "Beschreibbar"
 ],
 "container": [
  null,
  "container"
 ],
 "downloading": [
  null,
  "wird heruntergeladen"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "Host[:Port]/[Benutzer]/Container[:Tag]"
 ],
 "image": [
  null,
  "Image"
 ],
 "in": [
  null,
  "in"
 ],
 "n/a": [
  null,
  "n.v."
 ],
 "not available": [
  null,
  "nicht verfügbar"
 ],
 "pod group": [
  null,
  "Pod-Gruppe"
 ],
 "podman": [
  null,
  "podman"
 ],
 "ports": [
  null,
  "Ports"
 ],
 "seconds": [
  null,
  "Sekunden"
 ],
 "select all": [
  null,
  "Alles auswählen"
 ],
 "system": [
  null,
  "System"
 ],
 "unused": [
  null,
  "ungenutzt"
 ],
 "user:": [
  null,
  "Benutzer:"
 ],
 "volumes": [
  null,
  "Volumen"
 ]
});
