cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 ცალი კონტეინერი",
  "$0 კონტეინერი"
 ],
 "$0 image total, $1": [
  null,
  "$0 ცალი გამოსახულება, $1",
  "$0 გამოსახულება, $1"
 ],
 "$0 second": [
  null,
  "$0 წამი",
  "$0 წამი"
 ],
 "$0 unused image, $1": [
  null,
  "$0 ცალი გამოუყენებელი გამოსახულება, $1",
  "$0 გამოუყენებელი გამოსახულება, $1"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "ქმედება, რომელიც კონტეინერის არაჯანმრთელ მდომარეობაში გადასვლისას შესრულდება."
 ],
 "Add port mapping": [
  null,
  "პორტის ასახვის დამატება"
 ],
 "Add variable": [
  null,
  "ცვლადის დამატება"
 ],
 "Add volume": [
  null,
  "საცავის დამატება"
 ],
 "All": [
  null,
  "ყველა"
 ],
 "All registries": [
  null,
  "ყველა რეგისტრები"
 ],
 "Always": [
  null,
  "ყველთვის"
 ],
 "An error occurred": [
  null,
  "შეცდომა"
 ],
 "Author": [
  null,
  "ავტორი"
 ],
 "Automatically start podman on boot": [
  null,
  "podman-ის გაშვება სისტემის ჩატვირთვისას"
 ],
 "CPU": [
  null,
  "პროცესორი"
 ],
 "CPU Shares help": [
  null,
  "პროცესორის გაზიარების დახმარება"
 ],
 "CPU shares": [
  null,
  "CPU გაზიარება"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "CPU-ის ზიარები განსაზღვრავენ გაშვებულიკონტეინერების პრიორიტეტს. ნაგულისხმები პრიორიტეტი 1024-ის ტოლია. რაც მეტია რიცხვი, მით მეტია პრიორიტეტი; რაც ნაკლები -ნაკლები."
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Checking health": [
  null,
  "ჯანმრთელობის შემოწმება"
 ],
 "Checkpoint": [
  null,
  "საკონტროლო წერტილი"
 ],
 "Checkpoint and restore support": [
  null,
  "საკონტროლო წერტილის და აღდგენის მხარდაჭერა"
 ],
 "Checkpoint container $0": [
  null,
  "საკონტროლო წერტილის კონტეინერი ($0)"
 ],
 "Click to see published ports": [
  null,
  "დააწკაპუნეთ გამოჩენილი პორტების სანახავად"
 ],
 "Click to see volumes": [
  null,
  "დააწკაპუნეთ ტომების სანახავად"
 ],
 "Command": [
  null,
  "ბრძანება"
 ],
 "Comments": [
  null,
  "კომენტარები"
 ],
 "Commit": [
  null,
  "გადაცემა"
 ],
 "Commit container": [
  null,
  "კონტეინერის გაგზავნა"
 ],
 "Configured": [
  null,
  "მორგებულია"
 ],
 "Console": [
  null,
  "კონსოლი"
 ],
 "Container": [
  null,
  "კონტეინერი"
 ],
 "Container failed to be created": [
  null,
  "კონტეინერის შექმნის შეცდომა"
 ],
 "Container failed to be started": [
  null,
  "კონტეინერის გაშვების შეცდომა"
 ],
 "Container is not running": [
  null,
  "კონტეინერი გაშვებული არაა"
 ],
 "Container name": [
  null,
  "კონტეინერის სახელი"
 ],
 "Container name is required.": [
  null,
  "კონტეინერის სახელი აუცილებელია."
 ],
 "Container path": [
  null,
  "კონტეინერის ბილიკი"
 ],
 "Container port": [
  null,
  "კონტეინერის პორტი"
 ],
 "Containers": [
  null,
  "კონტეინერები"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "კონტეინერის ($0) მდგომარეობაზე დამყარებული ახალი გამოსახულების შექმნა."
 ],
 "Create and run": [
  null,
  "შექმნა და გაშვება"
 ],
 "Create container": [
  null,
  "კონტეინერის შექმნა"
 ],
 "Create container in $0": [
  null,
  "$0-ში კონტეინერის შექმნა"
 ],
 "Create container in pod": [
  null,
  "pod-ში კონტეინერის შექმნა"
 ],
 "Create pod": [
  null,
  "pod-ის შექმნა"
 ],
 "Created": [
  null,
  "შექმნილია"
 ],
 "Created by": [
  null,
  "ავტორი"
 ],
 "Decrease CPU shares": [
  null,
  "CPU გაზიარებების შემცირება"
 ],
 "Decrease interval": [
  null,
  "ინტერვალის შემცირება"
 ],
 "Decrease maximum retries": [
  null,
  "ცდების მაქსიმალური რაოდენობის შემცირება"
 ],
 "Decrease memory": [
  null,
  "მეხსიერების შემცირება"
 ],
 "Decrease retries": [
  null,
  "ცდების რაოდენობის შემცირება"
 ],
 "Decrease start period": [
  null,
  "გაშვების პერიოდის შემცირება"
 ],
 "Decrease timeout": [
  null,
  "მოლოდინის დროის შემცირება"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Delete $0": [
  null,
  "$0-ის წაშლა"
 ],
 "Delete $0?": [
  null,
  "წავშალო $0?"
 ],
 "Delete pod $0?": [
  null,
  "წავშალო პოდი $0?"
 ],
 "Delete tagged images": [
  null,
  "ჭდეებიანი გამოსახულებების წაშლა"
 ],
 "Delete unused system images:": [
  null,
  "სისტემის გამოუყენებელი გამოსახულებების წაშლა:"
 ],
 "Delete unused user images:": [
  null,
  "მომხმარებლის გამოუყენებელი გამოსახულებების წაშლა:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "კონტეინერის წაშლა მასში ყველა მონაცემს წაშლის."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "გაშვებული კონტეინერის წაშლა მასში ყველა მონაცემს წაშლის."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "ამ Pod-ის წაშლა ასევე წაშლის შემდეგ კონტეინერებს:"
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Disk space": [
  null,
  "ადგილი დისკზე"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Docker-ის ფორმატი ძალიან სასარგებლოა გამოსახულების Docker-თან ან Moby Engline-სთან გაზიარებისთვის"
 ],
 "Download": [
  null,
  "გადმოწერა"
 ],
 "Download new image": [
  null,
  "ახალი გამოსახულების გადმოწერა"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "ცარიელი პოდი $0 სამუდამოდ წაიშლება."
 ],
 "Entrypoint": [
  null,
  "შესავალი წერტილი"
 ],
 "Environment variables": [
  null,
  "გარემოს ცვლადები"
 ],
 "Error": [
  null,
  "შეცდომა"
 ],
 "Error message": [
  null,
  "შეცდომის შეტყობინება"
 ],
 "Error occurred while connecting console": [
  null,
  "კონსოლთან დაკავშირების შეცდომა"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "მაგ. თქვენი სახელი <yourname@example.com>"
 ],
 "Example: $0": [
  null,
  "მაგალითად: $0"
 ],
 "Exited": [
  null,
  "გამოსული"
 ],
 "Failed health run": [
  null,
  "ჯანმრთელობის შემოწმების შეცდომა"
 ],
 "Failed to checkpoint container $0": [
  null,
  "კონტეინერის ($0) საკონტროლო წერტილის შეცდომა"
 ],
 "Failed to clean up container": [
  null,
  "კონტეინერის გასუფთავების შეცდომა"
 ],
 "Failed to commit container $0": [
  null,
  "კონტეინერის ($0) გადაცემის შეცდომა"
 ],
 "Failed to create container $0": [
  null,
  "კონტეინერის ($0) შექმნის შეცდომა"
 ],
 "Failed to download image $0:$1": [
  null,
  "გამოსახულების ($0) გადმოწერის შეცდომა: $1"
 ],
 "Failed to force remove container $0": [
  null,
  "კონტეინერის ($0) წაშლის შეცდომა"
 ],
 "Failed to force remove image $0": [
  null,
  "გამოსახულების ($0) ძალით წაშლა შეუძლებელია"
 ],
 "Failed to force restart pod $0": [
  null,
  "Pod-ის ($0) ძალით რესტარტის შეცდომა"
 ],
 "Failed to force stop pod $0": [
  null,
  "Pod-ის ($0) ძალით გაჩერების შეცდომა"
 ],
 "Failed to pause container $0": [
  null,
  "კონტეინერის ($0) შეჩერების შეცდომა"
 ],
 "Failed to pause pod $0": [
  null,
  "Pod-ის ($0) შეჩერების შეცდომა"
 ],
 "Failed to prune unused images": [
  null,
  "გამოუყენებელი გამოსახულებების წაკვეთის შეცდომა"
 ],
 "Failed to pull image $0": [
  null,
  "გამოსახულების ($0) გამოთხოვნის შეცდომა"
 ],
 "Failed to remove container $0": [
  null,
  "კონტეინერის ($0) წაშლის შეცდომა"
 ],
 "Failed to remove image $0": [
  null,
  "გამოსახულების ($0) წაშლის შეცდომა"
 ],
 "Failed to rename container $0": [
  null,
  "კონტეინერის ($0) სახელის გადარქმევის შეცდომა"
 ],
 "Failed to restart container $0": [
  null,
  "კონტეინერის ($0) რესტარტის შეცდომა"
 ],
 "Failed to restart pod $0": [
  null,
  "Pod-ის ($0) რესტარტის შეცდომა"
 ],
 "Failed to restore container $0": [
  null,
  "კონტეინერის ($0) აღდგენის შეცდომა"
 ],
 "Failed to resume container $0": [
  null,
  "კონტეინერის ($0) გაგრძელების შეცდომა"
 ],
 "Failed to resume pod $0": [
  null,
  "Pod-ის ($0) გაგრძელების შეცდომა"
 ],
 "Failed to run container $0": [
  null,
  "კონტეინერის ($0) გაშვების შეცდომა"
 ],
 "Failed to run health check on container $0": [
  null,
  "კონტეინერის ($0) ჯანმრთელობის შემოწმების შეცდომა"
 ],
 "Failed to search for images.": [
  null,
  "გამოსახულებების ძებნის შეცდომა."
 ],
 "Failed to search for images: $0": [
  null,
  "გამოსახულების ძებნის შეცდომა: $0"
 ],
 "Failed to search for new images": [
  null,
  "ახალი გამოსახულებების ძებნის შეცდომა"
 ],
 "Failed to start container $0": [
  null,
  "კონტეინერის ($0) გაშვების შეცდომა"
 ],
 "Failed to start pod $0": [
  null,
  "pod-ს ($0) გაშვების შეცდომა"
 ],
 "Failed to stop container $0": [
  null,
  "კონტეინერის ($0) გაჩერების შეცდომა"
 ],
 "Failed to stop pod $0": [
  null,
  "pod-ის ($0) გაჩერების შეცდომა"
 ],
 "Failing streak": [
  null,
  "მრავალჯერადი წარუმატებლობა"
 ],
 "Failure action": [
  null,
  "ქმედება ავარიისას"
 ],
 "Force commit": [
  null,
  "ძალით გადაგზავნა"
 ],
 "Force delete": [
  null,
  "ძალით წაშლა"
 ],
 "Force delete pod $0?": [
  null,
  "წავშლო ძალით პოდი $0?"
 ],
 "Force restart": [
  null,
  "ძალით რესტარტი"
 ],
 "Force stop": [
  null,
  "ძალით გაჩერება"
 ],
 "GB": [
  null,
  "გბ"
 ],
 "Gateway": [
  null,
  "ნაგულისხმები რაუტერი"
 ],
 "Health check": [
  null,
  "ჯანმრთელობის შემოწმება"
 ],
 "Health check interval help": [
  null,
  "ჯანმრთელობის შემოწმების ინტერვალის დახმარება"
 ],
 "Health check retries help": [
  null,
  "ჯანმრთელობის შემოწმების ცდების რაოდენობის დახმარება"
 ],
 "Health check start period help": [
  null,
  "ჯანმრთელობის შემოწმების გაშვების პერიოდის დახმარება"
 ],
 "Health check timeout help": [
  null,
  "ჯანმრთელობის შემოწმების ვადის დახმარება"
 ],
 "Health failure check action help": [
  null,
  "ჯანმრთელობის შემოწმების ქმედების დახმარება"
 ],
 "Healthy": [
  null,
  "ჯანმრთელი"
 ],
 "Hide images": [
  null,
  "გამოსახულებების დამალვა"
 ],
 "Hide intermediate images": [
  null,
  "შუალედური გამოსახულებების დამალვა"
 ],
 "History": [
  null,
  "ისტორია"
 ],
 "Host path": [
  null,
  "ჰოსტის ბილიკი"
 ],
 "Host port": [
  null,
  "ჰოსტის პორტი"
 ],
 "Host port help": [
  null,
  "დახმარება ჰოსტის პორტის შესახებ"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP address": [
  null,
  "IP მისამართი"
 ],
 "IP address help": [
  null,
  "დახმარება IP მისამართის შესახებ"
 ],
 "Ideal for development": [
  null,
  "იდეალურია პროგრამირებისთვის"
 ],
 "Ideal for running services": [
  null,
  "იდეალურია სერვისების გასაშვებად"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "თუ ჰოსტის IP დაყენებულია 0.0.0.0-ზე ან საერთოდ არაა დაყენებული, პორტი ჰოსტზე არსებულ ყველა IP-ს მიებმება."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "თუ ჰოსტის პორტი დაყენებული არაა, კონტეინერის პორტი ჰოსტზე შემთხვევითად იქნება არჩეული."
 ],
 "Ignore IP address if set statically": [
  null,
  "სტატიკურად მინიჭებული IP მისამართის იგნორი"
 ],
 "Ignore MAC address if set statically": [
  null,
  "სტატიკურად მინიჭებული MAC მისამართის იგნორი"
 ],
 "Image": [
  null,
  "გამოსახულება"
 ],
 "Image name is not unique": [
  null,
  "ასლის სახელი უნიკალური არაა"
 ],
 "Image name is required": [
  null,
  "ასლის სახელი აუცილებელია"
 ],
 "Image selection help": [
  null,
  "დახმარება გამოსახულების არჩევის შესახებ"
 ],
 "Images": [
  null,
  "გამოსახულებები"
 ],
 "Increase CPU shares": [
  null,
  "CPU გაზიარებების გაზრდა"
 ],
 "Increase interval": [
  null,
  "ინტერვალის გაზრდა"
 ],
 "Increase maximum retries": [
  null,
  "ცდების მაქსიმალური რაოდენობის გაზრდა"
 ],
 "Increase memory": [
  null,
  "მეხსიერების გაზრდა"
 ],
 "Increase retries": [
  null,
  "ცდების რაოდენობის გაზრდა"
 ],
 "Increase start period": [
  null,
  "გაშვების პერიოდის გაზრდა"
 ],
 "Increase timeout": [
  null,
  "მოლოდინის დროის გაზრდა"
 ],
 "Integration": [
  null,
  "ინტეგრაცია"
 ],
 "Interval": [
  null,
  "ინტერვალი"
 ],
 "Interval how often health check is run.": [
  null,
  "ჯანმრთელობის შემოწმების გაშვების ინტერვალი."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "არასწორი სიმბოლოები. სახელი მხოლოდ ასოებს, ციფრებს და ზოგიერთ პუნქტუაციის ნიშანს (_,-) შეიძლება შეიცავდეს."
 ],
 "KB": [
  null,
  "კბ"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "საკონტროლო წერტილის ყველა დროებითი ფაილის შენახვა"
 ],
 "Key": [
  null,
  "გასაღები"
 ],
 "Last 5 runs": [
  null,
  "ბოლო 5 გაშვება"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "საკონტროლო წერტილის დისკზე ჩაწერის შემდეგ გაშვებულად დატოვება"
 ],
 "Loading details...": [
  null,
  "დეტალების ჩატვირთვა..."
 ],
 "Loading logs...": [
  null,
  "ჟურნალის ჩატვირთვა..."
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "Local": [
  null,
  "ლოკალური"
 ],
 "Local images": [
  null,
  "ლოკალური გამოსახულებები"
 ],
 "Logs": [
  null,
  "ჟურნალი"
 ],
 "MAC address": [
  null,
  "MAC მისამართი"
 ],
 "MB": [
  null,
  "მბ"
 ],
 "Maximum retries": [
  null,
  "ცდების მაქსიმალური რაოდენობა"
 ],
 "Memory": [
  null,
  "მეხსიერება"
 ],
 "Memory limit": [
  null,
  "მეხსიერების ლიმიტი"
 ],
 "Memory unit": [
  null,
  "მეხსიერების ერთეული"
 ],
 "Mode": [
  null,
  "რეჟიმი"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "ამ გამოსახულებას მრავალი ჭდე გააჩნია. წასაშლელად მონიშნეთ ჭდეებიანი გამოსახულებები."
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "New container name": [
  null,
  "ახალი კონტეინერის სახელი"
 ],
 "New image name": [
  null,
  "ახალი გამოსახულების სახელი"
 ],
 "No": [
  null,
  "არა"
 ],
 "No action": [
  null,
  "ქმედების გარეშე"
 ],
 "No containers": [
  null,
  "კონტეიენერების გარეშე"
 ],
 "No containers are using this image": [
  null,
  "ამ გამოსახულებას არცერთი კონტეინერი არ იყენებს"
 ],
 "No containers in this pod": [
  null,
  "ამ Pod-ში კონტეინერები არაა"
 ],
 "No containers that match the current filter": [
  null,
  "მიმდინარე ფილტრს არცერთი კონტეინერი არ შეესაბამება"
 ],
 "No environment variables specified": [
  null,
  "გარემოს ცვლადი მითითებული არაა"
 ],
 "No images": [
  null,
  "გამოსახულებების გარეშე"
 ],
 "No images found": [
  null,
  "გამოსახულებების გარეშე"
 ],
 "No images that match the current filter": [
  null,
  "მიმდინარე ფილტრს არცერთი გამოსახულება არ შეესაბამება"
 ],
 "No label": [
  null,
  "ჭდეების გარეშე"
 ],
 "No ports exposed": [
  null,
  "პორტები გამოტანილი არაა"
 ],
 "No results for $0": [
  null,
  "პასუხების გარეშე $0-თვის"
 ],
 "No running containers": [
  null,
  "გაშვებული კონტეინერების გარეშე"
 ],
 "No volumes specified": [
  null,
  "საცავი მითითებული არაა"
 ],
 "On failure": [
  null,
  "შეცდომისას"
 ],
 "Only running": [
  null,
  "მხოლოდ გაშვებული"
 ],
 "Options": [
  null,
  "მორგება"
 ],
 "Owner": [
  null,
  "მფლობელი"
 ],
 "Owner help": [
  null,
  "მფლობელის დახმარება"
 ],
 "Passed health run": [
  null,
  "ჯანმრთელობის შემოწმება წარმატებულია"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "მრავალი შემოტანისთვის ველებში ჩასვით ერთი ან მეტი გასაღები=მნიშვნელობა-ის ტიპის წყვილები"
 ],
 "Pause": [
  null,
  "პაუზა"
 ],
 "Pause container when creating image": [
  null,
  "კონტეინერის შეჩერება გამოსახულების შექმნისას"
 ],
 "Paused": [
  null,
  "შეჩერებულია"
 ],
 "Pod failed to be created": [
  null,
  "Pod-ის შექმნის შეცდომა"
 ],
 "Pod name": [
  null,
  "Pod-ის სახელი"
 ],
 "Podman containers": [
  null,
  "Podman-ის კონტეინერები"
 ],
 "Podman service is not active": [
  null,
  "Podman-ის სერვისი აქტიური არაა"
 ],
 "Port mapping": [
  null,
  "პორტების ასახვა"
 ],
 "Ports": [
  null,
  "პორტები"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "შეგიძლიათ 1024-ზე ნაკლები ნომრის მქონე პორტის მიბმა"
 ],
 "Private": [
  null,
  "პირადი"
 ],
 "Protocol": [
  null,
  "პროტოკოლი"
 ],
 "Prune": [
  null,
  "შეკვეცა"
 ],
 "Prune unused images": [
  null,
  "გამოუყენებელი გამოსახულებების წაკვეთა"
 ],
 "Pruning images": [
  null,
  "გამოსახულებების წაკვეთა"
 ],
 "Pull latest image": [
  null,
  "უახლესი გამოსახულების წამოღება"
 ],
 "Pulling": [
  null,
  "გამოწევა"
 ],
 "Read-only access": [
  null,
  "მხოლოდ-კითხვის წვდომა"
 ],
 "Read-write access": [
  null,
  "ჩაწერა/წაკითხვის წვდომა"
 ],
 "Remove item": [
  null,
  "ელემენტის წაშლა"
 ],
 "Removing": [
  null,
  "წაშლა"
 ],
 "Rename": [
  null,
  "გადარქმევა"
 ],
 "Rename container $0": [
  null,
  "კონტეინერის სახელის გადარქმევა ($0)"
 ],
 "Resource limits can be set": [
  null,
  "შეგიძლიათ ლიმიტების დაყენება"
 ],
 "Restart": [
  null,
  "გადატვირთვა"
 ],
 "Restart policy": [
  null,
  "რესტარტის წესები"
 ],
 "Restart policy help": [
  null,
  "დახმარება რესტარტის წესების შესახებ"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "კონტეინერების მუშაობის დასასრულისას რესტარტის წესები."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "კონტეინერების მუშაობის დასრულებისას მისაყოლი გადატვირთის პოლიტიკა. კონტეინერების ავტომატური გაშვებისთვის linger-მა ყოველთვის შეიძლება არ იმუშაოს. მაგალითად, თუ მომხმარებელზე enccryptfs, systemd-homed, NFS ან 2FA გამოიყენება."
 ],
 "Restore": [
  null,
  "აღდგენა"
 ],
 "Restore container $0": [
  null,
  "კონტეინერის აღდგენა ($0)"
 ],
 "Restore with established TCP connections": [
  null,
  "დამყარებული TCP კავშირებით აღდგენა"
 ],
 "Restricted by user account permissions": [
  null,
  "შეზღუდულია მომხმარებლის ანგარიშის წვდომებით"
 ],
 "Resume": [
  null,
  "გაგრძელება"
 ],
 "Retries": [
  null,
  "თავიდან ცდები"
 ],
 "Retry another term.": [
  null,
  "სხვა სიტყვა სცადეთ."
 ],
 "Run health check": [
  null,
  "ჯანმრთელობის შემოწმების გაშვება"
 ],
 "Running": [
  null,
  "გაშვებულია"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "სახელით ან აღწერით ძებნა"
 ],
 "Search by registry": [
  null,
  "რეგისტრის ძებნა"
 ],
 "Search for": [
  null,
  "ძებნა"
 ],
 "Search for an image": [
  null,
  "გამოსახულების ძებნა"
 ],
 "Search string or container location": [
  null,
  "სტრიქონის ან კონტეინერის მდებარეობის ძებნა"
 ],
 "Searching...": [
  null,
  "ძებნა..."
 ],
 "Searching: $0": [
  null,
  "ძებნა: $0"
 ],
 "Shared": [
  null,
  "გაზიარებული"
 ],
 "Show": [
  null,
  "ჩვენება"
 ],
 "Show images": [
  null,
  "გამოსახულებების ჩვენება"
 ],
 "Show intermediate images": [
  null,
  "შუალედური გამოსახულებების ჩვენება"
 ],
 "Show less": [
  null,
  "ნაკლების ჩვენება"
 ],
 "Show more": [
  null,
  "მეტის ჩვენება"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "Start": [
  null,
  "დაწყება"
 ],
 "Start period": [
  null,
  "გაშვების პერიოდი"
 ],
 "Start podman": [
  null,
  "Podman-ის გაშვება"
 ],
 "Start typing to look for images.": [
  null,
  "გამოსახულებების მოსაძებნად დაიწყეთ მისი სახელის კრეფა."
 ],
 "Started at": [
  null,
  "გაშვების დრო"
 ],
 "State": [
  null,
  "მდგომარეობა"
 ],
 "Status": [
  null,
  "სტატუსი"
 ],
 "Stop": [
  null,
  "გაჩერება"
 ],
 "Stopped": [
  null,
  "გაჩერებულია"
 ],
 "Support preserving established TCP connections": [
  null,
  "დამყარებული TCP კავშირების შენარჩუნების მხარდაჭერა"
 ],
 "System": [
  null,
  "სისტემა"
 ],
 "System Podman service is also available": [
  null,
  "ასევე ხელმისაწვდომია Podman-ის სისტემური სერვისი"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "ჭდე"
 ],
 "Tags": [
  null,
  "ჭდეები"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "კონტეინერის მოსარგებად საჭირო ინიციალიზაციის დრო."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "მაქსიმალური დრო ჯანმრთელობის შესამოწმებლად. ამ ინტერვალის გასვლის შემდეგ შემოწმება შეცდომის მქონედ ითვლება."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "ცდების რაოდენობა, რის შემდეგაც ჯანმრთელობის შემოწმება ავარიულად ითვლება."
 ],
 "Timeout": [
  null,
  "დროის ამოწურვა"
 ],
 "Troubleshoot": [
  null,
  "პრობლემების პოვნა"
 ],
 "Type to filter…": [
  null,
  "გაფილტვრისთვის აკრიფეთ…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "გამოსახულების ისტორიის ჩატვირთვის შეცდომა"
 ],
 "Unhealthy": [
  null,
  "ჯანმრთელი არაა"
 ],
 "Up since $0": [
  null,
  "$0 და ზემოთ"
 ],
 "Use legacy Docker format": [
  null,
  "Docker-ის ძველი ფორმატის გამოყენება"
 ],
 "Used by": [
  null,
  "გამოიყენება"
 ],
 "User": [
  null,
  "მომხმარებელი"
 ],
 "User Podman service is also available": [
  null,
  "ასევე ხელმისაწვდომია Podman-ის მომხმარებლის სერვისი"
 ],
 "User:": [
  null,
  "მომხმარებელი:"
 ],
 "Value": [
  null,
  "მნიშვნელობა"
 ],
 "Volumes": [
  null,
  "საცავები"
 ],
 "With terminal": [
  null,
  "ტერმინალით"
 ],
 "Writable": [
  null,
  "ჩაწერადი"
 ],
 "container": [
  null,
  "კონტეინერი"
 ],
 "downloading": [
  null,
  "გადმოწერა"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "ჰოსტი[:პორტი]/[მომხმარებელი]/კონტეინერი[:ჭდე]"
 ],
 "image": [
  null,
  "გამოსახულება"
 ],
 "in": [
  null,
  "-ში"
 ],
 "n/a": [
  null,
  "ა/მ"
 ],
 "not available": [
  null,
  "ხელმიუწვდომელია"
 ],
 "pod group": [
  null,
  "pod-ების ჯგუფი"
 ],
 "podman": [
  null,
  "podman"
 ],
 "ports": [
  null,
  "პორტები"
 ],
 "seconds": [
  null,
  "წამი"
 ],
 "select all": [
  null,
  "ყველას მონიშვნა"
 ],
 "system": [
  null,
  "სისტემა"
 ],
 "unused": [
  null,
  "გამოუყენებელი"
 ],
 "user:": [
  null,
  "მომხმარებელი:"
 ],
 "volumes": [
  null,
  "ტომები"
 ]
});
