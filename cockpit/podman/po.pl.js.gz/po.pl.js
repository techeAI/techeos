cockpit.locale({
 "": {
  "plural-forms": (n) => n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "pl",
  "language-direction": "ltr"
 },
 "$0 container": [
  null,
  "$0 kontener",
  "$0 kontenery",
  "$0 kontenerów"
 ],
 "$0 image total, $1": [
  null,
  "$0 obraz, $1",
  "$0 obrazy razem, $1",
  "$0 obrazów razem, $1"
 ],
 "$0 second": [
  null,
  "$0 sekunda",
  "$0 sekundy",
  "$0 sekund"
 ],
 "$0 unused image, $1": [
  null,
  "$0 nieużywany obraz, $1",
  "$0 nieużywane obrazy, $1",
  "$0 nieużywanych obrazów, $1"
 ],
 "Action to take once the container transitions to an unhealthy state.": [
  null,
  "Działanie podejmowane po przejściu kontenera do niezdrowego stanu."
 ],
 "Add port mapping": [
  null,
  "Dodaj mapowanie portów"
 ],
 "Add variable": [
  null,
  "Dodaj zmienną"
 ],
 "Add volume": [
  null,
  "Dodaj wolumin"
 ],
 "All": [
  null,
  "Wszystko"
 ],
 "All registries": [
  null,
  "Wszystkie rejestry"
 ],
 "Always": [
  null,
  "Zawsze"
 ],
 "An error occurred": [
  null,
  "Wystąpił błąd"
 ],
 "Author": [
  null,
  "Autor"
 ],
 "Automatically start podman on boot": [
  null,
  "Automatyczne włączanie usługi podman podczas uruchamiania"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "CPU Shares help": [
  null,
  "Pomoc udziałów procesora"
 ],
 "CPU shares": [
  null,
  "Udziały procesora"
 ],
 "CPU shares determine the priority of running containers. Default priority is 1024. A higher number prioritizes this container. A lower number decreases priority.": [
  null,
  "Udziały procesora ustalają priorytety uruchomionych kontenerów. Domyślny priorytet to 1024. Wyższa liczba zwiększa priorytet danego kontenera. Mniejsza liczba zmniejsza priorytet."
 ],
 "Cancel": [
  null,
  "Anuluj"
 ],
 "Checking health": [
  null,
  "Sprawdzanie zdrowia"
 ],
 "Checkpoint": [
  null,
  "Punkt kontrolny"
 ],
 "Checkpoint and restore support": [
  null,
  "Obsługa punktu kontrolnego i przywracania"
 ],
 "Checkpoint container $0": [
  null,
  "Kontener punktu kontrolnego $0"
 ],
 "Click to see published ports": [
  null,
  "Kliknięcie wyświetli opublikowane porty"
 ],
 "Click to see volumes": [
  null,
  "Kliknięcie wyświetli woluminy"
 ],
 "Command": [
  null,
  "Polecenie"
 ],
 "Comments": [
  null,
  "Komentarze"
 ],
 "Commit": [
  null,
  "Zatwierdź"
 ],
 "Commit container": [
  null,
  "Zatwierdź kontener"
 ],
 "Configured": [
  null,
  "Skonfigurowane"
 ],
 "Console": [
  null,
  "Konsola"
 ],
 "Container": [
  null,
  "Kontener"
 ],
 "Container failed to be created": [
  null,
  "Utworzenie kontenera się nie powiodło"
 ],
 "Container failed to be started": [
  null,
  "Uruchomienie kontenera się nie powiodło"
 ],
 "Container is not running": [
  null,
  "Kontener nie jest uruchomiony"
 ],
 "Container name": [
  null,
  "Nazwa kontenera"
 ],
 "Container name is required.": [
  null,
  "Wymagana jest nazwa kontenera."
 ],
 "Container path": [
  null,
  "Ścieżka do kontenera"
 ],
 "Container port": [
  null,
  "Port kontenera"
 ],
 "Containers": [
  null,
  "Kontenery"
 ],
 "Create": [
  null,
  "Utwórz"
 ],
 "Create a new image based on the current state of the $0 container.": [
  null,
  "Utwórz nowy obraz na podstawie obecnego stanu kontenera $0."
 ],
 "Create and run": [
  null,
  "Utwórz i uruchom"
 ],
 "Create container": [
  null,
  "Utwórz kontener"
 ],
 "Create container in $0": [
  null,
  "Utwórz kontener w $0"
 ],
 "Create container in pod": [
  null,
  "Utwórz kontener w pojemniku"
 ],
 "Create pod": [
  null,
  "Utwórz pojemnik"
 ],
 "Created": [
  null,
  "Utworzono"
 ],
 "Created by": [
  null,
  "Utworzony przez"
 ],
 "Decrease CPU shares": [
  null,
  "Zmniejsz udziały procesora"
 ],
 "Decrease interval": [
  null,
  "Zmniejsz odstęp"
 ],
 "Decrease maximum retries": [
  null,
  "Zmniejsz maksymalną liczbę ponownych prób"
 ],
 "Decrease memory": [
  null,
  "Zmniejsz pamięć"
 ],
 "Decrease retries": [
  null,
  "Zmniejsz liczbę ponownych prób"
 ],
 "Decrease start period": [
  null,
  "Zmniejsz okres uruchamiania"
 ],
 "Decrease timeout": [
  null,
  "Zmniejsz czas oczekiwania"
 ],
 "Delete": [
  null,
  "Usuń"
 ],
 "Delete $0": [
  null,
  "Usuń $0"
 ],
 "Delete $0?": [
  null,
  "Usunąć $0?"
 ],
 "Delete pod $0?": [
  null,
  "Usunąć pojemnik $0?"
 ],
 "Delete tagged images": [
  null,
  "Usuń oznaczone obrazy"
 ],
 "Delete unused system images:": [
  null,
  "Usunięcie nieużywanych obrazów systemowych:"
 ],
 "Delete unused user images:": [
  null,
  "Usunięcie nieużywanych obrazów użytkownika:"
 ],
 "Deleting a container will erase all data in it.": [
  null,
  "Usunięcie kontenera spowoduje usunięcie wszystkich zawartych na nim danych."
 ],
 "Deleting a running container will erase all data in it.": [
  null,
  "Usunięcie uruchomionego kontenera spowoduje usunięcie wszystkich zawartych na nim danych."
 ],
 "Deleting this pod will remove the following containers:": [
  null,
  "Usunięcie tego pojemnika spowoduje usunięcie tych kontenerów:"
 ],
 "Details": [
  null,
  "Szczegóły"
 ],
 "Disk space": [
  null,
  "Miejsce na dysku"
 ],
 "Docker format is useful when sharing the image with Docker or Moby Engine": [
  null,
  "Format Docker jest przydatny podczas udostępniania obrazu za pomocą Dockera lub Moby Engine"
 ],
 "Download": [
  null,
  "Pobierz"
 ],
 "Download new image": [
  null,
  "Pobierz nowy obraz"
 ],
 "Empty pod $0 will be permanently removed.": [
  null,
  "Pusty pojemnik $0 zostanie trwale usunięty."
 ],
 "Entrypoint": [
  null,
  "Punkt wejścia"
 ],
 "Environment variables": [
  null,
  "Zmienne środowiskowe"
 ],
 "Error": [
  null,
  "Błąd"
 ],
 "Error message": [
  null,
  "Komunikat o błędzie"
 ],
 "Error occurred while connecting console": [
  null,
  "Wystąpił błąd podczas łączenia konsoli"
 ],
 "Example, Your Name <yourname@example.com>": [
  null,
  "Przykład, Imię Nazwisko <imięnazwisko@example.com>"
 ],
 "Example: $0": [
  null,
  "Przykład: $0"
 ],
 "Exited": [
  null,
  "Zakończono"
 ],
 "Failed health run": [
  null,
  "Niepomyślny wynik sprawdzania zdrowia"
 ],
 "Failed to checkpoint container $0": [
  null,
  "Punkt kontrolny kontenera $0 się nie powiódł"
 ],
 "Failed to clean up container": [
  null,
  "Wyczyszczenie kontenera się nie powiodło"
 ],
 "Failed to commit container $0": [
  null,
  "Zatwierdzenie kontenera $0 się nie powiodło"
 ],
 "Failed to create container $0": [
  null,
  "Utworzenie kontenera $0 się nie powiodło"
 ],
 "Failed to download image $0:$1": [
  null,
  "Pobranie obrazu $0:$1 się nie powiodło"
 ],
 "Failed to force remove container $0": [
  null,
  "Wymuszenie usunięcia kontenera $0 się nie powiodło"
 ],
 "Failed to force remove image $0": [
  null,
  "Wymuszenie usunięcia obrazu $0 się nie powiodło"
 ],
 "Failed to force restart pod $0": [
  null,
  "Wymuszenie ponownego uruchomienia pojemnika $0 się nie powiodło"
 ],
 "Failed to force stop pod $0": [
  null,
  "Wymuszenie zatrzymania pojemnika $0 się nie powiodło"
 ],
 "Failed to pause container $0": [
  null,
  "Wstrzymanie kontenera $0 się nie powiodło"
 ],
 "Failed to pause pod $0": [
  null,
  "Wstrzymanie pojemnika $0 się nie powiodło"
 ],
 "Failed to prune unused images": [
  null,
  "Wyczyszczenie nieużywanych obrazów się nie powiodło"
 ],
 "Failed to pull image $0": [
  null,
  "Pobranie obrazu $0 się nie powiodło"
 ],
 "Failed to remove container $0": [
  null,
  "Usunięcie kontenera $0 się nie powiodło"
 ],
 "Failed to remove image $0": [
  null,
  "Usunięcie obrazu $0 się nie powiodło"
 ],
 "Failed to rename container $0": [
  null,
  "Zmiana nazwy kontenera $0 się nie powiodła"
 ],
 "Failed to restart container $0": [
  null,
  "Ponowne uruchomienie kontenera $0 się nie powiodło"
 ],
 "Failed to restart pod $0": [
  null,
  "Ponowne uruchomienie pojemnika $0 się nie powiodło"
 ],
 "Failed to restore container $0": [
  null,
  "Przywrócenie kontenera $0 się nie powiodło"
 ],
 "Failed to resume container $0": [
  null,
  "Wznowienie kontenera $0 się nie powiodło"
 ],
 "Failed to resume pod $0": [
  null,
  "Wznowienie pojemnika $0 się nie powiodło"
 ],
 "Failed to run container $0": [
  null,
  "Uruchomienie kontenera $0 się nie powiodło"
 ],
 "Failed to run health check on container $0": [
  null,
  "Wykonanie sprawdzania zdrowia na kontenerze $0 się nie powiodło"
 ],
 "Failed to search for images.": [
  null,
  "Wyszukanie obrazów się nie powiodło."
 ],
 "Failed to search for images: $0": [
  null,
  "Wyszukanie obrazów się nie powiodło: $0"
 ],
 "Failed to search for new images": [
  null,
  "Wyszukanie nowych obrazów się nie powiodło"
 ],
 "Failed to start container $0": [
  null,
  "Uruchomienie kontenera $0 się nie powiodło"
 ],
 "Failed to start pod $0": [
  null,
  "Uruchomienie pojemnika $0 się nie powiodło"
 ],
 "Failed to stop container $0": [
  null,
  "Zatrzymanie kontenera $0 się nie powiodło"
 ],
 "Failed to stop pod $0": [
  null,
  "Zatrzymanie pojemnika $0 się nie powiodło"
 ],
 "Failing streak": [
  null,
  "Wielokrotne niepowodzenia"
 ],
 "Failure action": [
  null,
  "Działanie niepowodzenia"
 ],
 "Force commit": [
  null,
  "Wymuś zatwierdzenie"
 ],
 "Force delete": [
  null,
  "Wymuś usunięcie"
 ],
 "Force delete pod $0?": [
  null,
  "Wymusić usunięcie pojemnika $0?"
 ],
 "Force restart": [
  null,
  "Wymuś ponowne uruchomienie"
 ],
 "Force stop": [
  null,
  "Wymuś zatrzymanie"
 ],
 "GB": [
  null,
  "GB"
 ],
 "Gateway": [
  null,
  "Brama"
 ],
 "Health check": [
  null,
  "Sprawdzanie zdrowia"
 ],
 "Health check interval help": [
  null,
  "Pomoc odstępów między sprawdzaniem zdrowia"
 ],
 "Health check retries help": [
  null,
  "Pomoc ponownych prób sprawdzania zdrowia"
 ],
 "Health check start period help": [
  null,
  "Pomoc okresu uruchamiania sprawdzania zdrowia"
 ],
 "Health check timeout help": [
  null,
  "Pomoc czasu oczekiwania sprawdzania zdrowia"
 ],
 "Health failure check action help": [
  null,
  "Pomoc działania niepowodzenia sprawdzania zdrowia"
 ],
 "Healthy": [
  null,
  "Zdrowy"
 ],
 "Hide images": [
  null,
  "Ukryj obrazy"
 ],
 "Hide intermediate images": [
  null,
  "Ukryj pośrednie obrazy"
 ],
 "History": [
  null,
  "Historia"
 ],
 "Host path": [
  null,
  "Ścieżka do gospodarza"
 ],
 "Host port": [
  null,
  "Port gospodarza"
 ],
 "Host port help": [
  null,
  "Pomoc portu gospodarza"
 ],
 "ID": [
  null,
  "Identyfikator"
 ],
 "IP address": [
  null,
  "Adres IP"
 ],
 "IP address help": [
  null,
  "Pomoc adresu IP"
 ],
 "Ideal for development": [
  null,
  "Doskonałe dla programistów"
 ],
 "Ideal for running services": [
  null,
  "Doskonałe do uruchamiania usług"
 ],
 "If host IP is set to 0.0.0.0 or not set at all, the port will be bound on all IPs on the host.": [
  null,
  "Jeśli adres IP gospodarza jest ustawiony na 0.0.0.0 lub nie jest ustawiony, to port będzie dowiązany do wszystkich adresów IP w gospodarzu."
 ],
 "If the host port is not set the container port will be randomly assigned a port on the host.": [
  null,
  "Jeśli port gospodarza nie jest ustawiony, to do portu kontenera będzie losowo przydzielany port na gospodarzu."
 ],
 "Ignore IP address if set statically": [
  null,
  "Ignorowanie adresu IP, jeśli jest ustawiony statycznie"
 ],
 "Ignore MAC address if set statically": [
  null,
  "Ignorowanie adresu MAC, jeśli jest ustawiony statycznie"
 ],
 "Image": [
  null,
  "Obraz"
 ],
 "Image name is not unique": [
  null,
  "Nazwa obrazu nie jest unikalna"
 ],
 "Image name is required": [
  null,
  "Nazwa obrazu jest wymagana"
 ],
 "Image selection help": [
  null,
  "Pomoc przy wyborze obrazu"
 ],
 "Images": [
  null,
  "Obrazy"
 ],
 "Increase CPU shares": [
  null,
  "Zwiększ udziały procesora"
 ],
 "Increase interval": [
  null,
  "Zwiększ odstęp"
 ],
 "Increase maximum retries": [
  null,
  "Zwiększ maksymalną liczbę ponownych prób"
 ],
 "Increase memory": [
  null,
  "Zwiększ pamięć"
 ],
 "Increase retries": [
  null,
  "Zwiększ liczbę ponownych prób"
 ],
 "Increase start period": [
  null,
  "Zwiększ okres uruchamiania"
 ],
 "Increase timeout": [
  null,
  "Zwiększ czas oczekiwania"
 ],
 "Integration": [
  null,
  "Integracja"
 ],
 "Interval": [
  null,
  "Odstęp"
 ],
 "Interval how often health check is run.": [
  null,
  "Odstęp między wykonywaniem sprawdzania zdrowia."
 ],
 "Invalid characters. Name can only contain letters, numbers, and certain punctuation (_ . -).": [
  null,
  "Nieprawidłowe znaki. Nazwa może zawierać tylko litery, cyfry i część znaków interpunkcyjnych (_ . -)."
 ],
 "KB": [
  null,
  "KB"
 ],
 "Keep all temporary checkpoint files": [
  null,
  "Przechowywanie wszystkich tymczasowych plików punktów kontrolnych"
 ],
 "Key": [
  null,
  "Klucz"
 ],
 "Last 5 runs": [
  null,
  "Ostatnie 5 razy"
 ],
 "Leave running after writing checkpoint to disk": [
  null,
  "Bez wyłączania po zapisaniu punktu kontrolnego na dysku"
 ],
 "Loading details...": [
  null,
  "Wczytywanie szczegółów…"
 ],
 "Loading logs...": [
  null,
  "Wczytywanie dzienników…"
 ],
 "Loading...": [
  null,
  "Wczytywanie…"
 ],
 "Local": [
  null,
  "Lokalne"
 ],
 "Local images": [
  null,
  "Lokalne obrazy"
 ],
 "Logs": [
  null,
  "Dzienniki"
 ],
 "MAC address": [
  null,
  "Adres MAC"
 ],
 "MB": [
  null,
  "MB"
 ],
 "Maximum retries": [
  null,
  "Maksymalna liczba ponownych prób"
 ],
 "Memory": [
  null,
  "Pamięć"
 ],
 "Memory limit": [
  null,
  "Ograniczenie pamięci"
 ],
 "Memory unit": [
  null,
  "Jednostka pamięci"
 ],
 "Mode": [
  null,
  "Tryb"
 ],
 "Multiple tags exist for this image. Select the tagged images to delete.": [
  null,
  "Dla tego obrazu istnieje wiele etykiet. Proszę wybrać oznaczone obrazy do usunięcia."
 ],
 "Name": [
  null,
  "Nazwa"
 ],
 "New container name": [
  null,
  "Nowa nazwa kontenera"
 ],
 "New image name": [
  null,
  "Nazwa nowego obrazu"
 ],
 "No": [
  null,
  "Nie"
 ],
 "No action": [
  null,
  "Brak działania"
 ],
 "No containers": [
  null,
  "Brak kontenerów"
 ],
 "No containers are using this image": [
  null,
  "Żadne kontenery nie używają tego obrazu"
 ],
 "No containers in this pod": [
  null,
  "Brak kontenerów w tym pojemniku"
 ],
 "No containers that match the current filter": [
  null,
  "Żadne kontenery nie pasują do obecnego filtru"
 ],
 "No environment variables specified": [
  null,
  "Nie podano zmiennych środowiskowych"
 ],
 "No images": [
  null,
  "Brak obrazów"
 ],
 "No images found": [
  null,
  "Nie odnaleziono obrazów"
 ],
 "No images that match the current filter": [
  null,
  "Żadne obrazy nie pasują do obecnego filtru"
 ],
 "No label": [
  null,
  "Brak etykiety"
 ],
 "No ports exposed": [
  null,
  "Brak eksponowanych portów"
 ],
 "No results for $0": [
  null,
  "Brak wyników dla zapytania „$0”"
 ],
 "No running containers": [
  null,
  "Brak uruchomionych kontenerów"
 ],
 "No volumes specified": [
  null,
  "Nie podano woluminów"
 ],
 "On failure": [
  null,
  "Przy niepowodzeniu"
 ],
 "Only running": [
  null,
  "Tylko uruchomione"
 ],
 "Options": [
  null,
  "Opcje"
 ],
 "Owner": [
  null,
  "Właściciel"
 ],
 "Owner help": [
  null,
  "Pomoc na temat właściciela"
 ],
 "Passed health run": [
  null,
  "Pomyślny wynik sprawdzania zdrowia"
 ],
 "Paste one or more lines of key=value pairs into any field for bulk import": [
  null,
  "Należy wkleić jeden lub więcej wierszy par klucz=wartość do dowolnego pola, aby zaimportować hurtowo"
 ],
 "Pause": [
  null,
  "Wstrzymaj"
 ],
 "Pause container when creating image": [
  null,
  "Wstrzymaj kontener podczas tworzenia obrazu"
 ],
 "Paused": [
  null,
  "Wstrzymane"
 ],
 "Pod failed to be created": [
  null,
  "Utworzenie pojemnika się nie powiodło"
 ],
 "Pod name": [
  null,
  "Nazwa pojemnika"
 ],
 "Podman containers": [
  null,
  "Kontenery Podman"
 ],
 "Podman service is not active": [
  null,
  "Usługa Podman nie jest aktywna"
 ],
 "Port mapping": [
  null,
  "Mapowanie portów"
 ],
 "Ports": [
  null,
  "Porty"
 ],
 "Ports under 1024 can be mapped": [
  null,
  "Można mapować porty poniżej 1024"
 ],
 "Private": [
  null,
  "Prywatne"
 ],
 "Protocol": [
  null,
  "Protokół"
 ],
 "Prune": [
  null,
  "Wyczyść"
 ],
 "Prune unused images": [
  null,
  "Wyczyść nieużywane obrazy"
 ],
 "Pruning images": [
  null,
  "Czyszczenie obrazów"
 ],
 "Pull latest image": [
  null,
  "Pobierz najnowszy obraz"
 ],
 "Pulling": [
  null,
  "Pobieranie"
 ],
 "Read-only access": [
  null,
  "Dostęp tylko do odczytu"
 ],
 "Read-write access": [
  null,
  "Dostęp do odczytu i zapisu"
 ],
 "Remove item": [
  null,
  "Usuń element"
 ],
 "Removing": [
  null,
  "Usuwanie"
 ],
 "Rename": [
  null,
  "Zmień nazwę"
 ],
 "Rename container $0": [
  null,
  "Zmień nazwę kontenera $0"
 ],
 "Resource limits can be set": [
  null,
  "Można ustawić ograniczenia zasobów"
 ],
 "Restart": [
  null,
  "Uruchom ponownie"
 ],
 "Restart policy": [
  null,
  "Zasada ponownego uruchamiania"
 ],
 "Restart policy help": [
  null,
  "Pomoc zasady ponownego uruchamiania"
 ],
 "Restart policy to follow when containers exit.": [
  null,
  "Zasada ponownego uruchamiania używana podczas wyłączania kontenerów."
 ],
 "Restart policy to follow when containers exit. Using linger for auto-starting containers may not work in some circumstances, such as when ecryptfs, systemd-homed, NFS, or 2FA are used on a user account.": [
  null,
  "Zasada ponownego uruchamiania używana podczas wyłączania kontenerów. Używanie zwlekania do automatycznego uruchamiania kontenerów może nie działać w pewnych warunkach, takich jak podczas używania eCryptfs, systemd-homed, NFS lub uwierzytelniania dwuskładnikowego na koncie użytkownika."
 ],
 "Restore": [
  null,
  "Przywróć"
 ],
 "Restore container $0": [
  null,
  "Przywróć kontener $0"
 ],
 "Restore with established TCP connections": [
  null,
  "Przywróć z nawiązanymi połączeniami TCP"
 ],
 "Restricted by user account permissions": [
  null,
  "Ograniczone przez uprawnienia konta użytkownika"
 ],
 "Resume": [
  null,
  "Wznów"
 ],
 "Retries": [
  null,
  "Ponowne próby"
 ],
 "Retry another term.": [
  null,
  "Spróbuj innych słów."
 ],
 "Run health check": [
  null,
  "Wykonaj sprawdzanie zdrowia"
 ],
 "Running": [
  null,
  "Uruchomione"
 ],
 "SELinux": [
  null,
  "SELinux"
 ],
 "Search by name or description": [
  null,
  "Szukaj według nazwy lub opisu"
 ],
 "Search by registry": [
  null,
  "Szukaj według rejestru"
 ],
 "Search for": [
  null,
  "Szukaj"
 ],
 "Search for an image": [
  null,
  "Znajdź obraz"
 ],
 "Search string or container location": [
  null,
  "Szukaj ciągu lub położenia kontenera"
 ],
 "Searching...": [
  null,
  "Wyszukiwanie…"
 ],
 "Searching: $0": [
  null,
  "Wyszukiwanie: $0"
 ],
 "Shared": [
  null,
  "Współdzielone"
 ],
 "Show": [
  null,
  "Wyświetl"
 ],
 "Show images": [
  null,
  "Wyświetl obrazy"
 ],
 "Show intermediate images": [
  null,
  "Wyświetl pośrednie obrazy"
 ],
 "Show less": [
  null,
  "Wyświetl mniej"
 ],
 "Show more": [
  null,
  "Wyświetl więcej"
 ],
 "Size": [
  null,
  "Rozmiar"
 ],
 "Start": [
  null,
  "Uruchom"
 ],
 "Start period": [
  null,
  "Okres uruchamiania"
 ],
 "Start podman": [
  null,
  "Uruchom usługę podman"
 ],
 "Start typing to look for images.": [
  null,
  "Zacznij pisać, aby wyszukać obrazy."
 ],
 "Started at": [
  null,
  "Uruchomiono"
 ],
 "State": [
  null,
  "Stan"
 ],
 "Status": [
  null,
  "Stan"
 ],
 "Stop": [
  null,
  "Zatrzymaj"
 ],
 "Stopped": [
  null,
  "Zatrzymane"
 ],
 "Support preserving established TCP connections": [
  null,
  "Obsługa zachowywania nawiązanych połączeń TCP"
 ],
 "System": [
  null,
  "System"
 ],
 "System Podman service is also available": [
  null,
  "Dostępna jest także systemowa usługa Podman"
 ],
 "TCP": [
  null,
  "TCP"
 ],
 "Tag": [
  null,
  "Etykieta"
 ],
 "Tags": [
  null,
  "Etykiety"
 ],
 "The initialization time needed for a container to bootstrap.": [
  null,
  "Czas inicjacji wymagany do uruchomienia kontenera."
 ],
 "The maximum time allowed to complete the health check before an interval is considered failed.": [
  null,
  "Maksymalny dozwolony czas na ukończenie sprawdzania zdrowia, zanim odstęp jest uważany za niepomyślny."
 ],
 "The number of retries allowed before a healthcheck is considered to be unhealthy.": [
  null,
  "Dozwolona liczba ponownych prób, zanim wynik sprawdzania zdrowia jest uważany za niepomyślny."
 ],
 "Timeout": [
  null,
  "Czas oczekiwania"
 ],
 "Troubleshoot": [
  null,
  "Rozwiąż problem"
 ],
 "Type to filter…": [
  null,
  "Wyszukiwanie…"
 ],
 "UDP": [
  null,
  "UDP"
 ],
 "Unable to load image history": [
  null,
  "Nie można wczytać historii obrazu"
 ],
 "Unhealthy": [
  null,
  "Niezdrowy"
 ],
 "Up since $0": [
  null,
  "Uruchomione od $0"
 ],
 "Use legacy Docker format": [
  null,
  "Przestarzały format Docker"
 ],
 "Used by": [
  null,
  "Używane przez"
 ],
 "User": [
  null,
  "Użytkownik"
 ],
 "User Podman service is also available": [
  null,
  "Dostępna jest także usługa Podman użytkownika"
 ],
 "User:": [
  null,
  "Użytkownik:"
 ],
 "Value": [
  null,
  "Wartość"
 ],
 "Volumes": [
  null,
  "Woluminy"
 ],
 "With terminal": [
  null,
  "Z terminalem"
 ],
 "Writable": [
  null,
  "Zapisywalny"
 ],
 "container": [
  null,
  "kontener"
 ],
 "downloading": [
  null,
  "pobieranie"
 ],
 "host[:port]/[user]/container[:tag]": [
  null,
  "komputer[:port]/[użytkownik]/kontener[:etykieta]"
 ],
 "image": [
  null,
  "obraz"
 ],
 "in": [
  null,
  "w"
 ],
 "n/a": [
  null,
  "niedostępne"
 ],
 "not available": [
  null,
  "niedostępne"
 ],
 "pod group": [
  null,
  "grupa pojemników"
 ],
 "podman": [
  null,
  "podman"
 ],
 "ports": [
  null,
  "porty"
 ],
 "seconds": [
  null,
  "s"
 ],
 "select all": [
  null,
  "zaznacz wszystko"
 ],
 "system": [
  null,
  "systemowa"
 ],
 "unused": [
  null,
  "nieużywane"
 ],
 "user:": [
  null,
  "użytkownik:"
 ],
 "volumes": [
  null,
  "woluminy"
 ]
});
