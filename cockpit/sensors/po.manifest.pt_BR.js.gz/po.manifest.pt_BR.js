cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Sensors": [
  null,
  "Sensores"
 ]
});
