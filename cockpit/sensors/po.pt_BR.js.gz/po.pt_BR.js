cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "pt_BR",
  "language-direction": "ltr"
 },
 "Cockpit Sensors": [
  null,
  "Sensores para Cockpit"
 ],
 "Sensors": [
  null,
  "Sensores"
 ],
 "lm-sensors not found, you want install it ?": [
  null,
  "Não foi encontrado o lm-sensors, deseja instala-lo?"
 ],
 "this version of lm-sensors don't suport output sensors data!": [
  null,
  "Essa versão do lm-sensors não tem suporte para saida de dados!"
 ],
 "lm-sensors has a bug that converts all data to fahrenheit, including voltage, fans and etc.": [
  null,
  "lm-sensors tem um problema aonde ele converte todos os dados para fahrenheit, incluindo voltage, vetoinhas e etc."
 ],
 "Show temperature in Fahrenheit": [
  null,
  "Exibir temperatus em Fahrenheit"
 ],
 "Expand all cards": [
  null,
  "Expandir todos os cards"
 ],
 "Install": [
  null,
  "Instalar"
 ]
});
