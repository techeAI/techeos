cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "Cockpit Sensors": [
  null,
  "Cockpit Sensoren"
 ],
 "Sensors": [
  null,
  "Sensoren"
 ],
 "lm-sensors not found, you want install it ?": [
  null,
  "lm-sensors nicht gefunden, möchten Sie es installieren?"
 ],
 "this version of lm-sensors don't suport output sensors data!": [
  null,
  "diese Version von lm-sensors unterstützt keine Ausgabe von Sensordaten!"
 ],
 "lm-sensors has a bug that converts all data to fahrenheit, including voltage, fans and etc.": [
  null,
  "lm-sensors hat einen Fehler, der alle Daten in Fahrenheit umwandelt, einschließlich Spannung, Lüfter usw."
 ],
 "Show temperature in Fahrenheit": [
  null,
  "Temperatur in Fahrenheit anzeigen"
 ],
 "Expand all cards": [
  null,
  "Erweitern Sie alle Karten"
 ],
 "Install": [
  null,
  "Installieren"
 ]
});
