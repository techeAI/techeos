cockpit.locale({
 "": {
  "plural-forms": (n) => (n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2,
  "language": "cs",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 k dispozici ve výchozím umístění"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 k dispozici na hostiteli"
 ],
 "$0 CPU configuration": [
  null,
  "Nastavení procesoru $0"
 ],
 "$0 Network": [
  null,
  "$0 síť",
  "$0 sítě",
  "$0 sítí"
 ],
 "$0 Storage pool": [
  null,
  "$0 fond úložiště",
  "$0 fondy úložiště",
  "$0 fondů úložiště"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 nepodporuje bezobslužnou instalaci."
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 je k dispozici pro většinu operačních systémů. Pro instalaci vyhledejte v GNOME Software nebo spusťte následující:"
 ],
 "$0 memory adjustment": [
  null,
  "$0 úprava nastavení paměti"
 ],
 "$0 network": [
  null,
  "$0 síť"
 ],
 "$0 vCPU": [
  null,
  "$0 virt. procesor",
  "$0 virt. procesory",
  "$0 virt. procesorů"
 ],
 "$0 vCPU details": [
  null,
  "podrobnosti o virt. procesoru $0"
 ],
 "$0 virtual network interface settings": [
  null,
  "Nastavení virtuálního síťového rozhraní $0"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Na cíli bude spuštěna kopie virt. stroje a po jejím vypnutí zmizí. Mezitím, původní hostitel si ponechá svou kopii nastavení virt. stroje."
 ],
 "Access": [
  null,
  "Přístup"
 ],
 "Action": [
  null,
  "Akce"
 ],
 "Activate": [
  null,
  "Aktivovat"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Pokud chcete spravovat svazky, aktivujte fond úložiště"
 ],
 "Add": [
  null,
  "Přidat"
 ],
 "Add a DHCP static host entry": [
  null,
  "Přidat statickou DHCP položku pro hostitele"
 ],
 "Add disk": [
  null,
  "Přidat disk"
 ],
 "Add host device": [
  null,
  "Přidat zařízení hostitele"
 ],
 "Add network interface": [
  null,
  "Přidat síťové rozhraní"
 ],
 "Add shared directory": [
  null,
  "Přidat sdílenou složku"
 ],
 "Add virtual network interface": [
  null,
  "Přidat virtuální síťové rozhraní"
 ],
 "Add watchdog device type": [
  null,
  "Přidat typ zařízení resetátor"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Přidávání sdílených složek je možné pouze když je host vypnutý"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  "Přidání tohoto disku změní jeho přístupový režim na sdílený."
 ],
 "Additional": [
  null,
  "Další"
 ],
 "Address": [
  null,
  "Adresa"
 ],
 "Address not within subnet": [
  null,
  "Adresa nespadá do dané podsítě"
 ],
 "All": [
  null,
  "Vše"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Veškerá aktivita virt. stroje, včetně úložiště, bude dočasná. Dojde tedy ke ztrátě všech dat za dobu chodu na cílovém hostiteli."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Povolené znaky: ty z latinské abecedy (bez diakritiky), číslice a některá interpunkční znaménka (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Také smazat veškeré svazky v tomto fondu:"
 ],
 "Always attach": [
  null,
  "Vždy připojit"
 ],
 "Apply": [
  null,
  "Použít"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Automatizované instalace jsou k dispozici pouze při stahování obrazu nebo použití cloud-init."
 ],
 "Automatic": [
  null,
  "Automaticky"
 ],
 "Automation": [
  null,
  "Automatizace"
 ],
 "Autostart": [
  null,
  "Automatické spouštění"
 ],
 "Blocked": [
  null,
  "Blokované"
 ],
 "Boot order": [
  null,
  "Pořadí zavádění"
 ],
 "Boot order settings could not be saved": [
  null,
  "Nastavení pořadí zavádění se nepodařilo uložit"
 ],
 "Bus": [
  null,
  "Sběrnice"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD disk"
 ],
 "CPU": [
  null,
  "Procesor"
 ],
 "CPU configuration could not be saved": [
  null,
  "Nastavení procesoru se nepodařilo uložit"
 ],
 "CPU type": [
  null,
  "Typ procesoru"
 ],
 "Cache": [
  null,
  "Mezipaměť"
 ],
 "Cancel": [
  null,
  "Storno"
 ],
 "Capacity": [
  null,
  "Kapacita"
 ],
 "Change boot order": [
  null,
  "Změnit pořadí zavádění"
 ],
 "Change firmware": [
  null,
  "Změnit firmware"
 ],
 "Changes pending": [
  null,
  "Čekající změny"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Změny se projeví až po vypnutí virt. stroje"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "Změna nastavení v BIOS/EFI se u různých výrobců provádí různě. Zahrnuje stisknutí klávesové zkratky (ESC, F1, F12, Del) po zapnutí stroje. Zapněte nastavení nazvaná nějak jako „virtualization“, „VM“, „VMX“, „SVM“, „VTX“, „VTD“. Podrobnosti zjistíte z příručky k počítači (či jeho základní desce)."
 ],
 "Checking token validity...": [
  null,
  "Ověřování platnosti tokenu…"
 ],
 "Choose an operating system": [
  null,
  "Zvolte operační systém"
 ],
 "Class": [
  null,
  "Třída"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "Kliknutím na „Spustit vzdálený prohlížeč“ se stáhne soubor ve formátu .vv a spustí se $0."
 ],
 "Clone": [
  null,
  "Klonovat"
 ],
 "Close": [
  null,
  "Zavřít"
 ],
 "Cloud base image": [
  null,
  "Obraz Cloud Base"
 ],
 "Confirm this action": [
  null,
  "Potvrďte tuto akci"
 ],
 "Connect": [
  null,
  "Připojit"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "Připojte se libovolnou aplikací pro zobrazování přes následující protokoly"
 ],
 "Connecting": [
  null,
  "Připojuje se"
 ],
 "Connection": [
  null,
  "Spojení"
 ],
 "Console": [
  null,
  "Konzole"
 ],
 "Copy storage": [
  null,
  "Zkopírovat úložiště"
 ],
 "Cores per socket": [
  null,
  "Jader na patici"
 ],
 "Could not delete $0": [
  null,
  "$0 se nepodařilo smazat"
 ],
 "Could not delete all storage for $0": [
  null,
  "Nepodařilo se smazat veškerá úložiště pro $0"
 ],
 "Could not delete disk's storage": [
  null,
  "Nepodařilo se smazat úložiště daného disku"
 ],
 "Could not revert to snapshot": [
  null,
  "Nepodařilo se vrátit do podoby ze zachyceného stavu"
 ],
 "Crashed": [
  null,
  "Zhavarovalo"
 ],
 "Create": [
  null,
  "Vytvořit"
 ],
 "Create VM": [
  null,
  "Vytvořit virt. stroj"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Vytvořit virt. stroj naimportováním obrazu disku existující instalace virt. stroje"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Vytvořit virt. stroj z lokálního nebo sítového instalačního média"
 ],
 "Create a clone VM based on $0": [
  null,
  "Vytvořit klon virt. stroje založený na $0"
 ],
 "Create and edit": [
  null,
  "Vytvořit a upravit"
 ],
 "Create and run": [
  null,
  "Vytvořit a spustit"
 ],
 "Create new": [
  null,
  "Vytvořit nový"
 ],
 "Create new virtual machine": [
  null,
  "Vytvořit nový virtuální stroj"
 ],
 "Create new volume": [
  null,
  "Vytvořit nový svazek"
 ],
 "Create snapshot": [
  null,
  "Pořídit zachycený stav"
 ],
 "Create storage pool": [
  null,
  "Vytvořit fond úložiště"
 ],
 "Create storage volume": [
  null,
  "Vytvořit svazek úložiště"
 ],
 "Create virtual network": [
  null,
  "Vytvořit virtuální síť"
 ],
 "Create volume": [
  null,
  "Vytvořit svazek"
 ],
 "Creating VM": [
  null,
  "Vytváří se virt. stroj"
 ],
 "Creating VM $0": [
  null,
  "Vytváří se virt. stroj $0"
 ],
 "Creation of VM $0 failed": [
  null,
  "Vytvoření virt. stroje $0 se nezdařilo"
 ],
 "Creation time": [
  null,
  "Okamžik vytvoření"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Stávající"
 ],
 "Current allocation": [
  null,
  "Stávající přidělení"
 ],
 "Custom firmware: $0": [
  null,
  "Uživatelsky určený firmware: $0"
 ],
 "Custom path": [
  null,
  "Uživatelsky určený popis umístění"
 ],
 "DHCP Settings": [
  null,
  "Nastavení pro DHCP"
 ],
 "Deactivate": [
  null,
  "Deaktivovat"
 ],
 "Delete": [
  null,
  "Smazat"
 ],
 "Delete $0 VM?": [
  null,
  "Smazat $0 virt. stroj?"
 ],
 "Delete $0 storage pool?": [
  null,
  "Smazat fond úložiště $0?"
 ],
 "Delete $0 volume": [
  null,
  "Smazat $0 svazek",
  "Smazat $0 svazky",
  "Smazat $0 svazků"
 ],
 "Delete associated storage files:": [
  null,
  "Smazat související soubory úložiště:"
 ],
 "Delete network?": [
  null,
  "Smazat síť?"
 ],
 "Delete snapshot?": [
  null,
  "Smazat zachycený stav?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Smazání neaktivního fondu úložiště pouze zruší jeho definici. Obsah fondu samotný smazán nebude."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Mazání sdílených složek je možné pouze pokud je host vypnutý"
 ],
 "Description": [
  null,
  "Popis"
 ],
 "Desktop viewer": [
  null,
  "Desktopový prohlížeč"
 ],
 "Destination URI": [
  null,
  "Cílová URI"
 ],
 "Destination URI must not be empty": [
  null,
  "Cílovou URI je třeba vyplnit"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Před pokusem o smazání odpojte veškeré disky, které využívají tento fond, z virt. strojů."
 ],
 "Details": [
  null,
  "Podrobnosti"
 ],
 "Device": [
  null,
  "Zařízení"
 ],
 "Devices": [
  null,
  "Zařízení"
 ],
 "Disconnect": [
  null,
  "Odpojit"
 ],
 "Disconnected": [
  null,
  "Odpojeno"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Odpojeno od sériové konzole. Klikněte na tlačítko Připojit."
 ],
 "Disk": [
  null,
  "Disk"
 ],
 "Disk $0 could not be removed": [
  null,
  "Disk $0 nebylo možné odebrat"
 ],
 "Disk failed to be attached": [
  null,
  "Disk se nepodařilo připojit"
 ],
 "Disk failed to be created": [
  null,
  "Disk se nepodařilo vytvořit"
 ],
 "Disk identifier": [
  null,
  "Identifikátor disku"
 ],
 "Disk image": [
  null,
  "Obraz disku"
 ],
 "Disk image file": [
  null,
  "Soubor s obrazem disku"
 ],
 "Disk image path must not be empty": [
  null,
  "Popis umístění obrazu disku je třeba vyplnit"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Obrazy disků je možné uchovávat v domovské složce uživatele"
 ],
 "Disk settings could not be saved": [
  null,
  "Nastavení disku nebylo možné uložit"
 ],
 "Disk-only snapshot": [
  null,
  "Zachycený stav pouze disku"
 ],
 "Disks": [
  null,
  "Disky"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Nespouštějte tento virt. stroj na původním a cílovém hostiteli naráz."
 ],
 "Do nothing": [
  null,
  "Nedělat nic"
 ],
 "Domain has crashed": [
  null,
  "Doména zhavarovala"
 ],
 "Domain is blocked on resource": [
  null,
  "Doména je blokována kvůli prostředku"
 ],
 "Download an OS": [
  null,
  "Stáhnout operační systém"
 ],
 "Download progress": [
  null,
  "Kolik už staženo"
 ],
 "Downloading image for VM $0": [
  null,
  "Stahuje se obraz pro virt. stroj $0"
 ],
 "Downloading: $0%": [
  null,
  "Stahování: $0%"
 ],
 "Dump core": [
  null,
  "Uložit výpis obsahu paměti"
 ],
 "Duration": [
  null,
  "Trvání"
 ],
 "Dying": [
  null,
  "Vypíná se"
 ],
 "Edit": [
  null,
  "Upravit"
 ],
 "Edit $0 attributes": [
  null,
  "Upravit atributy $0"
 ],
 "Edit watchdog device type": [
  null,
  "Upravit typ zařízení resetátoru"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Upravování síťových rozhraní přechodných hostů není možné"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Upravování přechodných síťových rozhraní není možné"
 ],
 "Eject": [
  null,
  "Vysunout"
 ],
 "Eject disc from VM?": [
  null,
  "Vysunout disk z virt. stroje?"
 ],
 "Emulated machine": [
  null,
  "Emulovaný stroj"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "Zapněte podporu virtualizace v nastavení BIOS/EFI."
 ],
 "End": [
  null,
  "Konec"
 ],
 "End should not be empty": [
  null,
  "Konec je třeba vyplnit"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Pokud chcete zapnout bezobslužnou instalaci, zadejte informace o účtu správce (root) a/nebo uživatele."
 ],
 "Error checking token": [
  null,
  "Chyba při ověřování tokenu"
 ],
 "Example, $0": [
  null,
  "Příklad, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Existující obraz disku na souborovém systému hostitele"
 ],
 "Expand": [
  null,
  "Rozbalit"
 ],
 "Extended attributes": [
  null,
  "Rozšířené atributy"
 ],
 "Failed": [
  null,
  "Neúspěšné"
 ],
 "Failed to add shared directory": [
  null,
  "Nepodařilo se přidat sdílenou složku"
 ],
 "Failed to change firmware": [
  null,
  "Firmware se nepodařilo změnit"
 ],
 "Failed to clone VM $0": [
  null,
  "Nepodařilo se naklonovat virt. stroj $0"
 ],
 "Failed to configure watchdog": [
  null,
  "Nepodařilo se nastavit resetátor"
 ],
 "Failed to detach watchdog": [
  null,
  "Nepodařilo se odpojit resetátor"
 ],
 "Failed to fetch some resources": [
  null,
  "Nepodařilo se stáhnout si některé prostředky"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "Nepodařilo se zjistit IP adresy rozhraní nacházející se v $0"
 ],
 "Failed to rename VM $0": [
  null,
  "Nepodařilo se přejmenovat virt. stroj $0"
 ],
 "Failed to save network settings": [
  null,
  "Nepodařilo se uložit nastavení sítě"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Nepodařilo se odeslat kombinaci kláves Ctrl+Alt+$0 do virt. stroje $1"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Mělo by být zapnuto méně než maximální počet virtuálních procesorů."
 ],
 "File": [
  null,
  "Soubor"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Souborový systém $0 nebylo možné odebrat"
 ],
 "Filesystem directory": [
  null,
  "Složka v souborovém systému"
 ],
 "Filter by name": [
  null,
  "Filtrovat podle názvu"
 ],
 "Firmware": [
  null,
  "Firmware"
 ],
 "Force eject": [
  null,
  "Vynutit vysunutí"
 ],
 "Force reboot": [
  null,
  "Vynutit restart"
 ],
 "Force revert": [
  null,
  "Vynutit vrácení k předchozímu stavu"
 ],
 "Force shut down": [
  null,
  "Vynutit vypnutí"
 ],
 "Format": [
  null,
  "Formát"
 ],
 "Forward mode": [
  null,
  "Režim přeposílání"
 ],
 "Forwarding mode": [
  null,
  "Režim přeposílání"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Budou přestěhovány celé obrazy disků a paměť virt. domény. Přeneseny budou pouze obrazy nesdílených, zapisovatelných disků. Nepoužitá úložiště zůstanou po přestěhování v původním umístění."
 ],
 "General": [
  null,
  "Obecné"
 ],
 "Generate automatically": [
  null,
  "Vytvořit automaticky"
 ],
 "Get a new RHSM token.": [
  null,
  "Získat nový RHSM token."
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "Přejít na seznam virt. strojů"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Dobrá volba pro virtualizaci desktopu"
 ],
 "Gracefully shutdown": [
  null,
  "Vypnout prostřednictvím operačního systému"
 ],
 "Hardware virtualization is disabled": [
  null,
  "Hardwarová podpora virtualizace je vypnutá"
 ],
 "Hide additional options": [
  null,
  "Skrýt další možnosti"
 ],
 "Host": [
  null,
  "Hostitel"
 ],
 "Host device": [
  null,
  "Zařízení hostitele"
 ],
 "Host device could not be attached": [
  null,
  "Zařízení hostitele se nepodařilo připojit"
 ],
 "Host device will be removed from $0:": [
  null,
  "Zařízení hostitele bude odebráno z $0:"
 ],
 "Host devices": [
  null,
  "Zařízení hostitele"
 ],
 "Host name": [
  null,
  "Název počítače"
 ],
 "Host should not be empty": [
  null,
  "Hostitele je třeba vyplnit"
 ],
 "Hypervisor details": [
  null,
  "Podrobnosti o hypervizoru"
 ],
 "ID": [
  null,
  "Identif."
 ],
 "IP": [
  null,
  "IP adresa"
 ],
 "IP address": [
  null,
  "IP adresa"
 ],
 "IP address must not be empty": [
  null,
  "IP adresu je třeba vyplnit"
 ],
 "IP configuration": [
  null,
  "Nastavení pro IP protokol"
 ],
 "IPv4 address": [
  null,
  "IPv4 adresa"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  "IPv4 adresa nemůže být stejná jako identifikátor sítě"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "IPv4 adresa nemůže být stejná jako adresa všesměrového vysílání sítě"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 a IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4 síť je třeba vyplnit"
 ],
 "IPv4 only": [
  null,
  "Pouze IPv4"
 ],
 "IPv6 address": [
  null,
  "IPv6 adresa"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6 síť je třeba vyplnit"
 ],
 "IPv6 only": [
  null,
  "Pouze IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "Ideální pro virt. stroje v roli serverů"
 ],
 "Ideal networking support": [
  null,
  "Ideální podpora sítě"
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Může se stát, že identifikátor bude bez upozornění zkrácen na $0 znaků "
 ],
 "Idle": [
  null,
  "Nečinné"
 ],
 "Ignore": [
  null,
  "Ignorovat"
 ],
 "Import VM": [
  null,
  "Naimportovat virt. stroj"
 ],
 "Import a virtual machine": [
  null,
  "Naimportovat virtuální stroj"
 ],
 "Import and edit": [
  null,
  "Naimportovat a upravit"
 ],
 "Import and run": [
  null,
  "Naimportovat a spustit"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "Import obrazu se souborem, na kterém je založen, není podporováno"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "Ve většině uspořádání, macvtap nefunguje pro komunikaci hostitel-host."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  "Ve výchozím „vepa“ režimu je přepínání (switch) předáváno na externí ethernetový přepínač. Pokud přepínač VEPA neumí, komunikace mezi virtuálními stroji nebo mezi virtuálními stroji a jejich hostitelem není možná."
 ],
 "Initiator": [
  null,
  "Iniciátor"
 ],
 "Initiator IQN should not be empty": [
  null,
  "IQN název iniciátoru by měl být vyplněný"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Vložit nemaskovatelné přerušení"
 ],
 "Insert": [
  null,
  "Vložit"
 ],
 "Insert disc media": [
  null,
  "Vložit médium disku"
 ],
 "Install": [
  null,
  "Nainstalovat"
 ],
 "Installation source": [
  null,
  "Zdroj instalace"
 ],
 "Installation source must not be empty": [
  null,
  "Zdroj pro instalaci je třeba vyplnit"
 ],
 "Installation type": [
  null,
  "Typ instalace"
 ],
 "Interface": [
  null,
  "Rozhraní"
 ],
 "Interface type": [
  null,
  "Typ rozhraní"
 ],
 "Interface type help": [
  null,
  "Nápověda k typu rozhraní"
 ],
 "Invalid IPv4 address": [
  null,
  "Neplatná IPv4 adresa"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Neplatná IPv4 maska nebo délka předpony"
 ],
 "Invalid IPv6 address": [
  null,
  "Neplatná IPv6 adresa"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Neplatná IPv6 předpona"
 ],
 "Invalid filename": [
  null,
  "Neplatný název souboru"
 ],
 "Isolated network": [
  null,
  "Izolovaná síť"
 ],
 "LVM volume group": [
  null,
  "LVM skupina svazků"
 ],
 "Launch remote viewer": [
  null,
  "Spustit vzdálený prohlížeč"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Pokud si nepřejete vytvořit účet root, nevyplňujte heslo k němu"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Pokud si nepřejete vytvořit uživatelský účet, nevyplňujte heslo k němu"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Pokud si nepřejete nastavit heslo pro účet root, nevyplňujte ho"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt nenalezlo na hostiteli žádný obraz UEFI/OVMF firmware"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt nebo hypervizor nepodporuje UEFI"
 ],
 "Loading available network devices": [
  null,
  "Načítání sítových zařízení, která jsou k dispozici"
 ],
 "Loading resources": [
  null,
  "Načítání prostředků"
 ],
 "Loading...": [
  null,
  "Načítání…"
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Místní instalační médium (ISO obraz nebo instalační strom distribuce)"
 ],
 "Location": [
  null,
  "Umístění"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC adresa"
 ],
 "MAC address must not be empty": [
  null,
  "MAC adresu je třeba vyplnit"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "Aby bylo možné změnit typ sběrnice je třeba, aby virt. stroj byl vypnutý"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "Aby bylo možné změnit režim mezipaměti je třeba, aby virt. stroj byl vypnutý"
 ],
 "Managing virtual machines": [
  null,
  "Správa virtuálních strojů"
 ],
 "Manual connection": [
  null,
  "Ruční připojení"
 ],
 "Mask or prefix length": [
  null,
  "Maska nebo délka předpony"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Masku nebo délku předpony je třeba vyplnit"
 ],
 "Maximum allocation": [
  null,
  "Přidělit nanejvýš"
 ],
 "Maximum memory could not be saved": [
  null,
  "Horní limit paměti se nepodařilo uložit"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Nejvyšší umožněný počet virtuálních procesorů, přiřazených operačnímu systému hosta"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Nejvyšší umožněný počet virtuálních procesorů, přidělený operačnímu systému hosta. Je třeba, aby bylo z rozmezí 1 až $0"
 ],
 "Maximum transmission unit": [
  null,
  "Přenosová jednotka nejvýše (MTU)"
 ],
 "Media could not be ejected from $0": [
  null,
  "Médium se nepodařilo vysunout z $0"
 ],
 "Media will be ejected from $0:": [
  null,
  "Médium bude vysunuto z $0:"
 ],
 "Memory": [
  null,
  "Paměť"
 ],
 "Memory could not be saved": [
  null,
  "Paměť se nepodařilo uložit"
 ],
 "Memory must not be 0": [
  null,
  "Je třeba, aby paměť nebyla 0 (nula)"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "Přestěhovat"
 ],
 "Migrate VM to another host": [
  null,
  "Přestěhovat virt. stroj na jiného hostitele"
 ],
 "Migration failed": [
  null,
  "Přestěhování se nezdařilo"
 ],
 "Mode": [
  null,
  "Režim"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Model type": [
  null,
  "Typ modelu"
 ],
 "More info for mount tag field": [
  null,
  "Další informace pro kolonku štítek připojování"
 ],
 "More info for source path field": [
  null,
  "Další informace pro kolonku popis umístění zdroje"
 ],
 "Mount tag": [
  null,
  "Štítek připojování"
 ],
 "Mount tag must not be empty": [
  null,
  "Štítek připojování je třeba vyplnit"
 ],
 "NAT to $0": [
  null,
  "NAT na $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "Nepodařilo se změnit stav síť. rozhraní $0 virt. stroje $1"
 ],
 "Name": [
  null,
  "Název"
 ],
 "Name already exists": [
  null,
  "Takový název už je používán"
 ],
 "Name contains invalid characters": [
  null,
  "Název obsahuje neplatné znaky"
 ],
 "Name must not be empty": [
  null,
  "Název je třeba vyplnit"
 ],
 "Name should not be empty": [
  null,
  "Název je třeba vyplnit"
 ],
 "Name: ": [
  null,
  "Název: "
 ],
 "Netmask": [
  null,
  "Maska sítě"
 ],
 "Network $0 could not be deleted": [
  null,
  "Síť $0 nebylo možné smazat"
 ],
 "Network $0 failed to get activated": [
  null,
  "Síť $0 se nepodařilo aktivovat"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Síť $0 se nepodařilo deaktivovat"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "Síť $0 bude nenávratně smazána."
 ],
 "Network boot (PXE)": [
  null,
  "Zavádění ze sítě (PXE)"
 ],
 "Network file system": [
  null,
  "Síťový souborový systém"
 ],
 "Network interface": [
  null,
  "Síťové rozhraní"
 ],
 "Network interface $0 could not be removed": [
  null,
  "Síťové rozhraní $0 nebylo možné odebrat"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "Síťové rozhraní $0 bude odebráno z $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "Nastavení síťového rozhraní se nepodařilo uložit"
 ],
 "Network interfaces": [
  null,
  "Síťová rozhraní"
 ],
 "Network selection does not support PXE.": [
  null,
  "Síťový výběr nepodporuje PXE."
 ],
 "Networks": [
  null,
  "Sítě"
 ],
 "New name": [
  null,
  "Nový název"
 ],
 "New name must not be empty": [
  null,
  "Nový název je třeba vyplnit"
 ],
 "New volume name": [
  null,
  "Název pro nový svazek"
 ],
 "No VM is running or defined on this host": [
  null,
  "Na tomto hostiteli nejsou spuštěné nebo definované žádné virt. stroje"
 ],
 "No boot device found": [
  null,
  "Nenalezeno žádné zařízení pro zavádění systému"
 ],
 "No connection available": [
  null,
  "Není k dispozici žádné připojení"
 ],
 "No description": [
  null,
  "Bez popisu"
 ],
 "No directories shared between the host and this VM": [
  null,
  "Mezi hostitelem a tímto virt. strojem nejsou sdíleny žádné složky"
 ],
 "No disks defined for this VM": [
  null,
  "Pro tento virt. stroj nejsou definované žádné disky"
 ],
 "No host device selected": [
  null,
  "Nevybráno žádné zařízení hostitele"
 ],
 "No host devices assigned to this VM": [
  null,
  "Tomuto virt. stroji nejsou přiřazena žádná zařízení hostitele"
 ],
 "No network devices": [
  null,
  "Žádná síťová zařízení"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Pro tento virt. stroj nebyla definována žádná síťová rozhraní"
 ],
 "No network is defined on this host": [
  null,
  "Na tomto hostiteli není definována žádná síť"
 ],
 "No networks available": [
  null,
  "Nejsou k dispozici žádné sítě"
 ],
 "No parent": [
  null,
  "Nic nenadřazeno"
 ],
 "No snapshots defined for this VM": [
  null,
  "Pro tento virt. stroj nejsou definované žádné zachycené stavy"
 ],
 "No state": [
  null,
  "Žádný stav"
 ],
 "No storage": [
  null,
  "Žádné úložiště"
 ],
 "No storage pool is defined on this host": [
  null,
  "Na tomto stroji není definován žádný fond úložiště"
 ],
 "No storage pools available": [
  null,
  "Nejsou k dispozici žádné fondy úložiště"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Pro tento fond úložiště nejsou definované žádné úložné svazky"
 ],
 "No virtual networks": [
  null,
  "Žádné virtuální sítě"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "V tomto fondu úložiště neexistují žádné svazky."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Netrvalou síť není možné smazat. Přestane existovat po vypnutí."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Netrvalý fond úložiště není možné smazat. Přestane existovat po vypnutí."
 ],
 "None": [
  null,
  "Žádné"
 ],
 "None (isolated network)": [
  null,
  "Žádné (izolovaná síť)"
 ],
 "Offline token": [
  null,
  "Offline token"
 ],
 "Offline token must not be empty": [
  null,
  "Offline toke je třeba vyplnit"
 ],
 "Old token expired": [
  null,
  "Platnost původního tokenu skončila"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Jeden či více z vybraných svazků je používán doménami. Aby bylo možné svazek smazat, je nejprve třeba odpojit z něj využívané disky."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Upravit je možné pouze pokud je host vypnutý"
 ],
 "Open": [
  null,
  "Otevřít"
 ],
 "Operating system": [
  null,
  "Operační systém"
 ],
 "Operation is in progress": [
  null,
  "Operace probíhá"
 ],
 "Overview": [
  null,
  "Přehled"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Nadřazený zachycený stav"
 ],
 "Path": [
  null,
  "Popis umístění"
 ],
 "Path on host's filesystem": [
  null,
  "Umístění v souborovém systému hostitele"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Popis umístění ISO souboru na souborovém systému hostitele"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Popis umístění souboru s cloud obrazem na souborovém systému hostitele"
 ],
 "Path to file on host's file system": [
  null,
  "Popis umístění souboru na souborovém systému hostitele"
 ],
 "Pause": [
  null,
  "Pozastavit"
 ],
 "Paused": [
  null,
  "Pozastaveno"
 ],
 "Permanent (default)": [
  null,
  "Trvalé (výchozí)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Oprávnění odepřeno pro obrazy disků v domovských složkách"
 ],
 "Persistence": [
  null,
  "Trvalost"
 ],
 "Persistent": [
  null,
  "Trvalé"
 ],
 "Physical disk device": [
  null,
  "Fyzické diskové zařízení"
 ],
 "Physical disk device on host": [
  null,
  "Fyzické diskové zařízení na hostiteli"
 ],
 "Please choose a storage pool": [
  null,
  "Zvolte fond úložiště"
 ],
 "Please choose a volume": [
  null,
  "Zvolte svazek"
 ],
 "Please enter new volume name": [
  null,
  "Zadejte název pro nový svazek"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "Pro přístup k jeho konzoli je třeba virtuální stroj napřed zapnout."
 ],
 "Pool": [
  null,
  "Úložiště"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Aby bylo možné vytvořit svazek, fond je třeba aktivovat"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "Typ fondu $0 nepodporuje vytváření svazků"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Typ fondu nepodporuje vytváření svazků"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "Svazky z fondu jsou využívány virt. stroji "
 ],
 "Port": [
  null,
  "Port"
 ],
 "Power off": [
  null,
  "Vypnout"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Upřednostňovaný počet patic který umožnit použít hostovi."
 ],
 "Prefix": [
  null,
  "Předpona"
 ],
 "Prefix length": [
  null,
  "Délka předpony"
 ],
 "Prefix length should not be empty": [
  null,
  "Délku předpony je třeba vyplnit"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Pokud se něco pokazí, v minulosti pořízené zachycené stavy vám umožňují se vrátit k dřívějšímu stavu"
 ],
 "Private": [
  null,
  "Soukromé"
 ],
 "Product": [
  null,
  "Produkt"
 ],
 "Profile": [
  null,
  "Profil"
 ],
 "Protocol": [
  null,
  "Protokol"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Poskytuje most mezi virt. strojem hosta přímo do místní sítě. To potřebuje zařízení mostu na hostiteli a v něm jedno či více fyzických síťových rozhraní."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Poskytuje připojení jehož podrobnosti jsou popsány v definici jmenované sítě."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Poskytuje virtuální místní síť s NAT překladem pro vnější svět."
 ],
 "Range": [
  null,
  "Rozsah"
 ],
 "Read-only": [
  null,
  "Pouze pro čtení"
 ],
 "Reboot": [
  null,
  "Restartovat"
 ],
 "Remote URL": [
  null,
  "Vzdálená URL adresa"
 ],
 "Remote viewer details": [
  null,
  "Podrobnosti o vzdáleném prohlížeči"
 ],
 "Remove": [
  null,
  "Odebrat"
 ],
 "Remove and delete file": [
  null,
  "Odebrat a smazat soubor"
 ],
 "Remove disk from VM?": [
  null,
  "Odebrat disk z virt. stroje?"
 ],
 "Remove filesystem?": [
  null,
  "Odebrat souborový systém?"
 ],
 "Remove host device from VM?": [
  null,
  "Odebrat zařízení hostitele z virt. stroje?"
 ],
 "Remove network interface?": [
  null,
  "Odebrat síťové rozhraní?"
 ],
 "Remove static host from DHCP": [
  null,
  "Odebrat statickou položku hostitele z DHCP"
 ],
 "Rename": [
  null,
  "Přejmenovat"
 ],
 "Rename VM $0": [
  null,
  "Přejmenovat virt. stroj $0"
 ],
 "Reset": [
  null,
  "Vrátit na výchozí"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Omezení v síťování (emulace založená na SLIRP) a přiřazení PCI zařízení"
 ],
 "Resume": [
  null,
  "Navázat v chodu"
 ],
 "Revert": [
  null,
  "Vrátit zpět"
 ],
 "Revert to snapshot $0": [
  null,
  "Vrátit zpět do podoby v zachyceném stavu $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Vrácení zpět do podoby v tomto zachyceném stavu vezme virt. stroj zpět do okamžiku pořízení zachyceného stavu a stávající stav bude ztracen, včetně všech dat, která se nenacházejí v zachyceném stavu"
 ],
 "Root password": [
  null,
  "Heslo pro účet root"
 ],
 "Route to $0": [
  null,
  "Trasa na $0"
 ],
 "Routed network": [
  null,
  "Směrovaná síť"
 ],
 "Run": [
  null,
  "Spustit"
 ],
 "Run when host boots": [
  null,
  "Spustit při startu hostitele"
 ],
 "Running": [
  null,
  "Spuštěné"
 ],
 "SPICE TLS port": [
  null,
  "SPICE TLS port"
 ],
 "SPICE address": [
  null,
  "Adresa SPICE"
 ],
 "SPICE port": [
  null,
  "SPICE port"
 ],
 "Save": [
  null,
  "Uložit"
 ],
 "Select console type": [
  null,
  "Vybrat typ konzole"
 ],
 "Send key": [
  null,
  "Poslat stisk klávesy"
 ],
 "Send non-maskable interrupt": [
  null,
  "Poslat nemaskovatelné přerušení"
 ],
 "Serial": [
  null,
  "Sériové číslo"
 ],
 "Serial console": [
  null,
  "Sériová konzole"
 ],
 "Serial console ($0)": [
  null,
  "Sériová konzole ($0)"
 ],
 "Set DHCP range": [
  null,
  "Nastavit DHCP rozsah"
 ],
 "Set manually": [
  null,
  "Nastavit ručně"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Nastavení hesel uživatelů pro bezobslužnou instalaci vyžaduje spuštění virt. stroje při jeho vytváření"
 ],
 "Share": [
  null,
  "Sdílení"
 ],
 "Share a host directory with the guest": [
  null,
  "Sdílet složku na hostiteli s hostem"
 ],
 "Shared directories": [
  null,
  "Sdílené složky"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Složky sdílené s hostitelem je třeba ve virt. stroji připojit ručně"
 ],
 "Shared storage": [
  null,
  "Sdílené úložiště"
 ],
 "Show additional options": [
  null,
  "Zobrazit další možnosti"
 ],
 "Shut down": [
  null,
  "Vypnout"
 ],
 "Shut off": [
  null,
  "Vypnout"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Aby bylo možné upravovat nastavení firmware, je třeba virt. stroj nejprve vypnout"
 ],
 "Shutting down": [
  null,
  "Vypínání"
 ],
 "Size": [
  null,
  "Velikost"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "Zachycený stav $0 nebylo možné smazat"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "Zachycený stav $0 bude vymazán z $1. Veškerý obsah v něm bude ztracen."
 ],
 "Snapshot failed to be created": [
  null,
  "Zachycený stav se nepodařilo vytvořit"
 ],
 "Snapshots": [
  null,
  "Zachycené stavy"
 ],
 "Sockets": [
  null,
  "Patic"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "Některé změny nastavení se projeví až po úplném vypnutí a zapnutí virt. stroje:"
 ],
 "Source": [
  null,
  "Zdroj"
 ],
 "Source format": [
  null,
  "Formát zdroje"
 ],
 "Source must not be empty": [
  null,
  "Zdroj je třeba vyplnit"
 ],
 "Source path": [
  null,
  "Popis umístění zdroje"
 ],
 "Source path should not be empty": [
  null,
  "Popis umístění zdroje je třeba vyplnit"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "Zdroj by měl začínat na http, ftp nebo nfs protokol"
 ],
 "Source volume group": [
  null,
  "Zdrojová skupina svazků"
 ],
 "Start": [
  null,
  "Spustit"
 ],
 "Start pool when host boots": [
  null,
  "Spustit fond při startu hostitele"
 ],
 "Start should not be empty": [
  null,
  "Začátek je třeba vyplnit"
 ],
 "Startup": [
  null,
  "Při spuštění"
 ],
 "State": [
  null,
  "Stav"
 ],
 "Static host entries": [
  null,
  "Statické položky hostitelů"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "Statickou položku hostitele z DHCP se nepodařilo odebrat"
 ],
 "Storage": [
  null,
  "Úložiště"
 ],
 "Storage is at a shared location": [
  null,
  "Úložiště se nachází ve sdíleném umístění"
 ],
 "Storage limit": [
  null,
  "Limit úložiště"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Fond úložiště $0 se nepodařilo aktivovat"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Fond úložiště $0 se nepodařilo deaktivovat"
 ],
 "Storage pool failed to be created": [
  null,
  "Fond úložiště se nepodařilo vytvořit"
 ],
 "Storage pool name": [
  null,
  "Název fondu úložiště"
 ],
 "Storage pools": [
  null,
  "Fondy úložiště"
 ],
 "Storage pools could not be fetched": [
  null,
  "Fondy úložiště se nepodařilo získat"
 ],
 "Storage size must not be 0": [
  null,
  "Velikost úložiště nemůže být nula"
 ],
 "Storage volume": [
  null,
  "Svazek z úložiště"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "Je třeba, aby velikost svazku z úložiště nepřesahovala kapacitu fondu úložiště ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Svazky z úložiště"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Svazky úložiště nebylo možné smazat"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Je třeba, aby svazky úložišť byly sdíleny mezi tímto hostitelem a cílovým hostitelem."
 ],
 "Suspended (PM)": [
  null,
  "Uspáno (správou napájení)"
 ],
 "System": [
  null,
  "Systém"
 ],
 "Table of selectable host devices": [
  null,
  "Tabulka zařízení hostitele, která je možné vybrat"
 ],
 "Target": [
  null,
  "Cíl"
 ],
 "Target path": [
  null,
  "Popis umístění cíle"
 ],
 "Target path should not be empty": [
  null,
  "Popis umístění cíle je třeba vyplnit"
 ],
 "Temporary": [
  null,
  "Dočasné"
 ],
 "Temporary migration": [
  null,
  "Dočasné přestěhování"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "Virt. stroj $0 je spuštěný a před smazáním bude vynuceně vypnut."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "Pro odpojení tohoto zařízení je třeba, aby virt. stroj byl spuštěný nebo vypnutý"
 ],
 "The directory on the server being exported": [
  null,
  "Složka na serveru, kterou exportovat"
 ],
 "The host path that is to be exported.": [
  null,
  "Popis umístění na hostiteli, které má být exportováno."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "Nastavení přestěhovaného virt. stroje je odebráno ze zdrojového hostitele. Cílový host je považován za nový domov virt. stroje."
 ],
 "The pool is empty": [
  null,
  "Fond je prázdný"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Zvolený operační systém vyžaduje přinejmenším $0 $1 operační paměti"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Zvolený operační systém vyžaduje velikost úložiště přinejmenším $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "Statická položka pro hostitele $0 bude odebrána:"
 ],
 "The storage pool could not be deleted": [
  null,
  "Fond úložiště nebylo možné smazat"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "Název štítku, který má být používán hostem pro připojení tohoto exportního bodu."
 ],
 "Then copy and paste it above.": [
  null,
  "Poté ho zkopírujte a vložte výše."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Tento vir. stroj je přechodný. Pokud ho chcete smazat, stačí ho vypnout."
 ],
 "This disk will be removed from $0:": [
  null,
  "Tento disk bude odebrán z $0:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Tento souborový systém bude odebrán z $0:"
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Toto je doporučené nastavení pro obecné připojení hosta na hostitelích s dynamickými / bezdrátovými nastaveními/uspořádáními sítě."
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Toto je doporučené nastavení pro obecné připojení hosta na hostitelích se statickými nastaveními drátové sítě."
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  "Toto je doporučené nastavení pro vysoký výkon nebo lepší zabezpečení."
 ],
 "This volume is already used by $0.": [
  null,
  "Tento svazek už je využíván $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "Tento svazek už je využíván jiným virt. strojem."
 ],
 "Threads per core": [
  null,
  "Vláken na jádro"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "U přechodných virt. strojů nelze upravovat nastavení firmware"
 ],
 "Troubleshoot": [
  null,
  "Řešit potíže"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type ID": [
  null,
  "Identifikátor typu"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (ISO obraz nebo instalační strom distribuce)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Neurčeno"
 ],
 "Unique name": [
  null,
  "Neopakující se název"
 ],
 "Unique name, default: $0": [
  null,
  "Neopakující se název, výchozí: $0"
 ],
 "Unique network name": [
  null,
  "Doposud nepoužívaný název sítě"
 ],
 "Unit": [
  null,
  "Jednotka"
 ],
 "Unknown": [
  null,
  "Neznámé"
 ],
 "Unknown firmware": [
  null,
  "Neznámý firmware"
 ],
 "Unspecified": [
  null,
  "Nespecifikováno"
 ],
 "Url": [
  null,
  "URL adresa"
 ],
 "Usage": [
  null,
  "Použití"
 ],
 "Use existing": [
  null,
  "Použít existující"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Použít rozšířené atributy (xattr) na souborech a složkách"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Ohledně úložiště, použít stejné umístění jak pro původního, tak pro cílového hostitele. Může to být sdílený fond úložišť, NFS, nebo jakákoli jiná metoda sdílení úložiště."
 ],
 "Used": [
  null,
  "Využito"
 ],
 "Used by": [
  null,
  "Používá"
 ],
 "User login": [
  null,
  "Uživatelské jméno"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Pokud je k němu zadáno heslo, je třeba vyplnit také uživatelské jméno"
 ],
 "User password": [
  null,
  "Heslo uživatele"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Pokud je zadáno uživatelské jméno, je třeba k němu také vyplnit heslo"
 ],
 "User session": [
  null,
  "Uživatelská relace"
 ],
 "VCPU settings could not be saved": [
  null,
  "Nastavení virt. procesorů se nepodařilo uložit"
 ],
 "VM $0 Host Devices": [
  null,
  "Zařízení hostitele ve virt. stroji $0"
 ],
 "VM $0 already exists": [
  null,
  "Virt. stroj $0 už existuje"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "Virt. stroj $0 neexistuje na $1 připojení"
 ],
 "VM $0 failed to force reboot": [
  null,
  "Nepodařilo se vynutit restart virt. stroje $0"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "Nepodařilo se vynutit vypnutí virt. stroje $0"
 ],
 "VM $0 failed to get installed": [
  null,
  "Virt. stroj $0 se nepodařilo nainstalovat"
 ],
 "VM $0 failed to pause": [
  null,
  "Virt. stroj $0 se nepodařilo pozastavit"
 ],
 "VM $0 failed to reboot": [
  null,
  "Virt. stroj $0 se nepodařilo restartovat"
 ],
 "VM $0 failed to resume": [
  null,
  "Nepodařilo se navázat v chodu virt. stroje $0"
 ],
 "VM $0 failed to send NMI": [
  null,
  "Nepodařilo se zaslat virt. stroji $0 nemaskovatelné přerušení"
 ],
 "VM $0 failed to shutdown": [
  null,
  "Virt. stroj $0 se nepodařilo vypnout"
 ],
 "VM $0 failed to start": [
  null,
  "Virt. stroj $0 se nepodařilo zapnout"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "Virt. stroj spuštěn s neprivilegovaným omezeným přístupem, kdy proces a pseudoterminál je vlastněn vaším uživatelským účtem"
 ],
 "VM needs shutdown": [
  null,
  "Virt. stroj je třeba vypnout"
 ],
 "VM state": [
  null,
  "Stav virt. stroje"
 ],
 "VM will launch with root permissions": [
  null,
  "Virt. stroj bude spuštěn s oprávněními správce (root)"
 ],
 "VNC TLS port": [
  null,
  "VNC TLS port"
 ],
 "VNC address": [
  null,
  "Adresa VNC"
 ],
 "VNC console": [
  null,
  "VNC konzole"
 ],
 "VNC port": [
  null,
  "VNC port"
 ],
 "Valid token": [
  null,
  "Platný token"
 ],
 "Vendor": [
  null,
  "Výrobce"
 ],
 "Virtual machines": [
  null,
  "Virtuální stroje"
 ],
 "Virtual machines management": [
  null,
  "Správa virtuálních strojů"
 ],
 "Virtual network": [
  null,
  "Virtuální síť"
 ],
 "Virtual network failed to be created": [
  null,
  "Vytvoření virtuální sítě se nezdařilo"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Služba virtualizace (libvirt) není aktivní"
 ],
 "Volume": [
  null,
  "Svazek"
 ],
 "Volume failed to be created": [
  null,
  "Svazek se nepodařilo vytvořit"
 ],
 "Volume group name": [
  null,
  "Název skupiny svazků"
 ],
 "Volume group name should not be empty": [
  null,
  "Název skupiny svazků je třeba vyplnit"
 ],
 "WWPN": [
  null,
  "Neopakující se číslo portu"
 ],
 "Watchdog": [
  null,
  "Resetátor (watchdog)"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Resetátory zasahují pokud systémy přestanou odpovídat. Pokud chcete použít toto virtuální zařízení resetátoru je třeba, aby systém v hostovi také měl další ovladač a provozoval službu pro resetátor."
 ],
 "Writeable": [
  null,
  "Zapisovatelné"
 ],
 "Writeable and shared": [
  null,
  "Zapisovatelné a sdílené"
 ],
 "You can mount the shared folder using:": [
  null,
  "Sdílenou složku je možné připojit pomocí:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Je třeba vybrat co nejvíce podobný operační systém"
 ],
 "active": [
  null,
  "aktivní"
 ],
 "add": [
  null,
  "přidat"
 ],
 "add entry": [
  null,
  "přidat položku"
 ],
 "bridge": [
  null,
  "most"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "uživatelsky určené"
 ],
 "direct": [
  null,
  "přímé"
 ],
 "disabled": [
  null,
  "zakázáno"
 ],
 "disk": [
  null,
  "disk"
 ],
 "down": [
  null,
  "vypnuté"
 ],
 "edit": [
  null,
  "upravit"
 ],
 "enabled": [
  null,
  "povoleno"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "stroj"
 ],
 "host device": [
  null,
  "zařízení hostitele"
 ],
 "host passthrough": [
  null,
  "průchod na hostitele"
 ],
 "hostdev": [
  null,
  "zařízení hostitele"
 ],
 "iSCSI direct target": [
  null,
  "Přímý cíl iSCSI"
 ],
 "iSCSI initiator IQN": [
  null,
  "IQN název iSCSI iniciátoru"
 ],
 "iSCSI target": [
  null,
  "iSCSI cíl"
 ],
 "iSCSI target IQN": [
  null,
  "IQN název iSCSI cíle"
 ],
 "inactive": [
  null,
  "neaktivní"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "vícesměrvysílání"
 ],
 "more info": [
  null,
  "další informace"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "přípojný bod: Přípojný bod uvnitř hosta"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "štítek připojení: Štítek přiřazený k exportovanému přípojnému bodu"
 ],
 "network": [
  null,
  "síť"
 ],
 "no": [
  null,
  "ne"
 ],
 "no state saved": [
  null,
  "neuložen žádný stav"
 ],
 "none": [
  null,
  "žádné"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "přesměrované zařízení"
 ],
 "remove": [
  null,
  "odebrat"
 ],
 "serial number": [
  null,
  "sériové číslo"
 ],
 "server": [
  null,
  "server"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "zapnuto"
 ],
 "user": [
  null,
  "uživatel"
 ],
 "vCPU count": [
  null,
  "Počet virt. procesorů"
 ],
 "vCPU maximum": [
  null,
  "Nejvýše virt. procesorů"
 ],
 "vCPUs": [
  null,
  "virt. procesorů"
 ],
 "vhostuser": [
  null,
  "uzivatelvirtstroje"
 ],
 "view more...": [
  null,
  "zobrazit více…"
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Aby bylo možné klonovat virt. stroje je třeba, aby byl nainstalovaný balíček virt-install"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Aby bylo možné vytvářet nové virt. stroje je třeba, aby byl nainstalovaný balíček virt-install"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Aby bylo možné upravovat tento atribut je třeba, aby byl nainstalovaný balíček virt-install"
 ],
 "vm": [
  null,
  "virt. stroj"
 ],
 "yes": [
  null,
  "ano"
 ]
});
