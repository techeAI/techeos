cockpit.locale({
 "": {
  "plural-forms": (n) => n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2,
  "language": "uk",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 доступно у типовому місці"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 доступно в основній системі"
 ],
 "$0 CPU configuration": [
  null,
  "Налаштування процесора $0"
 ],
 "$0 Network": [
  null,
  "$0 мережа",
  "$0 мережі",
  "$0 мереж"
 ],
 "$0 Storage pool": [
  null,
  "$0 буфер сховища",
  "$0 буфери сховищ",
  "$0 буферів сховищ"
 ],
 "$0 does not support unattended installation.": [
  null,
  "Для $0 не передбачено підтримки автоматичного встановлення."
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 можна користуватися у більшості операційних систем. Щоб встановити пакунок із програмою, знайдіть відповідний запис у Програмних засобах GNOME або віддайте таку команду:"
 ],
 "$0 memory adjustment": [
  null,
  "Коригування пам'яті $0"
 ],
 "$0 network": [
  null,
  "Мережа $0"
 ],
 "$0 vCPU": [
  null,
  "$0 вірт. проц.",
  "$0 вірт. проц.",
  "$0 вірт. проц."
 ],
 "$0 vCPU details": [
  null,
  "Подробиці щодо віртуального процесора $0"
 ],
 "$0 virtual network interface settings": [
  null,
  "Параметри інтерфейсу віртуальної мережі $0"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Копія ВМ працюватиме у системі призначення і зникне, коли її буде вимкнено. Тим часом основна система походження зберігатиме власну копію налаштувань ВМ."
 ],
 "Access": [
  null,
  "Доступ"
 ],
 "Action": [
  null,
  "Дія"
 ],
 "Activate": [
  null,
  "Задіяти"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Активувати буфер зберігання даних для адміністрування томів"
 ],
 "Add": [
  null,
  "Додати"
 ],
 "Add a DHCP static host entry": [
  null,
  "Додати запис статичного вузла DHCP"
 ],
 "Add disk": [
  null,
  "Додати диск"
 ],
 "Add host device": [
  null,
  "Додати пристрій основної системи"
 ],
 "Add network interface": [
  null,
  "Додати інтерфейс мережі"
 ],
 "Add shared directory": [
  null,
  "Додати спільний каталог"
 ],
 "Add virtual network interface": [
  null,
  "Додати інтерфейс віртуальної мережі"
 ],
 "Add watchdog device type": [
  null,
  "Додати тип пристрою нагляду"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Додавання спільних каталогів можливе, лише якщо гостьову систему вимкнено"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  "Додавання цього диска змінить режим доступу до нього на «спільний»."
 ],
 "Additional": [
  null,
  "Додаткові"
 ],
 "Address": [
  null,
  "Адреса"
 ],
 "Address not within subnet": [
  null,
  "Адреса поза межами підмережі"
 ],
 "All": [
  null,
  "Всі"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Уся робота ВМ, зокрема зі сховищем даних, буде тимчасовою. Це призведе до втрати даних на основній системі призначення."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Дозволені символи: основна латинка, цифри та деякі символи пунктуації (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Також вилучити усі томи у цьому буфері:"
 ],
 "Always attach": [
  null,
  "Завжди долучати"
 ],
 "Apply": [
  null,
  "Застосувати"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Автоматичне встановлення є доступним лише при отримання образу або використанні cloud-init."
 ],
 "Automatic": [
  null,
  "Автоматично"
 ],
 "Automation": [
  null,
  "Автоматизація"
 ],
 "Autostart": [
  null,
  "Автозапуск"
 ],
 "Blocked": [
  null,
  "Заблоковано"
 ],
 "Boot order": [
  null,
  "Порядок завантаження"
 ],
 "Boot order settings could not be saved": [
  null,
  "Не вдалося зберегти параметри порядку завантаження"
 ],
 "Bus": [
  null,
  "Канал"
 ],
 "CD/DVD disc": [
  null,
  "Диск CD/DVD"
 ],
 "CPU": [
  null,
  "Процесор"
 ],
 "CPU configuration could not be saved": [
  null,
  "Не вдалося зберегти параметри процесорів"
 ],
 "CPU type": [
  null,
  "Тип процесора"
 ],
 "Cache": [
  null,
  "Кеш"
 ],
 "Cancel": [
  null,
  "Скасувати"
 ],
 "Capacity": [
  null,
  "Місткість"
 ],
 "Change boot order": [
  null,
  "Змінити порядок завантаження"
 ],
 "Change firmware": [
  null,
  "Змінити мікропрограму"
 ],
 "Changes pending": [
  null,
  "Зміни у черзі"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Зміни буде застосовано після завершення роботи ВМ"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "Спосіб зміни параметрів BIOS/EFI є специфічним для кожного окремого виробника. Треба натиснути якусь клавішу під час завантаження (ESC, F1, F12, Del). Потім слід увімкнути параметр, який має назву «virtualization», «VM», «VMX», «SVM», «VTX», «VTD». Подробиці можна знайти у підручнику до вашого комп'ютера."
 ],
 "Checking token validity...": [
  null,
  "Перевірка чинності жетона…"
 ],
 "Choose an operating system": [
  null,
  "Виберіть операційну систему"
 ],
 "Class": [
  null,
  "Клас"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "У результаті натискання «Запустити віддалений переглядач» буде отримано файл .vv і запущено $0."
 ],
 "Clone": [
  null,
  "Клонувати"
 ],
 "Close": [
  null,
  "Закрити"
 ],
 "Cloud base image": [
  null,
  "Базовий образ хмари"
 ],
 "Confirm this action": [
  null,
  "Підтвердьте цю дію"
 ],
 "Connect": [
  null,
  "З'єднатися"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "З’єднатися із будь-якою програмою перегляду для вказаних нижче протоколів"
 ],
 "Connecting": [
  null,
  "З'єднання"
 ],
 "Connection": [
  null,
  "З’єднання"
 ],
 "Console": [
  null,
  "Консоль"
 ],
 "Copy storage": [
  null,
  "Копіювати сховище даних"
 ],
 "Cores per socket": [
  null,
  "Кількість ядер на сокет"
 ],
 "Could not delete $0": [
  null,
  "Не вдалося вилучити $0"
 ],
 "Could not delete all storage for $0": [
  null,
  "Не вдалося вилучити усе сховище для $0"
 ],
 "Could not delete disk's storage": [
  null,
  "Не вдалося вилучити сховище даних диска"
 ],
 "Could not revert to snapshot": [
  null,
  "Не вдалося скинути систему до знімка"
 ],
 "Crashed": [
  null,
  "Аварійне завершення"
 ],
 "Create": [
  null,
  "Створити"
 ],
 "Create VM": [
  null,
  "Створення ВМ"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Створити ВМ імпортуванням образу диска наявної встановленої ВМ"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Створити ВМ на основі локального або мережевого носія для встановлення"
 ],
 "Create a clone VM based on $0": [
  null,
  "Створити клон ВМ на основі $0"
 ],
 "Create and edit": [
  null,
  "Створити і редагувати"
 ],
 "Create and run": [
  null,
  "Створити і запустити"
 ],
 "Create new": [
  null,
  "Створити"
 ],
 "Create new virtual machine": [
  null,
  "Створити віртуальну машину"
 ],
 "Create new volume": [
  null,
  "Створити том"
 ],
 "Create snapshot": [
  null,
  "Створення знімка"
 ],
 "Create storage pool": [
  null,
  "Створити резервне сховище"
 ],
 "Create storage volume": [
  null,
  "Створити том сховища даних"
 ],
 "Create virtual network": [
  null,
  "Створити віртуальну мережу"
 ],
 "Create volume": [
  null,
  "Створити том"
 ],
 "Creating VM": [
  null,
  "створення ВМ"
 ],
 "Creating VM $0": [
  null,
  "Створення ВМ $0"
 ],
 "Creation of VM $0 failed": [
  null,
  "Не вдалося створити ВМ $0"
 ],
 "Creation time": [
  null,
  "Час створення"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Поточний"
 ],
 "Current allocation": [
  null,
  "Поточне отримання"
 ],
 "Custom firmware: $0": [
  null,
  "Нетипова мікропрограма: $0"
 ],
 "Custom path": [
  null,
  "Нетиповий шлях"
 ],
 "DHCP Settings": [
  null,
  "Параметри DHCP"
 ],
 "Deactivate": [
  null,
  "Вимкнути"
 ],
 "Delete": [
  null,
  "Вилучити"
 ],
 "Delete $0 VM?": [
  null,
  "Вилучити ВМ $0?"
 ],
 "Delete $0 storage pool?": [
  null,
  "Вилучити буфер зберігання даних $0?"
 ],
 "Delete $0 volume": [
  null,
  "Вилучити $0 том",
  "Вилучити $0 томи",
  "Вилучити $0 томів"
 ],
 "Delete associated storage files:": [
  null,
  "Вилучити пов’язані файли у сховищі даних:"
 ],
 "Delete network?": [
  null,
  "Вилучити мережу?"
 ],
 "Delete snapshot?": [
  null,
  "Вилучити знімок?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Вилучення неактивного буфера зберігання даних призведе лише до скасування визначення буфера. Вміст буфера вилучено не буде."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Вилучення спільних каталогів можливе, лише якщо гостьову систему вимкнено"
 ],
 "Description": [
  null,
  "Опис"
 ],
 "Desktop viewer": [
  null,
  "Стільничний переглядач"
 ],
 "Destination URI": [
  null,
  "Адреса призначення"
 ],
 "Destination URI must not be empty": [
  null,
  "Адреса призначення не може бути порожньою"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Від'єднайте диски, які використовують цей буфер від усіх віртуальних машин, перш ніж намагатися їх вилучити."
 ],
 "Details": [
  null,
  "Подробиці"
 ],
 "Device": [
  null,
  "Пристрій"
 ],
 "Devices": [
  null,
  "Пристрої"
 ],
 "Disconnect": [
  null,
  "Від’єднатися"
 ],
 "Disconnected": [
  null,
  "Від'єднано"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Від'єднано від послідовної консолі. Натисніть кнопку «З'єднатися»."
 ],
 "Disk": [
  null,
  "Диск"
 ],
 "Disk $0 could not be removed": [
  null,
  "Не вдалося вилучити диск $0"
 ],
 "Disk failed to be attached": [
  null,
  "Не вдалося долучити диск"
 ],
 "Disk failed to be created": [
  null,
  "Не вдалося створити диск"
 ],
 "Disk identifier": [
  null,
  "Ідентифікатор диска"
 ],
 "Disk image": [
  null,
  "Образ диска"
 ],
 "Disk image file": [
  null,
  "Файл образу диска"
 ],
 "Disk image path must not be empty": [
  null,
  "Шлях до образу диска не може бути порожнім"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Образи дисків можуть зберігатися у домашньому каталозі користувача"
 ],
 "Disk settings could not be saved": [
  null,
  "Не вдалося зберегти параметри диска"
 ],
 "Disk-only snapshot": [
  null,
  "Знімок лише на диску"
 ],
 "Disks": [
  null,
  "Диски"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Не запускайте цю ВМ на початковій основній системі і основній системі призначення одночасно."
 ],
 "Do nothing": [
  null,
  "Нічого не робити"
 ],
 "Domain has crashed": [
  null,
  "Домен завершив роботу аварійно"
 ],
 "Domain is blocked on resource": [
  null,
  "Домен заблоковано на ресурсі"
 ],
 "Download an OS": [
  null,
  "Отримати операційну систему"
 ],
 "Download progress": [
  null,
  "Поступ отримання"
 ],
 "Downloading image for VM $0": [
  null,
  "Отримуємо образ для ВМ $0"
 ],
 "Downloading: $0%": [
  null,
  "Отримуємо: $0%"
 ],
 "Dump core": [
  null,
  "Створити дамп ядра"
 ],
 "Duration": [
  null,
  "Тривалість"
 ],
 "Dying": [
  null,
  "Вмирає"
 ],
 "Edit": [
  null,
  "Змінити"
 ],
 "Edit $0 attributes": [
  null,
  "Редагувати атрибути $0"
 ],
 "Edit watchdog device type": [
  null,
  "Змінити тип пристрою нагляду"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Редагування інтерфейсів мережі проміжних гостьових систем заборонено"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Редагування проміжних інтерфейсів мережі заборонено"
 ],
 "Eject": [
  null,
  "Виштовхнути"
 ],
 "Eject disc from VM?": [
  null,
  "Виштовхнути диск з ВМ?"
 ],
 "Emulated machine": [
  null,
  "Емульована машина"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "Увімкніть підтримку віртуалізації у параметрах BIOS/EFI."
 ],
 "End": [
  null,
  "Кінець"
 ],
 "End should not be empty": [
  null,
  "Кінець не може бути порожнім"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Введіть дані root і/або користувача, щоб увімкнути автоматичне встановлення."
 ],
 "Error checking token": [
  null,
  "Помилка перевірки токена"
 ],
 "Example, $0": [
  null,
  "Приклад, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Наявний образ диска у файловій системі основної системи"
 ],
 "Expand": [
  null,
  "Розгорнути"
 ],
 "Extended attributes": [
  null,
  "Розширені атрибути"
 ],
 "Failed": [
  null,
  "Помилка"
 ],
 "Failed to add shared directory": [
  null,
  "Не вдалося додати спільний каталог"
 ],
 "Failed to change firmware": [
  null,
  "Не вдалося змінити мікропрограму"
 ],
 "Failed to clone VM $0": [
  null,
  "Не вдалося клонувати ВМ $0"
 ],
 "Failed to configure watchdog": [
  null,
  "Не вдалося налаштувати спостереження"
 ],
 "Failed to detach watchdog": [
  null,
  "Не вдалося від'єднати спостереження"
 ],
 "Failed to fetch some resources": [
  null,
  "Не вдалося отримати деякі ресурси"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "Не вдалося отримати IP-адреси інтерфейсів, які є у $0"
 ],
 "Failed to rename VM $0": [
  null,
  "Не вдалося перейменувати ВМ $0"
 ],
 "Failed to save network settings": [
  null,
  "Не вдалося зберегти параметри мережі"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Не вдалося надіслати комбінацію клавіш Ctrl+Alt+$0 до ВМ $1"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Має бути увімкнено менше за максимальну кількість віртуальних процесорів."
 ],
 "File": [
  null,
  "Файл"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Не вдалося вилучити файлову систему $0"
 ],
 "Filesystem directory": [
  null,
  "Каталог файлової системи"
 ],
 "Filter by name": [
  null,
  "Фільтрувати за назвою"
 ],
 "Firmware": [
  null,
  "Мікропрограма"
 ],
 "Force eject": [
  null,
  "Примусове виштовхування"
 ],
 "Force reboot": [
  null,
  "Примусове перезавантаження"
 ],
 "Force revert": [
  null,
  "Примусове повернення"
 ],
 "Force shut down": [
  null,
  "Примусово вимкнути"
 ],
 "Format": [
  null,
  "Формат"
 ],
 "Forward mode": [
  null,
  "Режим переспрямовування"
 ],
 "Forwarding mode": [
  null,
  "Режим переспрямовування"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Перенесенню підлягатимуть усі образи дисків і пам'ять домену. Перенесено буде лише неспільні придатні до запису образи дисків. Невикористаний обсяг сховища даних після перенесення лишатиметься у початковій системі."
 ],
 "General": [
  null,
  "Загальний"
 ],
 "Generate automatically": [
  null,
  "Створити автоматично"
 ],
 "Get a new RHSM token.": [
  null,
  "Отримати новий жетон RHSM."
 ],
 "GiB": [
  null,
  "ГіБ"
 ],
 "Go to VMs list": [
  null,
  "Перейти до списку ВМ"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Чудовий вибір для стільничної віртуалізації"
 ],
 "Gracefully shutdown": [
  null,
  "Штатно вимкнути"
 ],
 "Hardware virtualization is disabled": [
  null,
  "Апаратну віртуалізацію вимкнено"
 ],
 "Hide additional options": [
  null,
  "Приховати додаткові параметри"
 ],
 "Host": [
  null,
  "Вузол"
 ],
 "Host device": [
  null,
  "Пристрій основної системи"
 ],
 "Host device could not be attached": [
  null,
  "Не вдалося долучити пристрій основної системи"
 ],
 "Host device will be removed from $0:": [
  null,
  "Пристрій основної буде вилучено з $0:"
 ],
 "Host devices": [
  null,
  "Пристрої основної системи"
 ],
 "Host name": [
  null,
  "Назва вузла"
 ],
 "Host should not be empty": [
  null,
  "Вузол не повинен бути порожнім"
 ],
 "Hypervisor details": [
  null,
  "Докладніше про гіпервізор"
 ],
 "ID": [
  null,
  "Ід."
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP-адреса"
 ],
 "IP address must not be empty": [
  null,
  "IP-адреса має бути непорожньою"
 ],
 "IP configuration": [
  null,
  "Налаштування IP"
 ],
 "IPv4 address": [
  null,
  "Адреса IPv4"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  "Адреса IPv4 не може бути тою самою, що і ідентифікатор мережі"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "Адреса IPv4 не може бути тою самою, що і адреса трансляції мережі"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 і IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "Мережа IPv4 не повинна бути порожньою"
 ],
 "IPv4 only": [
  null,
  "Лише IPv4"
 ],
 "IPv6 address": [
  null,
  "Адреса IPv6"
 ],
 "IPv6 network should not be empty": [
  null,
  "Мережа IPv6 не повинна бути порожньою"
 ],
 "IPv6 only": [
  null,
  "Лише IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "Ідеальний для серверних ВМ"
 ],
 "Ideal networking support": [
  null,
  "Ідеальна підтримка роботи у мережі"
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Ідентифікатор може бути без повідомлень обрізано до $0 символів "
 ],
 "Idle": [
  null,
  "Бездіяльність"
 ],
 "Ignore": [
  null,
  "Ігнорувати"
 ],
 "Import VM": [
  null,
  "Імпортувати ВМ"
 ],
 "Import a virtual machine": [
  null,
  "Імпортувати віртуальну машину"
 ],
 "Import and edit": [
  null,
  "Імпортувати і редагувати"
 ],
 "Import and run": [
  null,
  "Імпортувати і запустити"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "Підтримки імпортування образу із базовим файлом не передбачено"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "У більшості конфігурацій macvtap не працює для обміну мережею між основною і гостьовою системами."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  "У типовому режимі «vepa» відповідальність за перемикання покладено на зовнішній комутатор. Якщо у комутаторі не передбачено підтримки VEPA, обмін даними між гостьовими віртуальними машинами або гостьовими операційними системами і основною системою буде неможливим."
 ],
 "Initiator": [
  null,
  "Ініціатор"
 ],
 "Initiator IQN should not be empty": [
  null,
  "IQN ініціатора має бути непорожнімy"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Вставити немасковане переривання"
 ],
 "Insert": [
  null,
  "Вставити"
 ],
 "Insert disc media": [
  null,
  "Вставте дисковий носій даних"
 ],
 "Install": [
  null,
  "Встановити"
 ],
 "Installation source": [
  null,
  "Джерело для встановлення"
 ],
 "Installation source must not be empty": [
  null,
  "Запис джерела встановлення не може бути порожнім"
 ],
 "Installation type": [
  null,
  "Тип встановлення"
 ],
 "Interface": [
  null,
  "Інтерфейс"
 ],
 "Interface type": [
  null,
  "Тип інтерфейсу"
 ],
 "Interface type help": [
  null,
  "Довідка щодо типу інтерфейсу"
 ],
 "Invalid IPv4 address": [
  null,
  "Некоректна адреса IPv4"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Некоректна довжина маски IPv4 або префікса"
 ],
 "Invalid IPv6 address": [
  null,
  "Некоректна адреса IPv6"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Некоректний префікс IPv6"
 ],
 "Invalid filename": [
  null,
  "Некоректна назва файла"
 ],
 "Isolated network": [
  null,
  "Ізольована мережа"
 ],
 "LVM volume group": [
  null,
  "Група томів LVM"
 ],
 "Launch remote viewer": [
  null,
  "Запустити віддалений переглядач"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Не заповнюйте поле пароля, якщо ви не хочете, щоб було створено обліковий запис root"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Не заповнюйте поле пароля, якщо ви не хочете, щоб було створено обліковий запис користувача"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Не заповнюйте поле пароля, якщо ви не хочете встановлювати пароль root"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt не вдалося виявити жодного образу мікропрограми UEFI/OVMF, встановлено у основній системі"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "У libvirt або гіпервізорі не передбачено підтримки UEFI"
 ],
 "Loading available network devices": [
  null,
  "Завантажуємо доступні мережеві пристрої"
 ],
 "Loading resources": [
  null,
  "Завантаження ресурсів"
 ],
 "Loading...": [
  null,
  "Завантаження…"
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Локальний носій даних для встановлення (образ ISO або ієрархія каталогів встановлення дистрибутиву)"
 ],
 "Location": [
  null,
  "Місце"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC-адреса"
 ],
 "MAC address must not be empty": [
  null,
  "MAC-адреса має бути непорожньою"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "До внесення змін до типу каналу машину слід вимкнути"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "До внесення змін до режиму кешування машину слід вимкнути"
 ],
 "Managing virtual machines": [
  null,
  "Керування віртуальними машинами"
 ],
 "Manual connection": [
  null,
  "З’єднання вручну"
 ],
 "Mask or prefix length": [
  null,
  "Довжина маски або префікса"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Довжина маски або префікса повинна бути непорожньою"
 ],
 "Maximum allocation": [
  null,
  "Максимальне отримання"
 ],
 "Maximum memory could not be saved": [
  null,
  "Не вдалося зберегти дані щодо максимального обсягу пам'яті"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Максимальна кількість віртуальних процесорів, наданих для гостьової операційної системи"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Максимальна кількість віртуальних процесорів, наданих для гостьової операційної системи, має бути у межах від 1 до $0"
 ],
 "Maximum transmission unit": [
  null,
  "Максимальна одиниця передавання"
 ],
 "Media could not be ejected from $0": [
  null,
  "Не вдалося виштовхнути носій даних з $0"
 ],
 "Media will be ejected from $0:": [
  null,
  "Носій даних буде виштовхнуто з $0:"
 ],
 "Memory": [
  null,
  "Пам'ять"
 ],
 "Memory could not be saved": [
  null,
  "Не вдалося зберегти дані щодо обсягу пам'яті"
 ],
 "Memory must not be 0": [
  null,
  "Об'єм пам'яті не може бути нульовим"
 ],
 "MiB": [
  null,
  "МіБ"
 ],
 "Migrate": [
  null,
  "Перенести"
 ],
 "Migrate VM to another host": [
  null,
  "Перенести ВМ на іншу основну систему"
 ],
 "Migration failed": [
  null,
  "Помилка під час перенесення"
 ],
 "Mode": [
  null,
  "Режим"
 ],
 "Model": [
  null,
  "Модель"
 ],
 "Model type": [
  null,
  "Тип моделі"
 ],
 "More info for mount tag field": [
  null,
  "Більше даних для поля мітки монтування"
 ],
 "More info for source path field": [
  null,
  "Більше даних для поля шляху джерела"
 ],
 "Mount tag": [
  null,
  "Мітка монтування"
 ],
 "Mount tag must not be empty": [
  null,
  "Мітка монтування не може бути порожньою"
 ],
 "NAT to $0": [
  null,
  "NAT до $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "NIC $0 ВМ $1, не вдалося змінити стан"
 ],
 "Name": [
  null,
  "Назва"
 ],
 "Name already exists": [
  null,
  "Таку назву вже використано"
 ],
 "Name contains invalid characters": [
  null,
  "У назві містяться некоректні символи"
 ],
 "Name must not be empty": [
  null,
  "Запис назви не може бути порожнім"
 ],
 "Name should not be empty": [
  null,
  "Назва має бути непорожньою"
 ],
 "Name: ": [
  null,
  "Назва: "
 ],
 "Netmask": [
  null,
  "Маска мережі"
 ],
 "Network $0 could not be deleted": [
  null,
  "Не вдалося вилучити мережу $0"
 ],
 "Network $0 failed to get activated": [
  null,
  "Не вдалося активувати мережу $0"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Не вдалося деактивувати мережу $0"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "Мережу $0 буде остаточно вилучено."
 ],
 "Network boot (PXE)": [
  null,
  "Мережеве завантаження (PXE)"
 ],
 "Network file system": [
  null,
  "Мережева файлова система"
 ],
 "Network interface": [
  null,
  "Інтерфейс мережі"
 ],
 "Network interface $0 could not be removed": [
  null,
  "Не вдалося вилучити інтерфейс мережі $0"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "Інтерфейс мережі $0 буде вилучено з $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "Не вдалося зберегти параметри інтерфейсу мережі"
 ],
 "Network interfaces": [
  null,
  "Інтерфейси мережі"
 ],
 "Network selection does not support PXE.": [
  null,
  "Для вибору мережі не передбачено підтримки PXE."
 ],
 "Networks": [
  null,
  "Мережі"
 ],
 "New name": [
  null,
  "Нова назва"
 ],
 "New name must not be empty": [
  null,
  "Нова назва не може бути порожньою"
 ],
 "New volume name": [
  null,
  "Назва нового тому"
 ],
 "No VM is running or defined on this host": [
  null,
  "У цій основній системі не запущено або не визначено віртуальних машин"
 ],
 "No boot device found": [
  null,
  "Не знайдено пристрою для завантаження"
 ],
 "No connection available": [
  null,
  "Немає доступних з'єднань"
 ],
 "No description": [
  null,
  "Немає опису"
 ],
 "No directories shared between the host and this VM": [
  null,
  "У основної системи і цієї ВМ немає спільних каталогів"
 ],
 "No disks defined for this VM": [
  null,
  "Для цієї ВМ не визначено дисків"
 ],
 "No host device selected": [
  null,
  "Не вибрано пристрою основної системи"
 ],
 "No host devices assigned to this VM": [
  null,
  "Із цією ВМ не пов'язано жодних пристроїв основної системи"
 ],
 "No network devices": [
  null,
  "Немає пристроїв мережі"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Немає інтерфейсів мережі, які визначено для цієї ВМ"
 ],
 "No network is defined on this host": [
  null,
  "У цій основній системі мережу не визначено"
 ],
 "No networks available": [
  null,
  "Немає доступних мереж"
 ],
 "No parent": [
  null,
  "Немає батьківського запису"
 ],
 "No snapshots defined for this VM": [
  null,
  "Для цієї ВМ не визначено знімків"
 ],
 "No state": [
  null,
  "Немає стану"
 ],
 "No storage": [
  null,
  "Немає сховища даних"
 ],
 "No storage pool is defined on this host": [
  null,
  "На цьому вузлі не визначено буфера зберігання даних"
 ],
 "No storage pools available": [
  null,
  "Немає доступних буферів зберігання даних"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Для цього буфера зберігання сховища не визначено томів сховища"
 ],
 "No virtual networks": [
  null,
  "Немає віртуальних мереж"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "У цьому буфері сховища даних не існує томів."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Несталу мережу не можна вилучати. Вона просто зникне, якщо її вимкнути."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Несталий буфер зберігання даних не можна вилучати. Він просто зникне, якщо його вимкнути."
 ],
 "None": [
  null,
  "Немає"
 ],
 "None (isolated network)": [
  null,
  "Немає (ізольована мережа)"
 ],
 "Offline token": [
  null,
  "Автономний жетон"
 ],
 "Offline token must not be empty": [
  null,
  "Автономний жетон не може бути порожнім"
 ],
 "Old token expired": [
  null,
  "Термін дії старого жетона сплив"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Один або декілька позначених томів використовуються доменами. Щоб уможливити вилучення цих томів, спочатку від'єднайте диски."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Можна редагувати, лише якщо гостьову систему вимкнено"
 ],
 "Open": [
  null,
  "Відкрита"
 ],
 "Operating system": [
  null,
  "Операційна система"
 ],
 "Operation is in progress": [
  null,
  "Виконується дія"
 ],
 "Overview": [
  null,
  "Огляд"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Батьківський знімок"
 ],
 "Path": [
  null,
  "Шлях"
 ],
 "Path on host's filesystem": [
  null,
  "Шлях у файловій системі вузла"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Шлях до ISO у файловій системі основної системи"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Шлях до файла образу хмари у файловій системі основної системи"
 ],
 "Path to file on host's file system": [
  null,
  "Шлях до файла у файловій системі основної системи"
 ],
 "Pause": [
  null,
  "Призупинити"
 ],
 "Paused": [
  null,
  "Призупинено"
 ],
 "Permanent (default)": [
  null,
  "Сталий (типовий)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Доступ заборонено для образів дисків у домашніх каталогах"
 ],
 "Persistence": [
  null,
  "Сталість"
 ],
 "Persistent": [
  null,
  "Постійний"
 ],
 "Physical disk device": [
  null,
  "Фізичний пристрій диска"
 ],
 "Physical disk device on host": [
  null,
  "Фізичний пристрій у основній системі"
 ],
 "Please choose a storage pool": [
  null,
  "Будь ласка, виберіть буфер зберігання даних"
 ],
 "Please choose a volume": [
  null,
  "Будь ласка, виберіть том"
 ],
 "Please enter new volume name": [
  null,
  "Будь ласка, введіть назву нового тому"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "Будь ласка, запустіть віртуальну машину, щоб отримати доступ до її консолі."
 ],
 "Pool": [
  null,
  "Буфер"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Для створення тому буфер має бути активним"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "Для типу буфера $0 не передбачено підтримки створення томів"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Для типу буфера не пердебачено підтримки створення томів"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "Томи буфера використовуються ВМ "
 ],
 "Port": [
  null,
  "Порт"
 ],
 "Power off": [
  null,
  "Вимкнути живлення"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Бажана кількість сокетів, які слід надавати гостьовій системі."
 ],
 "Prefix": [
  null,
  "Префікс"
 ],
 "Prefix length": [
  null,
  "Довжина префікса"
 ],
 "Prefix length should not be empty": [
  null,
  "Довжина префікса повинна бути непорожньою"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "За допомогою раніше зроблених знімків ви зможете повернутися до попереднього стану, якщо щось піде не так"
 ],
 "Private": [
  null,
  "Закрита"
 ],
 "Product": [
  null,
  "Продукт"
 ],
 "Profile": [
  null,
  "Профіль"
 ],
 "Protocol": [
  null,
  "Протокол"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Забезпечує роботу містка з гостьової віртуальної машини безпосередньо до LAN. Потребує пристрою містка у основній системі із одним або декількома фізичними NIC."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Надає з'єднання, параметри якого описано іменованим визначенням мережі."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Надає віртуальну LAN з NAT для зовнішнього світу."
 ],
 "Range": [
  null,
  "Діапазон"
 ],
 "Read-only": [
  null,
  "Лише читання"
 ],
 "Reboot": [
  null,
  "Перезавантажити"
 ],
 "Remote URL": [
  null,
  "Віддалена адреса"
 ],
 "Remote viewer details": [
  null,
  "Параметри віддаленого переглядача"
 ],
 "Remove": [
  null,
  "Вилучити"
 ],
 "Remove and delete file": [
  null,
  "Вилучити і витерти файл"
 ],
 "Remove disk from VM?": [
  null,
  "Вилучити диск з ВМ?"
 ],
 "Remove filesystem?": [
  null,
  "Вилучити файлову систему?"
 ],
 "Remove host device from VM?": [
  null,
  "Вилучити пристрій основної системи з ВМ?"
 ],
 "Remove network interface?": [
  null,
  "Вилучити інтерфейс мережі?"
 ],
 "Remove static host from DHCP": [
  null,
  "Вилучити статичний вузол з DHCP"
 ],
 "Rename": [
  null,
  "Перейменувати"
 ],
 "Rename VM $0": [
  null,
  "Перейменувати ВМ $0"
 ],
 "Reset": [
  null,
  "Скинути"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Обмеження для мережі (заснована на SLIRP емуляція) і призначення пристроїв PCI"
 ],
 "Resume": [
  null,
  "Відновити"
 ],
 "Revert": [
  null,
  "Повернутися"
 ],
 "Revert to snapshot $0": [
  null,
  "Повернутися до знімка $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Повернення до цього знімка переведе віртуальну машину до стану на момент створення знімка — поточний стан буде втрачено разом із усіма даними, які не захоплено до знімка"
 ],
 "Root password": [
  null,
  "Пароль root"
 ],
 "Route to $0": [
  null,
  "Маршрут до $0"
 ],
 "Routed network": [
  null,
  "Маршрутизована мережа"
 ],
 "Run": [
  null,
  "Запустити"
 ],
 "Run when host boots": [
  null,
  "Запустити під час завантаження основної системи"
 ],
 "Running": [
  null,
  "Працює"
 ],
 "SPICE TLS port": [
  null,
  "Порт TLS SPICE"
 ],
 "SPICE address": [
  null,
  "Адреса SPICE"
 ],
 "SPICE port": [
  null,
  "Порт SPICE"
 ],
 "Save": [
  null,
  "Зберегти"
 ],
 "Select console type": [
  null,
  "Вибір типу консолі"
 ],
 "Send key": [
  null,
  "Надіслати ключ"
 ],
 "Send non-maskable interrupt": [
  null,
  "Надіслати немасковане переривання"
 ],
 "Serial": [
  null,
  "Серійний номер"
 ],
 "Serial console": [
  null,
  "Послідовна консоль"
 ],
 "Serial console ($0)": [
  null,
  "Послідовна консоль ($0)"
 ],
 "Set DHCP range": [
  null,
  "Встановити діапазон DHCP"
 ],
 "Set manually": [
  null,
  "Встановити вручну"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Встановлення паролів користувачів для автоматичного встановлення потребує запуску віртуальної машини при створенні системи"
 ],
 "Share": [
  null,
  "Оприлюднити"
 ],
 "Share a host directory with the guest": [
  null,
  "Надати каталог основної системи у спільне користування гостьовій системі"
 ],
 "Shared directories": [
  null,
  "Спільні каталоги"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Спільні каталоги основної системи має бути змонтовано вручну у ВМ"
 ],
 "Shared storage": [
  null,
  "Спільне сховище даних"
 ],
 "Show additional options": [
  null,
  "Показати додаткові параметри"
 ],
 "Shut down": [
  null,
  "Вимкнути"
 ],
 "Shut off": [
  null,
  "Вимкнути"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Вимкніть віртуальну машину, щоб розпочати редагування налаштувань мікропрограми"
 ],
 "Shutting down": [
  null,
  "Вимикання"
 ],
 "Size": [
  null,
  "Розмір"
 ],
 "Slot": [
  null,
  "Слот"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "Не вдалося вилучити знімок $0"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "Знімок $0 буде вилучено з $1. Усі захоплені у ньому дані буде втрачено."
 ],
 "Snapshot failed to be created": [
  null,
  "Не вдалося створити знімок"
 ],
 "Snapshots": [
  null,
  "Знімки"
 ],
 "Sockets": [
  null,
  "Сокети"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "Деякі зміни у налаштуваннях набудуть чинності лише після перезавантаження:"
 ],
 "Source": [
  null,
  "Джерело"
 ],
 "Source format": [
  null,
  "Початковий формат"
 ],
 "Source must not be empty": [
  null,
  "Джерело має бути непорожнім"
 ],
 "Source path": [
  null,
  "Шлях до джерела"
 ],
 "Source path should not be empty": [
  null,
  "Шлях до джерела не може бути порожнім"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "Адреса джерела має починатися із назви протоколу — http, ftp або nfs"
 ],
 "Source volume group": [
  null,
  "Початкова група томів"
 ],
 "Start": [
  null,
  "Почати"
 ],
 "Start pool when host boots": [
  null,
  "Запускати резервне сховище після завантаження вузла"
 ],
 "Start should not be empty": [
  null,
  "Початок повинен бути непорожнім"
 ],
 "Startup": [
  null,
  "Запуск"
 ],
 "State": [
  null,
  "Стан"
 ],
 "Static host entries": [
  null,
  "Записи статичних вузлів"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "Не вдалося вилучити статичний вузол з DHCP"
 ],
 "Storage": [
  null,
  "Сховище даних"
 ],
 "Storage is at a shared location": [
  null,
  "Сховище даних є адресою спільного користування"
 ],
 "Storage limit": [
  null,
  "Обмеження сховища даних"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Не вдалося активувати буфер сховища $0"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Не вдалося деактивувати буфер сховища $0"
 ],
 "Storage pool failed to be created": [
  null,
  "Не вдалося створити резервне сховище"
 ],
 "Storage pool name": [
  null,
  "Назва резервного сховища"
 ],
 "Storage pools": [
  null,
  "Буфери даних"
 ],
 "Storage pools could not be fetched": [
  null,
  "Не вдалося отримати буфери сховища даних"
 ],
 "Storage size must not be 0": [
  null,
  "Розмір сховища має бути ненульовим"
 ],
 "Storage volume": [
  null,
  "Том сховища даних"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "Розмір тому сховища даних не повинен перевищувати місткість буфера сховища даних ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Томи даних"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Не вдалося вилучити томи сховища даних"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Томи сховища даних мають бути спільними між цією основною системою та основною системою призначення."
 ],
 "Suspended (PM)": [
  null,
  "призупинено (PM)"
 ],
 "System": [
  null,
  "Система"
 ],
 "Table of selectable host devices": [
  null,
  "Таблиця придатних для вибору пристроїв основної системи"
 ],
 "Target": [
  null,
  "Призначення"
 ],
 "Target path": [
  null,
  "Шлях призначення"
 ],
 "Target path should not be empty": [
  null,
  "Шлях призначення не може бути порожнім"
 ],
 "Temporary": [
  null,
  "Тимчасове"
 ],
 "Temporary migration": [
  null,
  "Тимчасове перенесення"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "Запущено віртуальну машину $0. Її буде примусово зупинено перед вилученням."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "Віртуальну машину має бути запущено або вимкнено, щоб можна було від'єднати цей пристрій"
 ],
 "The directory on the server being exported": [
  null,
  "Каталог на сервері, який експортується"
 ],
 "The host path that is to be exported.": [
  null,
  "Шлях у основній системі, який має бути експортовано."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "Налаштування перенесеної ВМ вилучено з основної системи джерела. Основна система призначення тепер вважається новою домівкою ВМ."
 ],
 "The pool is empty": [
  null,
  "Буфер порожній"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Для вибраної операційної системи мінімальним обсягом пам'яті є $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Для вибраної операційної системи мінімальним об'ємом пристрою накопичення даних є $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "Статичний запис вузла для $0 буде вилучено:"
 ],
 "The storage pool could not be deleted": [
  null,
  "Не вдалося вилучити буфер сховища даних"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "Назва мітки, яку буде використано гостьовою системою для монтування цієї точки експортування."
 ],
 "Then copy and paste it above.": [
  null,
  "Потім скопіюйте та вставте його вище."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Ця віртуальна машина є тимчасовою. Вимкніть її, якщо хочете її вилучити."
 ],
 "This disk will be removed from $0:": [
  null,
  "Цей диск буде вилучено з $0:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Цю файлову систему буде вилучено з $0:"
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Це рекомендовані налаштування для загальної можливості з'єднань у гостьовій системі на основних системах із динамічними/бездротовими налаштуваннями мережі."
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Це рекомендовані налаштування для загальної можливості з'єднань у гостьовій системі на основних системах зі статичними дротовими налаштуваннями мережі."
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  "Це рекомендовані налаштування для високої швидкодії і додаткового захисту."
 ],
 "This volume is already used by $0.": [
  null,
  "Цей том вже використано $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "Цей том вже використано іншою ВМ."
 ],
 "Threads per core": [
  null,
  "Потоків на ядро"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Для тимчасових віртуальних машин не передбачено підтримки редагування налаштувань мікропрограми"
 ],
 "Troubleshoot": [
  null,
  "Діагностика проблем"
 ],
 "Type": [
  null,
  "Тип"
 ],
 "Type ID": [
  null,
  "Ідентифікатор типу"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "Адреса (образ ISO або ієрархія каталогів встановлення дистрибутиву)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Не визначено"
 ],
 "Unique name": [
  null,
  "Унікальна назва"
 ],
 "Unique name, default: $0": [
  null,
  "Унікальна назва, типовий варіант: $0"
 ],
 "Unique network name": [
  null,
  "Унікальна назва мережі"
 ],
 "Unit": [
  null,
  "Модуль"
 ],
 "Unknown": [
  null,
  "Невідомий"
 ],
 "Unknown firmware": [
  null,
  "Невідома мікропрограма"
 ],
 "Unspecified": [
  null,
  "Не вказано"
 ],
 "Url": [
  null,
  "Адреса"
 ],
 "Usage": [
  null,
  "Використання"
 ],
 "Use existing": [
  null,
  "Використати наявний"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Використати розширені атрибути для файлів і каталогів"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Використати те саме місце на початковій основній системі і основній системі призначення для вашого сховища даних. Це може бути спільний буфер сховища даних, NFS або будь-який інший метод створення спільного сховища даних."
 ],
 "Used": [
  null,
  "Використано"
 ],
 "Used by": [
  null,
  "Використовується"
 ],
 "User login": [
  null,
  "Користувач"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Якщо встановлено пароль користувача, ім'я користувача не може бути порожнім"
 ],
 "User password": [
  null,
  "Пароль користувача"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Якщо встановлено ім'я користувача, пароль користувача не може бути порожнім"
 ],
 "User session": [
  null,
  "Сеанс користувача"
 ],
 "VCPU settings could not be saved": [
  null,
  "Не вдалося зберегти параметри віртуальних процесорів"
 ],
 "VM $0 Host Devices": [
  null,
  "Пристрої основної системи ВМ $0"
 ],
 "VM $0 already exists": [
  null,
  "ВМ із назвою $0 вже існує"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "На з'єднання $1 не існує ВМ $0"
 ],
 "VM $0 failed to force reboot": [
  null,
  "Не вдалося примусово перезавантажити віртуальну машину $0"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "Не вдалося примусово вимкнути віртуальну машину $0"
 ],
 "VM $0 failed to get installed": [
  null,
  "Не вдалося встановити віртуальну машину $0"
 ],
 "VM $0 failed to pause": [
  null,
  "Не вдалося призупинити віртуальну машину $0"
 ],
 "VM $0 failed to reboot": [
  null,
  "Не вдалося перезавантажити віртуальну машину $0"
 ],
 "VM $0 failed to resume": [
  null,
  "Не вдалося відновити роботу віртуальної машини $0"
 ],
 "VM $0 failed to send NMI": [
  null,
  "Не вдалося надіслати NMI віртуальній машині $0"
 ],
 "VM $0 failed to shutdown": [
  null,
  "Не вдалося вимкнути віртуальну машину $0"
 ],
 "VM $0 failed to start": [
  null,
  "Не вдалося запустити віртуальну машину $0"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "ВМ запущено із непривілейованим обмеженим доступом з процесом і PTY, власником яких є в ваш обліковий запис користувача"
 ],
 "VM needs shutdown": [
  null,
  "ВМ потребує вимикання"
 ],
 "VM state": [
  null,
  "Стан ВМ"
 ],
 "VM will launch with root permissions": [
  null,
  "ВМ буде запущено із правами доступу root"
 ],
 "VNC TLS port": [
  null,
  "Порт TLS VNC"
 ],
 "VNC address": [
  null,
  "Адреса VNC"
 ],
 "VNC console": [
  null,
  "Консоль VNC"
 ],
 "VNC port": [
  null,
  "Порт VNC"
 ],
 "Valid token": [
  null,
  "Чинний жетон"
 ],
 "Vendor": [
  null,
  "Постачальник"
 ],
 "Virtual machines": [
  null,
  "Віртуальні машини"
 ],
 "Virtual machines management": [
  null,
  "Керування віртуальними машинами"
 ],
 "Virtual network": [
  null,
  "Віртуальна мережа"
 ],
 "Virtual network failed to be created": [
  null,
  "Не вдалося створити віртуальну мережу"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Служба віртуалізації (libvirt) не є активною"
 ],
 "Volume": [
  null,
  "Том"
 ],
 "Volume failed to be created": [
  null,
  "Не вдалося створити том"
 ],
 "Volume group name": [
  null,
  "Назва групи томів"
 ],
 "Volume group name should not be empty": [
  null,
  "Назва групи томів має бути непорожньою"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Сторожовик"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Засоби нагляду (сторожовики) працюють, коли системи припиняють відповідати на запити. Щоб скористатися цим віртуальним пристроєм нагляду, у гостьовій системі також має бути додатковий драйвер і запущена служба нагляду."
 ],
 "Writeable": [
  null,
  "Придатний до запису"
 ],
 "Writeable and shared": [
  null,
  "Придатний до запису і спільний"
 ],
 "You can mount the shared folder using:": [
  null,
  "Змонтувати спільну теку можна за допомогою такої команди:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Вам слід вибрати найвідповіднішу операційну систему"
 ],
 "active": [
  null,
  "активний"
 ],
 "add": [
  null,
  "додати"
 ],
 "add entry": [
  null,
  "додати запис"
 ],
 "bridge": [
  null,
  "місток"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "нетиповий"
 ],
 "direct": [
  null,
  "безпосередньо"
 ],
 "disabled": [
  null,
  "вимкнено"
 ],
 "disk": [
  null,
  "диск"
 ],
 "down": [
  null,
  "нижче"
 ],
 "edit": [
  null,
  "редагувати"
 ],
 "enabled": [
  null,
  "увімкнено"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "вузол"
 ],
 "host device": [
  null,
  "пристрій основної системи"
 ],
 "host passthrough": [
  null,
  "передавання вузла"
 ],
 "hostdev": [
  null,
  "пристрій осн. системи"
 ],
 "iSCSI direct target": [
  null,
  "Безпосереднє призначення iSCSI"
 ],
 "iSCSI initiator IQN": [
  null,
  "IQN ініціатора iSCSI"
 ],
 "iSCSI target": [
  null,
  "Ціль iSCSI"
 ],
 "iSCSI target IQN": [
  null,
  "IQN цілі iSCSI"
 ],
 "inactive": [
  null,
  "неактивний"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "додаткова інформація"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "точка монтування: точка монтування всередині гостьової системи"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "мітка монтування: мітка, яку пов'язано із експортованою точкою монтування"
 ],
 "network": [
  null,
  "мережа"
 ],
 "no": [
  null,
  "ні"
 ],
 "no state saved": [
  null,
  "немає збережених станів"
 ],
 "none": [
  null,
  "немає"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "переспрямований пристрій"
 ],
 "remove": [
  null,
  "вилучити"
 ],
 "serial number": [
  null,
  "серійний номер"
 ],
 "server": [
  null,
  "сервер"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "вище"
 ],
 "user": [
  null,
  "користувач"
 ],
 "vCPU count": [
  null,
  "К-ть вірт. процесорів"
 ],
 "vCPU maximum": [
  null,
  "Макс. вірт. процесорів"
 ],
 "vCPUs": [
  null,
  "Вірт. проц."
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "докладніше…"
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Для клонування віртуальних машин у системі має бути встановлено пакунок virt-install"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Для створення нових віртуальних машин у системі має бути встановлено пакунок virt-install"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Для редагування цього атрибута у системі має бути встановлено пакунок virt-install"
 ],
 "vm": [
  null,
  "vm"
 ],
 "yes": [
  null,
  "так"
 ]
});
