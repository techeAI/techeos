cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "it",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  ""
 ],
 "$0 CPU configuration": [
  null,
  "Configurazione CPU $0"
 ],
 "$0 Network": [
  null,
  "Rete $0",
  "Rete $0"
 ],
 "$0 Storage pool": [
  null,
  "$0 Pool di archiviazione",
  "$0 Pool di archiviazione"
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 è disponibile per la maggior parte dei sistemi operativi. Per installarlo, cercalo in GNOME Software o esegui quanto segue:"
 ],
 "$0 memory adjustment": [
  null,
  "$0 regolazione della memoria"
 ],
 "$0 network": [
  null,
  "Rete $0"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPU",
  "$0 vCPU"
 ],
 "$0 vCPU details": [
  null,
  "$0 dettagli vCPU"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 impostazioni dell'interfaccia di rete virtuale"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  ""
 ],
 "Access": [
  null,
  "Accesso"
 ],
 "Activate": [
  null,
  "Attiva"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  ""
 ],
 "Add": [
  null,
  "Aggiungi"
 ],
 "Add a DHCP static host entry": [
  null,
  ""
 ],
 "Add disk": [
  null,
  "Aggiungi disco"
 ],
 "Add network interface": [
  null,
  "Aggiungi interfaccia di rete"
 ],
 "Add virtual network interface": [
  null,
  "Aggiungi interfaccia di rete virtuale"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  ""
 ],
 "Additional": [
  null,
  "Aggiuntivo"
 ],
 "Address": [
  null,
  "Indirizzo"
 ],
 "Address not within subnet": [
  null,
  "L'indirizzo non è nella sottorete"
 ],
 "All": [
  null,
  "Tutti"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  ""
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  ""
 ],
 "Always attach": [
  null,
  "Allega sempre"
 ],
 "Apply": [
  null,
  "Applica"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  ""
 ],
 "Automatic": [
  null,
  "Automatico"
 ],
 "Autostart": [
  null,
  "Avvio automatico"
 ],
 "Blocked": [
  null,
  "Bloccato"
 ],
 "Boot order": [
  null,
  "Ordine di Avvio"
 ],
 "Boot order settings could not be saved": [
  null,
  "Impossibile salvare le impostazioni dell'ordine di avvio"
 ],
 "Bus": [
  null,
  "Bus"
 ],
 "CD/DVD disc": [
  null,
  ""
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU configuration could not be saved": [
  null,
  "Impossibile salvare la configurazione della CPU"
 ],
 "CPU type": [
  null,
  "Tipo CPU"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Annulla"
 ],
 "Capacity": [
  null,
  "Capacità"
 ],
 "Change firmware": [
  null,
  "Cambia firmware"
 ],
 "Changes pending": [
  null,
  ""
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Le modifiche avranno effetto dopo lo spegnimento della VM"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  ""
 ],
 "Checking token validity...": [
  null,
  ""
 ],
 "Choose an operating system": [
  null,
  "Scegli un sistema operativo"
 ],
 "Class": [
  null,
  ""
 ],
 "Clone": [
  null,
  "Clona"
 ],
 "Close": [
  null,
  "Chiudi"
 ],
 "Confirm this action": [
  null,
  "Conferma questa azione"
 ],
 "Connect": [
  null,
  "Connetti"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "Connetti con qualsiasi applicazione di visualizzazione per i protocolli seguenti"
 ],
 "Connection": [
  null,
  "Connessione"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Cores per socket": [
  null,
  "Core per socket"
 ],
 "Could not revert to snapshot": [
  null,
  "Impossibile ripristinare lo snapshot"
 ],
 "Create": [
  null,
  "Crea"
 ],
 "Create VM": [
  null,
  "Crea VM"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  ""
 ],
 "Create VM from local or network installation medium": [
  null,
  ""
 ],
 "Create a clone VM based on $0": [
  null,
  "Crea un clone della VM basata su $0"
 ],
 "Create new": [
  null,
  "Crea nuovo"
 ],
 "Create new virtual machine": [
  null,
  "Crea nuova macchina virtuale"
 ],
 "Create new volume": [
  null,
  "Crea nuovo volume"
 ],
 "Create snapshot": [
  null,
  "Crea snapshot"
 ],
 "Create storage pool": [
  null,
  "Crea pool di archiviazione"
 ],
 "Create storage volume": [
  null,
  "Crea volume di archiviazione"
 ],
 "Create virtual network": [
  null,
  "Crea rete virtuale"
 ],
 "Create volume": [
  null,
  "Crea volume"
 ],
 "Creating VM": [
  null,
  "Creazione VM"
 ],
 "Creation of VM $0 failed": [
  null,
  "Creazione della VM $0 non riuscita"
 ],
 "Creation time": [
  null,
  "Data di creazione"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Corrente"
 ],
 "Current allocation": [
  null,
  "Allocazione corrente"
 ],
 "Custom firmware: $0": [
  null,
  "Firmware personalizzato: $0"
 ],
 "Deactivate": [
  null,
  "Disattiva"
 ],
 "Delete": [
  null,
  "Cancella"
 ],
 "Delete $0 volume": [
  null,
  "Elimina il volume $0",
  "Elimina i volumi $0"
 ],
 "Delete associated storage files:": [
  null,
  "Elimina i file di archiviazione associati:"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "L'eliminazione di un pool di archiviazione inattivo annullerà soltanto la definizione del pool. Il suo contenuto non verrà eliminato."
 ],
 "Description": [
  null,
  "Descrizione"
 ],
 "Desktop viewer": [
  null,
  "Visualizzatore desktop"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Scollegare i dischi utilizzando questo pool da qualsiasi VM prima di tentare l'eliminazione."
 ],
 "Details": [
  null,
  ""
 ],
 "Device": [
  null,
  "Dispositivo"
 ],
 "Devices": [
  null,
  "Dispositivi"
 ],
 "Disconnect": [
  null,
  "Disconnetti"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Disconnesso dalla console seriale. Fai clic sul pulsante Connetti."
 ],
 "Disk failed to be attached": [
  null,
  "Il disco non è stato collegato"
 ],
 "Disk failed to be created": [
  null,
  "Impossibile creare il disco"
 ],
 "Disk images can be stored in user home directory": [
  null,
  ""
 ],
 "Disk settings could not be saved": [
  null,
  "Impossibile salvare le impostazioni del disco"
 ],
 "Disk-only snapshot": [
  null,
  "Solo snapshot del disco"
 ],
 "Disks": [
  null,
  "Dischi"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  ""
 ],
 "Do nothing": [
  null,
  ""
 ],
 "Domain has crashed": [
  null,
  "Il dominio è andato in crash"
 ],
 "Domain is blocked on resource": [
  null,
  "Il dominio è bloccato sulla risorsa"
 ],
 "Download an OS": [
  null,
  "Scarica un OS"
 ],
 "Download progress": [
  null,
  ""
 ],
 "Dump core": [
  null,
  ""
 ],
 "Edit": [
  null,
  "Modifica"
 ],
 "Edit $0 attributes": [
  null,
  "Modifica $0 attributi"
 ],
 "Edit watchdog device type": [
  null,
  ""
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  ""
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  ""
 ],
 "Eject": [
  null,
  ""
 ],
 "Emulated machine": [
  null,
  "Macchina emulata"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  ""
 ],
 "End": [
  null,
  "Fine"
 ],
 "End should not be empty": [
  null,
  "La fine non può essere vuota"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  ""
 ],
 "Error checking token": [
  null,
  ""
 ],
 "Example, $0": [
  null,
  ""
 ],
 "Existing disk image on host's file system": [
  null,
  "Immagine del disco esistente sul file system dell'host"
 ],
 "Expand": [
  null,
  "Espandi"
 ],
 "Failed": [
  null,
  "Fallito"
 ],
 "Failed to change firmware": [
  null,
  "Impossibile cambiare il firmware"
 ],
 "Failed to clone VM $0": [
  null,
  "Impossibile clonare la VM $0"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "Impossibile recuperare gli indirizzi IP delle interfacce presenti in $0"
 ],
 "Failed to save network settings": [
  null,
  ""
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Impossibile inviare la combinazione Ctrl+Alt+$0 alla VM $1"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Un numero massimo inferiore di CPU virtuali dovrebbe essere abilitato."
 ],
 "File": [
  null,
  "File"
 ],
 "Filesystem directory": [
  null,
  "Cartella dei file system"
 ],
 "Filter by name": [
  null,
  "Filtra per nome"
 ],
 "Firmware": [
  null,
  "Firmware"
 ],
 "Force shut down": [
  null,
  "Forza spegnimento"
 ],
 "Format": [
  null,
  "Formatta"
 ],
 "Forward mode": [
  null,
  "Modalità di reindirizzamento"
 ],
 "Forwarding mode": [
  null,
  "Modalità di inoltro"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  ""
 ],
 "General": [
  null,
  "Generale"
 ],
 "Generate automatically": [
  null,
  "Genera automaticamente"
 ],
 "Get a new RHSM token.": [
  null,
  ""
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  ""
 ],
 "Good choice for desktop virtualization": [
  null,
  ""
 ],
 "Hide additional options": [
  null,
  "Nascondi opzioni aggiuntive"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Host device": [
  null,
  "Dispositivo host"
 ],
 "Host device will be removed from $0:": [
  null,
  ""
 ],
 "Host name": [
  null,
  "Nome dell'host"
 ],
 "Host should not be empty": [
  null,
  "L'host non deve essere vuoto"
 ],
 "Hypervisor details": [
  null,
  "Dettagli Hypervisor"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  ""
 ],
 "IP address": [
  null,
  "Indirizzo IP"
 ],
 "IP configuration": [
  null,
  "Configurazione IP"
 ],
 "IPv4 address": [
  null,
  "Indirizzo IPv4"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  ""
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  ""
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 e IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "La rete IPv4 non può essere vuota"
 ],
 "IPv4 only": [
  null,
  "Solo IPv4"
 ],
 "IPv6 address": [
  null,
  "Indirizzo IPv6"
 ],
 "IPv6 network should not be empty": [
  null,
  "La rete IPv6 non può essere vuota"
 ],
 "IPv6 only": [
  null,
  "Solo IPv6"
 ],
 "Ideal for server VMs": [
  null,
  ""
 ],
 "Ideal networking support": [
  null,
  ""
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  ""
 ],
 "Idle": [
  null,
  "Inattivo"
 ],
 "Ignore": [
  null,
  ""
 ],
 "Import VM": [
  null,
  "Importa VM"
 ],
 "Import a virtual machine": [
  null,
  "Importa una macchina virtuale"
 ],
 "Import and edit": [
  null,
  ""
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  ""
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "Nella maggior parte delle configurazioni, macvtap non funziona per le comunicazioni di rete da host a guest."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  ""
 ],
 "Initiator": [
  null,
  "Iniziatore"
 ],
 "Initiator IQN should not be empty": [
  null,
  "L'iniziatore IQN non può essere vuoto"
 ],
 "Insert disc media": [
  null,
  ""
 ],
 "Install": [
  null,
  "Installa"
 ],
 "Installation source must not be empty": [
  null,
  "L'origine dell'installazione non può essere vuota"
 ],
 "Installation type": [
  null,
  "Tipo di installazione"
 ],
 "Interface type": [
  null,
  "Tipo di interfaccia"
 ],
 "Invalid IPv4 address": [
  null,
  "Indirizzo IPv4 non valido"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Lunghezza maschera o prefisso IPv4 non valido"
 ],
 "Invalid IPv6 address": [
  null,
  "Indirizzo IPv6 non valido"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Prefisso IPv6 non valido"
 ],
 "Invalid filename": [
  null,
  "Nome file non valido"
 ],
 "Isolated network": [
  null,
  "Rete isolata"
 ],
 "LVM volume group": [
  null,
  "Gruppo di volumi LVM"
 ],
 "Launch remote viewer": [
  null,
  "Avviare il visualizzatore remoto"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Lascia vuota la password se non si desidera creare un account root"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Lasciare vuota la password se non si desidera creare un account utente"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt non ha rilevato alcuna immagine del firmware UEFI/OVMF installata sull'host"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt o hypervisor non supporta UEFI"
 ],
 "Loading resources": [
  null,
  "Caricamento delle risorse"
 ],
 "Loading...": [
  null,
  "Caricamento in corso..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  ""
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "Indirizzo MAC"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "La macchina deve essere spenta prima di cambiare il tipo di bus"
 ],
 "Managing virtual machines": [
  null,
  "Gestione delle macchine virtuali"
 ],
 "Manual connection": [
  null,
  "Collegamento manuale"
 ],
 "Mask or prefix length": [
  null,
  "Maschera o lunghezza prefisso"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "La maschera o la lunghezza del prefisso non può essere vuota"
 ],
 "Maximum allocation": [
  null,
  "Allocazione massima"
 ],
 "Maximum memory could not be saved": [
  null,
  "Non è stato possibile salvare la memoria massima"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Numero massimo di CPU virtuali allocate per il sistema operativo guest"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Numero massimo di CPU virtuali allocate per il sistema operativo guest, che deve essere compreso tra 1 e $0"
 ],
 "Maximum transmission unit": [
  null,
  "Unità di trasmissione massima (MTU)"
 ],
 "Media will be ejected from $0:": [
  null,
  ""
 ],
 "Memory": [
  null,
  "Memoria"
 ],
 "Memory could not be saved": [
  null,
  "Non è stato possibile salvare la memoria"
 ],
 "Memory must not be 0": [
  null,
  "La memoria non può essere 0"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  ""
 ],
 "Migrate VM to another host": [
  null,
  ""
 ],
 "Mode": [
  null,
  "Modalità"
 ],
 "Model": [
  null,
  "Modello"
 ],
 "Model type": [
  null,
  "Tipo di modello"
 ],
 "More info for mount tag field": [
  null,
  ""
 ],
 "More info for source path field": [
  null,
  ""
 ],
 "Mount tag": [
  null,
  ""
 ],
 "NAT to $0": [
  null,
  "NAT su $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "NIC $0 di VM $1 non è riuscito a cambiare stato"
 ],
 "Name": [
  null,
  "Nome"
 ],
 "Name contains invalid characters": [
  null,
  "Il nome contiene caratteri non validi"
 ],
 "Name must not be empty": [
  null,
  "Il nome non può essere vuoto"
 ],
 "Name should not be empty": [
  null,
  "Il nome non deve essere vuoto"
 ],
 "Name: ": [
  null,
  "Nome: "
 ],
 "Netmask": [
  null,
  "Maschera di rete"
 ],
 "Network $0 failed to get activated": [
  null,
  "Impossibile attivare la rete $0"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Impossibile disattivare la rete $0"
 ],
 "Network boot (PXE)": [
  null,
  "Avvio da rete (PXE)"
 ],
 "Network file system": [
  null,
  "File system di rete"
 ],
 "Network interface settings could not be saved": [
  null,
  "Impossibile salvare le impostazioni dell'interfaccia di rete"
 ],
 "Network selection does not support PXE.": [
  null,
  "La selezione della rete non supporta PXE."
 ],
 "Networks": [
  null,
  "Reti"
 ],
 "New volume name": [
  null,
  "Nuovo nome del volume"
 ],
 "No VM is running or defined on this host": [
  null,
  "Nessuna VM è in esecuzione o definita su questo host"
 ],
 "No boot device found": [
  null,
  "Nessun dispositivo di avvio trovato"
 ],
 "No description": [
  null,
  "Nessuna descrizione"
 ],
 "No directories shared between the host and this VM": [
  null,
  ""
 ],
 "No disks defined for this VM": [
  null,
  "Nessun disco definito per questa VM"
 ],
 "No network devices": [
  null,
  "Nessun dispositivo di rete"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Nessuna interfaccia di rete definita per questa macchina virtuale"
 ],
 "No network is defined on this host": [
  null,
  "Nessuna rete definita su questo host"
 ],
 "No networks available": [
  null,
  "Nessuna rete disponibile"
 ],
 "No storage": [
  null,
  "Nessuna archiviazione"
 ],
 "No storage pool is defined on this host": [
  null,
  "Nessun pool di archiviazione è definito su questo host"
 ],
 "No storage pools available": [
  null,
  "Nessun pool di archiviazione disponibile"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Nessun Volume di archiviazione definito per questo pool di archiviazione"
 ],
 "No virtual networks": [
  null,
  "Nessuna rete virtuale"
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "La rete non persistente non può essere eliminata. Cessa di esistere quando viene disattivata."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Il pool di archiviazione non persistente non può essere eliminato. Cessa di esistere quando è disattivato."
 ],
 "None": [
  null,
  "Nessuno"
 ],
 "None (isolated network)": [
  null,
  "Nessuno (Rete Isolata)"
 ],
 "Offline token": [
  null,
  ""
 ],
 "Old token expired": [
  null,
  ""
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Uno o più volumi selezionati sono utilizzati dai domini. Scollegare prima i dischi per consentire l'eliminazione del volume."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Modificabile solo quando il guest è spento"
 ],
 "Open": [
  null,
  "Apri"
 ],
 "Operating system": [
  null,
  "Sistema Operativo"
 ],
 "Operation is in progress": [
  null,
  "Operazione in corso"
 ],
 "Overview": [
  null,
  "Panoramica"
 ],
 "PCI": [
  null,
  ""
 ],
 "Path": [
  null,
  "Percorso"
 ],
 "Path on host's filesystem": [
  null,
  "Percorso sul file system dell'host"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Percorso del file ISO sul file system dell'host"
 ],
 "Pause": [
  null,
  "Pausa"
 ],
 "Paused": [
  null,
  "In pausa"
 ],
 "Permanent (default)": [
  null,
  ""
 ],
 "Permissions denied for disk images in home directories": [
  null,
  ""
 ],
 "Persistence": [
  null,
  "Persistenza"
 ],
 "Persistent": [
  null,
  "Persistente"
 ],
 "Physical disk device": [
  null,
  "Dispositivo disco fisico"
 ],
 "Physical disk device on host": [
  null,
  "Dispositivo disco fisico sull'host"
 ],
 "Please choose a storage pool": [
  null,
  "Scegli un pool di archiviazione"
 ],
 "Please choose a volume": [
  null,
  "Scegli un volume"
 ],
 "Please enter new volume name": [
  null,
  "Inserisci il nuovo nome del volume"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "Avvia la macchina virtuale per accedere alla sua console."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool needs to be active to create volume": [
  null,
  ""
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Il tipo di pool non supporta la creazione di volumi"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "I volumi del pool vengono utilizzati dalle VM "
 ],
 "Port": [
  null,
  "Porta"
 ],
 "Power off": [
  null,
  ""
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Numero preferito di socket da esporre al guest."
 ],
 "Prefix": [
  null,
  "Prefisso"
 ],
 "Prefix length": [
  null,
  "Lunghezza prefisso"
 ],
 "Prefix length should not be empty": [
  null,
  "La lunghezza del prefisso non può essere vuota"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Gli snapshot eseguiti in precedenza consentono di tornare a uno stato precedente se qualcosa va storto"
 ],
 "Private": [
  null,
  "Privato"
 ],
 "Product": [
  null,
  "Prodotto"
 ],
 "Profile": [
  null,
  "Profilo"
 ],
 "Protocol": [
  null,
  "Protocollo"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  ""
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  ""
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  ""
 ],
 "Read-only": [
  null,
  "Sola lettura"
 ],
 "Reboot": [
  null,
  "Riavvia"
 ],
 "Remote URL": [
  null,
  "URL remoto"
 ],
 "Remote viewer details": [
  null,
  "Dettagli visualizzatore remoto"
 ],
 "Remove": [
  null,
  "Elimina"
 ],
 "Remove and delete file": [
  null,
  ""
 ],
 "Remove static host from DHCP": [
  null,
  ""
 ],
 "Rename": [
  null,
  ""
 ],
 "Rename VM $0": [
  null,
  ""
 ],
 "Reset": [
  null,
  ""
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  ""
 ],
 "Resume": [
  null,
  "Riprendi"
 ],
 "Revert": [
  null,
  "Ripristina"
 ],
 "Revert to snapshot $0": [
  null,
  "Ripristina allo snapshot $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Il ripristino di questa istantanea riporterà la VM al momento dell'istantanea e lo stato corrente andrà perso, insieme a tutti i dati non acquisiti in un'istantanea"
 ],
 "Root password": [
  null,
  "Password di root"
 ],
 "Route to $0": [
  null,
  "Rotta verso $0"
 ],
 "Routed network": [
  null,
  "Rete instradata"
 ],
 "Run": [
  null,
  "Esegui"
 ],
 "Run when host boots": [
  null,
  "Esegui all'avvio dell'host"
 ],
 "Running": [
  null,
  "In esecuzione"
 ],
 "Save": [
  null,
  "Salva"
 ],
 "Select console type": [
  null,
  "Seleziona il tipo di console"
 ],
 "Send key": [
  null,
  "Invia tasto"
 ],
 "Send non-maskable interrupt": [
  null,
  "Invia interruzione non mascherabile"
 ],
 "Serial console": [
  null,
  "Console seriale"
 ],
 "Set DHCP range": [
  null,
  "Imposta intervallo DHCP"
 ],
 "Set manually": [
  null,
  "Imposta manualmente"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "L'impostazione delle password utente per l'installazione automatica richiede l'avvio della VM durante la sua creazione"
 ],
 "Share": [
  null,
  ""
 ],
 "Share a host directory with the guest": [
  null,
  ""
 ],
 "Shared directories": [
  null,
  ""
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  ""
 ],
 "Show additional options": [
  null,
  "Mostra opzioni aggiuntive"
 ],
 "Shut down": [
  null,
  "Arresto"
 ],
 "Shut off": [
  null,
  "Arresto"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Spegni la VM per modificare la configurazione del firmware"
 ],
 "Shutting down": [
  null,
  "Spegnimento"
 ],
 "Size": [
  null,
  "Dimensione"
 ],
 "Slot": [
  null,
  ""
 ],
 "Snapshot failed to be created": [
  null,
  "Impossibile creare lo snapshot"
 ],
 "Snapshots": [
  null,
  "Snapshot"
 ],
 "Sockets": [
  null,
  "Socket"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  ""
 ],
 "Source": [
  null,
  "Sorgente"
 ],
 "Source format": [
  null,
  "Formato sorgente"
 ],
 "Source path": [
  null,
  "Percorso della sorgente"
 ],
 "Source path should not be empty": [
  null,
  "Il percorso della sorgente non deve essere vuoto"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "La sorgente deve iniziare con il protocollo http, ftp o nfs"
 ],
 "Source volume group": [
  null,
  "Sorgente del gruppo di volumi"
 ],
 "Start": [
  null,
  "Avvia"
 ],
 "Start pool when host boots": [
  null,
  "Avvia il pool all'avvio dell'host"
 ],
 "Start should not be empty": [
  null,
  "L'inizio non può essere vuoto"
 ],
 "Startup": [
  null,
  "Avvio"
 ],
 "State": [
  null,
  "Stato"
 ],
 "Static host entries": [
  null,
  ""
 ],
 "Storage": [
  null,
  "Archiviazione"
 ],
 "Storage is at a shared location": [
  null,
  ""
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Impossibile attivare il pool di archiviazione $0"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Impossibile disattivare il pool di archiviazione $0"
 ],
 "Storage pool failed to be created": [
  null,
  "Impossibile creare il pool di archiviazione"
 ],
 "Storage pool name": [
  null,
  "Nome del pool di archiviazione"
 ],
 "Storage pools": [
  null,
  "Pool di Archiviazione"
 ],
 "Storage size must not be 0": [
  null,
  "Le dimensioni di archiviazione non possono essere 0"
 ],
 "Storage volume": [
  null,
  "Volume di Archiviazione"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "Il volume di archiviazione non deve eccedere il volume del pool di archiviazione ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Volumi di Archiviazione"
 ],
 "Storage volumes could not be deleted": [
  null,
  "I Volumi di Archiviazione non possono essere eliminati"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  ""
 ],
 "Suspended (PM)": [
  null,
  "Sospesi (PM)"
 ],
 "System": [
  null,
  "Sistema"
 ],
 "Table of selectable host devices": [
  null,
  ""
 ],
 "Target": [
  null,
  "Destinazione"
 ],
 "Target path": [
  null,
  "Percorso di destinazione"
 ],
 "Target path should not be empty": [
  null,
  "Il percorso di destinazione non deve essere vuoto"
 ],
 "Temporary": [
  null,
  ""
 ],
 "Temporary migration": [
  null,
  ""
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "La VM deve essere in esecuzione o spenta per rimuovere questo dispositivo"
 ],
 "The directory on the server being exported": [
  null,
  "La directory sul server da esportare"
 ],
 "The host path that is to be exported.": [
  null,
  ""
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  ""
 ],
 "The pool is empty": [
  null,
  "Il pool è vuoto"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Il sistema operativo selezionato ha un requisito di memoria minimo di $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Il sistema operativo selezionato ha un requisito di dimensione minima di archiviazione di $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  ""
 ],
 "The storage pool could not be deleted": [
  null,
  "Impossibile eliminare il pool di archiviazione"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  ""
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Questa VM è temporanea. Chiudila se desideri cancellarla."
 ],
 "This disk will be removed from $0:": [
  null,
  ""
 ],
 "This filesystem will be removed from $0:": [
  null,
  ""
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  ""
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  ""
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  ""
 ],
 "This volume is already used by another VM.": [
  null,
  "Questo volume è già utilizzato da un'altra VM."
 ],
 "Threads per core": [
  null,
  "Threads per core"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Le VM non persistenti non supportano la modifica della configurazione firmware"
 ],
 "Troubleshoot": [
  null,
  "Risoluzione dei problemi"
 ],
 "Type": [
  null,
  "Tipo"
 ],
 "Type ID": [
  null,
  "ID tipo"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  ""
 ],
 "USB": [
  null,
  ""
 ],
 "UUID": [
  null,
  ""
 ],
 "Undefined": [
  null,
  ""
 ],
 "Unique name": [
  null,
  "Nome univoco"
 ],
 "Unique network name": [
  null,
  "Nome di rete univoco"
 ],
 "Unit": [
  null,
  "Unità"
 ],
 "Unknown": [
  null,
  "Sconosciuto"
 ],
 "Unknown firmware": [
  null,
  "Firmware sconosciuto"
 ],
 "Unspecified": [
  null,
  ""
 ],
 "Url": [
  null,
  "URL"
 ],
 "Usage": [
  null,
  "Utilizzo"
 ],
 "Use existing": [
  null,
  "Usa esistente"
 ],
 "Use extended attributes on files and directories": [
  null,
  ""
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  ""
 ],
 "Used": [
  null,
  "Usato"
 ],
 "Used by": [
  null,
  "Usato da"
 ],
 "User login must not be empty when user password is set": [
  null,
  ""
 ],
 "User password": [
  null,
  "Password utente"
 ],
 "User password must not be empty when user login is set": [
  null,
  ""
 ],
 "VCPU settings could not be saved": [
  null,
  "Non è stato possibile salvare le impostazioni VCPU"
 ],
 "VM $0 already exists": [
  null,
  "La VM $0 esiste già"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  ""
 ],
 "VM $0 failed to force reboot": [
  null,
  "Impossibile riavviare forzatamente la VM $0"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "Impossibile spegnere forzatamente la VM $0"
 ],
 "VM $0 failed to get installed": [
  null,
  "Impossibile installare la VM $0"
 ],
 "VM $0 failed to pause": [
  null,
  "Impossibile mettere in pausa la VM $0"
 ],
 "VM $0 failed to reboot": [
  null,
  "Impossibile Riavviare la VM $0"
 ],
 "VM $0 failed to resume": [
  null,
  "Impossibile riprendere la VM $0"
 ],
 "VM $0 failed to send NMI": [
  null,
  "La VM $0 non è riuscita a inviare l'NMI"
 ],
 "VM $0 failed to shutdown": [
  null,
  "Impossibile spegnere la VM $0"
 ],
 "VM $0 failed to start": [
  null,
  "Impossibile avviare la VM $0"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  ""
 ],
 "VM state": [
  null,
  "Stato VM"
 ],
 "VM will launch with root permissions": [
  null,
  ""
 ],
 "VNC console": [
  null,
  "Console VNC"
 ],
 "Valid token": [
  null,
  ""
 ],
 "Vendor": [
  null,
  "Rivenditore"
 ],
 "Virtual machines": [
  null,
  "Macchine virtuali"
 ],
 "Virtual machines management": [
  null,
  "Gestione macchine virtuali"
 ],
 "Virtual network": [
  null,
  "Rete virtuale"
 ],
 "Virtual network failed to be created": [
  null,
  "Impossibile creare la rete virtuale"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Il servizio di virtualizzazione (libvirt) non è attivo"
 ],
 "Volume": [
  null,
  "Volume"
 ],
 "Volume failed to be created": [
  null,
  "Impossibile creare il volume"
 ],
 "Volume group name": [
  null,
  "Nome del gruppo di volumi"
 ],
 "Volume group name should not be empty": [
  null,
  "Il nome del gruppo di volumi non può essere vuoto"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  ""
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  ""
 ],
 "Writeable": [
  null,
  "Scrivibile"
 ],
 "Writeable and shared": [
  null,
  "Scrivibile e condiviso"
 ],
 "You can mount the shared folder using:": [
  null,
  ""
 ],
 "You need to select the most closely matching operating system": [
  null,
  "È necessario selezionare il sistema operativo più prossimo"
 ],
 "active": [
  null,
  "attivo"
 ],
 "add entry": [
  null,
  ""
 ],
 "bridge": [
  null,
  "bridge"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "personalizzato"
 ],
 "direct": [
  null,
  "diretto"
 ],
 "disabled": [
  null,
  "disabilitato"
 ],
 "disk": [
  null,
  "disco"
 ],
 "down": [
  null,
  "giù"
 ],
 "edit": [
  null,
  "modifica"
 ],
 "enabled": [
  null,
  "abilitato"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "host"
 ],
 "host device": [
  null,
  "dispositivo host"
 ],
 "host passthrough": [
  null,
  "host passthrough"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "Target iSCSI diretto"
 ],
 "iSCSI initiator IQN": [
  null,
  "Iniziatore iSCSI IQN"
 ],
 "iSCSI target": [
  null,
  "Target iSCSI"
 ],
 "iSCSI target IQN": [
  null,
  "Target iSCSI IQN"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  ""
 ],
 "mount point: The mount point inside the guest": [
  null,
  ""
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  ""
 ],
 "network": [
  null,
  "rete"
 ],
 "no": [
  null,
  "no"
 ],
 "no state saved": [
  null,
  "nessuno stato salvato"
 ],
 "none": [
  null,
  ""
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "dispositivo reindirizzato"
 ],
 "serial number": [
  null,
  ""
 ],
 "server": [
  null,
  "server"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "su"
 ],
 "user": [
  null,
  "utente"
 ],
 "vCPU count": [
  null,
  "conteggio vCPU"
 ],
 "vCPU maximum": [
  null,
  "vCPU Massimo"
 ],
 "vCPUs": [
  null,
  "vCPU"
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "vedi di più..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Il pacchetto virt-install deve essere installato sul sistema per clonare le macchine virtuali"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Il pacchetto virt-install deve essere installato sul sistema per creare nuove macchine virtuali"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Il pacchetto virt-install deve essere installato sul sistema per modificare questo attributo"
 ],
 "vm": [
  null,
  "vm"
 ],
 "yes": [
  null,
  "si"
 ]
});
