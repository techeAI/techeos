cockpit.locale({
 "": {
  "plural-forms": (n) => n > 1,
  "language": "fr",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 disponibles à l’emplacement par défaut"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 disponibles sur l’hôte"
 ],
 "$0 CPU configuration": [
  null,
  "$0 Configuration du CPU"
 ],
 "$0 Network": [
  null,
  "$0 Réseau",
  "$0 Réseaux"
 ],
 "$0 Storage pool": [
  null,
  "$0 Pool de stockage",
  "$0 Pools de stockage"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 ne prend pas en charge les installations sans surveillance."
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 est disponible pour la plupart des systèmes d’exploitation. Pour l’installer, recherchez-le dans le logiciel GNOME ou exécutez les opérations suivantes :"
 ],
 "$0 memory adjustment": [
  null,
  "$0 ajustement de la mémoire"
 ],
 "$0 network": [
  null,
  "$0 réseau"
 ],
 "$0 vCPU": [
  null,
  "$0 processeur virtuel",
  "$0 processeurs virtuels"
 ],
 "$0 vCPU details": [
  null,
  "$0 détails vCPU"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 les paramètres de l’interface réseau virtuelle"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Une copie de la machine virtuelle s’exécutera sur la destination et disparaîtra lorsqu’elle sera fermée. Pendant ce temps, l’hôte d'origine conserve sa copie de la configuration de la machine virtuelle."
 ],
 "Access": [
  null,
  "Accès"
 ],
 "Action": [
  null,
  "Action"
 ],
 "Activate": [
  null,
  "Activer"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Activer le pool de stockage pour gérer les volumes"
 ],
 "Add": [
  null,
  "Ajouter"
 ],
 "Add a DHCP static host entry": [
  null,
  "Ajouter une entrée d’hôte statique DHCP"
 ],
 "Add disk": [
  null,
  "Ajouter un disque"
 ],
 "Add host device": [
  null,
  "Ajouter un dispositif hôte"
 ],
 "Add network interface": [
  null,
  "Ajouter une interface réseau"
 ],
 "Add shared directory": [
  null,
  "Ajouter un répertoire partagé"
 ],
 "Add virtual network interface": [
  null,
  "Ajouter une interface de réseau virtuel"
 ],
 "Add watchdog device type": [
  null,
  "Ajouter un dispositif de surveillance"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "L’ajout de répertoires partagés n’est possible que lorsque la machine virtuelle de l’invité est fermée"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  "L'ajout de ce disque changera son mode d'accès en mode partagé."
 ],
 "Additional": [
  null,
  "Additionnel"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address not within subnet": [
  null,
  "Adresse ne faisant pas partie du sous-réseau"
 ],
 "All": [
  null,
  "Tout"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Toutes les activités de la machine virtuelle, y compris le stockage, seront temporaires. Cela entraînera une perte de données sur l’hôte de destination."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Caractères autorisés : lettres de l’alphabet latin, chiffres et un ensemble limité de caractères de ponctuation (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Supprimez également tous les volumes de ce pool :"
 ],
 "Always attach": [
  null,
  "Toujours attacher"
 ],
 "Apply": [
  null,
  "Appliquer"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Les installations automatiques ne sont disponibles que lorsque vous téléchargez une image ou utilisez cloud-init."
 ],
 "Automatic": [
  null,
  "Automatique"
 ],
 "Automation": [
  null,
  "Automatisation"
 ],
 "Autostart": [
  null,
  "Démarrage automatique"
 ],
 "Blocked": [
  null,
  "Bloqué"
 ],
 "Boot order": [
  null,
  "Ordre d’amorçage"
 ],
 "Boot order settings could not be saved": [
  null,
  "Les paramètres d’ordre d’amorçage n’ont pas pu être enregistrés"
 ],
 "Bus": [
  null,
  "Bus"
 ],
 "CD/DVD disc": [
  null,
  "Disque CD/DVD"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU configuration could not be saved": [
  null,
  "La configuration du CPU n’a pas pu être sauvegardée"
 ],
 "CPU type": [
  null,
  "Type de CPU"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Annuler"
 ],
 "Capacity": [
  null,
  "Capacité"
 ],
 "Change boot order": [
  null,
  "Modifier l’ordre de démarrage"
 ],
 "Change firmware": [
  null,
  "Changer de firmware"
 ],
 "Changes pending": [
  null,
  ""
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Ces modifications prendront effet après l’extinction de la machine virtuelle"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  ""
 ],
 "Checking token validity...": [
  null,
  "Vérification de la validité du jeton..."
 ],
 "Choose an operating system": [
  null,
  "Choisissez un système d’exploitation"
 ],
 "Class": [
  null,
  "Classe"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "En cliquant sur \"Launch Remote Viewer\" (lancer l’afficheur à distance), vous téléchargerez un fichier .vv et le lancerez $0 ."
 ],
 "Clone": [
  null,
  "Clone"
 ],
 "Close": [
  null,
  "Fermer"
 ],
 "Cloud base image": [
  null,
  "Images Cloud Base"
 ],
 "Confirm this action": [
  null,
  "Confirmer cette action"
 ],
 "Connect": [
  null,
  "Connecter"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "Connectez-vous à n’importe quelle application de visualisation pour les protocoles suivants"
 ],
 "Connecting": [
  null,
  "Connexion en cours"
 ],
 "Connection": [
  null,
  "Connexion"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Copy storage": [
  null,
  "Stockage de copie"
 ],
 "Cores per socket": [
  null,
  "Cœurs par prise"
 ],
 "Could not delete $0": [
  null,
  "Impossible de supprimer $0"
 ],
 "Could not revert to snapshot": [
  null,
  "N’a pas pu revenir à l’instantané"
 ],
 "Crashed": [
  null,
  "Échoué"
 ],
 "Create": [
  null,
  "Créer"
 ],
 "Create VM": [
  null,
  "Créer une machine virtuelle"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Créer une VM en important une image disque d'une installation VM existante"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Créer une VM à partir d'un support d'installation local ou en réseau"
 ],
 "Create a clone VM based on $0": [
  null,
  "Créer un clone de la machine virtuelle basé sur $0"
 ],
 "Create and edit": [
  null,
  "Créer nouveau et éditer"
 ],
 "Create and run": [
  null,
  "Créer nouveau et exécuter"
 ],
 "Create new": [
  null,
  "Créer Nouveau"
 ],
 "Create new virtual machine": [
  null,
  "Créer une nouvelle machine virtuelle"
 ],
 "Create new volume": [
  null,
  "Créer un nouveau volume"
 ],
 "Create snapshot": [
  null,
  "Créer Instantané"
 ],
 "Create storage pool": [
  null,
  "Création du pool de stockage"
 ],
 "Create storage volume": [
  null,
  "Création un volume de stockage"
 ],
 "Create virtual network": [
  null,
  "Créer un réseau virtuel"
 ],
 "Create volume": [
  null,
  "Créer un volume"
 ],
 "Creating VM": [
  null,
  "Création de la machine virtuelle"
 ],
 "Creating VM $0": [
  null,
  "Création de la machine virtuelle $0"
 ],
 "Creation of VM $0 failed": [
  null,
  "La création de la machine virtuelle $0 a échoué"
 ],
 "Creation time": [
  null,
  "Temps de création"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Actuel"
 ],
 "Current allocation": [
  null,
  "Allocation actuelle"
 ],
 "Custom firmware: $0": [
  null,
  "Micrologiciel personnalisé : $0"
 ],
 "Custom path": [
  null,
  "Chemin personnalisé"
 ],
 "DHCP Settings": [
  null,
  "Paramètres DHCP"
 ],
 "Deactivate": [
  null,
  "Désactiver"
 ],
 "Delete": [
  null,
  "Supprimer"
 ],
 "Delete $0 VM?": [
  null,
  "Supprimer $0 VM ?"
 ],
 "Delete $0 storage pool?": [
  null,
  "Supprimer le pool de stockage $0 ?"
 ],
 "Delete $0 volume": [
  null,
  "Supprimer le volume $0",
  "Supprimer les volumes $0"
 ],
 "Delete associated storage files:": [
  null,
  "Supprimer les fichiers de stockage associés :"
 ],
 "Delete network?": [
  null,
  "Supprimer le réseau ?"
 ],
 "Delete snapshot?": [
  null,
  "Supprimer l'instantané ?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Supprimer un pool de stockage inactif va seulement déprogrammer le pool. Son contenu ne sera pas supprimé."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "La suppression de répertoires partagés n’est possible que lorsque la machine virtuelle de l’invité est fermée"
 ],
 "Description": [
  null,
  "Description"
 ],
 "Desktop viewer": [
  null,
  "Affichage de bureau"
 ],
 "Destination URI": [
  null,
  "URI de destination"
 ],
 "Destination URI must not be empty": [
  null,
  "L’URI de destination ne doit pas être vide"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Détachez les disques utilisant ce pool de toutes les machines virtuelles avant de tenter la suppression."
 ],
 "Details": [
  null,
  "Détails"
 ],
 "Device": [
  null,
  "Périphérique"
 ],
 "Devices": [
  null,
  "Périphériques"
 ],
 "Disconnect": [
  null,
  "Déconnecter"
 ],
 "Disconnected": [
  null,
  "Déconnecté"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Déconnecté de la console série. Cliquez sur le bouton Connecter."
 ],
 "Disk $0 could not be removed": [
  null,
  "Le disque $0 ne peut pas être supprimé"
 ],
 "Disk failed to be attached": [
  null,
  "Le disque n’a pas pu être attaché"
 ],
 "Disk failed to be created": [
  null,
  "Le disque n’a pas pu être créé"
 ],
 "Disk identifier": [
  null,
  "Identifiant du disque"
 ],
 "Disk image": [
  null,
  "Image disque"
 ],
 "Disk image file": [
  null,
  "Fichier image disque"
 ],
 "Disk image path must not be empty": [
  null,
  "Le chemin de l’image disque ne doit pas être vide"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Les images disque peuvent être stockées dans le répertoire personnel de l'utilisateur"
 ],
 "Disk settings could not be saved": [
  null,
  "Les paramètres de configuration du disque n’ont pas pu être sauvegardés"
 ],
 "Disk-only snapshot": [
  null,
  "Instantané du disque uniquement"
 ],
 "Disks": [
  null,
  "Disques"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "N’exécutez pas cette machine virtuelle sur les hôtes d’origine et de destination en même temps."
 ],
 "Do nothing": [
  null,
  "Ne rien faire"
 ],
 "Domain has crashed": [
  null,
  "Le domaine a échoué"
 ],
 "Domain is blocked on resource": [
  null,
  "Le domaine est bloqué sur la ressource"
 ],
 "Download an OS": [
  null,
  "Télécharger un OS"
 ],
 "Download progress": [
  null,
  "Progression du téléchargement"
 ],
 "Downloading image for VM $0": [
  null,
  "Téléchargement de l'image pour VM $0"
 ],
 "Downloading: $0%": [
  null,
  "Téléchargement : $0%"
 ],
 "Dump core": [
  null,
  "Noyau Dump"
 ],
 "Duration": [
  null,
  "Durée"
 ],
 "Dying": [
  null,
  "Sur le point ce cesser toute activité"
 ],
 "Edit": [
  null,
  "Modifier"
 ],
 "Edit $0 attributes": [
  null,
  "Modifier les attributs de $0"
 ],
 "Edit watchdog device type": [
  null,
  "Modifier le dispositif de suveillance"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "La modification des interfaces réseau des invités transitoires n’est pas autorisée"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "La modification des interfaces réseau transitoires n’est pas autorisée"
 ],
 "Eject": [
  null,
  "Éjecter"
 ],
 "Eject disc from VM?": [
  null,
  "Éjecter le disque de la VM ?"
 ],
 "Emulated machine": [
  null,
  "Machine émulée"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  ""
 ],
 "End": [
  null,
  "Fin"
 ],
 "End should not be empty": [
  null,
  "L’extrémité ne doit pas être vide"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Entrez les informations de l’utilisateur ou de l’utilisateur root pour activer l’installation sans surveillance."
 ],
 "Error checking token": [
  null,
  "Jeton de vérification des erreurs"
 ],
 "Example, $0": [
  null,
  "Exemple, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Image disque existante sur le système de fichiers de l’hôte"
 ],
 "Expand": [
  null,
  "Développer"
 ],
 "Extended attributes": [
  null,
  "Attributs étendus"
 ],
 "Failed": [
  null,
  "Échoué"
 ],
 "Failed to add shared directory": [
  null,
  "Échec de l’ajout du répertoire partagé"
 ],
 "Failed to change firmware": [
  null,
  "Échec de la modification du micrologiciel"
 ],
 "Failed to clone VM $0": [
  null,
  "Echec du clonage de la machine virtuelle $0"
 ],
 "Failed to configure watchdog": [
  null,
  "Échec de la configuration du dispositif de surveillance"
 ],
 "Failed to detach watchdog": [
  null,
  "Échec du détachement du dispositif de surveillance"
 ],
 "Failed to fetch some resources": [
  null,
  "Échec de la récupération de certaines ressources"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "Impossible de récupérer les adresses IP des interfaces présentes dans $0"
 ],
 "Failed to rename VM $0": [
  null,
  "Échec du renommage de la machine virtuelle $0"
 ],
 "Failed to save network settings": [
  null,
  "Échec de l’enregistrement des paramètres du réseau"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Échec de l’envoi de la touche Ctrl+Alt+$0 à la machine virtuelle $1"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Un nombre inférieur au nombre maximal de processeurs virtuels doit être activé."
 ],
 "File": [
  null,
  "Fichier"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Le système de fichier $0 n’a pas pu être supprimé"
 ],
 "Filesystem directory": [
  null,
  "Répertoire des fichiers système"
 ],
 "Filter by name": [
  null,
  "Filtrer par nom"
 ],
 "Firmware": [
  null,
  "Micrologiciel"
 ],
 "Force eject": [
  null,
  "Forcer l'éjection"
 ],
 "Force reboot": [
  null,
  "Redémarrage forcé"
 ],
 "Force revert": [
  null,
  "Forcer le retour en arrière"
 ],
 "Force shut down": [
  null,
  "Arrêt forcé"
 ],
 "Format": [
  null,
  "Formater"
 ],
 "Forward mode": [
  null,
  "Mode de redirection"
 ],
 "Forwarding mode": [
  null,
  "Mode de redirection"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Les images disque complètes et la mémoire du domaine seront migrées. Seules les images disque non partagées et inscriptibles seront transférées. Le stockage inutilisé restera sur l’origine après la migration."
 ],
 "General": [
  null,
  "Général"
 ],
 "Generate automatically": [
  null,
  "Générer automatiquement"
 ],
 "Get a new RHSM token.": [
  null,
  "Obtenez un nouveau jeton RHSM."
 ],
 "GiB": [
  null,
  "Go"
 ],
 "Go to VMs list": [
  null,
  "Aller à la liste des machines virtuelles"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Un bon choix pour la virtualisation de poste de travail"
 ],
 "Gracefully shutdown": [
  null,
  "Arrêt définitif"
 ],
 "Hide additional options": [
  null,
  "Cacher les options supplémentaires"
 ],
 "Host": [
  null,
  "Hôte"
 ],
 "Host device": [
  null,
  "Périphérique hôte"
 ],
 "Host device could not be attached": [
  null,
  "Le dispositif hôte n’a pas pu être attaché"
 ],
 "Host device will be removed from $0:": [
  null,
  "Le dispositif hôte sera retiré de $0 :"
 ],
 "Host devices": [
  null,
  "Périphériques hôtes"
 ],
 "Host name": [
  null,
  "Nom de l’hôte"
 ],
 "Host should not be empty": [
  null,
  "Le nom d’hôte n’est peut-être pas vide"
 ],
 "Hypervisor details": [
  null,
  "Détails sur l’hyperviseur"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "Adresse IP"
 ],
 "IP address must not be empty": [
  null,
  "L’adresse IP ne doit pas être vide"
 ],
 "IP configuration": [
  null,
  "Configuration IP"
 ],
 "IPv4 address": [
  null,
  "Adresse IPv4"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  "L’adresse IPv4 ne peut pas être la même que l’identifiant du réseau"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "L’adresse IPv4 ne peut pas être la même que l’adresse de diffusion du réseau"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 et IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "Le réseau IPv4 ne doit pas être vide"
 ],
 "IPv4 only": [
  null,
  "IPv4 seulement"
 ],
 "IPv6 address": [
  null,
  "Adresse IPv6"
 ],
 "IPv6 network should not be empty": [
  null,
  "Le réseau IPv6 ne doit pas être vide"
 ],
 "IPv6 only": [
  null,
  "IPv6 seulement"
 ],
 "Ideal for server VMs": [
  null,
  "Idéal pour les VM de serveur"
 ],
 "Ideal networking support": [
  null,
  "Un support réseau idéal"
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "L’identifiant peut être tronqué silencieusement à $0 caractères "
 ],
 "Idle": [
  null,
  "inactif"
 ],
 "Ignore": [
  null,
  ""
 ],
 "Import VM": [
  null,
  "Importer une machine virtuelle"
 ],
 "Import a virtual machine": [
  null,
  "Importer une machine virtuelle"
 ],
 "Import and edit": [
  null,
  "Importer et éditer"
 ],
 "Import and run": [
  null,
  "Importer et démarrer"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "L'importation d'une image avec un fichier d'accompagnement n'est pas prise en charge"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "Dans la plupart des configurations, « macvtap » ne fonctionne pas pour les communications en réseau entre hôte et invité."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  "Dans le mode \"vepa\" par défaut, la commutation est confiée au commutateur externe. Si le commutateur n’est pas compatible VEPA, la communication entre les machines virtuelles invitées ou entre une machine invitée et l’hôte n’est pas possible."
 ],
 "Initiator": [
  null,
  "Initiateur"
 ],
 "Initiator IQN should not be empty": [
  null,
  "L’initiateur IQN ne doit pas rester vide"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Injection d'une interruption non-masquable"
 ],
 "Insert": [
  null,
  "Insérer"
 ],
 "Insert disc media": [
  null,
  "Insérer le support du disque"
 ],
 "Install": [
  null,
  "Installer"
 ],
 "Installation source": [
  null,
  "Source d’installation"
 ],
 "Installation source must not be empty": [
  null,
  "La source de l’installation ne doit pas être vide"
 ],
 "Installation type": [
  null,
  "Type d’installation"
 ],
 "Interface": [
  null,
  "Interface"
 ],
 "Interface type": [
  null,
  "Type d’interface"
 ],
 "Interface type help": [
  null,
  "Aide sur le type d’interface"
 ],
 "Invalid IPv4 address": [
  null,
  "Adresse IPv4 non valide"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Longueur de masque ou de préfixe IPv4 non valide"
 ],
 "Invalid IPv6 address": [
  null,
  "Adresse IPv6 non valide"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Adresse IPv6 non valide"
 ],
 "Invalid filename": [
  null,
  "Nom de fichier non valide"
 ],
 "Isolated network": [
  null,
  "Réseau isolé"
 ],
 "LVM volume group": [
  null,
  "Groupe de volumes LVM"
 ],
 "Launch remote viewer": [
  null,
  "Lancer l’afficheur à distance"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Laissez le mot de passe vide si vous ne souhaitez pas qu’un compte root soit créé"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Laissez le mot de passe vide si vous ne souhaitez pas qu’un compte d’utilisateur soit créé"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Laissez le mot de passe vide si vous ne souhaitez pas définir de mot de passe root"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt n’a détecté aucune image de micrologiciel UEFI/OVMF installée sur l’hôte"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt ou l’hyperviseur ne prend pas en charge UEFI"
 ],
 "Loading available network devices": [
  null,
  "Chargement des périphériques réseau disponibles"
 ],
 "Loading resources": [
  null,
  "Chargement des ressources"
 ],
 "Loading...": [
  null,
  "Chargement..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Support d’installation local (image ISO ou arborescence d'installation de la distribution)"
 ],
 "Location": [
  null,
  "Emplacement"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "Adresse MAC"
 ],
 "MAC address must not be empty": [
  null,
  "L’adresse MAC ne doit pas être vide"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "La machine doit être arrêtée avant de changer de type de bus"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "La machine doit être arrêtée avant de changer le mode de cache"
 ],
 "Managing virtual machines": [
  null,
  "Gestion des machines virtuelles"
 ],
 "Manual connection": [
  null,
  "Connexion manuelle"
 ],
 "Mask or prefix length": [
  null,
  "Masque ou Longueur du préfixe"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Le masque ou la longueur du préfixe ne doit pas être vide"
 ],
 "Maximum allocation": [
  null,
  "Allocation maximale"
 ],
 "Maximum memory could not be saved": [
  null,
  "La mémoire maximale n’a pas pu être sauvegardée"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Nombre maximum de CPU virtuels alloués pour le système d’exploitation invité"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Nombre maximum de CPU virtuels alloués pour l’OS invité, doit être compris entre 1 et $0"
 ],
 "Maximum transmission unit": [
  null,
  "Unité maximale de transmission (MTU)"
 ],
 "Media could not be ejected from $0": [
  null,
  "Le média n'a pas pu être éjecté de $0"
 ],
 "Media will be ejected from $0:": [
  null,
  "Le support sera éjecté de $0 :"
 ],
 "Memory": [
  null,
  "Mémoire"
 ],
 "Memory could not be saved": [
  null,
  "La mémoire n’a pas pu être sauvegardée"
 ],
 "Memory must not be 0": [
  null,
  "La mémoire ne doit pas être 0"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "Migrer"
 ],
 "Migrate VM to another host": [
  null,
  "Migrer la machine virtuelle vers un autre hôte"
 ],
 "Migration failed": [
  null,
  "Échec de la migration"
 ],
 "Mode": [
  null,
  "Mode"
 ],
 "Model": [
  null,
  "Modèle"
 ],
 "Model type": [
  null,
  "Type de modèle"
 ],
 "More info for mount tag field": [
  null,
  "Plus d’informations pour le champ de balise de montage"
 ],
 "More info for source path field": [
  null,
  "Plus d’informations pour le champ du chemin source"
 ],
 "Mount tag": [
  null,
  "Étiquette de montage"
 ],
 "Mount tag must not be empty": [
  null,
  "La balise de montage ne doit pas être vide"
 ],
 "NAT to $0": [
  null,
  "NAT vers $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "Échec du changement d’état du NIC $0 de la machine virtuelle $1"
 ],
 "Name": [
  null,
  "Nom"
 ],
 "Name already exists": [
  null,
  "Le nom existe déjà"
 ],
 "Name contains invalid characters": [
  null,
  "Le nom contient des caractères invalides"
 ],
 "Name must not be empty": [
  null,
  "Le nom ne doit pas être vide"
 ],
 "Name should not be empty": [
  null,
  "Le nom ne doit pas être vide"
 ],
 "Name: ": [
  null,
  "Nom : "
 ],
 "Netmask": [
  null,
  "Masque réseau"
 ],
 "Network $0 could not be deleted": [
  null,
  "Le réseau $0 n’a pas pu être supprimé"
 ],
 "Network $0 failed to get activated": [
  null,
  "Échec de l’activation du réseau $0"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Échec de la désactivation du réseau $0"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "Le réseau $0 sera définitivement supprimé."
 ],
 "Network boot (PXE)": [
  null,
  "Démarrage réseau (PXE)"
 ],
 "Network file system": [
  null,
  "Système de fichiers par réseau (NFS)"
 ],
 "Network interface $0 could not be removed": [
  null,
  "L'interface réseau $0 n'a pas pu être supprimée"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "L'interface réseau $0 sera supprimée de $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "Les paramètres de l’interface réseau n’ont pas pu être enregistrés"
 ],
 "Network interfaces": [
  null,
  "Interfaces réseau"
 ],
 "Network selection does not support PXE.": [
  null,
  "Le réseau sélectionné ne prend pas en charge PXE."
 ],
 "Networks": [
  null,
  "Réseaux"
 ],
 "New name": [
  null,
  "Nouveau nom"
 ],
 "New name must not be empty": [
  null,
  "Le nouveau nom ne doit pas être vide"
 ],
 "New volume name": [
  null,
  "Nouveau nom de volume"
 ],
 "No VM is running or defined on this host": [
  null,
  "Aucune machine virtuelle n’est en cours d’exécution ou définie sur cet hôte"
 ],
 "No boot device found": [
  null,
  "Aucun périphérique de démarrage trouvé"
 ],
 "No connection available": [
  null,
  "Aucune connexion disponible"
 ],
 "No description": [
  null,
  "Aucune description"
 ],
 "No directories shared between the host and this VM": [
  null,
  "Aucun répertoire partagé entre l’hôte et cette machine virtuelle"
 ],
 "No disks defined for this VM": [
  null,
  "Aucun disque défini pour cette machine virtuelle"
 ],
 "No host device selected": [
  null,
  "Pas de périphérique hôte sélectionné"
 ],
 "No host devices assigned to this VM": [
  null,
  "Aucun périphérique hôte affecté à cette machine virtuelle"
 ],
 "No network devices": [
  null,
  "Aucun périphérique réseau disponible"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Aucune interface réseau définie pour cette machine virtuelle"
 ],
 "No network is defined on this host": [
  null,
  "Aucun réseau n’est défini sur cet hôte"
 ],
 "No networks available": [
  null,
  "Aucun réseau disponible"
 ],
 "No parent": [
  null,
  "Pas de parent"
 ],
 "No snapshots defined for this VM": [
  null,
  "Aucun instantané défini pour cette machine virtuelle"
 ],
 "No state": [
  null,
  "Pas d’état"
 ],
 "No storage": [
  null,
  "Aucun stockage"
 ],
 "No storage pool is defined on this host": [
  null,
  "Aucun pool de stockage n’a été défini sur cet hôte"
 ],
 "No storage pools available": [
  null,
  "Aucun pool de stockage disponible"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Aucun volume de stockage n’a été défini pour ce pool de stockage"
 ],
 "No virtual networks": [
  null,
  "Aucun réseau virtuel"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "Aucun volume n'existe dans ce pool de stockage."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Un réseau non persistant ne peut pas être supprimé. Il cesse d’exister quand il est désactivé."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Un réseau non persistant ne peut pas être supprimé. Il cesse d’exister quand il est désactivé."
 ],
 "None": [
  null,
  "Aucun"
 ],
 "None (isolated network)": [
  null,
  "Aucune (réseau isolé)"
 ],
 "Offline token": [
  null,
  "Jeton hors ligne"
 ],
 "Offline token must not be empty": [
  null,
  "Le jeton hors ligne ne doit pas être vide"
 ],
 "Old token expired": [
  null,
  "L'ancien jeton a expiré"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Un ou plusieurs modules sélectionnés sont utilisés par les domaines. Détachez d’abords les disques pour permettre la suppression du volume."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Modifiable uniquement quand l’invité est fermé"
 ],
 "Open": [
  null,
  "Ouvrir"
 ],
 "Operating system": [
  null,
  "Système d’exploitation"
 ],
 "Operation is in progress": [
  null,
  "Opération en cours"
 ],
 "Overview": [
  null,
  "Aperçu"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Aperçu des parents"
 ],
 "Path": [
  null,
  "Chemin"
 ],
 "Path on host's filesystem": [
  null,
  "Chemin d’accès sur le système de fichiers de l’hôte"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Chemin d’accès au fichier ISO sur le système de fichiers de l’hôte"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Chemin d’accès au fichier image cloud sur le système de fichiers de l’hôte"
 ],
 "Path to file on host's file system": [
  null,
  "Chemin d’accès au fichier ISO sur le système de fichiers de l’hôte"
 ],
 "Pause": [
  null,
  "Suspendre"
 ],
 "Paused": [
  null,
  "Mis en pause"
 ],
 "Permanent (default)": [
  null,
  "Permanent (par défaut)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Permissions refusées pour les images disques dans les répertoires personnels"
 ],
 "Persistence": [
  null,
  "Persistance"
 ],
 "Persistent": [
  null,
  "Persistant"
 ],
 "Physical disk device": [
  null,
  "Périphérique de disque physique"
 ],
 "Physical disk device on host": [
  null,
  "Périphérique de disque physique sur l’hôte"
 ],
 "Please choose a storage pool": [
  null,
  "Veuillez choisir un pool de stockage"
 ],
 "Please choose a volume": [
  null,
  "Veuillez choisir un volume"
 ],
 "Please enter new volume name": [
  null,
  "Veuillez saisir un nouveau nom de volume"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "Veuillez démarrer la machine virtuelle pour accéder à sa console."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Le pool doit être actif pour créer du volume"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "Le type de pool $0 ne prend pas en charge la création de volume"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Le type de pool ne supporte pas la création de volume"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "Les volumes de pool sont utilisés par les machines virtuelles "
 ],
 "Port": [
  null,
  "Port"
 ],
 "Power off": [
  null,
  "Fermé"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Nombre choisi de sockets à exposer à l’invité."
 ],
 "Prefix": [
  null,
  "Préfixe"
 ],
 "Prefix length": [
  null,
  "Longueur du préfixe"
 ],
 "Prefix length should not be empty": [
  null,
  "La longueur du préfixe ne doit pas être vide"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Les clichés pris précédemment vous permettent de revenir à un état antérieur si quelque chose ne va pas"
 ],
 "Private": [
  null,
  "Privé"
 ],
 "Product": [
  null,
  "Produit"
 ],
 "Profile": [
  null,
  "Profil"
 ],
 "Protocol": [
  null,
  "Protocole"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Fournit un pont de la machine virtuelle invitée directement sur le réseau local. Cela nécessite un périphérique de pont sur l’hôte avec une ou plusieurs cartes réseau physiques."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Fournit une connexion dont les détails sont décrits par la définition de réseau nommée."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Fournit un réseau local virtuel avec NAT vers le monde extérieur."
 ],
 "Range": [
  null,
  "Gamme"
 ],
 "Read-only": [
  null,
  "Lecture seule"
 ],
 "Reboot": [
  null,
  "Redémarrer"
 ],
 "Remote URL": [
  null,
  "URL distante"
 ],
 "Remote viewer details": [
  null,
  "Détails de la visionneuse à distance"
 ],
 "Remove": [
  null,
  "Retirer"
 ],
 "Remove and delete file": [
  null,
  ""
 ],
 "Remove disk from VM?": [
  null,
  "Retirer le disque de la VM ?"
 ],
 "Remove filesystem?": [
  null,
  "Supprimer le système de fichiers ?"
 ],
 "Remove host device from VM?": [
  null,
  "Retirer le dispositif hôte de la VM ?"
 ],
 "Remove network interface?": [
  null,
  "Supprimer l'interface réseau ?"
 ],
 "Remove static host from DHCP": [
  null,
  "Entrées d’hôtes statiques"
 ],
 "Rename": [
  null,
  "Renommer"
 ],
 "Rename VM $0": [
  null,
  "Renommer la machine virtuelle $0"
 ],
 "Reset": [
  null,
  "Réinitialiser"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Restrictions en matière de mise en réseau (émulation basée sur SLIRP) et d'affectation des périphériques PCI"
 ],
 "Resume": [
  null,
  "Reprendre"
 ],
 "Revert": [
  null,
  "Rétablir"
 ],
 "Revert to snapshot $0": [
  null,
  "Revenir à l’instantané $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Le retour à cet instantané ramènera la machine virtuelle au moment de l’instantané et l’état actuel sera perdu, ainsi que toutes les données non saisies dans un instantané"
 ],
 "Root password": [
  null,
  "Mot de passe administrateur"
 ],
 "Route to $0": [
  null,
  "Routage vers $0"
 ],
 "Routed network": [
  null,
  "Réseau routé"
 ],
 "Run": [
  null,
  "Exécuter"
 ],
 "Run when host boots": [
  null,
  "Démarrer quand l’hôte est amorcé"
 ],
 "Running": [
  null,
  "En cours"
 ],
 "SPICE TLS port": [
  null,
  "Port SPICE TLS"
 ],
 "SPICE address": [
  null,
  "Adresse SPICE"
 ],
 "SPICE port": [
  null,
  "Port SPICE"
 ],
 "Save": [
  null,
  "sauvegarder"
 ],
 "Select console type": [
  null,
  "Sélectionnez le type de console"
 ],
 "Send key": [
  null,
  "Envoi de la clé"
 ],
 "Send non-maskable interrupt": [
  null,
  "Envoyer une interruption non masquable"
 ],
 "Serial": [
  null,
  "Série"
 ],
 "Serial console": [
  null,
  "Console série"
 ],
 "Serial console ($0)": [
  null,
  "Console série ($0)"
 ],
 "Set DHCP range": [
  null,
  "Définir plage DHCP"
 ],
 "Set manually": [
  null,
  "Définir manuellement"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "La définition des mots de passe utilisateur pour les installations sans surveillance nécessite le démarrage de la machine virtuelle lors de sa création"
 ],
 "Share": [
  null,
  "Partage"
 ],
 "Share a host directory with the guest": [
  null,
  "Partager un répertoire hôte avec l’invité"
 ],
 "Shared directories": [
  null,
  "Répertoires partagés"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Les répertoires hôtes partagés doivent être montés manuellement à l’intérieur de la machine virtuelle"
 ],
 "Shared storage": [
  null,
  "Stockage partagé"
 ],
 "Show additional options": [
  null,
  "Actions supplémentaires"
 ],
 "Shut down": [
  null,
  "Fermeture"
 ],
 "Shut off": [
  null,
  "Éteindre"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Éteindre la machine virtuelle afin de modifier la configuration du micrologiciel"
 ],
 "Shutting down": [
  null,
  "Fermeture"
 ],
 "Size": [
  null,
  "Taille"
 ],
 "Slot": [
  null,
  "Emplacement"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "L’instantané $0 n’a pas pu être supprimé"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "L'instantané $0 sera supprimé de $1. Tout son contenu capturé sera perdu."
 ],
 "Snapshot failed to be created": [
  null,
  "L’instantané n’a pas été créé"
 ],
 "Snapshots": [
  null,
  "Instantanés"
 ],
 "Sockets": [
  null,
  "Prises"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  ""
 ],
 "Source": [
  null,
  "La source"
 ],
 "Source format": [
  null,
  "Format de la source"
 ],
 "Source must not be empty": [
  null,
  "La source ne doit pas être vide"
 ],
 "Source path": [
  null,
  "Chemin d’accès à la source"
 ],
 "Source path should not be empty": [
  null,
  "Le chemin de la source ne doit pas être vide"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "La source devrait commencer par le protocole http, ftp ou nfs"
 ],
 "Source volume group": [
  null,
  "Renommer le groupe de volumes"
 ],
 "Start": [
  null,
  "Démarrer"
 ],
 "Start pool when host boots": [
  null,
  "Démarrer le pool quand l’hôte est amorcé"
 ],
 "Start should not be empty": [
  null,
  "Le démarrage ne doit pas être vide"
 ],
 "Startup": [
  null,
  "Démarrage"
 ],
 "State": [
  null,
  "État"
 ],
 "Static host entries": [
  null,
  "Entrées d’hôtes statiques"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "L’hôte statique du DHCP n’a pas pu être supprimé"
 ],
 "Storage": [
  null,
  "Stockage"
 ],
 "Storage is at a shared location": [
  null,
  "Le stockage est dans un emplacement partagé"
 ],
 "Storage limit": [
  null,
  "Limite de stockage"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Échec de l’activation du pool de stockage $0"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Échec de la désactivation du pool de stockage $0"
 ],
 "Storage pool failed to be created": [
  null,
  "Le pool de stockage n’a pas pu être créé"
 ],
 "Storage pool name": [
  null,
  "Nom du pool de stockage"
 ],
 "Storage pools": [
  null,
  "Pools de stockage"
 ],
 "Storage pools could not be fetched": [
  null,
  "Les pools de stockage n’ont pas pu être récupérés"
 ],
 "Storage size must not be 0": [
  null,
  "La taille de stockage ne doit pas être de 0"
 ],
 "Storage volume": [
  null,
  "Volume de stockage"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "La taille du volume de stockage ne doit pas dépasser la capacité du pool de stockage ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Volumes de stockage"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Les volumes de stockage n’ont pas pu être supprimés"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Les volumes de stockage doivent être partagés entre cet hôte et l’hôte de destination."
 ],
 "Suspended (PM)": [
  null,
  "Mode Attente (PM)"
 ],
 "System": [
  null,
  "Système"
 ],
 "Table of selectable host devices": [
  null,
  "Tableau des dispositifs hôtes sélectionnables"
 ],
 "Target": [
  null,
  "Cible"
 ],
 "Target path": [
  null,
  "Chemin cible"
 ],
 "Target path should not be empty": [
  null,
  "Le chemin cible ne doit pas rester vide"
 ],
 "Temporary": [
  null,
  "Temporaire"
 ],
 "Temporary migration": [
  null,
  "Migration temporaire"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "La VM $0 est en cours d'exécution et sera désactivée avant d'être supprimée."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "La machine virtuelle doit être en marche ou arrêtée pour détacher ce périphérique"
 ],
 "The directory on the server being exported": [
  null,
  "Le répertoire du serveur à exporter"
 ],
 "The host path that is to be exported.": [
  null,
  "Le chemin de l’hôte à exporter."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "La configuration de machine virtuelle migrée est supprimée de l’hôte source. L’hôte de destination est considéré comme le nouveau domicile de la machine virtuelle."
 ],
 "The pool is empty": [
  null,
  "La pool est vide"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Le système d’exploitation sélectionné a un besoin en mémoire minimum de $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Le système d’exécution sélectionné a un besoin en mémoire minimum de $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "L’entrée de l’hôte statique pour $0 sera supprimée :"
 ],
 "The storage pool could not be deleted": [
  null,
  "Le pool de stockage n’a pas pu être supprimé"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "Le nom de balise à utiliser par l’invité pour monter ce point d’exportation."
 ],
 "Then copy and paste it above.": [
  null,
  "Puis copiez et collez ci-dessus."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Cette machine virtuelle est temporaire. Éteignez-la si vous souhaitez la supprimer."
 ],
 "This disk will be removed from $0:": [
  null,
  "Ce disque sera retiré de $0 :"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Ce système de fichiers sera supprimé de $0 :"
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Il s’agit de la configuration recommandée pour la connectivité générale des invités sur les hôtes avec des configurations de réseau dynamique/sans fil."
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Il s’agit de la configuration recommandée pour la connectivité générale des invités sur les hôtes avec des configurations de réseau filaire statique."
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  "Il s’agit de la configuration recommandée pour des performances élevées ou une sécurité renforcée."
 ],
 "This volume is already used by $0.": [
  null,
  "Ce volume est déjà utilisé par $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "Ce volume est déjà utilisé par une autre machine virtuelle."
 ],
 "Threads per core": [
  null,
  "Threads par noyaux"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Les machines virtuelles temporaires ne permettent pas de modifier la configuration du micrologiciel"
 ],
 "Troubleshoot": [
  null,
  "Dépannage"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Type ID": [
  null,
  "ID type"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (image ISO ou arborescence d’installation de la distribution)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Indéfini"
 ],
 "Unique name": [
  null,
  "Nom unique"
 ],
 "Unique name, default: $0": [
  null,
  "Nom unique, par défaut : $0"
 ],
 "Unique network name": [
  null,
  "Nom du réseau unique"
 ],
 "Unit": [
  null,
  "Unité"
 ],
 "Unknown": [
  null,
  "Inconnu"
 ],
 "Unknown firmware": [
  null,
  "Micrologiciel inconnu"
 ],
 "Unspecified": [
  null,
  "Non-spécifié"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "Utilisation"
 ],
 "Use existing": [
  null,
  "Utiliser l’existant"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Utiliser les attributs étendus des fichiers et répertoires"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Utilisez le même emplacement sur les hôtes d’origine et de destination pour votre stockage. Il peut s’agir d'un pool de stockage partagé, de NFS ou de toute autre méthode de partage de stockage."
 ],
 "Used": [
  null,
  "Utilisé"
 ],
 "Used by": [
  null,
  "Utilisé par"
 ],
 "User login": [
  null,
  "Connexion utilisateur"
 ],
 "User login must not be empty when user password is set": [
  null,
  "La connexion utilisateur ne doit pas être vide lorsque le mot de passe utilisateur est défini"
 ],
 "User password": [
  null,
  "Mot de passe utilisateur"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Le mot de passe utilisateur ne doit pas être vide lorsque la connexion utilisateur est définie"
 ],
 "User session": [
  null,
  "Session utilisateur"
 ],
 "VCPU settings could not be saved": [
  null,
  "Les paramètres de configuration de VCPU n’ont pas pu être sauvegardés"
 ],
 "VM $0 Host Devices": [
  null,
  "Périphériques hôtes de la machine virtuelle $0"
 ],
 "VM $0 already exists": [
  null,
  "La machine virtuelle $0 existe déjà"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "La machine virtuelle $0 n’existe pas sur la connexion $1"
 ],
 "VM $0 failed to force reboot": [
  null,
  "Échec du redémarrage forcé de la machine virtuelle $0"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "Échec de l’arrêt forcé de la machine virtuelle $0"
 ],
 "VM $0 failed to get installed": [
  null,
  "Échec de l’installation de la machine virtuelle $0"
 ],
 "VM $0 failed to pause": [
  null,
  "Échec de la mise en pause de la machine virtuelle $0"
 ],
 "VM $0 failed to reboot": [
  null,
  "Échec du redémarrage de la machine virtuelle $0"
 ],
 "VM $0 failed to resume": [
  null,
  "Échec de la reprise de la machine virtuelle $0"
 ],
 "VM $0 failed to send NMI": [
  null,
  "Échec de l’envoi NMI de la machine virtuelle $0"
 ],
 "VM $0 failed to shutdown": [
  null,
  "Échec de l’arrêt de la machine virtuelle $0"
 ],
 "VM $0 failed to start": [
  null,
  "Échec du démarrage de la machine virtuelle $0"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "VM lancée avec un accès limité non privilégié, avec le processus et le PTY appartenant à votre compte utilisateur"
 ],
 "VM state": [
  null,
  "État de la machine virtuelle"
 ],
 "VM will launch with root permissions": [
  null,
  "La VM sera lancée avec les droits de root"
 ],
 "VNC TLS port": [
  null,
  "Port VNC TLS"
 ],
 "VNC address": [
  null,
  "Adresse VNC"
 ],
 "VNC console": [
  null,
  "Console VNC"
 ],
 "VNC port": [
  null,
  "Port VNC"
 ],
 "Valid token": [
  null,
  "Jeton valide"
 ],
 "Vendor": [
  null,
  "Fournisseur"
 ],
 "Virtual machines": [
  null,
  "Machines virtuelles"
 ],
 "Virtual machines management": [
  null,
  "Gestion des machines virtuelles"
 ],
 "Virtual network": [
  null,
  "Réseau virtuel"
 ],
 "Virtual network failed to be created": [
  null,
  "Le réseau virtuel n’a pas pu être créé"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Le service de virtualisation (libvirt) n’est pas actif"
 ],
 "Volume": [
  null,
  "Volume"
 ],
 "Volume failed to be created": [
  null,
  "Le volume n’a pas pu être créé"
 ],
 "Volume group name": [
  null,
  "Nom du groupe de volumes"
 ],
 "Volume group name should not be empty": [
  null,
  "Le nom du groupe de volumes ne doit pas être vide"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Dispositif de surveillance"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Les dispositifs de surveillance agissent lorsque les systèmes cessent de répondre. Pour utiliser ce dispositif de surveillance virtuel, le système invité doit également disposer d'un pilote supplémentaire et d'un service de surveillance en cours d'exécution."
 ],
 "Writeable": [
  null,
  "Mode écriture"
 ],
 "Writeable and shared": [
  null,
  "Mode écriture et partage"
 ],
 "You can mount the shared folder using:": [
  null,
  "Vous pouvez monter le dossier partagé en utilisant :"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Vous devez sélectionner le système d’exploitation le plus proche"
 ],
 "active": [
  null,
  "actif"
 ],
 "add": [
  null,
  "ajouter"
 ],
 "add entry": [
  null,
  "ajouter une entrée"
 ],
 "bridge": [
  null,
  "pont"
 ],
 "cdrom": [
  null,
  "CD ROM"
 ],
 "custom": [
  null,
  "personnalisé"
 ],
 "direct": [
  null,
  "direct"
 ],
 "disabled": [
  null,
  "désactivé"
 ],
 "disk": [
  null,
  "disque"
 ],
 "down": [
  null,
  "arrêté"
 ],
 "edit": [
  null,
  "modifier"
 ],
 "enabled": [
  null,
  "activée"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "hôte"
 ],
 "host device": [
  null,
  "périphérique hôte"
 ],
 "host passthrough": [
  null,
  "host passthrough"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "Cible directe iSCSI"
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI Initiator IQN"
 ],
 "iSCSI target": [
  null,
  "Cible iSCSI"
 ],
 "iSCSI target IQN": [
  null,
  "Cible iSCSI IQN"
 ],
 "inactive": [
  null,
  "inactif"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "plus d’informations"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "point de montage : point de montage à l’intérieur de l’invité"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "balise de montage : la balise associée au point de montage exporté"
 ],
 "network": [
  null,
  "réseau"
 ],
 "no": [
  null,
  "non"
 ],
 "no state saved": [
  null,
  "aucun état n’est sauvé"
 ],
 "none": [
  null,
  "aucun"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "périphérique redirigé"
 ],
 "remove": [
  null,
  "supprimer"
 ],
 "serial number": [
  null,
  "Numéro de série"
 ],
 "server": [
  null,
  "serveur"
 ],
 "udp": [
  null,
  "UDP"
 ],
 "up": [
  null,
  "en cours"
 ],
 "user": [
  null,
  "utilisateur"
 ],
 "vCPU count": [
  null,
  "Nombre de vCPU"
 ],
 "vCPU maximum": [
  null,
  "vCPU Maximum"
 ],
 "vCPUs": [
  null,
  "vCPU"
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "voir plus..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Le paquet virt-install doit être installé sur le système pour pouvoir cloner des machines virtuelles"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Le paquet virt-install doit être installé sur le système pour pouvoir créer de nouvelles machines virtuelles"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Le paquet virt-install doit être installé sur le système pour pouvoir éditer cet attribut"
 ],
 "vm": [
  null,
  "machine virtuelle"
 ],
 "yes": [
  null,
  "oui"
 ]
});
