cockpit.locale({
 "": {
  "plural-forms": (n) => (n == 1) ? 0 : ((n == 2) ? 1 : ((n > 10 && n % 10 == 0) ? 2 : 3)),
  "language": "he",
  "language-direction": "rtl"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 זמין במיקום ברירת המחדל"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 זמין במארח"
 ],
 "$0 CPU configuration": [
  null,
  "הגדרת המעבד $0"
 ],
 "$0 Network": [
  null,
  "רשת $0",
  "$0 רשתות",
  "$0 רשתות",
  "$0 רשתות"
 ],
 "$0 Storage pool": [
  null,
  "מאגר אחסון $0",
  "$0 מאגרי אחסון",
  "$0 מאגרי אחסון",
  "$0 מאגרי אחסון"
 ],
 "$0 does not support unattended installation.": [
  null,
  "ל־$0 אין תמיכה בהתקנה ללא מגע."
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 זמין לרוב מערכות ההפעלה. כדי להתקין אותו, יש לחפש אותו ב„תכנה של GNOME” או להריץ את הפקודה הבאה:"
 ],
 "$0 memory adjustment": [
  null,
  "התאמת זיכרון עבור $0"
 ],
 "$0 network": [
  null,
  "רשת $0"
 ],
 "$0 vCPU": [
  null,
  "מעבד וירטואלי אחד",
  "$0 מעבדים וירטואליים",
  "$0 מעבדים וירטואליים",
  "$0 מעבדים וירטואליים"
 ],
 "$0 vCPU details": [
  null,
  "פרטי המעבד הווירטואלי $0"
 ],
 "$0 virtual network interface settings": [
  null,
  "הגדרות מנשק הרשת הווירטואלי $0"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "עותק של המכונה הווירטואלית ירוץ ביעד וייעלם עם כיבויה. בינתיים, מארח המקור שומר על העותק שלו של הגדרות המכונה הווירטואלית."
 ],
 "Access": [
  null,
  "גישה"
 ],
 "Action": [
  null,
  "פעולה"
 ],
 "Activate": [
  null,
  "הפעלה"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "יש להפעיל את מאגר האחסון כדי לנהל כרכים"
 ],
 "Add": [
  null,
  "הוספה"
 ],
 "Add a DHCP static host entry": [
  null,
  "הוספת רשומת מארח סטטית ל־DHCP"
 ],
 "Add disk": [
  null,
  "הוספת כונן"
 ],
 "Add host device": [
  null,
  "הוספת התקן מארח"
 ],
 "Add network interface": [
  null,
  "הוספת מנשק רשת"
 ],
 "Add shared directory": [
  null,
  "הוספת תיקייה משותפת"
 ],
 "Add virtual network interface": [
  null,
  "הוספת מנשק רשת וירטואלי"
 ],
 "Add watchdog device type": [
  null,
  "הוספת סוג התקן השגחה"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "הוספת תיקיות משותפות אפשרית רק כשהאורחת כבויה"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  "הוספת הכונן הזה תשנה את מצב הגישה שלו למשותפת."
 ],
 "Additional": [
  null,
  "נוסף"
 ],
 "Address": [
  null,
  "כתובת"
 ],
 "Address not within subnet": [
  null,
  "הכתובת אינה בתת־הרשת"
 ],
 "All": [
  null,
  "הכול"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "כל פעילות המכונה הווירטואלית, לרבות אחסון, יהיו זמניים. מצב זה יגרום לאובדן נתונים במארח היעד."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "תווים מורשים: אלפבית לטיני בסיסי, מספרים וכמה סימני פיסוק (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "למחוק גם את כל הכרכים בתוך המאגר הזה:"
 ],
 "Always attach": [
  null,
  "להצמיד תמיד"
 ],
 "Apply": [
  null,
  "החלה"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "התקנות אוטומטיות זמינות רק בעת הורדת דמות או בעת שימוש ב־cloud-init."
 ],
 "Automatic": [
  null,
  "אוטומטית"
 ],
 "Automation": [
  null,
  "אוטומציה"
 ],
 "Autostart": [
  null,
  "התחלה אוטומטית"
 ],
 "Blocked": [
  null,
  "חסום"
 ],
 "Boot order": [
  null,
  "סדר עלייה"
 ],
 "Boot order settings could not be saved": [
  null,
  "לא ניתן לשמור הגדרות סדר עלייה"
 ],
 "Bus": [
  null,
  "אפיק"
 ],
 "CD/DVD disc": [
  null,
  "תקליטור/DVD"
 ],
 "CPU": [
  null,
  "מעבד"
 ],
 "CPU configuration could not be saved": [
  null,
  "לא ניתן לשמור את הגדרות המעבד"
 ],
 "CPU type": [
  null,
  "סוג מעבד"
 ],
 "Cache": [
  null,
  "מכלא"
 ],
 "Cancel": [
  null,
  "ביטול"
 ],
 "Capacity": [
  null,
  "קיבולת"
 ],
 "Change boot order": [
  null,
  "שינוי סדר עלייה"
 ],
 "Change firmware": [
  null,
  "החלפת קושחה"
 ],
 "Changes pending": [
  null,
  ""
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "השינויים יחולו לאחר הפעלת המכונה הווירטואלית מחדש"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  ""
 ],
 "Checking token validity...": [
  null,
  "תוקף האסימון נבדק…"
 ],
 "Choose an operating system": [
  null,
  "נא לבחור מערכת הפעלה"
 ],
 "Class": [
  null,
  "מחלקה"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "לחיצה על „הפעלת מציג חיצוני” תוריד קובץ ‎.vv ותפעיל את $0."
 ],
 "Clone": [
  null,
  "שכפול"
 ],
 "Close": [
  null,
  "סגירה"
 ],
 "Cloud base image": [
  null,
  "דמויות בסיס לענן"
 ],
 "Confirm this action": [
  null,
  "אישור הפעולה הזאת"
 ],
 "Connect": [
  null,
  "התחברות"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "ניתן להתחבר עם כל יישום שמציג עבור הפרוטוקולים הבאים"
 ],
 "Connecting": [
  null,
  "מתבצעת התחברות"
 ],
 "Connection": [
  null,
  "התחברות"
 ],
 "Console": [
  null,
  "מסוף"
 ],
 "Copy storage": [
  null,
  "העתקת אחסון"
 ],
 "Cores per socket": [
  null,
  "ליבות לתושבת"
 ],
 "Could not delete $0": [
  null,
  "לא ניתן למחוק את $0"
 ],
 "Could not revert to snapshot": [
  null,
  "לא ניתן להחזיר לתמונת המצב"
 ],
 "Crashed": [
  null,
  "קרס"
 ],
 "Create": [
  null,
  "יצירה"
 ],
 "Create VM": [
  null,
  "יצירת מכונה וירטואלית"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "יצירת מכונה וירטואלית על ידי ייבוא דמות כונן של התקנת מכונה וירטואלית קיימת"
 ],
 "Create VM from local or network installation medium": [
  null,
  "יצירת מכונה וירטואלית מאמצעי התקנה מקומי או מהרשת"
 ],
 "Create a clone VM based on $0": [
  null,
  "יצירת שכפול של מכונה וירטואלית על בסיס $0"
 ],
 "Create and edit": [
  null,
  "יצירת ועריכה"
 ],
 "Create and run": [
  null,
  "יצירה והרצה"
 ],
 "Create new": [
  null,
  "יצירת חדש"
 ],
 "Create new virtual machine": [
  null,
  "יצירת מכונה וירטואלית חדשה"
 ],
 "Create new volume": [
  null,
  "יצירת כרך חדש"
 ],
 "Create snapshot": [
  null,
  "יצירת תמונת מצב"
 ],
 "Create storage pool": [
  null,
  "יצירת מאגר אחסון"
 ],
 "Create storage volume": [
  null,
  "יצירת כרך אחסון"
 ],
 "Create virtual network": [
  null,
  "יצירת רשת וירטואלית"
 ],
 "Create volume": [
  null,
  "יצירת כרך"
 ],
 "Creating VM": [
  null,
  "יצירת מכונה וירטואלית"
 ],
 "Creating VM $0": [
  null,
  "יצירת מכונה וירטואלית $0"
 ],
 "Creation of VM $0 failed": [
  null,
  "היצירה של המכונה הווירטואלית $0 נכשלה"
 ],
 "Creation time": [
  null,
  "זמן יצירה"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "נוכחית"
 ],
 "Current allocation": [
  null,
  "ההקצאה הנוכחית"
 ],
 "Custom firmware: $0": [
  null,
  "קושחה מותאמת אישית: $0"
 ],
 "Custom path": [
  null,
  "נתיב מותאם אישית"
 ],
 "DHCP Settings": [
  null,
  "הגדרות DHCP"
 ],
 "Deactivate": [
  null,
  "השבתה"
 ],
 "Delete": [
  null,
  "מחיקה"
 ],
 "Delete $0 VM?": [
  null,
  "למחוק את המכונה הווירטואלית $0?"
 ],
 "Delete $0 storage pool?": [
  null,
  "למחוק את מאגר האחסון $0?"
 ],
 "Delete $0 volume": [
  null,
  "מחיקת כרך אחד",
  "מחיקת $0 כרכים",
  "מחיקת $0 כרכים",
  "מחיקת $0 כרכים"
 ],
 "Delete associated storage files:": [
  null,
  "מחיקת קובצי אחסון משויכים:"
 ],
 "Delete network?": [
  null,
  "למחוק את הרשת?"
 ],
 "Delete snapshot?": [
  null,
  "למחוק תמונת מצב?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "מחיקת מאגר אחסון בלתי פעיל תסיר את הגדרת המאגר. התוכן שבו לא יימחק."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "אפשר למחוק תיקיות משותפות רק כאשר האורחת כבויה"
 ],
 "Description": [
  null,
  "תיאור"
 ],
 "Desktop viewer": [
  null,
  "מציג שולחנות עבודה"
 ],
 "Destination URI": [
  null,
  "כתובת יעד מלאה"
 ],
 "Destination URI must not be empty": [
  null,
  "כתובת היעד המלאה לא יכולה להיות ריקה"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "יש לנתק את הכוננים שמשתמשים במאגר הזה מכל מכונה וירטואלית בטרם ביצוע ניסיון מחיקה."
 ],
 "Details": [
  null,
  "פרטים"
 ],
 "Device": [
  null,
  "התקן"
 ],
 "Devices": [
  null,
  "התקנים"
 ],
 "Disconnect": [
  null,
  "ניתוק"
 ],
 "Disconnected": [
  null,
  "מנותק"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "מנותק מהמסוף הטורי. יש ללחוץ על כפתור החיבור."
 ],
 "Disk $0 could not be removed": [
  null,
  "לא ניתן להסיר את הכונן $0"
 ],
 "Disk failed to be attached": [
  null,
  "חיבור הכונן נכשל"
 ],
 "Disk failed to be created": [
  null,
  "יצירת הכונן נכשלה"
 ],
 "Disk identifier": [
  null,
  "מזהה כונן"
 ],
 "Disk image": [
  null,
  "דמות כונן"
 ],
 "Disk image file": [
  null,
  "קובץ דמות כונן"
 ],
 "Disk image path must not be empty": [
  null,
  "נתיב דמות הכונן לא יכול להישאר ריק"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "ניתן לאחסן את דמויות הכוננים בתיקיית הבית של המשתמש"
 ],
 "Disk settings could not be saved": [
  null,
  "לא ניתן לשמור את הגדרות הכונן"
 ],
 "Disk-only snapshot": [
  null,
  "תמונת מצב בכונן בלבד"
 ],
 "Disks": [
  null,
  "כוננים"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "לא להריץ את המכונה הווירטואלית הזאת על מארחי המקור והיעד בו־זמנית."
 ],
 "Do nothing": [
  null,
  "לא לעשות כלום"
 ],
 "Domain has crashed": [
  null,
  "שם התחום קרס"
 ],
 "Domain is blocked on resource": [
  null,
  "שם התחום חסום במשאב"
 ],
 "Download an OS": [
  null,
  "הורדת מערכת הפעלה"
 ],
 "Download progress": [
  null,
  "תהליך ההורדה"
 ],
 "Downloading image for VM $0": [
  null,
  "מתבצעת הורדת דמות עבור המכונה הווירטואלית $0"
 ],
 "Downloading: $0%": [
  null,
  "בהורדה: $0%"
 ],
 "Dump core": [
  null,
  "הטלת ליבה"
 ],
 "Duration": [
  null,
  "משך"
 ],
 "Dying": [
  null,
  "גוסס"
 ],
 "Edit": [
  null,
  "עריכה"
 ],
 "Edit $0 attributes": [
  null,
  "עריכת מאפייני $0"
 ],
 "Edit watchdog device type": [
  null,
  "עריכת סוג התקן השגחה"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "עריכת מנשקי הרשת של אורחות חולפות אסורה"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "עריכת מנשקים של רשת חולפת אסורה"
 ],
 "Eject": [
  null,
  "שליפה"
 ],
 "Eject disc from VM?": [
  null,
  "לשלוף תקליטור מהמכונה הווירטואלית?"
 ],
 "Emulated machine": [
  null,
  "מכונה מדומה"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  ""
 ],
 "End": [
  null,
  "סוף"
 ],
 "End should not be empty": [
  null,
  "הסוף אמור להיות ריק"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "נא למלא פרטי משתמש על (root) ו/או משתמש כדי לאפשר התקנה ללא מגע."
 ],
 "Error checking token": [
  null,
  "שגיאה בבדיקת האסימון"
 ],
 "Example, $0": [
  null,
  "דוגמה, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "תמונת כונן קיימת במערכת הקבצים של המארח"
 ],
 "Expand": [
  null,
  "הרחבה"
 ],
 "Extended attributes": [
  null,
  "מאפיינים מורחבים"
 ],
 "Failed": [
  null,
  "נכשל"
 ],
 "Failed to add shared directory": [
  null,
  "הוספת התיקייה המשותפת נכשלה"
 ],
 "Failed to change firmware": [
  null,
  "החלפת הקושחה נכשלה"
 ],
 "Failed to clone VM $0": [
  null,
  "שכפול המכונה הווירטואלית $0 נכשל"
 ],
 "Failed to configure watchdog": [
  null,
  "הגדרת ההשגחה נכשלה"
 ],
 "Failed to detach watchdog": [
  null,
  "ניתוק ההשגחה נכשל"
 ],
 "Failed to fetch some resources": [
  null,
  "משיכה של חלק מהמשאבים נכשלה"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "קבלת כתובות ה־IP של המנשקים שקיימים תחת $0 נכשלה"
 ],
 "Failed to rename VM $0": [
  null,
  "שינוי שם המכונה הווירטואלית $0 נכשל"
 ],
 "Failed to save network settings": [
  null,
  "שמירת הגדרות הרשת נכשלה"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "שליחת צירוף המקשים Ctrl+Alt+$0 למכונה הווירטואלית $1 נכשלה"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "יש להפעיל פחות מכמות המעבדים הווירטואלים המרבית."
 ],
 "File": [
  null,
  "קובץ"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "לא ניתן להסיר את מערכת הקבצים $0"
 ],
 "Filesystem directory": [
  null,
  "תיקיית מערכת קבצים"
 ],
 "Filter by name": [
  null,
  "סינון לפי שם"
 ],
 "Firmware": [
  null,
  "קושחה"
 ],
 "Force eject": [
  null,
  "אילוץ שליפה"
 ],
 "Force reboot": [
  null,
  "לאלץ הפעלה מחדש"
 ],
 "Force revert": [
  null,
  "אילוץ החזרה"
 ],
 "Force shut down": [
  null,
  "לאלץ כיבוי"
 ],
 "Format": [
  null,
  "פרמוט"
 ],
 "Forward mode": [
  null,
  "מצב העברה"
 ],
 "Forwarding mode": [
  null,
  "מצב העברה"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  ""
 ],
 "General": [
  null,
  "כללי"
 ],
 "Generate automatically": [
  null,
  "לייצר אוטומטית"
 ],
 "Get a new RHSM token.": [
  null,
  ""
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "מעבר לרשימת המכונות הווירטואליות"
 ],
 "Good choice for desktop virtualization": [
  null,
  ""
 ],
 "Hide additional options": [
  null,
  "הסתרת אפשרויות נוספות"
 ],
 "Host": [
  null,
  "מארח"
 ],
 "Host device": [
  null,
  "התקן מארח"
 ],
 "Host device will be removed from $0:": [
  null,
  ""
 ],
 "Host name": [
  null,
  "שם מארח"
 ],
 "Host should not be empty": [
  null,
  "המארח לא אמור להיות ריק"
 ],
 "Hypervisor details": [
  null,
  "פרטי Hypervisor"
 ],
 "ID": [
  null,
  "מזהה"
 ],
 "IP": [
  null,
  ""
 ],
 "IP address": [
  null,
  "כתובת IP"
 ],
 "IP configuration": [
  null,
  "הגדרת IP"
 ],
 "IPv4 address": [
  null,
  "כתובת IPv4"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  ""
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  ""
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 ו־IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "רשת IPv4 לא אמורה להישאר ריקה"
 ],
 "IPv4 only": [
  null,
  "IPv4 בלבד"
 ],
 "IPv6 address": [
  null,
  "כתובת IPv6"
 ],
 "IPv6 network should not be empty": [
  null,
  "רשת IPv6 לא אמורה להישאר ריקה"
 ],
 "IPv6 only": [
  null,
  "IPv6 בלבד"
 ],
 "Ideal for server VMs": [
  null,
  ""
 ],
 "Ideal networking support": [
  null,
  ""
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  ""
 ],
 "Idle": [
  null,
  "בהמתנה"
 ],
 "Ignore": [
  null,
  ""
 ],
 "Import VM": [
  null,
  "ייבוא מכונה וירטואלית"
 ],
 "Import a virtual machine": [
  null,
  "ייבוא מכונה וירטואלית"
 ],
 "Import and edit": [
  null,
  ""
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  ""
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "ברוב אפשרויות ההגדרה, macvtap לא עובד לטובת תקשורת רשת בין מארח לאורח."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  ""
 ],
 "Initiator": [
  null,
  "מאתחל"
 ],
 "Initiator IQN should not be empty": [
  null,
  "ה־IQN של המפעיל לא אמור להיות ריק"
 ],
 "Insert disc media": [
  null,
  ""
 ],
 "Install": [
  null,
  "התקנה"
 ],
 "Installation source": [
  null,
  "מקור התקנה"
 ],
 "Installation source must not be empty": [
  null,
  "חובה למלא את מקור ההתקנה"
 ],
 "Installation type": [
  null,
  "סוג התקנה"
 ],
 "Interface type": [
  null,
  "סוג מנשק"
 ],
 "Invalid IPv4 address": [
  null,
  "כתובת IPv4 שגויה"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "מסכה או אורך קידומת של IPv4 שגוי"
 ],
 "Invalid IPv6 address": [
  null,
  "כתובת IPv6 שגויה"
 ],
 "Invalid IPv6 prefix": [
  null,
  "קידומת IPv6 שגויה"
 ],
 "Invalid filename": [
  null,
  "שם הקובץ שגוי"
 ],
 "Isolated network": [
  null,
  "רשת מבודדת"
 ],
 "LVM volume group": [
  null,
  "קבוצת כרכים LVM"
 ],
 "Launch remote viewer": [
  null,
  "הפעלת מציג מרחוק"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "ניתן להשאיר את הססמה ריקה אם בחירתך היא שלא ליצור חשבון על (root)"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "ניתן להשאיר את הססמה ריקה אם בחירתך היא שלא ליצור חשבון משתמש"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "ניתן להשאיר את הססמה ריקה אם בחירתך היא שלא להגדיר את הססמה של חשבון העל (root)"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt לא זיהה תמונת קושחה מסוג UEFI/OVMF מותקנת על המארח"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt או ה־hypervisor לא תומכים ב־UEFI"
 ],
 "Loading resources": [
  null,
  "משאבים נטענים"
 ],
 "Loading...": [
  null,
  "בטעינה…"
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "מדיה להתקנה מקומית (דמות ISO או עץ התקנת הפצה)"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "כתובת MAC"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "יש לכבות את המכונה לפני החלפת סוג אפיק"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "יש לכבות את המכונה לפני החלפת מצב המטמון"
 ],
 "Managing virtual machines": [
  null,
  "ניהול מכונות וירטואליות"
 ],
 "Manual connection": [
  null,
  "חיבור ידני"
 ],
 "Mask or prefix length": [
  null,
  "מסכה או אורך קידומת"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "מסכה או אורך קידומת לא אמור להישאר ריק"
 ],
 "Maximum allocation": [
  null,
  "הקצאה מרבית"
 ],
 "Maximum memory could not be saved": [
  null,
  "לא ניתן לשמור את הזיכרון המרבי"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "כמות המעבדים הווירטואליים המרבית שמוקצת למערכת ההפעלה האורחת"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "כמות המעבדים הווירטואליים המרבית שמוקצת למערכת ההפעלה האורחת, שחייבת להיות בין 1 ל־$0"
 ],
 "Maximum transmission unit": [
  null,
  "יחידת העברה מרבית"
 ],
 "Media will be ejected from $0:": [
  null,
  ""
 ],
 "Memory": [
  null,
  "זיכרון"
 ],
 "Memory could not be saved": [
  null,
  "לא ניתן לשמור את הזיכרון"
 ],
 "Memory must not be 0": [
  null,
  "אסור שהזיכרון יהיה 0"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  ""
 ],
 "Migrate VM to another host": [
  null,
  ""
 ],
 "Mode": [
  null,
  "מצב"
 ],
 "Model": [
  null,
  "דגם"
 ],
 "Model type": [
  null,
  "סוג דגם"
 ],
 "More info for mount tag field": [
  null,
  ""
 ],
 "More info for source path field": [
  null,
  ""
 ],
 "Mount tag": [
  null,
  ""
 ],
 "NAT to $0": [
  null,
  "NAT אל $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "החלפת מצב מתאם הרשת $0 של המכונה הווירטואלית $0 נכשלה"
 ],
 "Name": [
  null,
  "שם"
 ],
 "Name contains invalid characters": [
  null,
  "השם מכיל תווים שגויים"
 ],
 "Name must not be empty": [
  null,
  "השם לא יכול להישאר ריק"
 ],
 "Name should not be empty": [
  null,
  "השם לא אמור להיות ריק"
 ],
 "Name: ": [
  null,
  "שם: "
 ],
 "Netmask": [
  null,
  "מסכת רשת"
 ],
 "Network $0 failed to get activated": [
  null,
  "הפעלת הרשת $0 נכשלה"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "השבתת הרשת $0 נכשלה"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "הרשת $0 תימחק לצמיתות."
 ],
 "Network boot (PXE)": [
  null,
  "עלייה מהרשת (PXE)"
 ],
 "Network file system": [
  null,
  "מערכת קבצים רשתית"
 ],
 "Network interface settings could not be saved": [
  null,
  "לא ניתן לשמור את הגדרות מנשק הרשת"
 ],
 "Network selection does not support PXE.": [
  null,
  "בחירת הרשת לא תומכת ב־PXE."
 ],
 "Networks": [
  null,
  "רשתות"
 ],
 "New name must not be empty": [
  null,
  "השם החדש לא יכול להישאר ריק"
 ],
 "New volume name": [
  null,
  "שם חדש לכרך"
 ],
 "No VM is running or defined on this host": [
  null,
  "אף מכונה וירטואלית לא מופעלת או מוגדרת על המארח הזה"
 ],
 "No boot device found": [
  null,
  "לא נמצא התקן עלייה"
 ],
 "No connection available": [
  null,
  "אין חיבור זמין"
 ],
 "No description": [
  null,
  "אין תיאור"
 ],
 "No directories shared between the host and this VM": [
  null,
  ""
 ],
 "No disks defined for this VM": [
  null,
  "לא מוגדרים כוננים למכונה הווירטואלית הזאת"
 ],
 "No network devices": [
  null,
  "אין התקני רשת"
 ],
 "No network interfaces defined for this VM": [
  null,
  "לא הוגדרו מנשקי רשת למכונה הווירטואלית הזאת"
 ],
 "No network is defined on this host": [
  null,
  "לא הוגדרה רשת למארח הזה"
 ],
 "No networks available": [
  null,
  "אין רשתות זמינות"
 ],
 "No parent": [
  null,
  "אין הורה"
 ],
 "No snapshots defined for this VM": [
  null,
  "לא מוגדרות תמונות מצב למכונה הווירטואלית הזאת"
 ],
 "No state": [
  null,
  "אין מצב"
 ],
 "No storage": [
  null,
  "אין אחסון"
 ],
 "No storage pool is defined on this host": [
  null,
  "לא הוגדר מאגר אחסון למארח הזה"
 ],
 "No storage pools available": [
  null,
  "אין מאגרי אחסון זמינים"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "לא הוגדרו כרכי אחסון למאגר האחסון הזה"
 ],
 "No virtual networks": [
  null,
  "אין רשתות וירטואליות"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "לא קיימים כרכים במאגר האחסון הזה."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "לא ניתן למחוק רשת שאינה עקבית. היא פשוט חדלה מלהתקיים לאחר סיום הפעלתה."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "לא ניתן למחוק מאגר אחסון שאינו עקבי. הוא פשוט חדל מלהתקיים לאחר סיום הפעלתו."
 ],
 "None": [
  null,
  "אין"
 ],
 "None (isolated network)": [
  null,
  "אין (רשת מבודדת)"
 ],
 "Offline token": [
  null,
  ""
 ],
 "Old token expired": [
  null,
  ""
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "אחד או יותר מהכרכים שנבחרו משמשים את שם התחום. יש לנתק את הכוננים תחילה כדי לאפשר מחיקת כרכים."
 ],
 "Only editable when the guest is shut off": [
  null,
  "ניתן לעריכה רק כאשר האורח כבוי"
 ],
 "Open": [
  null,
  "פתיחה"
 ],
 "Operating system": [
  null,
  "מערכת הפעלה"
 ],
 "Operation is in progress": [
  null,
  "המשימה בתהליך"
 ],
 "Overview": [
  null,
  "סקירה"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "תמונת מצב הורה"
 ],
 "Path": [
  null,
  "נתיב"
 ],
 "Path on host's filesystem": [
  null,
  "הנתיב במערכת הקבצים של המארח"
 ],
 "Path to ISO file on host's file system": [
  null,
  "הנתיב לקובץ ISO על מערכת הקבצים של המארח"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "הנתיב לקובץ דמות הענן במערכת הקבצים של המארח"
 ],
 "Path to file on host's file system": [
  null,
  "הנתיב לקובץ במערכת הקבצים של המארח"
 ],
 "Pause": [
  null,
  "השהיה"
 ],
 "Paused": [
  null,
  "מושהה"
 ],
 "Permanent (default)": [
  null,
  ""
 ],
 "Permissions denied for disk images in home directories": [
  null,
  ""
 ],
 "Persistence": [
  null,
  "עקביות"
 ],
 "Persistent": [
  null,
  "עקבי"
 ],
 "Physical disk device": [
  null,
  "התקן כונן פיזי"
 ],
 "Physical disk device on host": [
  null,
  "התקן כונן פיזי במארח"
 ],
 "Please choose a storage pool": [
  null,
  "נא לבחור מאגר אחסון"
 ],
 "Please choose a volume": [
  null,
  "נא לבחור כרך"
 ],
 "Please enter new volume name": [
  null,
  "נא להקליד את שם הכרך החדש"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "נא להפעיל את המכונה הווירטואלית כדי לגשת למסוף שלה."
 ],
 "Pool": [
  null,
  "מאגר"
 ],
 "Pool needs to be active to create volume": [
  null,
  "יש להפעיל את המאגר כדי ליצור כרך"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "סוג המאגר $0 לא תומך ביצירת כרכים"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "סוג המאגר לא תומך ביצירת כרכים"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "כרכי המאגר משמשים מכונות וירטואליות "
 ],
 "Port": [
  null,
  "פתחה"
 ],
 "Power off": [
  null,
  "כיבוי"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "מספר השקעים המועדף לחשיפה לאורח."
 ],
 "Prefix": [
  null,
  "קידומת"
 ],
 "Prefix length": [
  null,
  "אורך קידומת"
 ],
 "Prefix length should not be empty": [
  null,
  "אורך הקידומת לא אמור להיות ריק"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "תמונות מצב שנלכדו בעבר מאפשרות לך לחזור למצב קודם אם משהו השתבש"
 ],
 "Private": [
  null,
  "פרטי"
 ],
 "Product": [
  null,
  "מוצר"
 ],
 "Profile": [
  null,
  "פרופיל"
 ],
 "Protocol": [
  null,
  "פרוטוקול"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  ""
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  ""
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  ""
 ],
 "Range": [
  null,
  "טווח"
 ],
 "Read-only": [
  null,
  "קריאה בלבד"
 ],
 "Reboot": [
  null,
  "הפעלה מחדש"
 ],
 "Remote URL": [
  null,
  "כתובת מרוחקת"
 ],
 "Remote viewer details": [
  null,
  "פרטי המציג מרחוק"
 ],
 "Remove": [
  null,
  "הסרה"
 ],
 "Remove and delete file": [
  null,
  ""
 ],
 "Remove disk from VM?": [
  null,
  "להסיר כונן מהמכונה הווירטואלית?"
 ],
 "Remove filesystem?": [
  null,
  "להסיר מערכת קבצים?"
 ],
 "Remove host device from VM?": [
  null,
  "להסיר התקן מארח ממכונה וירטואלית?"
 ],
 "Remove network interface?": [
  null,
  "להסיר מנשק רשת?"
 ],
 "Remove static host from DHCP": [
  null,
  ""
 ],
 "Rename": [
  null,
  "שינוי שם"
 ],
 "Rename VM $0": [
  null,
  ""
 ],
 "Reset": [
  null,
  "איפוס"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  ""
 ],
 "Resume": [
  null,
  "המשך"
 ],
 "Revert": [
  null,
  "החזרה אחורה"
 ],
 "Revert to snapshot $0": [
  null,
  "החזרה לתמונת מצב $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "החזרה לתמונת המצב הזו תחזיר את המכונה הווירטואלית אחורה לזמן תמונת המצב והמצב הנוכחי יאבד לצד כל הנתונים שלא נלכדו קודם לכן בתמונת המצב"
 ],
 "Root password": [
  null,
  "ססמת משתמש על (root)"
 ],
 "Route to $0": [
  null,
  "ניתוב אל $0"
 ],
 "Routed network": [
  null,
  "רשת מנותבת"
 ],
 "Run": [
  null,
  "הפעלה"
 ],
 "Run when host boots": [
  null,
  "הפעלה עם עליית המארח"
 ],
 "Running": [
  null,
  "פועל"
 ],
 "SPICE TLS port": [
  null,
  "פתחת TLS של SPICE"
 ],
 "SPICE address": [
  null,
  "כתובת SPICE"
 ],
 "SPICE port": [
  null,
  "פתחת SPICE"
 ],
 "Save": [
  null,
  "שמירה"
 ],
 "Select console type": [
  null,
  "בחירת סוג מסוף"
 ],
 "Send key": [
  null,
  "שליחת מקש"
 ],
 "Send non-maskable interrupt": [
  null,
  "שליחת פסיקה שלא ניתן למסך"
 ],
 "Serial": [
  null,
  "טורית"
 ],
 "Serial console": [
  null,
  "מסוף טורי"
 ],
 "Set DHCP range": [
  null,
  "הגדרת טווח DHCP"
 ],
 "Set manually": [
  null,
  "הגדרה ידנית"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "הגדרת ססמאות משתמש להתקנה ללא מגע דורש את הפעלת המכונה הווירטואלית בעת יצירת"
 ],
 "Share": [
  null,
  "שיתוף"
 ],
 "Share a host directory with the guest": [
  null,
  ""
 ],
 "Shared directories": [
  null,
  ""
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  ""
 ],
 "Show additional options": [
  null,
  "הצגת אפשרויות נוספות"
 ],
 "Shut down": [
  null,
  "כיבוי"
 ],
 "Shut off": [
  null,
  "לכבות"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "יש לכבות את המכונה הווירטואלית כדי לערוך הגדרות קושחה"
 ],
 "Shutting down": [
  null,
  "מתבצע כיבוי"
 ],
 "Size": [
  null,
  "גודל"
 ],
 "Slot": [
  null,
  "משבצת"
 ],
 "Snapshot failed to be created": [
  null,
  "יצירת תמונת המצב נכשלה"
 ],
 "Snapshots": [
  null,
  "תמונות מצב"
 ],
 "Sockets": [
  null,
  "שקעים"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  ""
 ],
 "Source": [
  null,
  "מקור"
 ],
 "Source format": [
  null,
  "תצורת מקור"
 ],
 "Source must not be empty": [
  null,
  "המקור לא יכול להישאר ריק"
 ],
 "Source path": [
  null,
  "נתיב מקור"
 ],
 "Source path should not be empty": [
  null,
  "נתיב המקור לא אמור להיות ריק"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "המקור אמור להיפתח בפרוטוקולי http,‏ ftp או nfs"
 ],
 "Source volume group": [
  null,
  "קבוצת כרכים מקורית"
 ],
 "Start": [
  null,
  "התחלה"
 ],
 "Start pool when host boots": [
  null,
  "הפעלת המאגר עם עליית המארח"
 ],
 "Start should not be empty": [
  null,
  "ההתחלה לא אמורה להיות ריקה"
 ],
 "Startup": [
  null,
  "בהתחלה"
 ],
 "State": [
  null,
  "מצב"
 ],
 "Static host entries": [
  null,
  ""
 ],
 "Storage": [
  null,
  "אחסון"
 ],
 "Storage is at a shared location": [
  null,
  ""
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "הפעלת מאגר האחסון $0 נכשלה"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "השבתת מאגר האחסון $0 נכשלה"
 ],
 "Storage pool failed to be created": [
  null,
  "יצירת מאגר האחסון נכשלה"
 ],
 "Storage pool name": [
  null,
  "שם מאגר אחסון"
 ],
 "Storage pools": [
  null,
  "מאגרי אחסון"
 ],
 "Storage size must not be 0": [
  null,
  "אסור שגודל האחסון יהיה 0"
 ],
 "Storage volume": [
  null,
  "כרך אחסון"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "גודל כרך האחסון לא יכול לחרוג מקיבולת מאגר האחסון ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "כרכי אחסון"
 ],
 "Storage volumes could not be deleted": [
  null,
  "לא ניתן למחוק את כרכי האחסון"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  ""
 ],
 "Suspended (PM)": [
  null,
  "מושהה (מכונה פיזית)"
 ],
 "System": [
  null,
  "מערכת"
 ],
 "Table of selectable host devices": [
  null,
  ""
 ],
 "Target": [
  null,
  "יעד"
 ],
 "Target path": [
  null,
  "נתיב יעד"
 ],
 "Target path should not be empty": [
  null,
  "נתיב היעד לא יכול להיות ריק"
 ],
 "Temporary": [
  null,
  ""
 ],
 "Temporary migration": [
  null,
  ""
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "על המכונה הווירטואלית להיות פעילה או כבויה כדי לנתק את ההתקן הזה"
 ],
 "The directory on the server being exported": [
  null,
  "התיקייה על השרת שמיוצא"
 ],
 "The host path that is to be exported.": [
  null,
  ""
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  ""
 ],
 "The pool is empty": [
  null,
  "המאגר ריק"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "למערכת ההפעלה הנוכחית יש דרישות סף מבחינת זיכרון של $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "למערכת ההפעלה הנוכחית יש דרישות סף מבחינת אחסון של $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  ""
 ],
 "The storage pool could not be deleted": [
  null,
  "לא ניתן למחוק את מאגר האחסון"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  ""
 ],
 "Then copy and paste it above.": [
  null,
  ""
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "זו מכונה וירטואלית זמנית. ניתן לכבות אותה אם ברצונך למחוק אותה."
 ],
 "This disk will be removed from $0:": [
  null,
  ""
 ],
 "This filesystem will be removed from $0:": [
  null,
  ""
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  ""
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  ""
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  ""
 ],
 "This volume is already used by $0.": [
  null,
  "כרך זה כבר בשימוש על ידי $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "כרך זה כבר בשימוש על ידי מכונה וירטואלית אחרת."
 ],
 "Threads per core": [
  null,
  "תהליכונים למעבד"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "מכונות וירטואליות זמניות לא תומכות בעריכת הגדרות קושחה"
 ],
 "Troubleshoot": [
  null,
  "איתור תקלות"
 ],
 "Type": [
  null,
  "סוג"
 ],
 "Type ID": [
  null,
  "מזהה סוג"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "כתובת (דמות ISO או עץ התקנת הפצה)"
 ],
 "USB": [
  null,
  ""
 ],
 "UUID": [
  null,
  ""
 ],
 "Undefined": [
  null,
  ""
 ],
 "Unique name": [
  null,
  "שם ייחודי"
 ],
 "Unique network name": [
  null,
  "שם רשת ייחודי"
 ],
 "Unit": [
  null,
  "יחידה"
 ],
 "Unknown": [
  null,
  "לא ידוע"
 ],
 "Unknown firmware": [
  null,
  "קושחה לא ידועה"
 ],
 "Unspecified": [
  null,
  ""
 ],
 "Url": [
  null,
  "כתובת"
 ],
 "Usage": [
  null,
  "שימוש"
 ],
 "Use existing": [
  null,
  "להשתמש בקיים"
 ],
 "Use extended attributes on files and directories": [
  null,
  ""
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  ""
 ],
 "Used": [
  null,
  "בשימוש"
 ],
 "Used by": [
  null,
  "בשימוש על ידי"
 ],
 "User login": [
  null,
  "שם המשתמש"
 ],
 "User login must not be empty when user password is set": [
  null,
  "שם המשתמש לא יכול להיות ריק כשמוגדרת ססמה"
 ],
 "User password": [
  null,
  "ססמת משתמש"
 ],
 "User password must not be empty when user login is set": [
  null,
  "ססמת המשתמש לא יכולה להיות ריקה כשמוגדר שם משתמש"
 ],
 "VCPU settings could not be saved": [
  null,
  "לא ניתן לשמור את הגדרות המעבד הווירטואלי"
 ],
 "VM $0 already exists": [
  null,
  "המכונה הווירטואלית $0 כבר קיימת"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "המכונה הווירטואלית $0 לא קיימת בחיבור $1"
 ],
 "VM $0 failed to force reboot": [
  null,
  "הפעלת המכונה הווירטואלית $0 מחדש בכוח נכשלה"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "כיבוי המכונה הווירטואלית $0 בכוח נכשל"
 ],
 "VM $0 failed to get installed": [
  null,
  "התקנת המכונה הווירטואלית $0 נכשלה"
 ],
 "VM $0 failed to pause": [
  null,
  "השהיית המכונה הווירטואלית $0 נכשלה"
 ],
 "VM $0 failed to reboot": [
  null,
  "הפעלת המכונה הווירטואלית $0 מחדש נכשלה"
 ],
 "VM $0 failed to resume": [
  null,
  "המשך המכונה הווירטואלית $0 נכשל"
 ],
 "VM $0 failed to send NMI": [
  null,
  "המכונה הווירטואלית $0 נכשלה בשליחת פסיקה ללא אפשרות מיסוך (NMI)"
 ],
 "VM $0 failed to shutdown": [
  null,
  "כיבוי המכונה הווירטואלית $0 נכשל"
 ],
 "VM $0 failed to start": [
  null,
  "הפעלת המכונה הווירטואלית $0 נכשלה"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  ""
 ],
 "VM state": [
  null,
  "מצב מכונה וירטואלית"
 ],
 "VM will launch with root permissions": [
  null,
  ""
 ],
 "VNC TLS port": [
  null,
  "פתחת TLS של VNC"
 ],
 "VNC address": [
  null,
  "כתובת VNC"
 ],
 "VNC console": [
  null,
  "מסוף VNC"
 ],
 "VNC port": [
  null,
  "פתחת VNC"
 ],
 "Valid token": [
  null,
  ""
 ],
 "Vendor": [
  null,
  "ספק"
 ],
 "Virtual machines": [
  null,
  "מכונות וירטואליות"
 ],
 "Virtual machines management": [
  null,
  "ניהול מכונות וירטואליות"
 ],
 "Virtual network": [
  null,
  "רשת וירטואלית"
 ],
 "Virtual network failed to be created": [
  null,
  "יצירת הרשת הווירטואלית נכשלה"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "שירות הווירטואליזציה (libvirt) אינו פעיל"
 ],
 "Volume": [
  null,
  "כרך"
 ],
 "Volume failed to be created": [
  null,
  "יצירת הכרך נכשלה"
 ],
 "Volume group name": [
  null,
  "שם קבוצת הכרכים"
 ],
 "Volume group name should not be empty": [
  null,
  "שם קבוצת הכרכים לא אמור להיות ריק"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  ""
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  ""
 ],
 "Writeable": [
  null,
  "ניתן לכתיבה"
 ],
 "Writeable and shared": [
  null,
  "ניתן לכתיבה ומשותף"
 ],
 "You can mount the shared folder using:": [
  null,
  ""
 ],
 "You need to select the most closely matching operating system": [
  null,
  "עליך לבחור את מערכת ההפעלה שהכי מתאימה"
 ],
 "active": [
  null,
  "פעיל"
 ],
 "add entry": [
  null,
  ""
 ],
 "bridge": [
  null,
  "גשר"
 ],
 "cdrom": [
  null,
  "תקליטור"
 ],
 "custom": [
  null,
  "מותאם אישית"
 ],
 "direct": [
  null,
  "ישיר"
 ],
 "disabled": [
  null,
  "מושבת"
 ],
 "disk": [
  null,
  "כונן"
 ],
 "down": [
  null,
  "מושבת"
 ],
 "edit": [
  null,
  "עריכה"
 ],
 "enabled": [
  null,
  "זמין"
 ],
 "ethernet": [
  null,
  "אתרנט"
 ],
 "host": [
  null,
  "מארח"
 ],
 "host device": [
  null,
  "התקן מארח"
 ],
 "host passthrough": [
  null,
  "מעקף מארח"
 ],
 "hostdev": [
  null,
  "התקן מארח"
 ],
 "iSCSI direct target": [
  null,
  "יעד ישיר של iSCSI"
 ],
 "iSCSI initiator IQN": [
  null,
  "IQN של מאתחל iSCSI"
 ],
 "iSCSI target": [
  null,
  "יעד iSCSI"
 ],
 "iSCSI target IQN": [
  null,
  "יעד IQN של iSCSI"
 ],
 "inactive": [
  null,
  "לא פעיל"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt‎"
 ],
 "mcast": [
  null,
  "mcast‎"
 ],
 "more info": [
  null,
  ""
 ],
 "mount point: The mount point inside the guest": [
  null,
  ""
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  ""
 ],
 "network": [
  null,
  "רשת"
 ],
 "no": [
  null,
  "לא"
 ],
 "no state saved": [
  null,
  "לא נשמר מצב"
 ],
 "none": [
  null,
  ""
 ],
 "pxe": [
  null,
  "‎pxe"
 ],
 "qcow2": [
  null,
  "‎qcow2"
 ],
 "qemu": [
  null,
  "‎qemu"
 ],
 "redirected device": [
  null,
  "התקן מופנה"
 ],
 "serial number": [
  null,
  ""
 ],
 "server": [
  null,
  "שרת"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "פעיל"
 ],
 "user": [
  null,
  "משתמש"
 ],
 "vCPU count": [
  null,
  "כמות מעבדים וירטואליים"
 ],
 "vCPU maximum": [
  null,
  "מעבד וירטואלי מרבי"
 ],
 "vCPUs": [
  null,
  "מעבדים וירטואליים"
 ],
 "vhostuser": [
  null,
  "‎vhostuser"
 ],
 "view more...": [
  null,
  "להציג עוד…"
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "יש להתקין את החבילה virt-install במערכת כדי לשכפל מכונות וירטואליות"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "יש להתקין את החבילה virt-install במערכת כדי ליצור מכונות וירטואליות חדשות"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "יש להתקין את החבילה virt-install במערכת כדי לערוך את המאפיין הזה"
 ],
 "vm": [
  null,
  "מכונה וירטואלית"
 ],
 "yes": [
  null,
  "כן"
 ]
});
