cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "zh_CN",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 位于默认位置"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 在主机上可用"
 ],
 "$0 CPU configuration": [
  null,
  "$0 CPU 配置"
 ],
 "$0 Network": [
  null,
  "$0 网络"
 ],
 "$0 Storage pool": [
  null,
  "$0 存储池"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 不支持无人值守安装。"
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 大多数操作系统可用。为了安装它，请在 GNOME 软件中心中搜索它，或运行以下命令："
 ],
 "$0 memory adjustment": [
  null,
  "$0 内存调整"
 ],
 "$0 network": [
  null,
  "$0 网络"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPU"
 ],
 "$0 vCPU details": [
  null,
  "$0 vCPU 详情"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 虚拟网络接口设置"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "一个虚拟机的副本将在目标上运行，并在其关闭时消失。同时，原始主机会保留其虚拟机配置的副本。"
 ],
 "Access": [
  null,
  "访问"
 ],
 "Action": [
  null,
  "操作"
 ],
 "Activate": [
  null,
  "激活"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "激活存储池以管理卷"
 ],
 "Add": [
  null,
  "添加"
 ],
 "Add a DHCP static host entry": [
  null,
  "添加一个DHCP静态主机条目"
 ],
 "Add disk": [
  null,
  "添加磁盘"
 ],
 "Add host device": [
  null,
  "添加主机设备"
 ],
 "Add network interface": [
  null,
  "添加网络接口"
 ],
 "Add shared directory": [
  null,
  "添加共享的目录"
 ],
 "Add virtual network interface": [
  null,
  "添加虚拟网络接口"
 ],
 "Add watchdog device type": [
  null,
  "添加 watchdog 设备类型"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "只有在客户机处于关机状态时才能添加共享目录"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  "添加此磁盘会将其访问模式改为共享。"
 ],
 "Additional": [
  null,
  "额外"
 ],
 "Address": [
  null,
  "地址"
 ],
 "Address not within subnet": [
  null,
  "地址不在子网内"
 ],
 "All": [
  null,
  "所有"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "所有虚拟机的活动（包括存储）都将是临时的。这将导致目标主机上的数据会丢失。"
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "允许的字符：基本的拉丁字母、数字和有限的标点（-、_、+、.）"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "同时删除这个池中的所有卷："
 ],
 "Always attach": [
  null,
  "保证连接"
 ],
 "Apply": [
  null,
  "应用"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "只有在下载镜像或使用 cloud-init 时，才可以使用自动安装。"
 ],
 "Automatic": [
  null,
  "自动"
 ],
 "Automation": [
  null,
  "自动化"
 ],
 "Autostart": [
  null,
  "自动启动"
 ],
 "Blocked": [
  null,
  "受阻"
 ],
 "Boot order": [
  null,
  "启动顺序"
 ],
 "Boot order settings could not be saved": [
  null,
  "无法保存启动顺序"
 ],
 "Bus": [
  null,
  "总线"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD 盘"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU configuration could not be saved": [
  null,
  "CPU 配置不能被保存"
 ],
 "CPU type": [
  null,
  "CPU类型"
 ],
 "Cache": [
  null,
  "缓存"
 ],
 "Cancel": [
  null,
  "取消"
 ],
 "Capacity": [
  null,
  "容量"
 ],
 "Change boot order": [
  null,
  "更改引导顺序"
 ],
 "Change firmware": [
  null,
  "修改固件"
 ],
 "Changes pending": [
  null,
  ""
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "改变生效需要关机"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  ""
 ],
 "Checking token validity...": [
  null,
  "检查令牌有效性..."
 ],
 "Choose an operating system": [
  null,
  "选择一个操作系统"
 ],
 "Class": [
  null,
  "等级"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "点 \"Launch remote viewer\" 将下载一个 .vv 文件并启动 $0。"
 ],
 "Clone": [
  null,
  "克隆"
 ],
 "Close": [
  null,
  "关闭"
 ],
 "Cloud base image": [
  null,
  "Cloud 基础镜像"
 ],
 "Confirm this action": [
  null,
  "确认此操作"
 ],
 "Connect": [
  null,
  "连接"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "使用任意 viewer 应用程序用于以下协议"
 ],
 "Connecting": [
  null,
  "连接中"
 ],
 "Connection": [
  null,
  "连接"
 ],
 "Console": [
  null,
  "控制台"
 ],
 "Copy storage": [
  null,
  "复制存储"
 ],
 "Cores per socket": [
  null,
  "每个插槽的内核数"
 ],
 "Could not delete $0": [
  null,
  "无法删除 $0"
 ],
 "Could not revert to snapshot": [
  null,
  "无法恢复到快照"
 ],
 "Crashed": [
  null,
  "已崩溃"
 ],
 "Create": [
  null,
  "创建"
 ],
 "Create VM": [
  null,
  "创建虚拟机"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "通过导入一个现存虚拟机的一个磁盘镜像来创建虚拟机"
 ],
 "Create VM from local or network installation medium": [
  null,
  "从本地或者网络安装介质创建虚拟机"
 ],
 "Create a clone VM based on $0": [
  null,
  "基于 $0 创建一个克隆虚拟机"
 ],
 "Create and edit": [
  null,
  "创建并编辑"
 ],
 "Create and run": [
  null,
  "创建并运行"
 ],
 "Create new": [
  null,
  "新建"
 ],
 "Create new virtual machine": [
  null,
  "创建新的虚拟机"
 ],
 "Create new volume": [
  null,
  "创建新卷"
 ],
 "Create snapshot": [
  null,
  "创建快照"
 ],
 "Create storage pool": [
  null,
  "创建存储池"
 ],
 "Create storage volume": [
  null,
  "创建存储卷"
 ],
 "Create virtual network": [
  null,
  "创建虚拟网络"
 ],
 "Create volume": [
  null,
  "创建卷"
 ],
 "Creating VM": [
  null,
  "创建虚拟机"
 ],
 "Creating VM $0": [
  null,
  "创建虚拟机 $0"
 ],
 "Creation of VM $0 failed": [
  null,
  "虚拟机$0创建失败"
 ],
 "Creation time": [
  null,
  "创建时间"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "当前的"
 ],
 "Current allocation": [
  null,
  "当前分配"
 ],
 "Custom firmware: $0": [
  null,
  "自定义固件：$0"
 ],
 "Custom path": [
  null,
  "自定义路径"
 ],
 "DHCP Settings": [
  null,
  "DHCP 设置"
 ],
 "Deactivate": [
  null,
  "取消激活"
 ],
 "Delete": [
  null,
  "删除"
 ],
 "Delete $0 VM?": [
  null,
  "删除 $0 虚拟机？"
 ],
 "Delete $0 storage pool?": [
  null,
  "删除 $0 存储池？"
 ],
 "Delete $0 volume": [
  null,
  "删除$0卷"
 ],
 "Delete associated storage files:": [
  null,
  "删除关联的存储文件："
 ],
 "Delete network?": [
  null,
  "删除网络？"
 ],
 "Delete snapshot?": [
  null,
  "删除快照？"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "删除一个不活跃的存储池将只会取消定义这个池。它的内容不会被删除。"
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "只有在客户机处于关机状态时才能删除共享目录"
 ],
 "Description": [
  null,
  "描述"
 ],
 "Desktop viewer": [
  null,
  "Desktop Viewer"
 ],
 "Destination URI": [
  null,
  "目标 URI"
 ],
 "Destination URI must not be empty": [
  null,
  "目标 URI 不能为空"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "尝试删除之前，从所有 VM 中分离使用这个池的磁盘。"
 ],
 "Details": [
  null,
  "详情"
 ],
 "Device": [
  null,
  "设备"
 ],
 "Devices": [
  null,
  "设备"
 ],
 "Disconnect": [
  null,
  "断开"
 ],
 "Disconnected": [
  null,
  "已断开连接"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "与串行控制台断开连接。单击连接按钮。"
 ],
 "Disk $0 could not be removed": [
  null,
  "无法删除磁盘 $0"
 ],
 "Disk failed to be attached": [
  null,
  "挂载磁盘失败"
 ],
 "Disk failed to be created": [
  null,
  "创建磁盘失败"
 ],
 "Disk identifier": [
  null,
  "磁盘识别符"
 ],
 "Disk image": [
  null,
  "磁盘镜像"
 ],
 "Disk image file": [
  null,
  "磁盘镜像文件"
 ],
 "Disk image path must not be empty": [
  null,
  "磁盘镜像路径不能为空"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "磁盘镜像可以存储在用户主目录中"
 ],
 "Disk settings could not be saved": [
  null,
  "磁盘设置不能被保存"
 ],
 "Disk-only snapshot": [
  null,
  "纯磁盘快照"
 ],
 "Disks": [
  null,
  "磁盘"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "不要同时在原始主机和目标主机上运行此虚拟机。"
 ],
 "Do nothing": [
  null,
  "什么都不做"
 ],
 "Domain has crashed": [
  null,
  "域已崩溃"
 ],
 "Domain is blocked on resource": [
  null,
  "域在资源上被阻塞"
 ],
 "Download an OS": [
  null,
  "下载一个 OS"
 ],
 "Download progress": [
  null,
  "下载进度"
 ],
 "Downloading image for VM $0": [
  null,
  "为虚拟机 $0 下载镜像"
 ],
 "Downloading: $0%": [
  null,
  "正在下载：$0%"
 ],
 "Dump core": [
  null,
  "转储内核"
 ],
 "Duration": [
  null,
  "持续时间"
 ],
 "Dying": [
  null,
  "停止工作"
 ],
 "Edit": [
  null,
  "编辑"
 ],
 "Edit $0 attributes": [
  null,
  "编辑 $0 属性"
 ],
 "Edit watchdog device type": [
  null,
  "编辑 watchdog 设备类型"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "不允许编辑临时客户机的网络接口"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "不允许编辑临时网络接口"
 ],
 "Eject": [
  null,
  "弹出"
 ],
 "Eject disc from VM?": [
  null,
  "从虚拟机中弹出磁盘？"
 ],
 "Emulated machine": [
  null,
  "虚拟的机器"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  ""
 ],
 "End": [
  null,
  "结束"
 ],
 "End should not be empty": [
  null,
  "结束不应为空"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "输入 root 和/或用户信息以启用无人值守安装。"
 ],
 "Error checking token": [
  null,
  "检查令牌出错"
 ],
 "Example, $0": [
  null,
  "例如，$0"
 ],
 "Existing disk image on host's file system": [
  null,
  "主机文件系统上存在的磁盘镜像"
 ],
 "Expand": [
  null,
  "展开"
 ],
 "Extended attributes": [
  null,
  "扩展属性"
 ],
 "Failed": [
  null,
  "已失败"
 ],
 "Failed to add shared directory": [
  null,
  "添加共享目录失败"
 ],
 "Failed to change firmware": [
  null,
  "修改固件失败"
 ],
 "Failed to clone VM $0": [
  null,
  "克隆虚拟机 $0 失败"
 ],
 "Failed to configure watchdog": [
  null,
  "配置 watchdog 失败"
 ],
 "Failed to detach watchdog": [
  null,
  "分离 watchdog 失败"
 ],
 "Failed to fetch some resources": [
  null,
  "获取一些资源失败"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "获取在 $0 中的接口的 IP 地址失败"
 ],
 "Failed to rename VM $0": [
  null,
  "重新命名虚拟机 $0 失败"
 ],
 "Failed to save network settings": [
  null,
  "保存网络设置失败"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "发送按键 Ctrl+Alt+$0 到 VM $1 失败"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "启用的虚拟 CPU 数量应少于最大虚拟 CPU 数量。"
 ],
 "File": [
  null,
  "文件"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "文件系统 $0 无法删除"
 ],
 "Filesystem directory": [
  null,
  "文件系统目录"
 ],
 "Filter by name": [
  null,
  "根据名称过滤"
 ],
 "Firmware": [
  null,
  "固件"
 ],
 "Force eject": [
  null,
  "强制弹出"
 ],
 "Force reboot": [
  null,
  "强制重启"
 ],
 "Force revert": [
  null,
  "强制恢复"
 ],
 "Force shut down": [
  null,
  "强制关机"
 ],
 "Format": [
  null,
  "格式化"
 ],
 "Forward mode": [
  null,
  "转发模式"
 ],
 "Forwarding mode": [
  null,
  "转发模式"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "完整的磁盘镜像和域的内存将被迁移。只有非共享的、可写入磁盘的镜像才会被迁移。迁移后，未使用的存储将保留在原始系统上。"
 ],
 "General": [
  null,
  "通用"
 ],
 "Generate automatically": [
  null,
  "自动产生"
 ],
 "Get a new RHSM token.": [
  null,
  "获取一个新的 RHSM 令牌。"
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "进入 VM 列表"
 ],
 "Good choice for desktop virtualization": [
  null,
  "桌面虚拟化的好选择"
 ],
 "Gracefully shutdown": [
  null,
  "正常关机"
 ],
 "Hide additional options": [
  null,
  "隐藏额外操作"
 ],
 "Host": [
  null,
  "主机"
 ],
 "Host device": [
  null,
  "主机设备"
 ],
 "Host device could not be attached": [
  null,
  "无法连接主机设备"
 ],
 "Host device will be removed from $0:": [
  null,
  "主机设备将从 $0 中删除："
 ],
 "Host devices": [
  null,
  "主机设备"
 ],
 "Host name": [
  null,
  "主机名"
 ],
 "Host should not be empty": [
  null,
  "主机不能为空"
 ],
 "Hypervisor details": [
  null,
  "Hypervisor 详情"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP 地址"
 ],
 "IP address must not be empty": [
  null,
  "IP 地址不能为空"
 ],
 "IP configuration": [
  null,
  "IP 配置"
 ],
 "IPv4 address": [
  null,
  "IPv4 地址"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  "IPv4 地址不能与网络标识符相同"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "IPv4 地址不能与网络广播地址相同"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 和 IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4 网络不能为空"
 ],
 "IPv4 only": [
  null,
  "仅 IPv4"
 ],
 "IPv6 address": [
  null,
  "IPv6 地址"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6 网络不能为空"
 ],
 "IPv6 only": [
  null,
  "仅 IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "非常适合服务器虚拟机"
 ],
 "Ideal networking support": [
  null,
  "理想的网络支持"
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "标识符可能会被静默地截断为 $0 个字符 "
 ],
 "Idle": [
  null,
  "休眠"
 ],
 "Ignore": [
  null,
  ""
 ],
 "Import VM": [
  null,
  "导入 VM"
 ],
 "Import a virtual machine": [
  null,
  "导入一个虚拟机"
 ],
 "Import and edit": [
  null,
  "导入并编辑"
 ],
 "Import and run": [
  null,
  "导入并运行"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "导入镜像文件(不支持的基础镜像文件)"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "在多数配置中，macvtap 不能为主机到客户机的网络通信工作。"
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  "在默认的 \"vepa \"模式下，切换被卸载到外部交换机。如果交换机不具备VEPA功能，客户虚拟机之间或客户机与主机之间就不可能进行通信。"
 ],
 "Initiator": [
  null,
  "启动器"
 ],
 "Initiator IQN should not be empty": [
  null,
  "启动器 IQN 不能为空"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "注入不可屏蔽中断"
 ],
 "Insert": [
  null,
  "插入"
 ],
 "Insert disc media": [
  null,
  "插入磁盘介质"
 ],
 "Install": [
  null,
  "安装"
 ],
 "Installation source": [
  null,
  "安装源"
 ],
 "Installation source must not be empty": [
  null,
  "安装源不能为空"
 ],
 "Installation type": [
  null,
  "安装类型"
 ],
 "Interface": [
  null,
  "接口"
 ],
 "Interface type": [
  null,
  "接口类型"
 ],
 "Interface type help": [
  null,
  "接口类型帮助"
 ],
 "Invalid IPv4 address": [
  null,
  "无效的 IPv4 地址"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "无效的 IPv4 掩码或前缀长度"
 ],
 "Invalid IPv6 address": [
  null,
  "无效的 IPv6 地址"
 ],
 "Invalid IPv6 prefix": [
  null,
  "无效的 IPv6 前缀"
 ],
 "Invalid filename": [
  null,
  "无效的文件名"
 ],
 "Isolated network": [
  null,
  "隔离的网络"
 ],
 "LVM volume group": [
  null,
  "LVM 卷组"
 ],
 "Launch remote viewer": [
  null,
  "启动 Remote Viewer"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "如果您不希望创建一个 root 账号，则将密码留空"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "如果你不希望创建一个用户账号，则将密码留空"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "如果您不希望设置 root 的密码，则将密码留空"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt 未检测到安装在主机上的任何 UEFI/OVMF 固件镜像"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt 或虚拟机管理器不支持 UEFI"
 ],
 "Loading available network devices": [
  null,
  "加载可用的网络设备"
 ],
 "Loading resources": [
  null,
  "加载资源"
 ],
 "Loading...": [
  null,
  "载入中..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "本地安装媒体（ISO镜像或者发行版安装树）"
 ],
 "Location": [
  null,
  "位置"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC 地址"
 ],
 "MAC address must not be empty": [
  null,
  "MAC 地址不能为空"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "更改总线类型前必须关闭机器"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "更改缓存类型之前必须关闭机器"
 ],
 "Managing virtual machines": [
  null,
  "管理虚拟机"
 ],
 "Manual connection": [
  null,
  "手动连接"
 ],
 "Mask or prefix length": [
  null,
  "掩码或前缀长度"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "掩码或前缀长度不能为空"
 ],
 "Maximum allocation": [
  null,
  "最大分配"
 ],
 "Maximum memory could not be saved": [
  null,
  "最大内存不能被保存"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "为客户端操作系统分配的最大虚拟 CPU 数"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "为客户机操作系统分配的最大虚拟 CPU 数，必须介于 1 和 $0 之间"
 ],
 "Maximum transmission unit": [
  null,
  "最大传输单元"
 ],
 "Media could not be ejected from $0": [
  null,
  "介质无法从 $0 弹出"
 ],
 "Media will be ejected from $0:": [
  null,
  "介质将从 $0 中弹出："
 ],
 "Memory": [
  null,
  "内存"
 ],
 "Memory could not be saved": [
  null,
  "内存不能被保存"
 ],
 "Memory must not be 0": [
  null,
  "内存不能为 0"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "迁移"
 ],
 "Migrate VM to another host": [
  null,
  "将虚拟机迁移到另一主机"
 ],
 "Migration failed": [
  null,
  "迁移失败"
 ],
 "Mode": [
  null,
  "模式"
 ],
 "Model": [
  null,
  "型号"
 ],
 "Model type": [
  null,
  "型号类型"
 ],
 "More info for mount tag field": [
  null,
  "挂载标签字段的更多信息"
 ],
 "More info for source path field": [
  null,
  "源路径字段的更多信息"
 ],
 "Mount tag": [
  null,
  "挂载标签"
 ],
 "Mount tag must not be empty": [
  null,
  "挂载标签不能为空"
 ],
 "NAT to $0": [
  null,
  "NAT 到 $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "VM $1 的 NIC $0 改变状态失败"
 ],
 "Name": [
  null,
  "名称"
 ],
 "Name already exists": [
  null,
  "名称已存在"
 ],
 "Name contains invalid characters": [
  null,
  "名称包含无效的字符"
 ],
 "Name must not be empty": [
  null,
  "名称不能为空"
 ],
 "Name should not be empty": [
  null,
  "名称不应为空"
 ],
 "Name: ": [
  null,
  "名称： "
 ],
 "Netmask": [
  null,
  "网络掩码"
 ],
 "Network $0 could not be deleted": [
  null,
  "无法删除网络 $0"
 ],
 "Network $0 failed to get activated": [
  null,
  "网络 $0 激活失败"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "网络 $0 取消激活失败"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "网络 $0 将被永久删除。"
 ],
 "Network boot (PXE)": [
  null,
  "网络引导 (PXE)"
 ],
 "Network file system": [
  null,
  "网络文件系统"
 ],
 "Network interface $0 could not be removed": [
  null,
  "无法删除网络接口 $0"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "网络接口 $0 将从 $1 中删除"
 ],
 "Network interface settings could not be saved": [
  null,
  "网络接口设置不能被保存"
 ],
 "Network interfaces": [
  null,
  "网络接口"
 ],
 "Network selection does not support PXE.": [
  null,
  "网络选择不支持 PXE。"
 ],
 "Networks": [
  null,
  "网络"
 ],
 "New name": [
  null,
  "新名称"
 ],
 "New name must not be empty": [
  null,
  "新名称不能为空"
 ],
 "New volume name": [
  null,
  "新卷名称"
 ],
 "No VM is running or defined on this host": [
  null,
  "该主机上没有定义或运行虚拟机"
 ],
 "No boot device found": [
  null,
  "没有找到引导设备"
 ],
 "No connection available": [
  null,
  "没有可用连接"
 ],
 "No description": [
  null,
  "没有描述"
 ],
 "No directories shared between the host and this VM": [
  null,
  "主机和此虚拟机之间没有共享的目录"
 ],
 "No disks defined for this VM": [
  null,
  "没有为该虚拟机定义磁盘"
 ],
 "No host device selected": [
  null,
  "没有选择主机设备"
 ],
 "No host devices assigned to this VM": [
  null,
  "没有分配给这个虚拟机的主机设备"
 ],
 "No network devices": [
  null,
  "没有网络设备"
 ],
 "No network interfaces defined for this VM": [
  null,
  "没有为此 VM 定义网络接口"
 ],
 "No network is defined on this host": [
  null,
  "没有在这个主机上定义网络"
 ],
 "No networks available": [
  null,
  "没有可用的网络"
 ],
 "No parent": [
  null,
  "没有上级"
 ],
 "No snapshots defined for this VM": [
  null,
  "没有为这个虚拟机定义快照"
 ],
 "No state": [
  null,
  "无状态"
 ],
 "No storage": [
  null,
  "没有存储"
 ],
 "No storage pool is defined on this host": [
  null,
  "没有在这个主机上定义存储池"
 ],
 "No storage pools available": [
  null,
  "没有可用的存储池"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "没有为这个存储池定义存储卷"
 ],
 "No virtual networks": [
  null,
  "没有虚拟网络"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "这个存储池中没有卷。"
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "非持久性网络无法删除。停用后它不再存在。"
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "非持久性网络池无法删除。停用后它不再存在。"
 ],
 "None": [
  null,
  "无"
 ],
 "None (isolated network)": [
  null,
  "无 (隔离的网络)"
 ],
 "Offline token": [
  null,
  "离线令牌"
 ],
 "Offline token must not be empty": [
  null,
  "离线令牌不能为空"
 ],
 "Old token expired": [
  null,
  "令牌已过期"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "一个或多个卷被域使用。需要先分离磁盘后才可以删除卷。"
 ],
 "Only editable when the guest is shut off": [
  null,
  "只有在客户机关闭后才可以编辑"
 ],
 "Open": [
  null,
  "Open"
 ],
 "Operating system": [
  null,
  "操作系统"
 ],
 "Operation is in progress": [
  null,
  "操作进行中"
 ],
 "Overview": [
  null,
  "概览"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "上级快照"
 ],
 "Path": [
  null,
  "路径"
 ],
 "Path on host's filesystem": [
  null,
  "主机文件系统上的路径"
 ],
 "Path to ISO file on host's file system": [
  null,
  "主机文件系统中到 ISO 文件的路径"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "到主机文件系统上 cloud 镜像文件的路径"
 ],
 "Path to file on host's file system": [
  null,
  "到主机文件系统上的文件的路径"
 ],
 "Pause": [
  null,
  "暂停"
 ],
 "Paused": [
  null,
  "已暂停"
 ],
 "Permanent (default)": [
  null,
  "永久（默认）"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "主目录中磁盘映像的权限被拒绝"
 ],
 "Persistence": [
  null,
  "持久"
 ],
 "Persistent": [
  null,
  "持久"
 ],
 "Physical disk device": [
  null,
  "物理磁盘设备"
 ],
 "Physical disk device on host": [
  null,
  "主机上的物理磁盘设备"
 ],
 "Please choose a storage pool": [
  null,
  "请选择一个存储池"
 ],
 "Please choose a volume": [
  null,
  "请选择一个卷"
 ],
 "Please enter new volume name": [
  null,
  "请输入新的卷名"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "请启动虚拟机来访问其控制台。"
 ],
 "Pool": [
  null,
  "池"
 ],
 "Pool needs to be active to create volume": [
  null,
  "池需要激活才能创建卷"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "池类型 $0 不支持创建卷"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "池类型不支持创建卷"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "池的卷被 VM 使用 "
 ],
 "Port": [
  null,
  "端口"
 ],
 "Power off": [
  null,
  "关机"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "向客户机公开的首选插槽数。"
 ],
 "Prefix": [
  null,
  "前缀"
 ],
 "Prefix length": [
  null,
  "前缀长度"
 ],
 "Prefix length should not be empty": [
  null,
  "前缀长度不能为空"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "提前创建的快照使得您可以在出现问题的时候回复到较早的状态"
 ],
 "Private": [
  null,
  "私有"
 ],
 "Product": [
  null,
  "产品"
 ],
 "Profile": [
  null,
  "配置集"
 ],
 "Protocol": [
  null,
  "协议"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "从客户虚拟机直接提供桥接到 LAN。这需要带有一个或多个物理 NIC 的主机上的桥接设备。"
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "提供一个连接，其详细信息由指定网络定义描述。"
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "通过 NAT 向外界提供虚拟 LAN。"
 ],
 "Range": [
  null,
  "范围"
 ],
 "Read-only": [
  null,
  "只读"
 ],
 "Reboot": [
  null,
  "重启"
 ],
 "Remote URL": [
  null,
  "远程 URL"
 ],
 "Remote viewer details": [
  null,
  "Remote viewer 详情"
 ],
 "Remove": [
  null,
  "删除"
 ],
 "Remove and delete file": [
  null,
  ""
 ],
 "Remove disk from VM?": [
  null,
  "从虚拟机中删除磁盘？"
 ],
 "Remove filesystem?": [
  null,
  "删除文件系统？"
 ],
 "Remove host device from VM?": [
  null,
  "从虚拟机中删除主机设备？"
 ],
 "Remove network interface?": [
  null,
  "删除网络接口？"
 ],
 "Remove static host from DHCP": [
  null,
  "从 DHCP 中删除静态主机"
 ],
 "Rename": [
  null,
  "重命名"
 ],
 "Rename VM $0": [
  null,
  "重命名虚拟机 $0"
 ],
 "Reset": [
  null,
  "重置"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "网络中的限制（基于SLIRP 的模拟）和 PCI 设备分配"
 ],
 "Resume": [
  null,
  "恢复"
 ],
 "Revert": [
  null,
  "恢复"
 ],
 "Revert to snapshot $0": [
  null,
  "恢复到快照 $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "恢复到此快照将使虚拟机返回到创建快照时的状态，当前状态将丢失，同时丢失快照中未包括的任何数据"
 ],
 "Root password": [
  null,
  "Root 密码"
 ],
 "Route to $0": [
  null,
  "路由到 $0"
 ],
 "Routed network": [
  null,
  "路由的网络"
 ],
 "Run": [
  null,
  "运行"
 ],
 "Run when host boots": [
  null,
  "在主机引导时运行"
 ],
 "Running": [
  null,
  "运行中"
 ],
 "SPICE TLS port": [
  null,
  "SPICE TLS 端口"
 ],
 "SPICE address": [
  null,
  "SPICE 地址"
 ],
 "SPICE port": [
  null,
  "SPICE 端口"
 ],
 "Save": [
  null,
  "保存"
 ],
 "Select console type": [
  null,
  "选择控制台类型"
 ],
 "Send key": [
  null,
  "发送按键"
 ],
 "Send non-maskable interrupt": [
  null,
  "发送不可屏蔽中断"
 ],
 "Serial": [
  null,
  "序列号"
 ],
 "Serial console": [
  null,
  "串行控制台"
 ],
 "Serial console ($0)": [
  null,
  "串行控制台 ($0)"
 ],
 "Set DHCP range": [
  null,
  "设置 DHCP 范围"
 ],
 "Set manually": [
  null,
  "手工设置"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "为无人值守安装设置用户密码要求在创建 VM 的时候启动它"
 ],
 "Share": [
  null,
  "共享"
 ],
 "Share a host directory with the guest": [
  null,
  "与虚拟客户机共享主机目录"
 ],
 "Shared directories": [
  null,
  "共享的目录"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "共享的主机目录需要手动挂载到虚拟机中"
 ],
 "Shared storage": [
  null,
  "共享的存储"
 ],
 "Show additional options": [
  null,
  "显示额外操作"
 ],
 "Shut down": [
  null,
  "关机"
 ],
 "Shut off": [
  null,
  "关闭"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "关闭 VM 以编辑固件配置"
 ],
 "Shutting down": [
  null,
  "正在关机"
 ],
 "Size": [
  null,
  "大小"
 ],
 "Slot": [
  null,
  "插槽"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "快照 $0 无法删除"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "快照 $0 将从 $1 中删除。其获取的所有内容都将丢失。"
 ],
 "Snapshot failed to be created": [
  null,
  "创建快照失败"
 ],
 "Snapshots": [
  null,
  "快照"
 ],
 "Sockets": [
  null,
  "插槽"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  ""
 ],
 "Source": [
  null,
  "源"
 ],
 "Source format": [
  null,
  "源格式"
 ],
 "Source must not be empty": [
  null,
  "源不能为空"
 ],
 "Source path": [
  null,
  "源路径"
 ],
 "Source path should not be empty": [
  null,
  "源路径不能为空"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "源应该以 http、ftp 或 nfs 协议开头"
 ],
 "Source volume group": [
  null,
  "源卷组"
 ],
 "Start": [
  null,
  "启动"
 ],
 "Start pool when host boots": [
  null,
  "在主机引导时启动池"
 ],
 "Start should not be empty": [
  null,
  "开始不能为空"
 ],
 "Startup": [
  null,
  "启动"
 ],
 "State": [
  null,
  "状态"
 ],
 "Static host entries": [
  null,
  "静态主机条目"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "无法从 DHCP 中删除静态主机"
 ],
 "Storage": [
  null,
  "存储"
 ],
 "Storage is at a shared location": [
  null,
  "存储位于共享位置"
 ],
 "Storage limit": [
  null,
  "存储限制"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "存储池 $0 激活失败"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "存储池 $0 取消激活失败"
 ],
 "Storage pool failed to be created": [
  null,
  "创建存储池失败"
 ],
 "Storage pool name": [
  null,
  "存储池名"
 ],
 "Storage pools": [
  null,
  "存储池"
 ],
 "Storage pools could not be fetched": [
  null,
  "存储池不能被获取"
 ],
 "Storage size must not be 0": [
  null,
  "储存空间大小不能为 0"
 ],
 "Storage volume": [
  null,
  "存储卷"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "存储卷大小不能超过存储池的容量（$0 $1）"
 ],
 "Storage volumes": [
  null,
  "存储卷"
 ],
 "Storage volumes could not be deleted": [
  null,
  "存储卷不能被删除"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "存储卷必须在此主机和目标主机之间共享。"
 ],
 "Suspended (PM)": [
  null,
  "已挂起 （电源管理）"
 ],
 "System": [
  null,
  "系统"
 ],
 "Table of selectable host devices": [
  null,
  "可选择的主机设备表"
 ],
 "Target": [
  null,
  "目标"
 ],
 "Target path": [
  null,
  "目标路径"
 ],
 "Target path should not be empty": [
  null,
  "目标路径不能为空"
 ],
 "Temporary": [
  null,
  "临时"
 ],
 "Temporary migration": [
  null,
  "临时迁移"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "虚拟机 $0 正在运行，在删除前将被强制关闭。"
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "虚拟机需要运行或关闭才能分离该设备"
 ],
 "The directory on the server being exported": [
  null,
  "服务器上的目录被导出"
 ],
 "The host path that is to be exported.": [
  null,
  "要导出的主机路径。"
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "迁移的虚拟机配置将从源主机中删除。目标主机被视为虚拟机的新主目录。"
 ],
 "The pool is empty": [
  null,
  "池为空"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "所选操作系统的最小内存要求是 $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "所选操作系统的最小存储要求是 $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "$0 的静态主机条目将被删除："
 ],
 "The storage pool could not be deleted": [
  null,
  "存储池不能被删除"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "客户机用来挂载此导出点的标签名称。"
 ],
 "Then copy and paste it above.": [
  null,
  "然后复制并在上面粘贴它。"
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "此 VM 是瞬态的。如果希望删除它，请将其关机。"
 ],
 "This disk will be removed from $0:": [
  null,
  "这个磁盘将从 $0 中删除："
 ],
 "This filesystem will be removed from $0:": [
  null,
  "这个文件系统将从 $0 中删除："
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "这是对使用动态/无线网络配置的主机上的常规客户机连接的建议配置。"
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "这是对使用静态有线网络配置的主机上的常规客户机连接的建议配置。"
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  "这是为高性能或增强安全性而推荐的配置。"
 ],
 "This volume is already used by $0.": [
  null,
  "这个卷已经被 $0 使用。"
 ],
 "This volume is already used by another VM.": [
  null,
  "这个卷已被另外一个虚拟机使用。"
 ],
 "Threads per core": [
  null,
  "每个内核的线程数"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "瞬态 VM 不支持编辑固件配置"
 ],
 "Troubleshoot": [
  null,
  "排错"
 ],
 "Type": [
  null,
  "类型"
 ],
 "Type ID": [
  null,
  "类型 ID"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL（ISO镜像或者发行版安装树）"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "未定义"
 ],
 "Unique name": [
  null,
  "唯一名称"
 ],
 "Unique name, default: $0": [
  null,
  "唯一名称，默认：$0"
 ],
 "Unique network name": [
  null,
  "唯一的网络名称"
 ],
 "Unit": [
  null,
  "单位"
 ],
 "Unknown": [
  null,
  "未知"
 ],
 "Unknown firmware": [
  null,
  "未知固件"
 ],
 "Unspecified": [
  null,
  "未指定"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "使用"
 ],
 "Use existing": [
  null,
  "使用现有的"
 ],
 "Use extended attributes on files and directories": [
  null,
  "对文件和目录使用扩展属性"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "在存储的原始主机和目标主机上使用相同的位置。这可以是共享存储池、NFS 或任何其他共享存储方式。"
 ],
 "Used": [
  null,
  "已使用"
 ],
 "Used by": [
  null,
  "用于"
 ],
 "User login": [
  null,
  "用户登录名"
 ],
 "User login must not be empty when user password is set": [
  null,
  "当用户密码设置后，用户登录名必须不为空"
 ],
 "User password": [
  null,
  "用户密码"
 ],
 "User password must not be empty when user login is set": [
  null,
  "当设置用户登录名之后，用户密码必须不为空"
 ],
 "User session": [
  null,
  "用户会话"
 ],
 "VCPU settings could not be saved": [
  null,
  "VCPU 设置不能被保存"
 ],
 "VM $0 Host Devices": [
  null,
  "虚拟机 $0 主机设备"
 ],
 "VM $0 already exists": [
  null,
  "VM $0 已存在"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "VM $0 在 $1 连接中不存在"
 ],
 "VM $0 failed to force reboot": [
  null,
  "VM $0 强制重启失败"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "VM $0 强制关闭失败"
 ],
 "VM $0 failed to get installed": [
  null,
  "VM $0 安装失败"
 ],
 "VM $0 failed to pause": [
  null,
  "VM $0 暂停失败"
 ],
 "VM $0 failed to reboot": [
  null,
  "VM $0 重启失败"
 ],
 "VM $0 failed to resume": [
  null,
  "VM $0 恢复失败"
 ],
 "VM $0 failed to send NMI": [
  null,
  "VM $0 发送 NMI 失败"
 ],
 "VM $0 failed to shutdown": [
  null,
  "VM $0 关闭失败"
 ],
 "VM $0 failed to start": [
  null,
  "VM $0 启动失败"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "使用非特权限制访问启动的虚拟机，具有您的用户帐户所拥有的进程和 PTY"
 ],
 "VM state": [
  null,
  "VM 状态"
 ],
 "VM will launch with root permissions": [
  null,
  "虚拟机将以 root 权限启动"
 ],
 "VNC TLS port": [
  null,
  "VNC TLS 端口"
 ],
 "VNC address": [
  null,
  "VNC 地址"
 ],
 "VNC console": [
  null,
  "VNC 控制台"
 ],
 "VNC port": [
  null,
  "VNC 端口"
 ],
 "Valid token": [
  null,
  "有效令牌"
 ],
 "Vendor": [
  null,
  "厂商"
 ],
 "Virtual machines": [
  null,
  "虚拟机"
 ],
 "Virtual machines management": [
  null,
  "虚拟机管理"
 ],
 "Virtual network": [
  null,
  "虚拟网络"
 ],
 "Virtual network failed to be created": [
  null,
  "虚拟网络创建失败"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "虚拟化服务（libvirt）未激活"
 ],
 "Volume": [
  null,
  "卷"
 ],
 "Volume failed to be created": [
  null,
  "创建磁盘失败"
 ],
 "Volume group name": [
  null,
  "卷组名称"
 ],
 "Volume group name should not be empty": [
  null,
  "卷组名称不应为空"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "监督者"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "系统停止响应时 watchdogs 的行为。要使用此虚拟 watchdog 设备，客户端系统也需要有一个额外的驱动程序和一个正在运行的 watchdog 服务。"
 ],
 "Writeable": [
  null,
  "可写"
 ],
 "Writeable and shared": [
  null,
  "可写和共享"
 ],
 "You can mount the shared folder using:": [
  null,
  "您可以使用以下方法挂载共享文件夹："
 ],
 "You need to select the most closely matching operating system": [
  null,
  "您需要选择最匹配的操作系统"
 ],
 "active": [
  null,
  "激活"
 ],
 "add": [
  null,
  "添加"
 ],
 "add entry": [
  null,
  "添加条目"
 ],
 "bridge": [
  null,
  "网桥"
 ],
 "cdrom": [
  null,
  "光驱"
 ],
 "custom": [
  null,
  "自定义"
 ],
 "direct": [
  null,
  "直接"
 ],
 "disabled": [
  null,
  "已禁用"
 ],
 "disk": [
  null,
  "磁盘"
 ],
 "down": [
  null,
  "已关闭"
 ],
 "edit": [
  null,
  "编辑"
 ],
 "enabled": [
  null,
  "已启用"
 ],
 "ethernet": [
  null,
  "以太网"
 ],
 "host": [
  null,
  "主机"
 ],
 "host device": [
  null,
  "主机设备"
 ],
 "host passthrough": [
  null,
  "主机透传"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "iSCSI 直接目标"
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI 发起者 IQN"
 ],
 "iSCSI target": [
  null,
  "iSCSI 目标"
 ],
 "iSCSI target IQN": [
  null,
  "iSCSI 目标 IQN"
 ],
 "inactive": [
  null,
  "未激活"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "MCAST"
 ],
 "more info": [
  null,
  "更多信息"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "挂载点：客户机内的挂载点"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "挂载标签：与导出的挂载点关联的标签"
 ],
 "network": [
  null,
  "网络"
 ],
 "no": [
  null,
  "否"
 ],
 "no state saved": [
  null,
  "无保存的状态"
 ],
 "none": [
  null,
  "无"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "重定向设备"
 ],
 "remove": [
  null,
  "删除"
 ],
 "serial number": [
  null,
  "序列号"
 ],
 "server": [
  null,
  "服务器"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "运行中"
 ],
 "user": [
  null,
  "用户"
 ],
 "vCPU count": [
  null,
  "vCPU 数"
 ],
 "vCPU maximum": [
  null,
  "vCPU 的最大值"
 ],
 "vCPUs": [
  null,
  "vCPU"
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "查看更多......"
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "为了克隆虚拟机，需要在系统中安装 virt-install 软件包"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "为了创建新虚拟机需要在系统上安装 virt-install 软件包"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "为了编辑这个属性，需要在系统中安装 virt-install 软件包"
 ],
 "vm": [
  null,
  "vm"
 ],
 "yes": [
  null,
  "是"
 ]
});
