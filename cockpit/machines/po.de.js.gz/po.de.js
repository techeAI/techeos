cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "de",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 am Standardort verfügbar"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 auf dem Host verfügbar"
 ],
 "$0 CPU configuration": [
  null,
  "$0 CPU-Konfiguration"
 ],
 "$0 Network": [
  null,
  "$0 Netzwerk",
  "$0 Netzwerke"
 ],
 "$0 Storage pool": [
  null,
  "$0 Storage Pool",
  "$0 Storage Pools"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 unterstützt keine unbeaufsichtigte Installation."
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 ist für die meisten Betriebssysteme verfügbar. Um es zu installieren, suchen Sie es in der GNOME-Software oder führen Sie Folgendes aus:"
 ],
 "$0 memory adjustment": [
  null,
  "$0 Speicher-Anpassung"
 ],
 "$0 network": [
  null,
  "$0 Netzwerk"
 ],
 "$0 vCPU": [
  null,
  "$0  vCPU",
  "$0 vCPUs"
 ],
 "$0 vCPU details": [
  null,
  "$0 vCPU-Details"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 Virtuelle Netzwerkschnittstelle hinzufügen"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Eine Kopie der VM wird auf dem Zielhost ausgeführt und verschwindet, wenn dieser ausgeschaltet wird. In der Zwischenzeit behält der ursprüngliche Host seine Kopie der VM-Konfiguration."
 ],
 "Access": [
  null,
  "Zugriff"
 ],
 "Action": [
  null,
  "Aktion"
 ],
 "Activate": [
  null,
  "Aktivieren"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  ""
 ],
 "Add": [
  null,
  "Hinzufügen"
 ],
 "Add a DHCP static host entry": [
  null,
  ""
 ],
 "Add disk": [
  null,
  "Datenträger hinzufügen"
 ],
 "Add host device": [
  null,
  "Host-Gerät hinzufügen"
 ],
 "Add network interface": [
  null,
  "Netzwerkschnittstelle hinzufügen"
 ],
 "Add shared directory": [
  null,
  "Geteiltes Verzeichnis hinzufügen"
 ],
 "Add virtual network interface": [
  null,
  "Virtuelle Netzwerkschnittstelle hinzufügen"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Geteiltes Verzeichnis kann nur hinzugefügt werden wenn Gast ausgeschaltet ist"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  ""
 ],
 "Additional": [
  null,
  "Mehr"
 ],
 "Address": [
  null,
  "Adresse"
 ],
 "Address not within subnet": [
  null,
  "Adresse befindet sich nicht im Subnetz"
 ],
 "All": [
  null,
  "Alle"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Alle VM-Aktivitäten, einschließlich der Speicherung, sind temporär. Dies führt zu einem Datenverlust auf dem Zielhost."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Erlaubte Zeichen: lateinisches Grundalphabet, Zahlen und begrenzte Satzzeichen (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  ""
 ],
 "Always attach": [
  null,
  "Immer verbinden"
 ],
 "Apply": [
  null,
  "Anwenden"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  ""
 ],
 "Automatic": [
  null,
  "Automatisch"
 ],
 "Automation": [
  null,
  "Automatisierung"
 ],
 "Autostart": [
  null,
  "Autostart"
 ],
 "Blocked": [
  null,
  "Gesperrt"
 ],
 "Boot order": [
  null,
  "Boot-Reihenfolge"
 ],
 "Boot order settings could not be saved": [
  null,
  "Boot-Reihenfolge konnte nicht gespeichert werden"
 ],
 "Bus": [
  null,
  "Bus"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD"
 ],
 "CPU": [
  null,
  "Prozessor"
 ],
 "CPU configuration could not be saved": [
  null,
  "CPU-Einstellungen konnten nicht gespeichert werden"
 ],
 "CPU type": [
  null,
  "Prozessor-Typ"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Abbrechen"
 ],
 "Capacity": [
  null,
  "Kapazität"
 ],
 "Change boot order": [
  null,
  "Boot-Reihenfolge ändern"
 ],
 "Change firmware": [
  null,
  "Firmware ändern"
 ],
 "Changes pending": [
  null,
  ""
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Änderungen werden nach dem Herunterfahren der VM wirksam"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  ""
 ],
 "Checking token validity...": [
  null,
  "Token-Gültigkeit wird geprüft ..."
 ],
 "Choose an operating system": [
  null,
  "Betriebssystem auswählen"
 ],
 "Class": [
  null,
  "Klasse"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "Klick auf\"Remote Viewer starten\" lädt eine .vv-Datei herunter und startet $0."
 ],
 "Clone": [
  null,
  "Klonen"
 ],
 "Close": [
  null,
  "Schließen"
 ],
 "Cloud base image": [
  null,
  "Cloud-Basis-Image"
 ],
 "Confirm this action": [
  null,
  "Aktion bestätigen"
 ],
 "Connect": [
  null,
  "Verbinden"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "Mit einer Anwendung für die folgenen Protokolle verbinden"
 ],
 "Connecting": [
  null,
  "Verbinde"
 ],
 "Connection": [
  null,
  "Verbindung"
 ],
 "Console": [
  null,
  "Konsole"
 ],
 "Copy storage": [
  null,
  "Speicher kopieren"
 ],
 "Cores per socket": [
  null,
  "Kerne pro Socket"
 ],
 "Could not delete $0": [
  null,
  "$0 konnte nicht gelöscht werden"
 ],
 "Could not revert to snapshot": [
  null,
  "Konnte den Schnappschuss nicht zurücksetzen"
 ],
 "Crashed": [
  null,
  "Abgestürzt"
 ],
 "Create": [
  null,
  "Erstellen"
 ],
 "Create VM": [
  null,
  "VM erstellen"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Erstellen einer VM durch Importieren eines Festplattenabbildes einer bestehenden VM-Installation"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Erstellen einer VM von einem lokalen oder Netzwerk-Installationsmedium"
 ],
 "Create a clone VM based on $0": [
  null,
  "Eine Klon-VM basierend auf $0 erstellen"
 ],
 "Create and edit": [
  null,
  "Erstellen und bearbeiten"
 ],
 "Create and run": [
  null,
  "Erstellen und ausführen"
 ],
 "Create new": [
  null,
  "Neu erstellen"
 ],
 "Create new virtual machine": [
  null,
  "Neue Virtuelle Maschine erstellen"
 ],
 "Create new volume": [
  null,
  "Neuen Datenträger erstellen"
 ],
 "Create snapshot": [
  null,
  "Snapshot erzeugen"
 ],
 "Create storage pool": [
  null,
  "Erstellen Sie einen Speicherpool"
 ],
 "Create storage volume": [
  null,
  "Datenträger erstellen"
 ],
 "Create virtual network": [
  null,
  "Erstelle Virtuelles Netzwerk"
 ],
 "Create volume": [
  null,
  "Volume erzeugen"
 ],
 "Creating VM": [
  null,
  "VM erstellen"
 ],
 "Creating VM $0": [
  null,
  "VM $0 erstellen"
 ],
 "Creation of VM $0 failed": [
  null,
  "Das Erstellen von VM $0 ist fehlgeschlagen"
 ],
 "Creation time": [
  null,
  "Erstellungszeit"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Strg + Alt +$0"
 ],
 "Current": [
  null,
  "Aktuell"
 ],
 "Current allocation": [
  null,
  "aktuelle Zuweisung"
 ],
 "Custom firmware: $0": [
  null,
  "Benutzerdefinierte Firmware: $0"
 ],
 "Custom path": [
  null,
  "Benutzerdefinierter Pfad"
 ],
 "DHCP Settings": [
  null,
  "DHCP-Einstellungen"
 ],
 "Deactivate": [
  null,
  "Deaktivieren"
 ],
 "Delete": [
  null,
  "Löschen"
 ],
 "Delete $0 VM?": [
  null,
  "$0 VM löschen?"
 ],
 "Delete $0 storage pool?": [
  null,
  ""
 ],
 "Delete $0 volume": [
  null,
  "$0 Datenträger löschen",
  "Datenträger $0 löschen"
 ],
 "Delete associated storage files:": [
  null,
  "Verknüpfte Speicherdateien löschen:"
 ],
 "Delete network?": [
  null,
  "Netzwerk löschen?"
 ],
 "Delete snapshot?": [
  null,
  "Schnappschuss löschen?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  ""
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Das Löschen von gemeinsamen Verzeichnissen ist nur möglich, wenn der Gast ausgeschaltet ist"
 ],
 "Description": [
  null,
  "Beschreibung"
 ],
 "Destination URI": [
  null,
  "Ziel-URI"
 ],
 "Destination URI must not be empty": [
  null,
  "Ziel-URI darf nicht leer sein"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  ""
 ],
 "Details": [
  null,
  "Details"
 ],
 "Device": [
  null,
  "Gerät"
 ],
 "Devices": [
  null,
  "Geräte"
 ],
 "Disconnect": [
  null,
  "Verbindung trennen"
 ],
 "Disconnected": [
  null,
  "Getrennt"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Verbindung zur seriellen Konsole getrennt Klicken Sie auf die Schaltfläche 'Neu verbinden'."
 ],
 "Disk $0 could not be removed": [
  null,
  "Festplatte $0 konnte nicht entfernt werden"
 ],
 "Disk failed to be attached": [
  null,
  "Festplatte konnte nicht angeschlossen werden"
 ],
 "Disk failed to be created": [
  null,
  "Datenträger konnte nicht erstellt werden"
 ],
 "Disk identifier": [
  null,
  "Festplattenbezeichner"
 ],
 "Disk image": [
  null,
  "Festplattenabbild"
 ],
 "Disk image file": [
  null,
  "Festplattenabbilddatei"
 ],
 "Disk image path must not be empty": [
  null,
  "Festplattenabbildpfad darf nicht leer sein"
 ],
 "Disk images can be stored in user home directory": [
  null,
  ""
 ],
 "Disk settings could not be saved": [
  null,
  "Festplatten-Einstellungen konnten nicht gespeichert werden"
 ],
 "Disk-only snapshot": [
  null,
  "Nur-Datenträger-Schnappschuss"
 ],
 "Disks": [
  null,
  "Datenträger"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Führen Sie diese VM nicht gleichzeitig auf dem Ursprungs- und dem Zielhost aus."
 ],
 "Do nothing": [
  null,
  ""
 ],
 "Domain has crashed": [
  null,
  "Domain ist abgestürzt"
 ],
 "Domain is blocked on resource": [
  null,
  "Domain ist durch Resource blockiert"
 ],
 "Download an OS": [
  null,
  "Ein Betriebssystem herunterladen"
 ],
 "Download progress": [
  null,
  ""
 ],
 "Downloading image for VM $0": [
  null,
  "Abbild für VM $0 wird heruntergeladen"
 ],
 "Downloading: $0%": [
  null,
  "Herunterladen: $0%"
 ],
 "Dump core": [
  null,
  ""
 ],
 "Duration": [
  null,
  "Dauer"
 ],
 "Dying": [
  null,
  "Sterbend"
 ],
 "Edit": [
  null,
  "Bearbeiten"
 ],
 "Edit $0 attributes": [
  null,
  "$0 Attribute bearbeiten"
 ],
 "Edit watchdog device type": [
  null,
  ""
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Die Bearbeitung von Netzwerkschnittstellen vorübergehender Gäste ist nicht erlaubt"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Die Bearbeitung vorübergehender Netzwerkschnittstellen ist nicht erlaubt"
 ],
 "Eject": [
  null,
  ""
 ],
 "Emulated machine": [
  null,
  "Emulierte Maschine"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  ""
 ],
 "End": [
  null,
  "Ende"
 ],
 "End should not be empty": [
  null,
  "Das Ende sollte nicht leer sein"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Geben Sie root- und/oder Benutzerinformationen ein, um eine unbeaufsichtigte Installation zu aktivieren."
 ],
 "Error checking token": [
  null,
  "Fehler bei der Prüfung des Tokens"
 ],
 "Example, $0": [
  null,
  "Beispiel, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Existierenes Festplatten Abbild auf dem Host Dateisystem"
 ],
 "Expand": [
  null,
  "Erweitern"
 ],
 "Extended attributes": [
  null,
  "Erweiterte Attribute"
 ],
 "Failed": [
  null,
  "Fehlgeschlagen"
 ],
 "Failed to add shared directory": [
  null,
  "Fehler beim Hinzufügen eines gemeinsamen Verzeichnisses"
 ],
 "Failed to change firmware": [
  null,
  "Firmware konnte nicht geändert werden"
 ],
 "Failed to clone VM $0": [
  null,
  "Fehler beim Klonen von VM $0"
 ],
 "Failed to fetch some resources": [
  null,
  "Fehler beim Abrufen einiger Ressourcen"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "IP-Adresse der Schnittstellen in $0 können nicht bezogen werden"
 ],
 "Failed to rename VM $0": [
  null,
  "Fehler beim Umbenennen von VM $0"
 ],
 "Failed to save network settings": [
  null,
  "Fehler beim Speichern der Netzwerkeinstellungen"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Senden der Tastenkombination Strg+Alt+$0 an die VM $1 fehlgeschlagen"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Es sollte weniger als die maximale Anzahl virtueller CPUs aktiviert sein."
 ],
 "File": [
  null,
  "Datei"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Dateisystem $0 konnte nicht entfernt werden"
 ],
 "Filesystem directory": [
  null,
  "Dateisystemverzeichnis"
 ],
 "Filter by name": [
  null,
  "Nach Namen filtern"
 ],
 "Firmware": [
  null,
  "Firmware"
 ],
 "Force reboot": [
  null,
  "Neustart erzwingen"
 ],
 "Force shut down": [
  null,
  "Herunterfahren erzwingen"
 ],
 "Format": [
  null,
  "Formatieren"
 ],
 "Forward mode": [
  null,
  "Weiterleitungs-Modus"
 ],
 "Forwarding mode": [
  null,
  "Weiterleitungs-Modus"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  ""
 ],
 "General": [
  null,
  "Allgemein"
 ],
 "Generate automatically": [
  null,
  "Automatisch generieren"
 ],
 "Get a new RHSM token.": [
  null,
  ""
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "Zur VM-Liste gehen"
 ],
 "Good choice for desktop virtualization": [
  null,
  ""
 ],
 "Hide additional options": [
  null,
  "Zusätzlichen Einstellungen verstecken"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Host device": [
  null,
  "Host-Gerät"
 ],
 "Host device could not be attached": [
  null,
  "Host-Gerät konnte nicht angehängt werden"
 ],
 "Host device will be removed from $0:": [
  null,
  "Das Host-Gerät wird von $0 entfernt:"
 ],
 "Host devices": [
  null,
  "Host-Geräte"
 ],
 "Host name": [
  null,
  "Rechnername"
 ],
 "Host should not be empty": [
  null,
  "Host sollte nicht leer sein"
 ],
 "Hypervisor details": [
  null,
  "Hypervisor-Details"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP-Adresse"
 ],
 "IP address must not be empty": [
  null,
  "IP-Adresse darf nicht leer sein"
 ],
 "IP configuration": [
  null,
  "IP-Konfiguration"
 ],
 "IPv4 address": [
  null,
  "IPv4-Adresse"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  "IPv4-Adresse darf nicht mit der Netzwerkkennung übereinstimmen"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  ""
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 und IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4-Netzwerk sollte nicht leer sein"
 ],
 "IPv4 only": [
  null,
  "Nur IPv4"
 ],
 "IPv6 address": [
  null,
  "IPv6-Adresse"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6-Netzwerk sollte nicht leer sein"
 ],
 "IPv6 only": [
  null,
  "Nur IPv6"
 ],
 "Ideal for server VMs": [
  null,
  ""
 ],
 "Ideal networking support": [
  null,
  ""
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Der Bezeichner kann stillschweigend auf $0 Zeichen gekürzt werden. "
 ],
 "Idle": [
  null,
  "Untätig"
 ],
 "Ignore": [
  null,
  ""
 ],
 "Import VM": [
  null,
  "VM importieren"
 ],
 "Import a virtual machine": [
  null,
  "Virtuelle Maschine importieren"
 ],
 "Import and edit": [
  null,
  "Importieren und bearbeiten"
 ],
 "Import and run": [
  null,
  "Importieren und ausführen"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  ""
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "In den meisten Konfigurationen funktioniert macvtap nicht für die Kommunikation zwischen Host und Gast im Netzwerk."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  ""
 ],
 "Initiator": [
  null,
  "Initiator"
 ],
 "Initiator IQN should not be empty": [
  null,
  ""
 ],
 "Insert disc media": [
  null,
  ""
 ],
 "Install": [
  null,
  "Installation"
 ],
 "Installation source": [
  null,
  "Installationsquelle"
 ],
 "Installation source must not be empty": [
  null,
  "Installationsquelle sollte nicht leer sein"
 ],
 "Installation type": [
  null,
  "Installationstyp"
 ],
 "Interface": [
  null,
  "Schnittstelle"
 ],
 "Interface type": [
  null,
  "Art der Schnittstelle"
 ],
 "Interface type help": [
  null,
  "Hilfe zum Schnittstellentyp"
 ],
 "Invalid IPv4 address": [
  null,
  "Ungültige IPv4-Adresse"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Ungültige IPv4-Maske oder Prefix-Länge"
 ],
 "Invalid IPv6 address": [
  null,
  "Ungültige IPv6-Adresse"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Ungültiger IPv6-Prefix"
 ],
 "Invalid filename": [
  null,
  "Ungültiger Dateiname"
 ],
 "Isolated network": [
  null,
  "Isoliertes Netzwerk"
 ],
 "LVM volume group": [
  null,
  "LVM Speichergruppe (VG)"
 ],
 "Launch remote viewer": [
  null,
  "Fernbetrachter starten"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Lassen Sie das Passwort leer, wenn Sie kein Root-Konto erstellen möchten"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Lassen Sie das Passwort leer, wenn Sie kein Benutzerkonto erstellen lassen möchten"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Lassen Sie das Passwort leer, wenn Sie kein Root-Passwort festlegen möchten"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt hat kein UEFI/OVMF Firmware-Abbild auf dem Host-System gefunden"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt oder der Hypervisor unterstützen UEFI nicht"
 ],
 "Loading available network devices": [
  null,
  "Verfügbare Netzwerkgeräte werden geladen"
 ],
 "Loading resources": [
  null,
  "Ressourcen werden geladen"
 ],
 "Loading...": [
  null,
  "Wird geladen ..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Lokales Installationsmedium (ISO-Abbild oder Distro-Installationsbaum)"
 ],
 "Location": [
  null,
  "Ort"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC-Adresse"
 ],
 "MAC address must not be empty": [
  null,
  "MAC-Adresse darf nicht leer sein"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "Vor dem Wechsel des Bustyps muss die Maschine ausgeschaltet werden"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  ""
 ],
 "Managing virtual machines": [
  null,
  "Virtuelle Maschinen verwalten"
 ],
 "Manual connection": [
  null,
  "Manuelle Verbindung"
 ],
 "Mask or prefix length": [
  null,
  "Masken- oder Präfixlänge"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Masken- oder Präfixlänge sollte nicht leer sein"
 ],
 "Maximum allocation": [
  null,
  "Maximale Zuweisung"
 ],
 "Maximum memory could not be saved": [
  null,
  "Maximaler Speicher konnte nicht gespeichert werden"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Maximale Anzahl der virtuellen CPUs, die dem Gast-BS zugewiesen werden"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Maximale Anzahl der für das Gastbetriebssystem zugewiesenen virtuellen CPUs, die zwischen 1 und 1 liegen muss $0"
 ],
 "Maximum transmission unit": [
  null,
  "Maximale Übertragungseinheit"
 ],
 "Memory": [
  null,
  "Speicher"
 ],
 "Memory could not be saved": [
  null,
  "Speicher konnte nicht gespeichert werden"
 ],
 "Memory must not be 0": [
  null,
  "Speicher darf nicht 0 sein"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "Migrieren"
 ],
 "Migrate VM to another host": [
  null,
  "VM auf einen anderen Host migrieren"
 ],
 "Migration failed": [
  null,
  "Migration fehlgeschlagen"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Model": [
  null,
  "Modell"
 ],
 "Model type": [
  null,
  "Modelltyp"
 ],
 "More info for mount tag field": [
  null,
  ""
 ],
 "More info for source path field": [
  null,
  "Mehr Informationen zum Feld Quellpfad"
 ],
 "Mount tag": [
  null,
  ""
 ],
 "Mount tag must not be empty": [
  null,
  ""
 ],
 "NAT to $0": [
  null,
  "NAT auf $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  ""
 ],
 "Name": [
  null,
  "Name"
 ],
 "Name already exists": [
  null,
  "Name existiert bereits"
 ],
 "Name contains invalid characters": [
  null,
  "Name enthält ungültige Zeichen"
 ],
 "Name must not be empty": [
  null,
  "Name darf nicht leer sein"
 ],
 "Name should not be empty": [
  null,
  "Name sollte nicht leer sein"
 ],
 "Name: ": [
  null,
  "Name: "
 ],
 "Netmask": [
  null,
  "Netzmaske"
 ],
 "Network $0 could not be deleted": [
  null,
  "Netzwerk $0 konnte nicht gelöscht werden"
 ],
 "Network $0 failed to get activated": [
  null,
  "Netzwerk $0 konnte nicht aktiviert werden"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Netzwerk $0 konnte nicht deaktiviert werden"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "Netzwerk $0 wird dauerhaft gelöscht."
 ],
 "Network boot (PXE)": [
  null,
  ""
 ],
 "Network file system": [
  null,
  "Netzwerk-Dateisystem"
 ],
 "Network interface $0 could not be removed": [
  null,
  "Netzwerkschnittstelle $0 konnte nicht entfernt werden"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "Netzwerkschnittstelle $0 wird aus $1 entfernt"
 ],
 "Network interface settings could not be saved": [
  null,
  "Netzwerkadaptereinstellungen konnten nicht gespeichert werden"
 ],
 "Network interfaces": [
  null,
  "Netzwerkschnittstellen"
 ],
 "Network selection does not support PXE.": [
  null,
  "Netzwerkauswahl unterstützt PXE nicht."
 ],
 "Networks": [
  null,
  "Netzwerke"
 ],
 "New name": [
  null,
  "Neuer Name"
 ],
 "New name must not be empty": [
  null,
  "Neuer Name darf nicht leer sein"
 ],
 "New volume name": [
  null,
  "Neuer Volume-Name"
 ],
 "No VM is running or defined on this host": [
  null,
  "Auf diesem Host ist weder eine VM definiert, noch wird eine VM ausgeführt"
 ],
 "No boot device found": [
  null,
  "Kein Startgerät gefunden"
 ],
 "No connection available": [
  null,
  "Keine Verbindung verfügbar"
 ],
 "No description": [
  null,
  "Keine Beschreibung"
 ],
 "No directories shared between the host and this VM": [
  null,
  "Keine gemeinsamen Verzeichnisse zwischen dem Host und dieser VM"
 ],
 "No disks defined for this VM": [
  null,
  "Keine Festplatten für diese VM definiert"
 ],
 "No host device selected": [
  null,
  "Kein Host-Gerät ausgewählt"
 ],
 "No host devices assigned to this VM": [
  null,
  "Dieser VM sind keine Host-Geräte zugewiesen"
 ],
 "No network devices": [
  null,
  "Keine Netzwerkgeräte"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Keine Netzwerkschnittstellen für diese VM definiert"
 ],
 "No network is defined on this host": [
  null,
  "Kein Netzwerk auf diesem Host definiert"
 ],
 "No networks available": [
  null,
  "Keine Netzwerke verfügbar"
 ],
 "No parent": [
  null,
  "Kein Elternteil"
 ],
 "No snapshots defined for this VM": [
  null,
  "Für diese VM sind keine Schnappschüsse definiert"
 ],
 "No state": [
  null,
  "Kein Status"
 ],
 "No storage": [
  null,
  "Kein Speicher"
 ],
 "No storage pool is defined on this host": [
  null,
  "Auf diesem Host ist kein Speicherpool definiert"
 ],
 "No storage pools available": [
  null,
  "Keine Speicherpools vorhanden"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Für dieses Speicherpool sind keine Speichervolumes definiert"
 ],
 "No virtual networks": [
  null,
  "Keine virtuellen Netzwerke"
 ],
 "No volumes exist in this storage pool.": [
  null,
  ""
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Ein nicht persistentes Netz kann nicht gelöscht werden. Es hört auf zu existieren, wenn es deaktiviert wird."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  ""
 ],
 "None": [
  null,
  "Kein"
 ],
 "None (isolated network)": [
  null,
  "Getrennt (Isoliertes Netzwerk)"
 ],
 "Offline token": [
  null,
  "Offline-Token"
 ],
 "Offline token must not be empty": [
  null,
  "Offline-Token darf nicht leer sein"
 ],
 "Old token expired": [
  null,
  "Altes Token ist abgelaufen"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  ""
 ],
 "Only editable when the guest is shut off": [
  null,
  "Kann nur bearbeitet werden wenn Gast ausgeschaltet ist"
 ],
 "Open": [
  null,
  "Öffnen"
 ],
 "Operating system": [
  null,
  "Betriebssystem"
 ],
 "Operation is in progress": [
  null,
  "Vorgang läuft"
 ],
 "Overview": [
  null,
  "Überblick"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Übergeordneter Schnappschuss"
 ],
 "Path": [
  null,
  "Pfad"
 ],
 "Path on host's filesystem": [
  null,
  "Pfad zum Dateisystem des Hosts"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Pfad zur ISO-Datei im Dateisystem des Hosts"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Pfad zur Cloud-Abbilddatei im Dateisystem des Hosts"
 ],
 "Path to file on host's file system": [
  null,
  "Pfad zur Datei im Dateisystem des Hosts"
 ],
 "Pause": [
  null,
  "Pause"
 ],
 "Paused": [
  null,
  "Pausiert"
 ],
 "Permanent (default)": [
  null,
  "Dauerhaft (Standard)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  ""
 ],
 "Persistence": [
  null,
  "Persistenz"
 ],
 "Persistent": [
  null,
  "Persistent"
 ],
 "Physical disk device": [
  null,
  "Physikalisches Festplattengerät"
 ],
 "Physical disk device on host": [
  null,
  "Physikalisches Festplattengerät auf dem Host"
 ],
 "Please choose a storage pool": [
  null,
  ""
 ],
 "Please choose a volume": [
  null,
  ""
 ],
 "Please enter new volume name": [
  null,
  "Bitte geben Sie den neuen Datenträgernamen ein"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "Starten Sie die virtuelle Maschine, um auf die Konsole zuzugreifen."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool needs to be active to create volume": [
  null,
  ""
 ],
 "Pool type $0 does not support volume creation": [
  null,
  ""
 ],
 "Pool type doesn't support volume creation": [
  null,
  ""
 ],
 "Pool's volumes are used by VMs ": [
  null,
  ""
 ],
 "Port": [
  null,
  "Port"
 ],
 "Power off": [
  null,
  ""
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Bevorzugte Anzahl von Sockets , die dem Gast zugänglich gemacht werden sollen."
 ],
 "Prefix": [
  null,
  "Präfix"
 ],
 "Prefix length": [
  null,
  "Präfixlänge"
 ],
 "Prefix length should not be empty": [
  null,
  "Präfixlänge sollte nicht leer sein"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Zuvor erstellte Schnappschüsse ermöglichen es Ihnen, zu einem früheren Zustand zurückzukehren, wenn etwas schief geht"
 ],
 "Private": [
  null,
  "Privat"
 ],
 "Product": [
  null,
  "Produkt"
 ],
 "Profile": [
  null,
  "Profil"
 ],
 "Protocol": [
  null,
  "Protokoll"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  ""
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Stellt eine Verbindung bereit, deren Details durch die benannte Netzwerkdefinition beschrieben werden."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Stellt ein virtuelles LAN mit NAT zur Außenwelt bereit."
 ],
 "Range": [
  null,
  "Bereich"
 ],
 "Read-only": [
  null,
  "Nur-lesen"
 ],
 "Reboot": [
  null,
  "Neustart"
 ],
 "Remote URL": [
  null,
  "Remote-URL"
 ],
 "Remote viewer details": [
  null,
  "Fernbetrachter-Details"
 ],
 "Remove": [
  null,
  "Entfernen"
 ],
 "Remove and delete file": [
  null,
  ""
 ],
 "Remove disk from VM?": [
  null,
  "Festplatte aus VM entfernen?"
 ],
 "Remove filesystem?": [
  null,
  "Dateisystem entfernen?"
 ],
 "Remove host device from VM?": [
  null,
  "Host-Gerät aus VM entfernen?"
 ],
 "Remove network interface?": [
  null,
  "Netzwerkschnittstelle entfernen?"
 ],
 "Remove static host from DHCP": [
  null,
  "Statischen Host aus DHCP entfernen"
 ],
 "Rename": [
  null,
  "Umbenennen"
 ],
 "Rename VM $0": [
  null,
  "VM $0 umbenennen"
 ],
 "Reset": [
  null,
  ""
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  ""
 ],
 "Resume": [
  null,
  "Fortfahren"
 ],
 "Revert": [
  null,
  "Zurückkehren"
 ],
 "Revert to snapshot $0": [
  null,
  "Zum Schnappschuss $0 zurückkehren"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Wenn Sie zu diesem Schnappschuss zurückkehren, wird die VM auf den Zeitpunkt des Schnappschusses zurückgesetzt und der aktuelle Zustand geht verloren, zusammen mit allen Daten, die nicht in einem Schnappschuss erfasst wurden"
 ],
 "Root password": [
  null,
  "Root-Passwort"
 ],
 "Route to $0": [
  null,
  "Route zu $0"
 ],
 "Routed network": [
  null,
  "Weitergeleitetes Netzwerk"
 ],
 "Run": [
  null,
  "Ausführen"
 ],
 "Run when host boots": [
  null,
  "Starten wenn Host hochfährt"
 ],
 "Running": [
  null,
  "Läuft"
 ],
 "SPICE TLS port": [
  null,
  "SPICE TLS-Port"
 ],
 "SPICE address": [
  null,
  "SPICE-Adresse"
 ],
 "SPICE port": [
  null,
  "SPICE-Port"
 ],
 "Save": [
  null,
  "Speichern"
 ],
 "Select console type": [
  null,
  "Konsolentyp auswählen"
 ],
 "Send key": [
  null,
  "Tastendruck senden"
 ],
 "Send non-maskable interrupt": [
  null,
  "Nicht maskierbare Unterbrechung senden"
 ],
 "Serial": [
  null,
  "Seriell"
 ],
 "Serial console": [
  null,
  "Serielle Konsole"
 ],
 "Serial console ($0)": [
  null,
  "Serielle Konsole ($0)"
 ],
 "Set DHCP range": [
  null,
  "DHCP-Bereich festlegen"
 ],
 "Set manually": [
  null,
  "Manuell einstellen"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Das Festlegen der Benutzerpasswörter für die unbeaufsichtigte Installation erfordert das Starten der VM beim Erstellen"
 ],
 "Share": [
  null,
  "Freigabe"
 ],
 "Share a host directory with the guest": [
  null,
  "Ein Host-Verzeichnis mit dem Gast teilen"
 ],
 "Shared directories": [
  null,
  "Gemeinsame Verzeichnisse"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Gemeinsam genutzte Host-Verzeichnisse müssen innerhalb der VM manuell eingehängt werden"
 ],
 "Shared storage": [
  null,
  "Gemeinsamer Speicher"
 ],
 "Show additional options": [
  null,
  "Zusätzlicher Optionen anzeigen"
 ],
 "Shut down": [
  null,
  "Herunterfahren"
 ],
 "Shut off": [
  null,
  "Ausgeschaltet"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Fahren Sie die VM herunter, um die Firmware-Konfiguration zu bearbeiten"
 ],
 "Shutting down": [
  null,
  "Wird heruntergefahren"
 ],
 "Size": [
  null,
  "Größe"
 ],
 "Slot": [
  null,
  ""
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "Schnappschuss $0 konnte nicht gelöscht werden"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "Schnappschuss $0 wird aus $1 gelöscht. Der gesamte erfasste Inhalt geht dabei verloren."
 ],
 "Snapshot failed to be created": [
  null,
  "Schnappschuss konnte nicht erstellt werden"
 ],
 "Snapshots": [
  null,
  "Schnappschüsse"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  ""
 ],
 "Source": [
  null,
  "Quelle"
 ],
 "Source format": [
  null,
  "Quellenformat"
 ],
 "Source must not be empty": [
  null,
  "Quelle darf nicht leer sein"
 ],
 "Source path": [
  null,
  "Quellpfad"
 ],
 "Source path should not be empty": [
  null,
  "Quellpfad sollte nicht leer sein"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "Die Quelle sollte mit dem http,ftp oder nfs Protokoll starten"
 ],
 "Source volume group": [
  null,
  ""
 ],
 "Start": [
  null,
  "Starten"
 ],
 "Start pool when host boots": [
  null,
  "Starten Sie den Pool, wenn der Host bootet"
 ],
 "Start should not be empty": [
  null,
  "Start sollte nicht leer sein"
 ],
 "Startup": [
  null,
  "Anlaufen"
 ],
 "State": [
  null,
  "Status"
 ],
 "Static host entries": [
  null,
  "Statische Host-Einträge"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "Statischer Host aus DHCP konnte nicht entfernt werden"
 ],
 "Storage": [
  null,
  "Speicher"
 ],
 "Storage is at a shared location": [
  null,
  "Speicher ist an einem gemeinsamen Ort"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  ""
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  ""
 ],
 "Storage pool failed to be created": [
  null,
  "Speicherpool konnte nicht erstellt werden"
 ],
 "Storage pool name": [
  null,
  "Speicherpoolname"
 ],
 "Storage pools": [
  null,
  "Speicherpools"
 ],
 "Storage pools could not be fetched": [
  null,
  ""
 ],
 "Storage size must not be 0": [
  null,
  "Speichergröße darf nicht 0 sein"
 ],
 "Storage volume": [
  null,
  "Speichervolumen"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  ""
 ],
 "Storage volumes": [
  null,
  "Speichervolumen"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Speichervolumen konnte nicht gelöscht werden"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Speichervolumes müssen von diesem Host und dem Zielhost gemeinsam genutzt werden."
 ],
 "Suspended (PM)": [
  null,
  "Angehalten (PM)"
 ],
 "System": [
  null,
  "System"
 ],
 "Table of selectable host devices": [
  null,
  "Tabelle der auswählbaren Host-Geräte"
 ],
 "Target": [
  null,
  "Ziel"
 ],
 "Target path": [
  null,
  "Zielpfad"
 ],
 "Target path should not be empty": [
  null,
  "Zielpfad sollte nicht leer sein"
 ],
 "Temporary": [
  null,
  "Temporär"
 ],
 "Temporary migration": [
  null,
  "Temporäre Migration"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "Die VM $0 ist in Betrieb und wird vor dem Löschen zwangsweise abgeschaltet."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "Um das Gerät zu entfernen muss die VM laufen oder ausgeschaltet sein"
 ],
 "The directory on the server being exported": [
  null,
  "Das Verzeichnis auf dem Server, der exportiert wird"
 ],
 "The host path that is to be exported.": [
  null,
  "Der zu exportierende Host-Pfad."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "Die migrierte VM-Konfiguration wird vom Quellhost entfernt. Der Zielhost wird als neues Zuhause der VM betrachtet."
 ],
 "The pool is empty": [
  null,
  "Der Pool ist leer"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Das ausgewählte Betriebssystem hat einen Mindestspeicherbedarf von $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Das ausgewählte Betriebssystem erfordert eine Mindestspeichergröße von $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "Der statische Host-Eintrag für $0 wird entfernt:"
 ],
 "The storage pool could not be deleted": [
  null,
  "Der Speicher-Pool konnte nicht entfernt werden"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  ""
 ],
 "Then copy and paste it above.": [
  null,
  "Kopieren Sie es dann und fügen Sie es oben ein."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Diese VM ist vorübergehend. Schalten Sie sie ab, wenn Sie sie löschen möchten."
 ],
 "This disk will be removed from $0:": [
  null,
  "Diese Festplatte wird aus $0 entfernt:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Dieses Dateisystem wird aus $0 entfernt:"
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Dies ist die empfohlene Konfiguration für allgemeine Gastkonnektivität auf Hosts mit dynamischen / drahtlosen Netzwerkkonfigurationen."
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Dies ist die empfohlene Konfiguration für die allgemeine Gastkonnektivität auf Hosts mit statischen kabelgebundenen Netzwerkkonfigurationen."
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  "Dies ist die empfohlene Konfiguration für hohe Leistung oder erweiterte Sicherheit."
 ],
 "This volume is already used by $0.": [
  null,
  "Dieses Volumen wird bereits von $0 verwendet."
 ],
 "This volume is already used by another VM.": [
  null,
  "Dieses Volumen wird bereits von einer anderen VM verwendet."
 ],
 "Threads per core": [
  null,
  "Fäden pro Kern"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Vorübergehende VMs unterstützen die Bearbeitung der Firmware-Konfiguration nicht"
 ],
 "Troubleshoot": [
  null,
  "Fehlersuche"
 ],
 "Type": [
  null,
  "Typ"
 ],
 "Type ID": [
  null,
  "Typ ID"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (ISO-Abbild oder Distro-Installationsbaum)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Undefiniert"
 ],
 "Unique name": [
  null,
  "Einzigartiger Name"
 ],
 "Unique name, default: $0": [
  null,
  "Eindeutiger Name, Standard: $0"
 ],
 "Unique network name": [
  null,
  "Eindeutiger Netzwerkname"
 ],
 "Unit": [
  null,
  "Einheit"
 ],
 "Unknown": [
  null,
  "Unbekannt"
 ],
 "Unknown firmware": [
  null,
  "Unbekannte Firmware"
 ],
 "Unspecified": [
  null,
  "Nicht spezifiziert"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "Auslastung"
 ],
 "Use existing": [
  null,
  "Benutze existierendes"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Erweiterte Attribute für Dateien und Verzeichnisse verwenden"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Verwenden Sie auf dem Ausgangs- und dem Zielhost denselben Ort für Ihren Speicher. Dies kann ein gemeinsamer Speicherpool, NFS oder eine andere Methode zur gemeinsamen Nutzung von Speicher sein."
 ],
 "Used": [
  null,
  "Benutzt"
 ],
 "Used by": [
  null,
  "Benutzt von"
 ],
 "User login": [
  null,
  "Benutzeranmeldung"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Benutzeranmeldung darf nicht leer sein, wenn das Benutzerpasswort festgelegt ist"
 ],
 "User password": [
  null,
  "Benutzerpasswort"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Benutzerpasswort darf nicht leer sein, wenn die Benutzeranmeldung festgelegt ist"
 ],
 "User session": [
  null,
  "Benutzersitzung"
 ],
 "VCPU settings could not be saved": [
  null,
  "VCPU-Einstellungen konnten nicht gespeichert werden"
 ],
 "VM $0 Host Devices": [
  null,
  "VM $0 Host-Geräte"
 ],
 "VM $0 already exists": [
  null,
  "VM $0 existiert bereits"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "VM $0 existiert nicht auf Verbindung $1"
 ],
 "VM $0 failed to force reboot": [
  null,
  "VM $0 konnte nicht zum Neustart gezwungen werden"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "VM $0 konnte nicht zum Herunterfahren gezwungen werden"
 ],
 "VM $0 failed to get installed": [
  null,
  "VM$0 konnte nicht installiert werden"
 ],
 "VM $0 failed to pause": [
  null,
  "VM $0 konnte nicht pausiert werden"
 ],
 "VM $0 failed to reboot": [
  null,
  "VM $0 konnte nicht neugestartet werden"
 ],
 "VM $0 failed to resume": [
  null,
  "VM $0 konnte nicht fortgesetzt werden"
 ],
 "VM $0 failed to send NMI": [
  null,
  "NMI konnte nicht an VM $0 gesendet werden"
 ],
 "VM $0 failed to shutdown": [
  null,
  "VM $0 konnte nicht heruntergefahren werden"
 ],
 "VM $0 failed to start": [
  null,
  "VM $0 konnte nicht gestartet werden"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  ""
 ],
 "VM state": [
  null,
  "VM-Status"
 ],
 "VM will launch with root permissions": [
  null,
  ""
 ],
 "VNC TLS port": [
  null,
  "VNC-TLS-Port"
 ],
 "VNC address": [
  null,
  "VNC-Adresse"
 ],
 "VNC console": [
  null,
  "VNC-Konsole"
 ],
 "VNC port": [
  null,
  "VNC-Port"
 ],
 "Valid token": [
  null,
  "Gültiges Token"
 ],
 "Vendor": [
  null,
  "Anbieter"
 ],
 "Virtual machines": [
  null,
  "Virtuelle Maschinen"
 ],
 "Virtual machines management": [
  null,
  "Verwaltung Virtueller Maschinen"
 ],
 "Virtual network": [
  null,
  "Virtuelles Netzwerk"
 ],
 "Virtual network failed to be created": [
  null,
  "Virtuelles Netzwerk konnte nicht erstellt werden"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Der Virtualisierungsdienst (libvirt) ist nicht aktiv"
 ],
 "Volume": [
  null,
  "Lautstärke"
 ],
 "Volume failed to be created": [
  null,
  "Volumen konnte nicht erstellt werden"
 ],
 "Volume group name": [
  null,
  ""
 ],
 "Volume group name should not be empty": [
  null,
  ""
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  ""
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  ""
 ],
 "Writeable": [
  null,
  "Beschreibbar"
 ],
 "Writeable and shared": [
  null,
  "Beschreibbar und geteilt"
 ],
 "You can mount the shared folder using:": [
  null,
  ""
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Bitte wählen sie das passende Betriebssystem aus"
 ],
 "active": [
  null,
  "Aktiv"
 ],
 "add entry": [
  null,
  "Eintrag hinzufügen"
 ],
 "bridge": [
  null,
  "Brücke"
 ],
 "cdrom": [
  null,
  "CD-ROM"
 ],
 "custom": [
  null,
  "Benutzerdefiniert"
 ],
 "direct": [
  null,
  "Direkte"
 ],
 "disabled": [
  null,
  "Aus"
 ],
 "disk": [
  null,
  "Datenträger"
 ],
 "down": [
  null,
  "runter"
 ],
 "edit": [
  null,
  "bearbeiten"
 ],
 "enabled": [
  null,
  "An"
 ],
 "ethernet": [
  null,
  "Ethernet"
 ],
 "host": [
  null,
  "host"
 ],
 "host device": [
  null,
  "Host-Gerät"
 ],
 "host passthrough": [
  null,
  "Host-Durchleitung"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  ""
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI initiator IQN"
 ],
 "iSCSI target": [
  null,
  "iSCSI targets"
 ],
 "iSCSI target IQN": [
  null,
  ""
 ],
 "inactive": [
  null,
  "Inaktiv"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  ""
 ],
 "mount point: The mount point inside the guest": [
  null,
  "Einhängepunkt: Der Einhängepunkt innerhalb des Gastes"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  ""
 ],
 "network": [
  null,
  "Netzwerk"
 ],
 "no": [
  null,
  "Nein"
 ],
 "no state saved": [
  null,
  "kein Zustand gespeichert"
 ],
 "none": [
  null,
  "keine"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "weitergeleitete Geräte"
 ],
 "remove": [
  null,
  "entfernen"
 ],
 "serial number": [
  null,
  "Seriennummer"
 ],
 "server": [
  null,
  "server"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "hoch"
 ],
 "user": [
  null,
  "Benutzer"
 ],
 "vCPU count": [
  null,
  "Anzahl vCPUs"
 ],
 "vCPU maximum": [
  null,
  "vCPU maximum"
 ],
 "vCPUs": [
  null,
  "vCPUs"
 ],
 "vhostuser": [
  null,
  "vhostbenutzer"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Das \"virt-install\" Paket muss auf dem System installiert werden, um neue VMs zu erstellen"
 ],
 "vm": [
  null,
  "VM"
 ],
 "yes": [
  null,
  "Ja"
 ]
});
