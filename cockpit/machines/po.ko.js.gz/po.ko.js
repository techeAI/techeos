cockpit.locale({
 "": {
  "plural-forms": (n) => 0,
  "language": "ko",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "기본 위치에서 사용 가능한 $0 $1"
 ],
 "$0 $1 available on host": [
  null,
  "호스트에서 사용 가능한 $0 $1"
 ],
 "$0 CPU configuration": [
  null,
  "$0 CPU 구성"
 ],
 "$0 Network": [
  null,
  "$0 네트워크"
 ],
 "$0 Storage pool": [
  null,
  "$0 저장소 풀"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0는 무인 설치를 지원하지 않습니다."
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 대부분의 운영 체제에서 사용 할 수 있습니다. 설치하려면 그놈 소프트웨어에서 검색하거나 다음을 실행하십시오:"
 ],
 "$0 memory adjustment": [
  null,
  "$0 메모리 조정"
 ],
 "$0 network": [
  null,
  "$0 네트워크"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPUs"
 ],
 "$0 vCPU details": [
  null,
  "$0 vCPU 세부 정보"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 가상 네트워크 연결장치 설정"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "VM의 복사는 대상에서 실행해야 하고 이를 종료 할 때에 사라집니다. 그 동안에, 원래 호스트는 VM 구성의 복사를 유지합니다."
 ],
 "Access": [
  null,
  "접근"
 ],
 "Action": [
  null,
  "동작"
 ],
 "Activate": [
  null,
  "활성화"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "볼륨을 관리하려면 저장소 풀을 활성화하세요"
 ],
 "Add": [
  null,
  "추가"
 ],
 "Add a DHCP static host entry": [
  null,
  "DHCP 고정 호스트 항목 추가"
 ],
 "Add disk": [
  null,
  "디스크 추가"
 ],
 "Add host device": [
  null,
  "호스트 장치 추가"
 ],
 "Add network interface": [
  null,
  "네트워크 연결장치 추가"
 ],
 "Add shared directory": [
  null,
  "공유 디렉토리를 추가합니다"
 ],
 "Add virtual network interface": [
  null,
  "가상 네트워크 연결장치 추가"
 ],
 "Add watchdog device type": [
  null,
  "와치독 장치 유형 추가"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "공유 디렉토리 추가는 게스트가 종료된 경우에만 편집 할 수 있습니다"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  "이와 같은 디스크 추가하기는 접근 방법을 공유하기로 변경합니다."
 ],
 "Additional": [
  null,
  "추가"
 ],
 "Address": [
  null,
  "주소"
 ],
 "Address not within subnet": [
  null,
  "서브넷 내에 없는 주소"
 ],
 "All": [
  null,
  "모두"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "저장소를 포함하는 모든 가상화 동작은 임시적입니다. 이는 대상 호스트에서 자료 손실로 귀결됩니다."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "허용되는 문자: 기본 라틴 알파벳, 숫자와 제한된 구두점 (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "또한 이 풀 안에 있는 모든 볼륨을 삭제합니다:"
 ],
 "Always attach": [
  null,
  "항상 연결"
 ],
 "Apply": [
  null,
  "적용"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "자동 설치는 이미지를 내려 받거나 클라우드-설치를 사용 할 때에만 사용 할 수 있습니다."
 ],
 "Automatic": [
  null,
  "자동"
 ],
 "Automation": [
  null,
  "자동화"
 ],
 "Autostart": [
  null,
  "자동 시작"
 ],
 "Blocked": [
  null,
  "차단됩니다"
 ],
 "Boot order": [
  null,
  "부팅 순서"
 ],
 "Boot order settings could not be saved": [
  null,
  "부팅 순서 설정을 저장 할 수 없습니다"
 ],
 "Bus": [
  null,
  "버스"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD 디스크"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU configuration could not be saved": [
  null,
  "CPU 구성을 저장 할 수 없습니다"
 ],
 "CPU type": [
  null,
  "CPU 유형"
 ],
 "Cache": [
  null,
  "캐쉬"
 ],
 "Cancel": [
  null,
  "취소"
 ],
 "Capacity": [
  null,
  "용량"
 ],
 "Change boot order": [
  null,
  "부팅 순서 변경"
 ],
 "Change firmware": [
  null,
  "펌웨어 변경"
 ],
 "Changes pending": [
  null,
  "보류 중인 변경 부분"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "변경은 VM 종료 후에 적용됩니다"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "BIOS/EFI 설정 변경하기는 개별 제조사 별로 지정되어 있습니다. 이는 부팅 중에(ESC, F1, F2, F12, Del)와 같은 바로 가기 키를 포함합니다. \"가상화\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\"라고 불리는 설정을 활성화합니다. 보다 자세히 알기 위해 자신의 컴퓨터 사용 설명서를 참고하세요."
 ],
 "Checking token validity...": [
  null,
  "토큰 유효성 확인 중..."
 ],
 "Choose an operating system": [
  null,
  "운영 체제를 선택하십시오"
 ],
 "Class": [
  null,
  "등급"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "\"원격 뷰어 시작\"을 누르면 .vv 파일을 내려받기 하고 $0를 시작합니다."
 ],
 "Clone": [
  null,
  "복제"
 ],
 "Close": [
  null,
  "닫기"
 ],
 "Cloud base image": [
  null,
  "클라우드 기반 이미지"
 ],
 "Confirm this action": [
  null,
  "작업 확인"
 ],
 "Connect": [
  null,
  "연결"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "다음 통신규약에 뷰어 응용프로그램에 연결합니다"
 ],
 "Connecting": [
  null,
  "연결 중"
 ],
 "Connection": [
  null,
  "연결"
 ],
 "Console": [
  null,
  "콘솔"
 ],
 "Copy storage": [
  null,
  "저장소 복사"
 ],
 "Cores per socket": [
  null,
  "소켓당 코어 수"
 ],
 "Could not delete $0": [
  null,
  "$0를 삭제 할 수 없습니다"
 ],
 "Could not delete all storage for $0": [
  null,
  "$0를 위해 모든 저장소를 삭제 할 수 없습니다"
 ],
 "Could not delete disk's storage": [
  null,
  "디스크 저장소를 삭제 할 수 없습니다"
 ],
 "Could not revert to snapshot": [
  null,
  "스냅샷으로 전환 할 수 없습니다"
 ],
 "Crashed": [
  null,
  "충돌"
 ],
 "Create": [
  null,
  "생성"
 ],
 "Create VM": [
  null,
  "가상 머신 만들기"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "기존 VM 설치의 가져온 디스크 이미지에 의해 VM을 생성합니다"
 ],
 "Create VM from local or network installation medium": [
  null,
  "로컬 또는 네트워크 설치 환경에서 VM을 생성합니다"
 ],
 "Create a clone VM based on $0": [
  null,
  "$0을 기반으로 복제 VM 만들기"
 ],
 "Create and edit": [
  null,
  "생성과 편집"
 ],
 "Create and run": [
  null,
  "생성과 동작"
 ],
 "Create new": [
  null,
  "새로 만들기"
 ],
 "Create new virtual machine": [
  null,
  "새로운 가상 머신 만들기"
 ],
 "Create new volume": [
  null,
  "새로운 볼륨 만들기"
 ],
 "Create snapshot": [
  null,
  "스냅샷 만들기"
 ],
 "Create storage pool": [
  null,
  "저장소 풀 만들기"
 ],
 "Create storage volume": [
  null,
  "저장소 볼륨 만들기"
 ],
 "Create virtual network": [
  null,
  "가상 네트워크 만들기"
 ],
 "Create volume": [
  null,
  "볼륨 만들기"
 ],
 "Creating VM": [
  null,
  "VM 생성 중"
 ],
 "Creating VM $0": [
  null,
  "VM $0 생성 중"
 ],
 "Creation of VM $0 failed": [
  null,
  "VM $0 생성이 실패했습니다"
 ],
 "Creation time": [
  null,
  "생성 시간"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "현재"
 ],
 "Current allocation": [
  null,
  "현재 할당"
 ],
 "Custom firmware: $0": [
  null,
  "사용자 지정 펌웨어: $0"
 ],
 "Custom path": [
  null,
  "사용자 지정 경로"
 ],
 "DHCP Settings": [
  null,
  "DHCP 설정"
 ],
 "Deactivate": [
  null,
  "비활성화"
 ],
 "Delete": [
  null,
  "삭제"
 ],
 "Delete $0 VM?": [
  null,
  "$0 VM 삭제?"
 ],
 "Delete $0 storage pool?": [
  null,
  "$0 저장소 풀 삭제?"
 ],
 "Delete $0 volume": [
  null,
  "$0 볼륨 삭제"
 ],
 "Delete associated storage files:": [
  null,
  "관련된 저장소 파일 삭제:"
 ],
 "Delete network?": [
  null,
  "네트워크 삭제?"
 ],
 "Delete snapshot?": [
  null,
  "스냅샷 삭제?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "비활성화된 저장소 풀 삭제는 풀만 정의 해제하면 됩니다. 내용는 삭제되지 않습니다."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "공유된 디렉토리 삭제하기는 게스트가 종료된 경우에만 할 수 있습니다"
 ],
 "Description": [
  null,
  "설명"
 ],
 "Desktop viewer": [
  null,
  "데스크탑 뷰어"
 ],
 "Destination URI": [
  null,
  "대상 URI"
 ],
 "Destination URI must not be empty": [
  null,
  "대상 URI는 비워 두면 안됩니다"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "삭제를 시도하기 전에 VM에서 이 풀을 사용하는 디스크를 분리하십시오."
 ],
 "Details": [
  null,
  "상세정보"
 ],
 "Device": [
  null,
  "장치"
 ],
 "Devices": [
  null,
  "장치"
 ],
 "Disconnect": [
  null,
  "연결 끊김"
 ],
 "Disconnected": [
  null,
  "연결 끊김"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "시리얼 콘솔에서 연결이 끊어졌습니다. 연결 버튼을 눌러주세요."
 ],
 "Disk": [
  null,
  "디스크"
 ],
 "Disk $0 could not be removed": [
  null,
  "디스크 $0는 제거 될 수 없습니다"
 ],
 "Disk failed to be attached": [
  null,
  "디스크를 연결하지 못했습니다"
 ],
 "Disk failed to be created": [
  null,
  "디스크를 생성하지 못했습니다"
 ],
 "Disk identifier": [
  null,
  "디스크 식별자"
 ],
 "Disk image": [
  null,
  "디스크 이미지"
 ],
 "Disk image file": [
  null,
  "디스크 이미지 파일"
 ],
 "Disk image path must not be empty": [
  null,
  "디스크 이름 경로는 비워두면 안됩니다"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "디스크 이미지는 사용자 홈 디렉토리에 저장 될 수 있습니다"
 ],
 "Disk settings could not be saved": [
  null,
  "디스크 설정을 저장 할 수 없습니다"
 ],
 "Disk-only snapshot": [
  null,
  "디스크-전용 스냅샷"
 ],
 "Disks": [
  null,
  "디스크"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "동시에 출발지와 대상 호스트에서 이 VM을 동작하지 마세요."
 ],
 "Do nothing": [
  null,
  "아무 것도 하지 않기"
 ],
 "Domain has crashed": [
  null,
  "도메인이 충돌했습니다"
 ],
 "Domain is blocked on resource": [
  null,
  "도메인은 리소스에서 차단되었습니다"
 ],
 "Download an OS": [
  null,
  "OS 내려받기"
 ],
 "Download progress": [
  null,
  "내려받기 진행"
 ],
 "Downloading image for VM $0": [
  null,
  "VM $0를 위해 이미지 내려받기 중"
 ],
 "Downloading: $0%": [
  null,
  "내려받기 중: $0%"
 ],
 "Dump core": [
  null,
  "덤프 코어"
 ],
 "Duration": [
  null,
  "지속기간"
 ],
 "Dying": [
  null,
  "종료 중"
 ],
 "Edit": [
  null,
  "편집"
 ],
 "Edit $0 attributes": [
  null,
  "$0 속성 편집"
 ],
 "Edit watchdog device type": [
  null,
  "와치독 장치 유형을 편집합니다"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "임시 게스트의 네트워크 연결장치 편집하기는 허용되지 않습니다"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "임시 네트워크 연결장치 편집하기는 허용되지 않습니다"
 ],
 "Eject": [
  null,
  "꺼내기"
 ],
 "Eject disc from VM?": [
  null,
  "VM에서 디스크 꺼내기?"
 ],
 "Emulated machine": [
  null,
  "에뮬레이트된 기기"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "BIOS/EFI 설정에서 가상화 지원을 활성화합니다."
 ],
 "End": [
  null,
  "종료"
 ],
 "End should not be empty": [
  null,
  "끝은 비워둘 수 없습니다"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "무인 설치를 활성화 하기 위해 root 와 / 또는 사용자 정보를 입력하세요."
 ],
 "Error checking token": [
  null,
  "토큰 확인 중 오류"
 ],
 "Example, $0": [
  null,
  "예제, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "호스트의 파일 시스템에서 기존 디스크 이미지"
 ],
 "Expand": [
  null,
  "확장"
 ],
 "Extended attributes": [
  null,
  "확장된 속성"
 ],
 "Failed": [
  null,
  "실패함"
 ],
 "Failed to add shared directory": [
  null,
  "공유 디렉토리에 추가하기 실패함"
 ],
 "Failed to change firmware": [
  null,
  "펌웨어 변경에 실패하였습니다"
 ],
 "Failed to clone VM $0": [
  null,
  "VM $0 복제에 실패하였습니다"
 ],
 "Failed to configure watchdog": [
  null,
  "와치독을 구성하는데 실패함"
 ],
 "Failed to detach watchdog": [
  null,
  "와치독을 분리하는데 실패함"
 ],
 "Failed to fetch some resources": [
  null,
  "몇 가지 자원 가져오기에 실패함"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "$0에 표시된 연결장치의 IP 주소를 가져오지 못했습니다"
 ],
 "Failed to rename VM $0": [
  null,
  "VM $0 이름변경에 실패함"
 ],
 "Failed to save network settings": [
  null,
  "네트워크 설정을 저장하는데 실패함"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "키 Ctrl+Alt+$0를 VM $1으로 보내지 못했습니다"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "최대 가상 CPU 수 보다 적은 수를 활성화해야 합니다."
 ],
 "File": [
  null,
  "파일"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "파일시스템 $0는 제거 될 수 없습니다"
 ],
 "Filesystem directory": [
  null,
  "파일 시스템 디렉토리"
 ],
 "Filter by name": [
  null,
  "이름으로 필터링"
 ],
 "Firmware": [
  null,
  "펌웨어"
 ],
 "Force eject": [
  null,
  "강제로 꺼내기"
 ],
 "Force reboot": [
  null,
  "강제 재시작"
 ],
 "Force revert": [
  null,
  "강제로 되돌리기"
 ],
 "Force shut down": [
  null,
  "강제 종료"
 ],
 "Format": [
  null,
  "포멧"
 ],
 "Forward mode": [
  null,
  "포워드 모드"
 ],
 "Forwarding mode": [
  null,
  "포워딩 방법"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "전체 디스크 이미지와 도메인의 메모리는 이전 될 것입니다. 공유되지 않고, 쓰기 가능한 디스크 이미지만 전송 될 것입니다. 사용하지 않은 저장소는 이전 후에도 원본에 남아 있습니다."
 ],
 "General": [
  null,
  "일반"
 ],
 "Generate automatically": [
  null,
  "자동 생성"
 ],
 "Get a new RHSM token.": [
  null,
  "신규 RHSM 토큰 가져오기."
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "VM 목록으로 이동"
 ],
 "Good choice for desktop virtualization": [
  null,
  "데스크탑 가상화를 위한 훌륭한 선택"
 ],
 "Gracefully shutdown": [
  null,
  "우아한 종료"
 ],
 "Hardware virtualization is disabled": [
  null,
  "하드웨어 가상화가 비활성화 되었습니다"
 ],
 "Hide additional options": [
  null,
  "추가 선택 숨기기"
 ],
 "Host": [
  null,
  "호스트"
 ],
 "Host device": [
  null,
  "호스트 장치"
 ],
 "Host device could not be attached": [
  null,
  "호스트 장치는 추가 할 수 없습니다"
 ],
 "Host device will be removed from $0:": [
  null,
  "호스트 장치는 $0에서 제거됩니다:"
 ],
 "Host devices": [
  null,
  "호스트 장치"
 ],
 "Host name": [
  null,
  "호스트 이름"
 ],
 "Host should not be empty": [
  null,
  "호스트는 비워둘 수 없습니다"
 ],
 "Hypervisor details": [
  null,
  "하이퍼바이저 세부 사항"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "네트워크 주소"
 ],
 "IP address must not be empty": [
  null,
  "IP 주소는 비워두면 안됩니다"
 ],
 "IP configuration": [
  null,
  "IP 구성"
 ],
 "IPv4 address": [
  null,
  "IPv4 주소"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  "IPV4 주소는 네트워크 식별자로 동일 할 수 없습니다"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "IPv4 주소는 네트워크의 광역 주소로 동일 할 수 없습니다"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 및 IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4 네트워크는 비워둘 수 없습니다"
 ],
 "IPv4 only": [
  null,
  "IPv4만"
 ],
 "IPv6 address": [
  null,
  "IPv6 주소"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6 네트워크는 비워둘 수 없습니다"
 ],
 "IPv6 only": [
  null,
  "IPv6만"
 ],
 "Ideal for server VMs": [
  null,
  "서버 가상장비에 적합"
 ],
 "Ideal networking support": [
  null,
  "이상적인 네트워크 지원"
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "식별자는 $0 문자로 자동으로 잘릴 수 있습니다 "
 ],
 "Idle": [
  null,
  "유휴"
 ],
 "Ignore": [
  null,
  "무시"
 ],
 "Import VM": [
  null,
  "VM 가져 오기"
 ],
 "Import a virtual machine": [
  null,
  "가상 머신 가져 오기"
 ],
 "Import and edit": [
  null,
  "가져오기와 편집"
 ],
 "Import and run": [
  null,
  "가져 오기와 실행"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "백업된 파일 이미지 가져오기는 지원되지 않습니다"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "대부분의 설정에서 macvtap는 호스트와 게스트 간 네트워크 통신에서 작동하지 않습니다."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  "기본설정 'vepa' 방식에서, 스위칭은 외부 스위치로 처리됩니다. 만약 스위치가 VEPA-가용하지 않으면, 게스트 가상 장비 간 또는 게스트와 호스트 사이의 통신이 불가능합니다."
 ],
 "Initiator": [
  null,
  "초기자"
 ],
 "Initiator IQN should not be empty": [
  null,
  "초기자 IQN은 비워둘 수 없습니다"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "마스크 불가능 인터럽트 주입"
 ],
 "Insert": [
  null,
  "Insert"
 ],
 "Insert disc media": [
  null,
  "디스크 미디어 넣기"
 ],
 "Install": [
  null,
  "설치"
 ],
 "Installation source": [
  null,
  "설치 원천"
 ],
 "Installation source must not be empty": [
  null,
  "설치 원천는 비워둘 수 없습니다"
 ],
 "Installation type": [
  null,
  "설치 유형"
 ],
 "Interface": [
  null,
  "연결장치"
 ],
 "Interface type": [
  null,
  "연결장치 유형"
 ],
 "Interface type help": [
  null,
  "연결장치 유형 도움"
 ],
 "Invalid IPv4 address": [
  null,
  "잘못된 IPv4 주소"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "잘못된 IPv4 매스크 또는 프리픽스 길이"
 ],
 "Invalid IPv6 address": [
  null,
  "잘못된 IPv6 주소"
 ],
 "Invalid IPv6 prefix": [
  null,
  "잘못된 IPv6 프리픽스"
 ],
 "Invalid filename": [
  null,
  "잘못된 파일 이름"
 ],
 "Isolated network": [
  null,
  "격리된 네트워크"
 ],
 "LVM volume group": [
  null,
  "LVM 볼륨 그룹"
 ],
 "Launch remote viewer": [
  null,
  "원격 뷰어 시작"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "root 계정을 만들지 않으려면 암호를 비워 두십시오"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "사용자 계정을 만들지 않으려면 암호를 비워 두십시오"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "root 비밀번호를 설정하기를 원하지 않으면 비밀번호를 비워 두십시오"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt가 호스트에 설치된 UEFI/OVMF 펌웨어 이미지를 감지하지 못했습니다"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt 또는 하이퍼바이저는 UEFI를 지원하지 않습니다"
 ],
 "Loading available network devices": [
  null,
  "사용 할 수 있는 네트워크 장치 적재 중"
 ],
 "Loading resources": [
  null,
  "자원 적재 중"
 ],
 "Loading...": [
  null,
  "적재 중..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "로컬 설치 미디어 (ISO 이미지 또는 저장소 설치 트리)"
 ],
 "Location": [
  null,
  "위치"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC 주소"
 ],
 "MAC address must not be empty": [
  null,
  "맥 주소는 비워두면 안됩니다"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "버스 유형을 변경하기 전에 장치를 종료해야 합니다"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "캐쉬 방법을 변경하기 전에 장치를 종료해야 합니다"
 ],
 "Managing virtual machines": [
  null,
  "가상 머신 관리"
 ],
 "Manual connection": [
  null,
  "수동 연결"
 ],
 "Mask or prefix length": [
  null,
  "매스크 또는프리픽스 길이"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "매스크 또는 프리픽스 길이는 비워둘 수 없습니다"
 ],
 "Maximum allocation": [
  null,
  "최대 할당"
 ],
 "Maximum memory could not be saved": [
  null,
  "최대 메모리는 저장 할 수 없습니다"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "게스트 OS에 할당된 가상 CPU의 최대 개수"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "게스트 OS에 할당된 가상 CPU의 최대 개수는 1에서 $0 사이여야 합니다"
 ],
 "Maximum transmission unit": [
  null,
  "MTU(Maximum Transmission Unit)"
 ],
 "Media could not be ejected from $0": [
  null,
  "미디어는 $0에서 꺼낼 수 없습니다"
 ],
 "Media will be ejected from $0:": [
  null,
  "미디어는 $0에서 꺼냅니다:"
 ],
 "Memory": [
  null,
  "메모리"
 ],
 "Memory could not be saved": [
  null,
  "메모리는 저장 할 수 없습니다"
 ],
 "Memory must not be 0": [
  null,
  "메모리는 0이 아니어야 합니다"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "이전"
 ],
 "Migrate VM to another host": [
  null,
  "VM을 다른 호스트로 이전합니다"
 ],
 "Migration failed": [
  null,
  "이전이 실패했습니다"
 ],
 "Mode": [
  null,
  "모드"
 ],
 "Model": [
  null,
  "방식"
 ],
 "Model type": [
  null,
  "모델 유형"
 ],
 "More info for mount tag field": [
  null,
  "적재 태그 입력부분을 위한 더 많은 정보"
 ],
 "More info for source path field": [
  null,
  "원천 경로 입력 부분을 위한 더 많은 정보"
 ],
 "Mount tag": [
  null,
  "적재 태그"
 ],
 "Mount tag must not be empty": [
  null,
  "적재 태그는 비워두면 안됩니다"
 ],
 "NAT to $0": [
  null,
  "$0에 NAT"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "VM $1의 NIC $0은 상태 변경에 실패했습니다"
 ],
 "Name": [
  null,
  "이름"
 ],
 "Name already exists": [
  null,
  "이름이 이미 존재합니다"
 ],
 "Name contains invalid characters": [
  null,
  "이름에 잘못된 문자가 있습니다"
 ],
 "Name must not be empty": [
  null,
  "이름을 입력하셔야 합니다"
 ],
 "Name should not be empty": [
  null,
  "이름을 입력해야 합니다"
 ],
 "Name: ": [
  null,
  "이름: "
 ],
 "Netmask": [
  null,
  "넷마스크"
 ],
 "Network $0 could not be deleted": [
  null,
  "네트워크 $0는 삭제 될 수 없습니다"
 ],
 "Network $0 failed to get activated": [
  null,
  "네트워크 $0의 활성화에 실패했습니다"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "네트워크 $0의 비활성화에 실패했습니다"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "네트워크 $0는 영구히 삭제됩니다."
 ],
 "Network boot (PXE)": [
  null,
  "네트워크 부팅(PXE)"
 ],
 "Network file system": [
  null,
  "네트워크 파일 시스템"
 ],
 "Network interface": [
  null,
  "네트워크 연결장치"
 ],
 "Network interface $0 could not be removed": [
  null,
  "네트워크 연결장치 $0는 제거 될 수 없습니다"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "네트워크 연결장치 $1에서 제거됩니다"
 ],
 "Network interface settings could not be saved": [
  null,
  "네트워크 연결장치 설정을 저장하지 못했습니다"
 ],
 "Network interfaces": [
  null,
  "네트워크 연결장치"
 ],
 "Network selection does not support PXE.": [
  null,
  "네트워크 선택은 PXE를 지원하지 않습니다."
 ],
 "Networks": [
  null,
  "네트워크"
 ],
 "New name": [
  null,
  "새로운 이름"
 ],
 "New name must not be empty": [
  null,
  "새로운 이름은 비워 두면 안됩니다"
 ],
 "New volume name": [
  null,
  "새 볼륨 이름"
 ],
 "No VM is running or defined on this host": [
  null,
  "이 호스트에서 실행 중이거나 정의된 가상 머신이 없습니다"
 ],
 "No boot device found": [
  null,
  "부팅 장치를 찾을 수 없습니다"
 ],
 "No connection available": [
  null,
  "사용 가능한 연결 없음"
 ],
 "No description": [
  null,
  "설명 없음"
 ],
 "No directories shared between the host and this VM": [
  null,
  "호스트와 이 VM 사이에서 공유된 디렉토리가 없습니다"
 ],
 "No disks defined for this VM": [
  null,
  "이 가상 머신에 지정된 디스크가 없습니다"
 ],
 "No host device selected": [
  null,
  "선택된 호스트 장치가 없습니다"
 ],
 "No host devices assigned to this VM": [
  null,
  "이 VM에 대해 정의된 호스트 장치가 없습니다"
 ],
 "No network devices": [
  null,
  "네트워크 장치 없음"
 ],
 "No network interfaces defined for this VM": [
  null,
  "이 가상 머신에 네트워크 연결장치가 정의되지 않았습니다"
 ],
 "No network is defined on this host": [
  null,
  "이 호스트에 정의된 네트워크가 없습니다"
 ],
 "No networks available": [
  null,
  "사용 가능한 네트워크가 없습니다"
 ],
 "No parent": [
  null,
  "원인 개체 없음"
 ],
 "No snapshots defined for this VM": [
  null,
  "이 VM에 대해 정의된 스냅샷 없음"
 ],
 "No state": [
  null,
  "상태 없음"
 ],
 "No storage": [
  null,
  "저장소 없음"
 ],
 "No storage pool is defined on this host": [
  null,
  "이 호스트에 지정된 저장소 풀이 없습니다"
 ],
 "No storage pools available": [
  null,
  "사용 가능한 저장소 풀 없음"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "이 저장소 풀에 대해 정의된 저장소 볼륨 없음"
 ],
 "No virtual networks": [
  null,
  "가상 네트워크 없음"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "이 저장소 풀에 대해 볼륨이 없습니다."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "비영구적 네트워크는 삭제할 수 없습니다. 비활성화되면 존재하지 않습니다."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "비영구적 저장소 풀은 삭제할 수 없습니다. 비활성화되면 존재하지 않습니다."
 ],
 "None": [
  null,
  "없음"
 ],
 "None (isolated network)": [
  null,
  "없음(격리된 네트워크)"
 ],
 "Offline token": [
  null,
  "오프라인 토큰"
 ],
 "Offline token must not be empty": [
  null,
  "오프라인 토큰은 비워 두면 안됩니다"
 ],
 "Old token expired": [
  null,
  "오래된 토큰이 만료됨"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "하나 이상의 선택된 볼륨이 도메인에서 사용되고 있습니다. 먼저 디스크를 분리하여 볼륨을 삭제하십시오."
 ],
 "Only editable when the guest is shut off": [
  null,
  "게스트가 종료된 경우에만 편집할 수 있습니다"
 ],
 "Open": [
  null,
  "열기"
 ],
 "Operating system": [
  null,
  "운영 체제"
 ],
 "Operation is in progress": [
  null,
  "실행 중인 작업"
 ],
 "Overview": [
  null,
  "개요"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "원인 스냅샷"
 ],
 "Path": [
  null,
  "경로"
 ],
 "Path on host's filesystem": [
  null,
  "호스트 파일시스템의 경로"
 ],
 "Path to ISO file on host's file system": [
  null,
  "호스트의 파일 시스템에서 ISO 파일로의 경로"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "호스트 파일 시스템에서 클라우드 이미지 파일 경로"
 ],
 "Path to file on host's file system": [
  null,
  "호스트 파일 시스템에서 파일의 경로"
 ],
 "Pause": [
  null,
  "일시정지"
 ],
 "Paused": [
  null,
  "일시정지"
 ],
 "Permanent (default)": [
  null,
  "매개변수(기본값)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "홈 디렉토리에서 디스크 이미지용 권한이 거부됨"
 ],
 "Persistence": [
  null,
  "고집"
 ],
 "Persistent": [
  null,
  "지속적"
 ],
 "Physical disk device": [
  null,
  "물리적 디스크 장치"
 ],
 "Physical disk device on host": [
  null,
  "호스트에서 물리적 디스크 장치"
 ],
 "Please choose a storage pool": [
  null,
  "저장소 풀을 선택하십시오"
 ],
 "Please choose a volume": [
  null,
  "볼륨을 선택하십시오"
 ],
 "Please enter new volume name": [
  null,
  "새 볼륨 이름을 입력해 주십시오"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "가상 머신을 시작하여 콘솔에 접근하세요."
 ],
 "Pool": [
  null,
  "풀"
 ],
 "Pool needs to be active to create volume": [
  null,
  "볼륨 생성을 위해 풀을 활성화해야 합니다"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "풀 유형 $0는 볼륨 생성을 지원하지 않습니다"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "풀 유형이 볼륨 생성을 지원하지 않습니다"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "풀 볼륨은 VM에서 사용됩니다 "
 ],
 "Port": [
  null,
  "포트"
 ],
 "Power off": [
  null,
  "전원 종료"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "게스트에게 공개하기 위한 권장 소캣 수입니다."
 ],
 "Prefix": [
  null,
  "접두어"
 ],
 "Prefix length": [
  null,
  "접두 길이"
 ],
 "Prefix length should not be empty": [
  null,
  "프리픽스 길이는 비워둘 수 없습니다"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "이전에 촬영한 스냅샷을 사용하면 문제가 발생했을 때 이전 상태로 돌아갈 수 있습니다"
 ],
 "Private": [
  null,
  "비공개"
 ],
 "Product": [
  null,
  "제품"
 ],
 "Profile": [
  null,
  "프로파일"
 ],
 "Protocol": [
  null,
  "프로토콜"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "게스트 가상 장비에서 직접 LAN으로 브릿를 제공합니다. 이는 호스트에서 한 개 또는 더 많은 물리적인 NIC을 가지고 있는 브릿지 장치가 필요합니다."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "이름을 갖고 있는 네트워크 정의에 의해 세부사항을 설명되는 연결을 제공합니다."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "NAT을 통한 가상 랜을 외부 세상으로 제공합니다."
 ],
 "Range": [
  null,
  "범위"
 ],
 "Read-only": [
  null,
  "읽기 전용"
 ],
 "Reboot": [
  null,
  "재시작"
 ],
 "Remote URL": [
  null,
  "원격 URL"
 ],
 "Remote viewer details": [
  null,
  "원격 뷰어 세부 정보"
 ],
 "Remove": [
  null,
  "제거"
 ],
 "Remove and delete file": [
  null,
  "제거하고 파일을 삭제합니다"
 ],
 "Remove disk from VM?": [
  null,
  "VM에서 디스크 제거?"
 ],
 "Remove filesystem?": [
  null,
  "파일 시스템 제거?"
 ],
 "Remove host device from VM?": [
  null,
  "VM에서 호스트 장치를 제거?"
 ],
 "Remove network interface?": [
  null,
  "네트워크 연결장치 제거?"
 ],
 "Remove static host from DHCP": [
  null,
  "DHCP에서 고정 호스트를 제거합니다"
 ],
 "Rename": [
  null,
  "이름변경"
 ],
 "Rename VM $0": [
  null,
  "VM $0 이름변경"
 ],
 "Reset": [
  null,
  "초기화"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "네트워크(SLIRP-기반 모의)와 PCI 장치 할당 제한"
 ],
 "Resume": [
  null,
  "다시 시작"
 ],
 "Revert": [
  null,
  "되돌리기"
 ],
 "Revert to snapshot $0": [
  null,
  "스냅샷 $0(으)로 되돌리기"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "이 스냅샷으로 되돌리면 VM이 스냅샷 촬영 시점으로 돌아가며 스냅샷에 캡처되지 않은 데이터와 함께 현재 상태가 모두 손실됩니다"
 ],
 "Root password": [
  null,
  "root 암호"
 ],
 "Route to $0": [
  null,
  "$0로 라우팅"
 ],
 "Routed network": [
  null,
  "라우팅된 네트워크"
 ],
 "Run": [
  null,
  "실행"
 ],
 "Run when host boots": [
  null,
  "호스트 부팅 시 실행"
 ],
 "Running": [
  null,
  "작동중"
 ],
 "SPICE TLS port": [
  null,
  "SPICE TLS 포트"
 ],
 "SPICE address": [
  null,
  "SPICE 주소"
 ],
 "SPICE port": [
  null,
  "SPICE 포트"
 ],
 "Save": [
  null,
  "저장"
 ],
 "Select console type": [
  null,
  "콘솔 유형 선택"
 ],
 "Send key": [
  null,
  "키 전송"
 ],
 "Send non-maskable interrupt": [
  null,
  "마스크 불가능 인터럽트 보내기"
 ],
 "Serial": [
  null,
  "직렬"
 ],
 "Serial console": [
  null,
  "직렬 콘솔"
 ],
 "Serial console ($0)": [
  null,
  "시리얼 콘솔 ($0)"
 ],
 "Set DHCP range": [
  null,
  "DHCP 범위 설정"
 ],
 "Set manually": [
  null,
  "수동 설정"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "자동 설치를 위한 사용자 암호를 설정하려면 VM을 생성할 때 VM을 시작해야합니다"
 ],
 "Share": [
  null,
  "공유"
 ],
 "Share a host directory with the guest": [
  null,
  "게스트와 호스트 디텍토리를 공유합니다"
 ],
 "Shared directories": [
  null,
  "공유 디렉토리"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "공유 호스트 디렉토리는 VM 안에세 수동으로 적재가 필요합니다"
 ],
 "Shared storage": [
  null,
  "공유 저장소"
 ],
 "Show additional options": [
  null,
  "추가 옵션 표시"
 ],
 "Shut down": [
  null,
  "종료"
 ],
 "Shut off": [
  null,
  "종료"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "펌웨어 구성을 편집하려면 VM을 종료하십시오"
 ],
 "Shutting down": [
  null,
  "종료 중"
 ],
 "Size": [
  null,
  "크기"
 ],
 "Slot": [
  null,
  "슬롯"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "스냅샷 $0는 삭제 될 수 없습니다"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "스냅샷 $0는 $1에서 삭제됩니다. 캡춰된 모든 내용이 손실됩니다."
 ],
 "Snapshot failed to be created": [
  null,
  "스냅샷을 만들지 못했습니다"
 ],
 "Snapshots": [
  null,
  "스냅샷"
 ],
 "Sockets": [
  null,
  "소켓"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "몇 가지 구성은 일반적인 부팅 후에만 영향을 미칩니다:"
 ],
 "Source": [
  null,
  "소스"
 ],
 "Source format": [
  null,
  "소스 형식"
 ],
 "Source must not be empty": [
  null,
  "원천은 비워두지 않아야 합니다"
 ],
 "Source path": [
  null,
  "소스 경로"
 ],
 "Source path should not be empty": [
  null,
  "소스 경로를 비워둘 수 없습니다"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "소스는 http, ftp, nfs 프로토콜로 시작해야 합니다"
 ],
 "Source volume group": [
  null,
  "원천 볼륨 그룹"
 ],
 "Start": [
  null,
  "시작"
 ],
 "Start pool when host boots": [
  null,
  "호스트 부팅 시 풀 시작"
 ],
 "Start should not be empty": [
  null,
  "시작은 비워둘 수 없습니다"
 ],
 "Startup": [
  null,
  "시작"
 ],
 "State": [
  null,
  "상태"
 ],
 "Static host entries": [
  null,
  "고정 호스트 항목"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "DHCP에서 고정 호스트가 제거 될 수 없습니다"
 ],
 "Storage": [
  null,
  "저장소"
 ],
 "Storage is at a shared location": [
  null,
  "저장소는 공유된 장소에 있습니다"
 ],
 "Storage limit": [
  null,
  "저장소 제한"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "저장소 풀 $0의 활성화에 실패했습니다"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "저장소 풀 $0의 비활성화에 실패했습니다"
 ],
 "Storage pool failed to be created": [
  null,
  "저장소 풀 생성에 실패했습니다"
 ],
 "Storage pool name": [
  null,
  "저장소 풀 이름"
 ],
 "Storage pools": [
  null,
  "저장장치 풀"
 ],
 "Storage pools could not be fetched": [
  null,
  "저장소 풀은 가져 올 수 없습니다"
 ],
 "Storage size must not be 0": [
  null,
  "저장소 크기가 0이 되어서는 안됩니다"
 ],
 "Storage volume": [
  null,
  "저장소 볼륨"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "저장소 볼륨 크기는 저장소 풀의 용량을 초과해서는 안 됩니다($0 $1)"
 ],
 "Storage volumes": [
  null,
  "저장소 볼륨"
 ],
 "Storage volumes could not be deleted": [
  null,
  "저장소 볼륨은 삭제 할 수 없습니다"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "저장소 볼륨은 이 호스트와 대상 호스트 사이에서 공유되어야 합니다."
 ],
 "Suspended (PM)": [
  null,
  "일시 정지됩니다(PM)"
 ],
 "System": [
  null,
  "시스템"
 ],
 "Table of selectable host devices": [
  null,
  "선택 할 수 있는 호스트 장치의 표"
 ],
 "Target": [
  null,
  "대상"
 ],
 "Target path": [
  null,
  "대상 경로"
 ],
 "Target path should not be empty": [
  null,
  "대상 경로를 비워둘 수 없습니다"
 ],
 "Temporary": [
  null,
  "임시"
 ],
 "Temporary migration": [
  null,
  "임시 이전"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "VM $0는 실행되고 있으므로 삭제 전 강제로 종료됩니다."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "이 장치를 분리하려면 VM이 실행 중이거나 종료되어 있어야합니다"
 ],
 "The directory on the server being exported": [
  null,
  "서버의 디렉토리를 내보내는 중"
 ],
 "The host path that is to be exported.": [
  null,
  "내보내어야 할 호스트 경로."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "이전된 VM 구성은 원천 호스트에서 제거 됩니다. 대상 호스트는 VM의 신규 홈이 고려됩니다."
 ],
 "The pool is empty": [
  null,
  "풀이 비어 있습니다"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "선택한 운영 체제의 최소 메모리 요구 사항은 $0 $1입니다"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "선택한 운영 체제의 최소 저장소 크기 요구 사항은 $0 $1입니다"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "$0를 위한 고정 호스트 항목이 제거됩니다:"
 ],
 "The storage pool could not be deleted": [
  null,
  "저장소 풀을 삭제 할 수 없습니다"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "게스트가 이 내보내기 지점으로 적재하는데 사용되는 태그 이름."
 ],
 "Then copy and paste it above.": [
  null,
  "그런 다음 복사하고 이를 위에 붙입니다."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "이 VM은 일시적입니다. 삭제하려면 VM을 종료하십시오."
 ],
 "This disk will be removed from $0:": [
  null,
  "이 디스크는 $0에서 제거됩니다:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "이 파일시스템은 $0에서 제거됩니다:"
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "이는 동적 / 무선 네트워크 환경을 갖는 호스트에서 일반적인 게스트 연결을 위해 추천되는 구성입니다."
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "이는 고정된 유선 네트워크 구성과 함께 호스트에서 일반적인 게스트 연결을 위해 추천되는 구성입니다."
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  "이는 고성능 또는 향상된 보안을 위해 추천된 구성입니다."
 ],
 "This volume is already used by $0.": [
  null,
  "이 볼륨은 이미 $s0에서 사용하고 있습니다."
 ],
 "This volume is already used by another VM.": [
  null,
  "이 볼륨은 이미 다른 가상 머신에서 사용하고 있습니다."
 ],
 "Threads per core": [
  null,
  "코어 당 스레드"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Transient VM은 펌웨어 구성 편집을 지원하지 않습니다"
 ],
 "Troubleshoot": [
  null,
  "문제 해결"
 ],
 "Type": [
  null,
  "유형"
 ],
 "Type ID": [
  null,
  "ID 입력"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (ISO 이미지 또는 저장소 설치 트리)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "정의되지 않음"
 ],
 "Unique name": [
  null,
  "고유한 이름"
 ],
 "Unique name, default: $0": [
  null,
  "고유한 이름, 기본값: $0"
 ],
 "Unique network name": [
  null,
  "고유한 네트워크 이름"
 ],
 "Unit": [
  null,
  "단위"
 ],
 "Unknown": [
  null,
  "알 수 없음"
 ],
 "Unknown firmware": [
  null,
  "알 수 없는 펌웨어"
 ],
 "Unspecified": [
  null,
  "지정되지 않음"
 ],
 "Url": [
  null,
  "URL"
 ],
 "Usage": [
  null,
  "사용량"
 ],
 "Use existing": [
  null,
  "기존 사용"
 ],
 "Use extended attributes on files and directories": [
  null,
  "파일과 디렉토리에서 확장된 속성을 사용합니다"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "자신의 저장소를 위해 원점과 대상 호스트 모두에서 동일한 경로를 사용해야 합니다. 이는 공유된 저장소 풀, NFS, 또는 다른 공유하는 저장소 방식이 될 수 있습니다."
 ],
 "Used": [
  null,
  "사용 중"
 ],
 "Used by": [
  null,
  "사용되었습니다"
 ],
 "User login": [
  null,
  "사용자 로그인"
 ],
 "User login must not be empty when user password is set": [
  null,
  "사용자 로그인은 사용자 비밀번호 설정 할 때에 비워두지 않아야 합니다"
 ],
 "User password": [
  null,
  "암호 사용"
 ],
 "User password must not be empty when user login is set": [
  null,
  "사용자 비밀번호는 사용자 로그인 설정 할 때에 비워두지 않아야 합니다"
 ],
 "User session": [
  null,
  "사용자 세션"
 ],
 "VCPU settings could not be saved": [
  null,
  "VCPU 설정을 저장할 수 없습니다"
 ],
 "VM $0 Host Devices": [
  null,
  "VM $0 호스트 장치"
 ],
 "VM $0 already exists": [
  null,
  "VM $0이 이미 존재합니다"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "VM $0이(가) $1 연결에 존재하지 않습니다"
 ],
 "VM $0 failed to force reboot": [
  null,
  "VM $0의 강제 재시작에 실패했습니다"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "VM $0 강제 종료에 실패했습니다"
 ],
 "VM $0 failed to get installed": [
  null,
  "VM $0 설치에 실패했습니다"
 ],
 "VM $0 failed to pause": [
  null,
  "VM $0 일시 정지에 실패했습니다"
 ],
 "VM $0 failed to reboot": [
  null,
  "VM $0의 재시작에 실패했습니다"
 ],
 "VM $0 failed to resume": [
  null,
  "VM $0 재개에 실패했습니다"
 ],
 "VM $0 failed to send NMI": [
  null,
  "VM $0의 NMI 전송에 실패했습니다"
 ],
 "VM $0 failed to shutdown": [
  null,
  "VM $0 종료에 실패했습니다"
 ],
 "VM $0 failed to start": [
  null,
  "VM $0 시작에 실패했습니다"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "자신의 사용자 계정에 의해 소유한 프로세스와 PTY와 함께 권한 없이 제한된 접근으로 시작된 가상장비"
 ],
 "VM needs shutdown": [
  null,
  "VM 종료가 필요합니다"
 ],
 "VM state": [
  null,
  "VM 상태"
 ],
 "VM will launch with root permissions": [
  null,
  "가상장비는 root 권한으로 시작합니다"
 ],
 "VNC TLS port": [
  null,
  "VNC TLS 포트"
 ],
 "VNC address": [
  null,
  "VNC 주소"
 ],
 "VNC console": [
  null,
  "VNC 콘솔"
 ],
 "VNC port": [
  null,
  "VNC 포트"
 ],
 "Valid token": [
  null,
  "유효한 토큰"
 ],
 "Vendor": [
  null,
  "제조사"
 ],
 "Virtual machines": [
  null,
  "가상 머신"
 ],
 "Virtual machines management": [
  null,
  "가상 머신 관리"
 ],
 "Virtual network": [
  null,
  "가상 네트워크"
 ],
 "Virtual network failed to be created": [
  null,
  "가상 네트워크를 만들지 못했습니다"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "가상화 서비스(libvirt)가 활성화되어 있지 않습니다"
 ],
 "Volume": [
  null,
  "볼륨"
 ],
 "Volume failed to be created": [
  null,
  "볼륨을 만들지 못했습니다"
 ],
 "Volume group name": [
  null,
  "볼륨 그룹 이름"
 ],
 "Volume group name should not be empty": [
  null,
  "볼륨 그룹 이름은 비워둘 수 없습니다"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "와치독"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "시스템 멈춤 응답 할 때에 와치독 동작. 이와 같은 가상 와치독 장치를 사용하려면, 게스트 시스템은 또한 추가적인 드라이버와 동작중인 와치독 서비스도 있어야 합니다."
 ],
 "Writeable": [
  null,
  "쓰기 가능"
 ],
 "Writeable and shared": [
  null,
  "쓰기 가능 및 공유"
 ],
 "You can mount the shared folder using:": [
  null,
  "다음을 사용하여 공유 폴더를 적재 할 수 있습니다:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "가장 일치하는 운영 체제를 선택해야합니다"
 ],
 "active": [
  null,
  "활성"
 ],
 "add": [
  null,
  "추가"
 ],
 "add entry": [
  null,
  "항목 추가"
 ],
 "bridge": [
  null,
  "브릿지"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "사용자 지정"
 ],
 "direct": [
  null,
  "직접"
 ],
 "disabled": [
  null,
  "비활성화됨"
 ],
 "disk": [
  null,
  "디스크"
 ],
 "down": [
  null,
  "아래로"
 ],
 "edit": [
  null,
  "편집"
 ],
 "enabled": [
  null,
  "활성화됩니다"
 ],
 "ethernet": [
  null,
  "이더넷"
 ],
 "host": [
  null,
  "호스트"
 ],
 "host device": [
  null,
  "호스트 장치"
 ],
 "host passthrough": [
  null,
  "호스트 통과"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "iSCSI 직접 대상"
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI 개시자 IQN"
 ],
 "iSCSI target": [
  null,
  "iSCSI 대상"
 ],
 "iSCSI target IQN": [
  null,
  "iSCSI 대상 IQN"
 ],
 "inactive": [
  null,
  "비활성"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "더 많은 정보"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "적재점: 게스트 안에서 적재점"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "적재 태그: 내보낸 적재점과 연결된 태그"
 ],
 "network": [
  null,
  "네트워크"
 ],
 "no": [
  null,
  "아니요"
 ],
 "no state saved": [
  null,
  "저장된 상태 없음"
 ],
 "none": [
  null,
  "없음"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "리디렉트된 장치"
 ],
 "remove": [
  null,
  "제거"
 ],
 "serial number": [
  null,
  "일련 번호"
 ],
 "server": [
  null,
  "서버"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "위로"
 ],
 "user": [
  null,
  "사용자"
 ],
 "vCPU count": [
  null,
  "vCPU 개수"
 ],
 "vCPU maximum": [
  null,
  "vCPU 최대"
 ],
 "vCPUs": [
  null,
  "vCPU"
 ],
 "vhostuser": [
  null,
  "가상 호스트 사용자"
 ],
 "view more...": [
  null,
  "더 알아보기..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "VM을 복제하려면 시스템에 virt-install 꾸러미를 설치해야 합니다"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "새로운 가상 머신을 생성하려면 시스템에 virt-install 꾸러미를 설치해야 합니다"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "이 속성을 편집하려면 시스템에 virt-install 꾸러미를 설치해야 합니다"
 ],
 "vm": [
  null,
  "vm"
 ],
 "yes": [
  null,
  "예"
 ]
});
