cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "nl",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 beschikbaar op standaard locatie"
 ],
 "$0 $1 available on host": [
  null,
  "$0 $1 beschikbaar op host"
 ],
 "$0 CPU configuration": [
  null,
  "$0 CPU-configuratie"
 ],
 "$0 Network": [
  null,
  "$0 Netwerk",
  "$0 Netwerken"
 ],
 "$0 Storage pool": [
  null,
  "$0 Opslagpool",
  "$0 Opslagpools"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 ondersteunt geen installatie zonder toezicht."
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 is beschikbaar voor de meeste besturingssystemen. Om het te installeren zoek je het op in GNOME Software of je voert het volgende uit:"
 ],
 "$0 memory adjustment": [
  null,
  "$0 geheugenaanpassing"
 ],
 "$0 network": [
  null,
  "$0 netwerk"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPU",
  "$0 vCPU's"
 ],
 "$0 vCPU details": [
  null,
  "$0 vCPU-details"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 virtueel netwerkinterface instellingen"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Een kopie van de VM wordt op de bestemming uitgevoerd en verdwijnt wanneer deze wordt uitgeschakeld. Ondertussen behoudt de oorspronkelijke host zijn kopie van de VM-configuratie."
 ],
 "Access": [
  null,
  "Toegang"
 ],
 "Action": [
  null,
  "Actie"
 ],
 "Activate": [
  null,
  "Activeren"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Activeer de opslagpool om volumes te beheren"
 ],
 "Add": [
  null,
  "Toevoegen"
 ],
 "Add a DHCP static host entry": [
  null,
  "Voeg een DHCP statische hostingang toe"
 ],
 "Add disk": [
  null,
  "Schijf toevoegen"
 ],
 "Add host device": [
  null,
  "Voeg hostapparaat toe"
 ],
 "Add network interface": [
  null,
  "Netwerkinterface toevoegen"
 ],
 "Add shared directory": [
  null,
  "Gedeelde map toevoegen"
 ],
 "Add virtual network interface": [
  null,
  "Virtueel netwerkinterface toevoegen"
 ],
 "Add watchdog device type": [
  null,
  "Watchdog-apparaattype toevoegen"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Het toevoegen van gedeelde mappen is alleen mogelijk als de gast is uitgeschakeld"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  "Als je deze schijf toevoegt, wordt de toegangsmodus gewijzigd in gedeeld."
 ],
 "Additional": [
  null,
  "Extra"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address not within subnet": [
  null,
  "Adres bevindt zich niet in subnet"
 ],
 "All": [
  null,
  "Alle"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Alle VM-activiteiten, inclusief opslag, zullen tijdelijk zijn. Dit resulteert in dataverlies op de bestemmingshost."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "Toegestane tekens: basis Latijns alfabet, cijfers en beperkte interpunctie (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Verwijder ook alle volumes in deze pool:"
 ],
 "Always attach": [
  null,
  "Altijd hechten"
 ],
 "Apply": [
  null,
  "Toepassen"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Geautomatiseerde installaties zijn alleen beschikbaar bij het downloaden van een image of het gebruik van cloud-init."
 ],
 "Automatic": [
  null,
  "Automatisch"
 ],
 "Automation": [
  null,
  "Automatisering"
 ],
 "Autostart": [
  null,
  "Automatische start"
 ],
 "Blocked": [
  null,
  "Geblokkeerd"
 ],
 "Boot order": [
  null,
  "Opstartvolgorde"
 ],
 "Boot order settings could not be saved": [
  null,
  "Opstartvolgorde instellingen konden niet opgeslagen worden"
 ],
 "Bus": [
  null,
  "Bus"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD-schijf"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU configuration could not be saved": [
  null,
  "CPU-configuratie kon niet worden opgeslagen"
 ],
 "CPU type": [
  null,
  "CPU-type"
 ],
 "Cache": [
  null,
  "Cache"
 ],
 "Cancel": [
  null,
  "Annuleren"
 ],
 "Capacity": [
  null,
  "Capaciteit"
 ],
 "Change boot order": [
  null,
  "Verander opstartvolgorde"
 ],
 "Change firmware": [
  null,
  "Verander firmware"
 ],
 "Changes pending": [
  null,
  "Wijzigingen in behandeling"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Wijzigingen worden van kracht na het afsluiten van de VM"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "Het wijzigen van BIOS/EFI-instellingen is specifiek voor elke fabrikant. Het gaat om het indrukken van een sneltoets tijdens het opstarten (ESC, F1, F12, Del). Schakel een instelling in met de naam \"virtualisatie\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Raadpleeg de handleiding van jecomputer voor details."
 ],
 "Checking token validity...": [
  null,
  "Geldigheid token controleren..."
 ],
 "Choose an operating system": [
  null,
  "Kies een besturingssysteem"
 ],
 "Class": [
  null,
  "Klasse"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "Klikken op \"Lanceer viewer op afstand\" zal een .vv bestand downloaden en $0 opstarten."
 ],
 "Clone": [
  null,
  "Kloon"
 ],
 "Close": [
  null,
  "Sluiten"
 ],
 "Cloud base image": [
  null,
  "Cloud basis image"
 ],
 "Confirm this action": [
  null,
  "Bevestig deze actie"
 ],
 "Connect": [
  null,
  "Verbinden"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "Maak verbinding met elke viewertoepassing voor de volgende protocollen"
 ],
 "Connecting": [
  null,
  "Verbinding maken"
 ],
 "Connection": [
  null,
  "Verbinding"
 ],
 "Console": [
  null,
  "Console"
 ],
 "Copy storage": [
  null,
  "Opslag kopiëren"
 ],
 "Cores per socket": [
  null,
  "Kernen per socket"
 ],
 "Could not delete $0": [
  null,
  "$0 kon niet worden verwijderd"
 ],
 "Could not delete all storage for $0": [
  null,
  "Kon alle opslag voor $0 niet verwijderen"
 ],
 "Could not delete disk's storage": [
  null,
  "Kan de schijfopslag niet verwijderen"
 ],
 "Could not revert to snapshot": [
  null,
  "Kan niet terugkeren naar snapshot"
 ],
 "Crashed": [
  null,
  "Gecrasht"
 ],
 "Create": [
  null,
  "Aanmaken"
 ],
 "Create VM": [
  null,
  "Maak VM aan"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Maak een VM door een schijfimage van een bestaande VM-installatie te importeren"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Maak een VM vanaf een lokaal of netwerkinstallatiemedium"
 ],
 "Create a clone VM based on $0": [
  null,
  "Maak een kloon VM aan gebaseerd op $0"
 ],
 "Create and edit": [
  null,
  "Aanmaken en bewerken"
 ],
 "Create and run": [
  null,
  "Aanmaken en uitvoeren"
 ],
 "Create new": [
  null,
  "Nieuwe aanmaken"
 ],
 "Create new virtual machine": [
  null,
  "Nieuwe virtuele machine aanmaken"
 ],
 "Create new volume": [
  null,
  "Nieuwe volume aanmaken"
 ],
 "Create snapshot": [
  null,
  "Maak snapshot aan"
 ],
 "Create storage pool": [
  null,
  "Maak opslagpool aan"
 ],
 "Create storage volume": [
  null,
  "Maak opslagvolume aan"
 ],
 "Create virtual network": [
  null,
  "Maak virtueel netwerk aan"
 ],
 "Create volume": [
  null,
  "Maak volume aan"
 ],
 "Creating VM": [
  null,
  "VM aanmaken"
 ],
 "Creating VM $0": [
  null,
  "VM $0 aanmaken"
 ],
 "Creation of VM $0 failed": [
  null,
  "Aanmaken van VM $0 mislukte"
 ],
 "Creation time": [
  null,
  "Aanmaaktijd"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Huidig"
 ],
 "Current allocation": [
  null,
  "Huidige toewijzing"
 ],
 "Custom firmware: $0": [
  null,
  "Aangepaste firmware: $0"
 ],
 "Custom path": [
  null,
  "Aangepast pad"
 ],
 "DHCP Settings": [
  null,
  "DHCP-instellingen"
 ],
 "Deactivate": [
  null,
  "Deactiveren"
 ],
 "Delete": [
  null,
  "Verwijderen"
 ],
 "Delete $0 VM?": [
  null,
  "$0 VM verwijderen?"
 ],
 "Delete $0 storage pool?": [
  null,
  "$0 opslagpool verwijderen?"
 ],
 "Delete $0 volume": [
  null,
  "Verwijder $0 volume",
  "Verwijder $0 volumes"
 ],
 "Delete associated storage files:": [
  null,
  "Verwijder bijbehorende opslagbestanden:"
 ],
 "Delete network?": [
  null,
  "Netwerk verwijderen?"
 ],
 "Delete snapshot?": [
  null,
  "Snapshot verwijderen?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Het verwijderen van een inactieve opslagpool zal alleen de definitie van de pool verwijderen. De inhoud ervan wordt niet verwijderd."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Het verwijderen van gedeelde mappen is alleen mogelijk als de gast is uitgeschakeld"
 ],
 "Description": [
  null,
  "Beschrijving"
 ],
 "Desktop viewer": [
  null,
  "Bureaubladviewer"
 ],
 "Destination URI": [
  null,
  "Bestemmings-URI"
 ],
 "Destination URI must not be empty": [
  null,
  "Bestemmings-URI mag niet leeg zijn"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Koppel de schijven die deze pool gebruiken los van alle VM's voordat je ze probeert te verwijderen."
 ],
 "Details": [
  null,
  "Details"
 ],
 "Device": [
  null,
  "Apparaat"
 ],
 "Devices": [
  null,
  "Apparaten"
 ],
 "Disconnect": [
  null,
  "Verbinding verbreken"
 ],
 "Disconnected": [
  null,
  "Niet verbonden"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Verbinden met seriële console verbroken. Klik op de verbinden knop."
 ],
 "Disk": [
  null,
  "Schijf"
 ],
 "Disk $0 could not be removed": [
  null,
  "Schijf $0 kon niet worden verwijderd"
 ],
 "Disk failed to be attached": [
  null,
  "Schijf kon niet worden aangesloten"
 ],
 "Disk failed to be created": [
  null,
  "Schijf kon niet aangemaakt worden"
 ],
 "Disk identifier": [
  null,
  "Schijf-ID"
 ],
 "Disk image": [
  null,
  "Schijfimage"
 ],
 "Disk image file": [
  null,
  "Schijfimagebestand"
 ],
 "Disk image path must not be empty": [
  null,
  "Schijfimagepad mag niet leeg zijn"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Schijfimages kunnen worden opgeslagen in de thuismap van de gebruiker"
 ],
 "Disk settings could not be saved": [
  null,
  "Schijfinstellingen konden niet opgeslagen worden"
 ],
 "Disk-only snapshot": [
  null,
  "Momentopname op schijf"
 ],
 "Disks": [
  null,
  "Schijven"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Voer deze VM niet tegelijkertijd uit op de herkomst- en bestemmingshosts."
 ],
 "Do nothing": [
  null,
  "Niets doen"
 ],
 "Domain has crashed": [
  null,
  "Domein is vastgelopen"
 ],
 "Domain is blocked on resource": [
  null,
  "Domein is geblokkeerd op hulpbron"
 ],
 "Download an OS": [
  null,
  "Download een OS"
 ],
 "Download progress": [
  null,
  "Download voortgang"
 ],
 "Downloading image for VM $0": [
  null,
  "Image voor VM $0 downloaden"
 ],
 "Downloading: $0%": [
  null,
  "Downloaden: $0%"
 ],
 "Dump core": [
  null,
  "Dump kern"
 ],
 "Duration": [
  null,
  "Looptijd"
 ],
 "Dying": [
  null,
  "Achteruitgaan"
 ],
 "Edit": [
  null,
  "Bewerken"
 ],
 "Edit $0 attributes": [
  null,
  "Bewerk $0 attributen"
 ],
 "Edit watchdog device type": [
  null,
  "Watchdog-apparaattype bewerken"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Het bewerken van netwerkinterfaces van tijdelijke gasten is niet toegestaan"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Het bewerken van tijdelijke netwerkinterfaces is niet toegestaan"
 ],
 "Eject": [
  null,
  "Uitwerpen"
 ],
 "Eject disc from VM?": [
  null,
  "Schijf uit VM werpen?"
 ],
 "Emulated machine": [
  null,
  "Geëmuleerde machine"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "Ondersteuning voor virtualisatie inschakelen in BIOS/EFI-instellingen."
 ],
 "End": [
  null,
  "Einde"
 ],
 "End should not be empty": [
  null,
  "Einde mag niet leeg zijn"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Voer root- en/of gebruikersinformatie in om installatie zonder toezicht mogelijk te maken."
 ],
 "Error checking token": [
  null,
  "Fout bij het controleren van token"
 ],
 "Example, $0": [
  null,
  "Voorbeeld, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Bestaande schijfimage op het bestandssysteem van de host"
 ],
 "Expand": [
  null,
  "Uitbreiden"
 ],
 "Extended attributes": [
  null,
  "Uitgebreide attributen"
 ],
 "Failed": [
  null,
  "Mislukt"
 ],
 "Failed to add shared directory": [
  null,
  "Kan gedeelde map niet toevoegen"
 ],
 "Failed to change firmware": [
  null,
  "Kan firmware niet veranderen"
 ],
 "Failed to clone VM $0": [
  null,
  "Kan VM $0 niet klonen"
 ],
 "Failed to configure watchdog": [
  null,
  "Kan watchdog niet configureren"
 ],
 "Failed to detach watchdog": [
  null,
  "Kan watchdog niet loskoppelen"
 ],
 "Failed to fetch some resources": [
  null,
  "Kan sommige bronnen niet ophalen"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "Het ophalen van de IP-adressen van de interfaces in $0 is mislukt"
 ],
 "Failed to rename VM $0": [
  null,
  "Kan de naam van VM $0 niet wijzigen"
 ],
 "Failed to save network settings": [
  null,
  "Opslaan van netwerkinstellingen mislukte"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Kan toets Ctrl+Alt+$0 niet verzenden naar VM $1"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "Minder dan het maximale aantal virtuele CPU's moet zijn ingeschakeld."
 ],
 "File": [
  null,
  "Bestand"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "Bestandssysteem $0 kon niet worden verwijderd"
 ],
 "Filesystem directory": [
  null,
  "Bestandssysteemmap"
 ],
 "Filter by name": [
  null,
  "Filteren op naam"
 ],
 "Firmware": [
  null,
  "Firmware"
 ],
 "Force eject": [
  null,
  "Forceer uitwerpen"
 ],
 "Force reboot": [
  null,
  "Forceer opnieuw starten"
 ],
 "Force revert": [
  null,
  "Geforceerd terugzetten"
 ],
 "Force shut down": [
  null,
  "Forceer afsluiten"
 ],
 "Format": [
  null,
  "Formatteren"
 ],
 "Forward mode": [
  null,
  "Voorwaartse modus"
 ],
 "Forwarding mode": [
  null,
  "Modus doorsturen"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Volledige schijfimages en het geheugen van het domein worden gemigreerd. Alleen niet-gedeelde, beschrijfbare schijfimages worden overgedragen. Ongebruikte opslag blijft na migratie op de oorsprong staan."
 ],
 "General": [
  null,
  "Algemeen"
 ],
 "Generate automatically": [
  null,
  "Automatisch genereren"
 ],
 "Get a new RHSM token.": [
  null,
  "Ontvang een nieuw RHSM-token."
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "Ga naar VM's lijst"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Goede keuze voor desktopvirtualisatie"
 ],
 "Gracefully shutdown": [
  null,
  "Gracieus afsluiten"
 ],
 "Hardware virtualization is disabled": [
  null,
  "Hardwarevirtualisatie is uitgeschakeld"
 ],
 "Hide additional options": [
  null,
  "Verberg extra opties"
 ],
 "Host": [
  null,
  "Host"
 ],
 "Host device": [
  null,
  "Hostapparaat"
 ],
 "Host device could not be attached": [
  null,
  "Hostapparaat kan niet worden aangesloten"
 ],
 "Host device will be removed from $0:": [
  null,
  "Hostapparaat wordt verwijderd van $0:"
 ],
 "Host devices": [
  null,
  "Hostapparaten"
 ],
 "Host name": [
  null,
  "Hostnaam"
 ],
 "Host should not be empty": [
  null,
  "Host mag niet leeg zijn"
 ],
 "Hypervisor details": [
  null,
  "Hypervisor-details"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP-adres"
 ],
 "IP address must not be empty": [
  null,
  "IP-adres mag niet leeg zijn"
 ],
 "IP configuration": [
  null,
  "IP-configuratie"
 ],
 "IPv4 address": [
  null,
  "IPv4-adres"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  "IPv4-adres mag niet hetzelfde zijn als de netwerk-ID"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "IPv4-adres mag niet hetzelfde zijn als het broadcast-adres van het netwerk"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 en IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4-netwerk mag niet leeg zijn"
 ],
 "IPv4 only": [
  null,
  "alleen IPv4"
 ],
 "IPv6 address": [
  null,
  "IPv6-adres"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6-netwerk mag niet leeg zijn"
 ],
 "IPv6 only": [
  null,
  "Alleen IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "Ideaal voor server-VM's"
 ],
 "Ideal networking support": [
  null,
  "Ideale netwerkondersteuning"
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Identificatie kan stil worden afgekapt tot $0 tekens "
 ],
 "Idle": [
  null,
  "Inactief"
 ],
 "Ignore": [
  null,
  "Negeren"
 ],
 "Import VM": [
  null,
  "Importeer VM"
 ],
 "Import a virtual machine": [
  null,
  "Importeer een virtuele machine"
 ],
 "Import and edit": [
  null,
  "Importeren en bewerken"
 ],
 "Import and run": [
  null,
  "Importeren en uitvoeren"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "Het importeren van een afbeelding met een back-upbestand wordt niet ondersteund"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "In de meeste configuraties werkt macvtap niet voor netwerkcommunicatie van host naar gast."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  "In de standaard 'vepa'-modus wordt het schakelen overgelaten aan de externe schakelaar. Als de schakelaar niet VEPA-compatibel is, is communicatie tussen virtuele gastmachines of tussen een gast en de host niet mogelijk."
 ],
 "Initiator": [
  null,
  "Initiator"
 ],
 "Initiator IQN should not be empty": [
  null,
  "Initiator IQN mag niet leeg zijn"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Injecteer een niet-maskeerbare interrupt"
 ],
 "Insert": [
  null,
  "Plaatsen"
 ],
 "Insert disc media": [
  null,
  "Schijfmedia plaatsen"
 ],
 "Install": [
  null,
  "Installeren"
 ],
 "Installation source": [
  null,
  "Installatiebron"
 ],
 "Installation source must not be empty": [
  null,
  "Installatiebron mag niet leeg zijn"
 ],
 "Installation type": [
  null,
  "Installatietype"
 ],
 "Interface": [
  null,
  "Interface"
 ],
 "Interface type": [
  null,
  "Interfacetype"
 ],
 "Interface type help": [
  null,
  "Interfacetype hulp"
 ],
 "Invalid IPv4 address": [
  null,
  "Ongeldig IPv4-adres"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Ongeldig IPv4-masker of voorvoegsel lengte"
 ],
 "Invalid IPv6 address": [
  null,
  "Ongeldig IPv6-adres"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Ongeldig IPv6-voorvoegsel"
 ],
 "Invalid filename": [
  null,
  "Ongeldige bestandsnaam"
 ],
 "Isolated network": [
  null,
  "Geïsoleerd netwerk"
 ],
 "LVM volume group": [
  null,
  "LVM-volumegroep"
 ],
 "Launch remote viewer": [
  null,
  "Start viewer op afstand"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Laat het wachtwoord leeg als je geen root-account wilt aanmaken"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Laat het wachtwoord leeg als je geen gebruikersaccount wilt aanmaken"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Laat het wachtwoord leeg als je geen root-wachtwoord wilt aanmaken"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt heeft geen UEFI/OVMF firmware-image op de host gedetecteerd"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt of hypervisor ondersteunt UEFI niet"
 ],
 "Loading available network devices": [
  null,
  "Beschikbare netwerkapparaten worden geladen"
 ],
 "Loading resources": [
  null,
  "Bronnen laden"
 ],
 "Loading...": [
  null,
  "Laden..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Lokale installatiemedia (ISO-image of distro-installatieboom)"
 ],
 "Location": [
  null,
  "Locatie"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC-adres"
 ],
 "MAC address must not be empty": [
  null,
  "MAC-adres mag niet leeg zijn"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "De machine moet worden uitgeschakeld voordat het bustype wordt gewijzigd"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "De machine moet worden uitgeschakeld voordat de cachemodus wordt gewijzigd"
 ],
 "Managing virtual machines": [
  null,
  "Virtuele machines beheren"
 ],
 "Manual connection": [
  null,
  "Handmatige verbinding"
 ],
 "Mask or prefix length": [
  null,
  "Masker of voorvoegsel lengte"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Masker of voorvoegsel lengte mag niet leeg zijn"
 ],
 "Maximum allocation": [
  null,
  "Maximale toewijzing"
 ],
 "Maximum memory could not be saved": [
  null,
  "Maximaal geheugen kon niet worden opgeslagen"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Maximaal aantal virtuele CPU's toegewezen aan het gast-besturingssysteem"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "Maximaal aantal virtuele CPU's toegewezen voor het gastbesturingssysteem, dat moet liggen tussen 1 en $0"
 ],
 "Maximum transmission unit": [
  null,
  "Maximale transmissie-eenheid"
 ],
 "Media could not be ejected from $0": [
  null,
  "edia kan niet worden uitgeworpen uit $0"
 ],
 "Media will be ejected from $0:": [
  null,
  "Media wordt uitgeworpen uit $0:"
 ],
 "Memory": [
  null,
  "Geheugen"
 ],
 "Memory could not be saved": [
  null,
  "Geheugen kon niet worden opgeslagen"
 ],
 "Memory must not be 0": [
  null,
  "Geheugen mag niet 0 zijn"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "Migreren"
 ],
 "Migrate VM to another host": [
  null,
  "VM migreren naar een andere host"
 ],
 "Migration failed": [
  null,
  "Migratie mislukte"
 ],
 "Mode": [
  null,
  "Modus"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Model type": [
  null,
  "Modeltype"
 ],
 "More info for mount tag field": [
  null,
  "Meer info voor het veld voor het aankoppelen van tag"
 ],
 "More info for source path field": [
  null,
  "Meer info voor het bronpadveld"
 ],
 "Mount tag": [
  null,
  "Aankoppel tag"
 ],
 "Mount tag must not be empty": [
  null,
  "Aankoppel tag mag niet leeg zijn"
 ],
 "NAT to $0": [
  null,
  "NAT naar $0"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "NIC $0 van VM $1 kon de status niet wijzigen"
 ],
 "Name": [
  null,
  "Naam"
 ],
 "Name already exists": [
  null,
  "Naam bestaat al"
 ],
 "Name contains invalid characters": [
  null,
  "Naam bevat ongeldige tekens"
 ],
 "Name must not be empty": [
  null,
  "Naam mag niet leeg zijn"
 ],
 "Name should not be empty": [
  null,
  "Naam mag niet leeg zijn"
 ],
 "Name: ": [
  null,
  "Naam: "
 ],
 "Netmask": [
  null,
  "Netmasker"
 ],
 "Network $0 could not be deleted": [
  null,
  "Netwerk $0 kon niet worden verwijderd"
 ],
 "Network $0 failed to get activated": [
  null,
  "Netwerk $0 kan niet geactiveerd worden"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "Netwerk $0 kan niet gedeactiveerd worden"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "Netwerk $0 wordt permanent verwijderd."
 ],
 "Network boot (PXE)": [
  null,
  "Netwerk opstarten (PXE)"
 ],
 "Network file system": [
  null,
  "Netwerk bestandssyteem"
 ],
 "Network interface": [
  null,
  "Netwerkinterface"
 ],
 "Network interface $0 could not be removed": [
  null,
  "Netwerkinterface $0 kond niet worden verwijderd"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "Netwerkinterface $0 wordt verwijderd van $1"
 ],
 "Network interface settings could not be saved": [
  null,
  "Netwerkinterface-instellingen konden niet opgeslagen worden"
 ],
 "Network interfaces": [
  null,
  "Netwerkinterfaces"
 ],
 "Network selection does not support PXE.": [
  null,
  "Netwerk selectie ondersteunt PXE niet."
 ],
 "Networks": [
  null,
  "Netwerken"
 ],
 "New name": [
  null,
  "Nieuwe naam"
 ],
 "New name must not be empty": [
  null,
  "Nieuwe naam mag niet leeg zijn"
 ],
 "New volume name": [
  null,
  "Nieuwe volumenaam"
 ],
 "No VM is running or defined on this host": [
  null,
  "Er is geen VM actief of gedefinieerd op deze host"
 ],
 "No boot device found": [
  null,
  "Geen opstartapparaat gevonden"
 ],
 "No connection available": [
  null,
  "Geen verbinding beschikbaar"
 ],
 "No description": [
  null,
  "Geen beschrijving"
 ],
 "No directories shared between the host and this VM": [
  null,
  "Geen mappen gedeeld tussen de host en deze VM"
 ],
 "No disks defined for this VM": [
  null,
  "Geen schijven gedefinieerd voor deze VM"
 ],
 "No host device selected": [
  null,
  "Geen hostapparaat geselecteerd"
 ],
 "No host devices assigned to this VM": [
  null,
  "Geen hostapparaten toegewezen aan deze VM"
 ],
 "No network devices": [
  null,
  "Geen netwerkapparaten"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Geen netwerkinterfaces gedefinieerd voor deze VM"
 ],
 "No network is defined on this host": [
  null,
  "Geen netwerk gedefinieerd op deze host"
 ],
 "No networks available": [
  null,
  "Geen netwerken beschikbaar"
 ],
 "No parent": [
  null,
  "Geen ouder"
 ],
 "No snapshots defined for this VM": [
  null,
  "Geen momentopnames gedefinieerd voor deze VM"
 ],
 "No state": [
  null,
  "Geen status"
 ],
 "No storage": [
  null,
  "Geen opslag"
 ],
 "No storage pool is defined on this host": [
  null,
  "Er is geen opslagpool gedefinieerd op deze host"
 ],
 "No storage pools available": [
  null,
  "Geen opslagpools beschikbaar"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Geen opslagvolumes gedefinieerd voor deze opslagpool"
 ],
 "No virtual networks": [
  null,
  "Geen virtuele netwerken"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "Er zijn geen volumes in deze opslagpool."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Niet-perminent netwerk kan niet worden verwijderd. Het houdt op te bestaan wanneer het wordt gedeactiveerd."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Niet-permanente opslagpool kan niet worden verwijderd. Het houdt op te bestaan wanneer het wordt gedeactiveerd."
 ],
 "None": [
  null,
  "Geen"
 ],
 "None (isolated network)": [
  null,
  "Geen (geïsoleerd netwerk)"
 ],
 "Offline token": [
  null,
  "Offline token"
 ],
 "Offline token must not be empty": [
  null,
  "Offline token mag niet leeg zijn"
 ],
 "Old token expired": [
  null,
  "Oude token verlopen"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Een of meer geselecteerde volumes worden gebruikt door domeinen. Maak eerst de schijven los om het volume te verwijderen."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Alleen bewerkbaar wanneer de gast uitgeschakeld is"
 ],
 "Open": [
  null,
  "Openen"
 ],
 "Operating system": [
  null,
  "Besturingssysteem"
 ],
 "Operation is in progress": [
  null,
  "Bewerking is bezig"
 ],
 "Overview": [
  null,
  "Overzicht"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Ouder momentopname"
 ],
 "Path": [
  null,
  "Pad"
 ],
 "Path on host's filesystem": [
  null,
  "Pan op bestandssysteem van host"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Pad naar ISO-bestand op bestandssysteem van host"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Pad naar cloud-image op bestandssysteem van host"
 ],
 "Path to file on host's file system": [
  null,
  "Pad naar bestand op bestandssysteem van host"
 ],
 "Pause": [
  null,
  "Pauze"
 ],
 "Paused": [
  null,
  "Gepauzeerd"
 ],
 "Permanent (default)": [
  null,
  "Permanent (standaard)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Toestemming geweigerd voor schijfimages in thuis-mappen"
 ],
 "Persistence": [
  null,
  "Volhardend"
 ],
 "Persistent": [
  null,
  "Aanhoudend"
 ],
 "Physical disk device": [
  null,
  "Fysiek schijfapparaat"
 ],
 "Physical disk device on host": [
  null,
  "Fysiek schijfapparaat op host"
 ],
 "Please choose a storage pool": [
  null,
  "Kies een opslagpool"
 ],
 "Please choose a volume": [
  null,
  "Kies een volume"
 ],
 "Please enter new volume name": [
  null,
  "Voer een nieuwe volumenaam in"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "Start de virtuele machine om toegang te krijgen tot de console."
 ],
 "Pool": [
  null,
  "Pool"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Pool moet actief zijn om volume te creëren"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "Pooltype $0 ondersteunt geen volume-creatie"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Pooltype ondersteunt geen volume-creatie"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "De volumes van pool worden gebruikt door VM's "
 ],
 "Port": [
  null,
  "Poort"
 ],
 "Power off": [
  null,
  "Uitschakelen"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Gewenst aantal sockets voor de gast."
 ],
 "Prefix": [
  null,
  "Voorvoegsel"
 ],
 "Prefix length": [
  null,
  "Voorvoegsel-lengte"
 ],
 "Prefix length should not be empty": [
  null,
  "Prefixlengte mag niet leeg zijn"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Met eerder gemaakte momentopnames kun je terugkeren naar een eerdere toestand als er iets misgaat"
 ],
 "Private": [
  null,
  "Privaat"
 ],
 "Product": [
  null,
  "Product"
 ],
 "Profile": [
  null,
  "Profiel"
 ],
 "Protocol": [
  null,
  "Protocol"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Biedt een rechtstreekse brug van de virtuele gastmachine naar het LAN. Hiervoor is een bridge-apparaat op de host nodig met een of meer fysieke NIC's."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Biedt een verbinding waarvan de details worden beschreven door de benoemde netwerkdefinitie."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "Biedt een virtueel LAN met NAT naar de buitenwereld."
 ],
 "Range": [
  null,
  "Reeks"
 ],
 "Read-only": [
  null,
  "Alleen-lezen"
 ],
 "Reboot": [
  null,
  "Opnieuw opstarten"
 ],
 "Remote URL": [
  null,
  "URL op afstand"
 ],
 "Remote viewer details": [
  null,
  "Viewerdetails op afstand"
 ],
 "Remove": [
  null,
  "Verwijderen"
 ],
 "Remove and delete file": [
  null,
  "Bestand verwijderen"
 ],
 "Remove disk from VM?": [
  null,
  "Schijf verwijderen uit VM?"
 ],
 "Remove filesystem?": [
  null,
  "Bestandssysteem verwijderen?"
 ],
 "Remove host device from VM?": [
  null,
  "Hostapparaat verwijderen uit VM?"
 ],
 "Remove network interface?": [
  null,
  "Netwerkinterface verwijderen?"
 ],
 "Remove static host from DHCP": [
  null,
  "Verwijder statische host van DHCP"
 ],
 "Rename": [
  null,
  "Hernoemen"
 ],
 "Rename VM $0": [
  null,
  "Hernoem VM $0"
 ],
 "Reset": [
  null,
  "Resetten"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Beperkingen in netwerken (op SLIRP gebaseerde emulatie) en toewijzing van PCI-apparaten"
 ],
 "Resume": [
  null,
  "Samenvatten"
 ],
 "Revert": [
  null,
  "Terugdraaien"
 ],
 "Revert to snapshot $0": [
  null,
  "Keer terug naar snapshot $0"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Als je terugkeert naar deze snapshot, keert de VM terug naar het moment van de snapshot en gaat de huidige status verloren, samen met alle gegevens die niet in een snapshot zijn vastgelegd"
 ],
 "Root password": [
  null,
  "Rootwachtwoord"
 ],
 "Route to $0": [
  null,
  "Route naar $0"
 ],
 "Routed network": [
  null,
  "Gerouteerd netwerk"
 ],
 "Run": [
  null,
  "Uitvoeren"
 ],
 "Run when host boots": [
  null,
  "Uitvoeren wanneer de host opstart"
 ],
 "Running": [
  null,
  "Actief"
 ],
 "SPICE TLS port": [
  null,
  "SPICE TLS poort"
 ],
 "SPICE address": [
  null,
  "SPICE adres"
 ],
 "SPICE port": [
  null,
  "SPICE poort"
 ],
 "Save": [
  null,
  "Opslaan"
 ],
 "Select console type": [
  null,
  "Selecteer consoletype"
 ],
 "Send key": [
  null,
  "Verzend sleutel"
 ],
 "Send non-maskable interrupt": [
  null,
  "Verzend niet-maskeerbare onderbreking"
 ],
 "Serial": [
  null,
  "Serieel"
 ],
 "Serial console": [
  null,
  "Seriële console"
 ],
 "Serial console ($0)": [
  null,
  "Seriële console ($0)"
 ],
 "Set DHCP range": [
  null,
  "Stel DHCP-bereik in"
 ],
 "Set manually": [
  null,
  "Stel handmatig in"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Het instellen van de gebruikerswachtwoorden voor installatie zonder toezicht vereist het starten van de VM bij het maken ervan"
 ],
 "Share": [
  null,
  "Delen"
 ],
 "Share a host directory with the guest": [
  null,
  "Deel een hostmap met de gast"
 ],
 "Shared directories": [
  null,
  "Gedeelde mappen"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Gedeelde hostmappen moeten handmatig in de VM worden aangekoppeld"
 ],
 "Shared storage": [
  null,
  "Gedeelde opslag"
 ],
 "Show additional options": [
  null,
  "Extra opties tonen"
 ],
 "Shut down": [
  null,
  "Afsluiten"
 ],
 "Shut off": [
  null,
  "Uitgeschakeld"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Schakel de VM uit om de firmwareconfiguratie te bewerken"
 ],
 "Shutting down": [
  null,
  "Afsluiten"
 ],
 "Size": [
  null,
  "Grootte"
 ],
 "Slot": [
  null,
  "Slot"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "Snapshot $0 kon niet worden verwijderd"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "Snapshot $0 wordt verwijderd uit $1. Alle vastgelegde inhoud gaat verloren."
 ],
 "Snapshot failed to be created": [
  null,
  "Momentopname kon niet aangemaakt worden"
 ],
 "Snapshots": [
  null,
  "Momentopnames"
 ],
 "Sockets": [
  null,
  "Sockets"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "Sommige configuratiewijzigingen worden pas van kracht na een nieuwe start:"
 ],
 "Source": [
  null,
  "Bron"
 ],
 "Source format": [
  null,
  "Bronformaat"
 ],
 "Source must not be empty": [
  null,
  "Bron mag niet leeg zijn"
 ],
 "Source path": [
  null,
  "Bronpad"
 ],
 "Source path should not be empty": [
  null,
  "Bronpad mag niet leeg zijn"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "Bron moet beginnen met http, ftp of nfs protocol"
 ],
 "Source volume group": [
  null,
  "Bron volumegroep"
 ],
 "Start": [
  null,
  "Start"
 ],
 "Start pool when host boots": [
  null,
  "Start pool wanneer host opstart"
 ],
 "Start should not be empty": [
  null,
  "Start mag niet leeg zijn"
 ],
 "Startup": [
  null,
  "Opstarten"
 ],
 "State": [
  null,
  "Toestand"
 ],
 "Static host entries": [
  null,
  "Statische hostingangen"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "Statische host van DHCP kon niet worden verwijderd"
 ],
 "Storage": [
  null,
  "Opslag"
 ],
 "Storage is at a shared location": [
  null,
  "Opslag is op een gedeelde locatie"
 ],
 "Storage limit": [
  null,
  "Opslaglimiet"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "Opslagpool $0 kan niet geactiveerd worden"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "Opslagpool $0 kan niet gedeactiveerd worden"
 ],
 "Storage pool failed to be created": [
  null,
  "Opslagpool kan niet worden gemaakt"
 ],
 "Storage pool name": [
  null,
  "Opslagpoolnaam"
 ],
 "Storage pools": [
  null,
  "Opslagpools"
 ],
 "Storage pools could not be fetched": [
  null,
  "Opslagpools kunnen niet worden opgehaald"
 ],
 "Storage size must not be 0": [
  null,
  "Opslaggrootte mag niet nul zijn"
 ],
 "Storage volume": [
  null,
  "Opslagvolume"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "De grootte van het opslagvolume mag de capaciteit van de opslagpool niet overschrijden ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "Opslagvolumes"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Opslagvolumes konden niet verwijderd worden"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Opslagvolumes moeten worden gedeeld tussen deze host en de doelhost."
 ],
 "Suspended (PM)": [
  null,
  "Geschorst (PM)"
 ],
 "System": [
  null,
  "Systeem"
 ],
 "Table of selectable host devices": [
  null,
  "Tabel met selecteerbare hostapparaten"
 ],
 "Target": [
  null,
  "Doel"
 ],
 "Target path": [
  null,
  "Doelpad"
 ],
 "Target path should not be empty": [
  null,
  "Doelpad mag niet leeg zijn"
 ],
 "Temporary": [
  null,
  "Tijdelijk"
 ],
 "Temporary migration": [
  null,
  "Tijdelijke migratie"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "De VM $0 is actief en wordt vóór verwijdering uitgeschakeld."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "De VM moet actief of uitgeschakeld zijn om dit apparaat te ontkoppelen"
 ],
 "The directory on the server being exported": [
  null,
  "De map op de server die wordt geëxporteerd"
 ],
 "The host path that is to be exported.": [
  null,
  "Het hostpad dat moet worden geëxporteerd."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "De gemigreerde VM-configuratie wordt verwijderd van de bronhost. De doelhost wordt beschouwd als de nieuwe thuisbasis van de VM."
 ],
 "The pool is empty": [
  null,
  "De pool is leeg"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Het geselecteerde besturingssysteem heeft een minimale geheugenvereiste van $0 $1"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Het geselecteerde besturingssysteem heeft een minimale geheugengroottevereiste van $ 0 $ 1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "Het statische hostitem voor $0 wordt verwijderd:"
 ],
 "The storage pool could not be deleted": [
  null,
  "De opslagpool kon niet verwijderd worden"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "De tagnaam die door de gast moet worden gebruikt om dit exportpunt aan te koppelen."
 ],
 "Then copy and paste it above.": [
  null,
  "Kopieer en plak het dan hierboven."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Deze virtuele machine is van voorbijgaande aard. Sluit het af als je het wilt verwijderen."
 ],
 "This disk will be removed from $0:": [
  null,
  "Deze schijf wordt verwijderd uit $0:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Dit bestandssysteem wordt verwijderd van $0:"
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Dit is de aanbevolen configuratie voor algemene gastconnectiviteit op hosts met dynamische/draadloze netwerkconfiguraties."
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Dit is de aanbevolen configuratie voor algemene gastconnectiviteit op hosts met statische bedrade netwerkconfiguraties."
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  "Dit is de aanbevolen configuratie voor hoge prestaties of verbeterde beveiliging."
 ],
 "This volume is already used by $0.": [
  null,
  "Dit volume wordt al gebruikt door $0."
 ],
 "This volume is already used by another VM.": [
  null,
  "Dit volume wordt al gebruikt door een andere VM."
 ],
 "Threads per core": [
  null,
  "Threads per kern"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Tijdelijke VM's bieden geen ondersteuning voor het bewerken van firmwareconfiguratie"
 ],
 "Troubleshoot": [
  null,
  "Problemen"
 ],
 "Type": [
  null,
  "Type"
 ],
 "Type ID": [
  null,
  "Type-ID"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (ISO image of distro installatieboom)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Onbepaald"
 ],
 "Unique name": [
  null,
  "Unieke naam"
 ],
 "Unique name, default: $0": [
  null,
  "Unieke naam, standaard: $0"
 ],
 "Unique network name": [
  null,
  "Unieke netwerknaam"
 ],
 "Unit": [
  null,
  "Unit"
 ],
 "Unknown": [
  null,
  "Onbekend"
 ],
 "Unknown firmware": [
  null,
  "Onbekende firmware"
 ],
 "Unspecified": [
  null,
  "Niet gespecificeerd"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "Gebruik"
 ],
 "Use existing": [
  null,
  "Gebruik bestaande"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Gebruik uitgebreide attributen voor bestanden en mappen"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Gebruik dezelfde locatie op zowel de herkomst- als de bestemmingshost voor je opslag. Dit kan een gedeelde opslagpool, NFS of een andere methode voor het delen van opslag zijn."
 ],
 "Used": [
  null,
  "Gebruikt"
 ],
 "Used by": [
  null,
  "Gebruikt door"
 ],
 "User login": [
  null,
  "Gebruikersaanmelding"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Gebruikersaanmelding mag niet leeg zijn als het gebruikerswachtwoord is ingesteld"
 ],
 "User password": [
  null,
  "Gebruikerswachtwoord"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Het gebruikerswachtwoord mag niet leeg zijn als gebruikersaanmelding is ingesteld"
 ],
 "User session": [
  null,
  "Gebruikerssessie"
 ],
 "VCPU settings could not be saved": [
  null,
  "VCPU-instellingen konden niet opgeslagen worden"
 ],
 "VM $0 Host Devices": [
  null,
  "VM $0 hostapparaten"
 ],
 "VM $0 already exists": [
  null,
  "VM $0 bestaat al"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "VM $0 bestaat niet op $1 verbinding"
 ],
 "VM $0 failed to force reboot": [
  null,
  "VM $0 kan opnieuw opstarten niet forceren"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "VM $0 kon afsluiten niet forceren"
 ],
 "VM $0 failed to get installed": [
  null,
  "VM $0 kan niet geïnstalleerd worden"
 ],
 "VM $0 failed to pause": [
  null,
  "VM $0 kan niet gepauzeerd worden"
 ],
 "VM $0 failed to reboot": [
  null,
  "VM $0 kon niet opnieuw opstarten"
 ],
 "VM $0 failed to resume": [
  null,
  "VM $0 kan niet hervat worden"
 ],
 "VM $0 failed to send NMI": [
  null,
  "VM $0 kan NMI niet verzenden"
 ],
 "VM $0 failed to shutdown": [
  null,
  "VM $0 kan niet afgesloten worden"
 ],
 "VM $0 failed to start": [
  null,
  "VM $0 kan niet gestart worden"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "VM gelanceerd met onbevoegde beperkte toegang, waarbij het proces en PTY eigendom zijn van je gebruikersaccount"
 ],
 "VM needs shutdown": [
  null,
  "VM moet worden afgesloten"
 ],
 "VM state": [
  null,
  "VM toestand"
 ],
 "VM will launch with root permissions": [
  null,
  "VM wordt gestart met rootrechten"
 ],
 "VNC TLS port": [
  null,
  "VNC TLS-poort"
 ],
 "VNC address": [
  null,
  "VNC-adres"
 ],
 "VNC console": [
  null,
  "VNC-console"
 ],
 "VNC port": [
  null,
  "VNC-poort"
 ],
 "Valid token": [
  null,
  "Geldig token"
 ],
 "Vendor": [
  null,
  "Leverancier"
 ],
 "Virtual machines": [
  null,
  "Virtuele machines"
 ],
 "Virtual machines management": [
  null,
  "Beheer van virtuele machines"
 ],
 "Virtual network": [
  null,
  "Virtueel netwerk"
 ],
 "Virtual network failed to be created": [
  null,
  "Virtueel netwerk kan niet aangemaakt worden"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Virtualisatieservice (libvirt) is niet actief"
 ],
 "Volume": [
  null,
  "Volume"
 ],
 "Volume failed to be created": [
  null,
  "Volume kan niet aangemaakt worden"
 ],
 "Volume group name": [
  null,
  "Naam van volumegroep"
 ],
 "Volume group name should not be empty": [
  null,
  "Naam van volumegroep mag niet leeg zijn"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Bewaker"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Bewakers komen in actie wanneer de systemen niet meer reageren. Om dit virtuele watchdog-apparaat te gebruiken, moet het gastsysteem ook een extra stuurprogramma en een draaiende watchdog-service hebben."
 ],
 "Writeable": [
  null,
  "Beschrijfbaar"
 ],
 "Writeable and shared": [
  null,
  "Beschrijfbaar en gedeeld"
 ],
 "You can mount the shared folder using:": [
  null,
  "Je kunt de gedeelde map aankoppelen met:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "Je moet het meest overeenkomende besturingssysteem selecteren"
 ],
 "active": [
  null,
  "actief"
 ],
 "add": [
  null,
  "toevoegen"
 ],
 "add entry": [
  null,
  "voeg ingang toe"
 ],
 "bridge": [
  null,
  "brug"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "aangepast"
 ],
 "direct": [
  null,
  "direct"
 ],
 "disabled": [
  null,
  "uitgeschakeld"
 ],
 "disk": [
  null,
  "schijf"
 ],
 "down": [
  null,
  "niet actief"
 ],
 "edit": [
  null,
  "bewerken"
 ],
 "enabled": [
  null,
  "ingeschakeld"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "host"
 ],
 "host device": [
  null,
  "hostapparaat"
 ],
 "host passthrough": [
  null,
  "host doorgeven"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "iSCSI direct doel"
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI-initiator IQN"
 ],
 "iSCSI target": [
  null,
  "iSCSI-doel"
 ],
 "iSCSI target IQN": [
  null,
  "iSCSI-doel IQN"
 ],
 "inactive": [
  null,
  "inactief"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "meer info"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "aankoppelpunt: Het aankoppelpunt in de gast"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "aankoppel-tag: de tag die is gekoppeld aan het geëxporteerde aankoppelpunt"
 ],
 "network": [
  null,
  "netwerk"
 ],
 "no": [
  null,
  "nee"
 ],
 "no state saved": [
  null,
  "geen toestand opgeslagen"
 ],
 "none": [
  null,
  "geen"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "omgeleid apparaat"
 ],
 "remove": [
  null,
  "verwijderen"
 ],
 "serial number": [
  null,
  "serienummer"
 ],
 "server": [
  null,
  "server"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "actief"
 ],
 "user": [
  null,
  "gebruiker"
 ],
 "vCPU count": [
  null,
  "vCPU telling"
 ],
 "vCPU maximum": [
  null,
  "vCPU maximum"
 ],
 "vCPUs": [
  null,
  "vCPU's"
 ],
 "vhostuser": [
  null,
  "vhost-gebruiker"
 ],
 "view more...": [
  null,
  "bekijk meer..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "virt-install pakket moet op het systeem geïnstalleerd worden om VM's te klonen"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "virt-install pakket moet op het systeem geïnstalleerd worden om nieuwe VM's te creëren"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "virt-install pakket moet op het systeem geïnstalleerd worden om dit kenmerk te bewerken"
 ],
 "vm": [
  null,
  "vm"
 ],
 "yes": [
  null,
  "ja"
 ]
});
