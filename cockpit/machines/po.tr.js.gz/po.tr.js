cockpit.locale({
 "": {
  "plural-forms": (n) => (n>1),
  "language": "tr",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "Öntanımlı konumda $0 $1 kullanılabilir"
 ],
 "$0 $1 available on host": [
  null,
  "Ana makinede $0 $1 kullanılabilir"
 ],
 "$0 CPU configuration": [
  null,
  "$0 CPU yapılandırması"
 ],
 "$0 Network": [
  null,
  "$0 Ağ",
  "$0 Ağ"
 ],
 "$0 Storage pool": [
  null,
  "$0 Depolama havuzu",
  "$0 Depolama havuzu"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0 katılımsız kurulumu desteklemiyor."
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0, çoğu işletim sisteminde kullanılabilir. Yüklemek için GNOME Yazılımı'nda arayın veya aşağıdaki komutu çalıştırın:"
 ],
 "$0 memory adjustment": [
  null,
  "$0 bellek ayarlaması"
 ],
 "$0 network": [
  null,
  "$0 ağ"
 ],
 "$0 vCPU": [
  null,
  "$0 vCPU",
  "$0 vCPU"
 ],
 "$0 vCPU details": [
  null,
  "$0 vCPU ayrıntıları"
 ],
 "$0 virtual network interface settings": [
  null,
  "$0 sanal ağ arayüzü ayarları"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "Sanal makinenin bir kopyası hedef üzerinde çalışacak ve kapatıldığında kaybolacaktır. Bu arada kaynak ana makine, sanal makine yapılandırmasının kopyasını tutar."
 ],
 "Access": [
  null,
  "Erişim"
 ],
 "Action": [
  null,
  "Eylem"
 ],
 "Activate": [
  null,
  "Etkinleştir"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "Birimleri yönetmek için depolama havuzunu etkinleştir"
 ],
 "Add": [
  null,
  "Ekle"
 ],
 "Add a DHCP static host entry": [
  null,
  "DHCP statik ana makine girdisi ekle"
 ],
 "Add disk": [
  null,
  "Disk ekle"
 ],
 "Add host device": [
  null,
  "Anamakine aygıtı ekle"
 ],
 "Add network interface": [
  null,
  "Ağ arayüzü ekle"
 ],
 "Add shared directory": [
  null,
  "Paylaşılan dizin ekle"
 ],
 "Add virtual network interface": [
  null,
  "Sanal ağ arayüzü ekle"
 ],
 "Add watchdog device type": [
  null,
  "Gözlemci aygıt türü ekle"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "Paylaşılan dizinler eklemek yalnızca konuk kapalı olduğunda mümkündür"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  "Bu diskin eklenmesi erişim modunu paylaşılan olarak değiştirecektir."
 ],
 "Additional": [
  null,
  "Ek"
 ],
 "Address": [
  null,
  "Adres"
 ],
 "Address not within subnet": [
  null,
  "Adres alt ağ içinde değil"
 ],
 "All": [
  null,
  "Tümü"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "Depolama dahil tüm sanal makine etkinliği geçici olacaktır. Bu, hedef ana makinede veri kaybına neden olacaktır."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "İzin verilen karakterler: temel Latin alfabesi, sayılar ve sınırlı noktalama işaretleri (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "Ayrıca bu havuzun içindeki tüm birimleri sil:"
 ],
 "Always attach": [
  null,
  "Her zaman bağla"
 ],
 "Apply": [
  null,
  "Uygula"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "Otomatik kurulumlar yalnızca bir kalıp indirilirken veya cloud-init ile kullanılabilir."
 ],
 "Automatic": [
  null,
  "Otomatik"
 ],
 "Automation": [
  null,
  "Otomasyon"
 ],
 "Autostart": [
  null,
  "Otomatik başlat"
 ],
 "Blocked": [
  null,
  "Engellendi"
 ],
 "Boot order": [
  null,
  "Önyükleme sırası"
 ],
 "Boot order settings could not be saved": [
  null,
  "Önyükleme sırası ayarları kaydedilemedi"
 ],
 "Bus": [
  null,
  "Veri yolu"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD disk"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU configuration could not be saved": [
  null,
  "CPU yapılandırması kaydedilemedi"
 ],
 "CPU type": [
  null,
  "CPU türü"
 ],
 "Cache": [
  null,
  "Önbellek"
 ],
 "Cancel": [
  null,
  "İptal"
 ],
 "Capacity": [
  null,
  "Kapasite"
 ],
 "Change boot order": [
  null,
  "Önyükleme sırasını değiştir"
 ],
 "Change firmware": [
  null,
  "Aygıt yazılımını değiştir"
 ],
 "Changes pending": [
  null,
  ""
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "Değişiklikler, sanal makine kapatıldıktan sonra etkili olacaktır"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  ""
 ],
 "Checking token validity...": [
  null,
  "Belirteç geçerliliği denetleniyor..."
 ],
 "Choose an operating system": [
  null,
  "Bir işletim sistemi seçin"
 ],
 "Class": [
  null,
  "Sınıf"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "\"Remote Viewer'ı Başlat\"a tıklamak bir .vv dosyası indirecek ve $0 başlatılacak."
 ],
 "Clone": [
  null,
  "Kopya"
 ],
 "Close": [
  null,
  "Kapat"
 ],
 "Cloud base image": [
  null,
  "Bulut temel kalıbı"
 ],
 "Confirm this action": [
  null,
  "Bu eylemi onayla"
 ],
 "Connect": [
  null,
  "Bağlan"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "Aşağıdaki protokoller için herhangi bir görüntüleyici uygulamasıyla bağlan"
 ],
 "Connecting": [
  null,
  "Bağlanıyor"
 ],
 "Connection": [
  null,
  "Bağlantı"
 ],
 "Console": [
  null,
  "Konsol"
 ],
 "Copy storage": [
  null,
  "Depolamayı kopyala"
 ],
 "Cores per socket": [
  null,
  "Soket başına çekirdek sayısı"
 ],
 "Could not delete $0": [
  null,
  "$0 silinemedi"
 ],
 "Could not revert to snapshot": [
  null,
  "Anlık görüntüye geri döndürülemedi"
 ],
 "Crashed": [
  null,
  "Çöktü"
 ],
 "Create": [
  null,
  "Oluştur"
 ],
 "Create VM": [
  null,
  "Sanal makine oluştur"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "Mevcut bir sanal makine kurulumunun disk kalıbını içe aktararak sanal makine oluşturun"
 ],
 "Create VM from local or network installation medium": [
  null,
  "Yerel veya ağ kurulum ortamından sanal makine oluşturun"
 ],
 "Create a clone VM based on $0": [
  null,
  "$ 0'a dayalı bir kopya sanal makine oluştur"
 ],
 "Create and edit": [
  null,
  "Oluştur ve düzenle"
 ],
 "Create and run": [
  null,
  "Oluştur ve çalıştır"
 ],
 "Create new": [
  null,
  "Yeni oluştur"
 ],
 "Create new virtual machine": [
  null,
  "Yeni sanal makine oluştur"
 ],
 "Create new volume": [
  null,
  "Yeni birim oluştur"
 ],
 "Create snapshot": [
  null,
  "Anlık görüntü oluştur"
 ],
 "Create storage pool": [
  null,
  "Depolama havuzu oluştur"
 ],
 "Create storage volume": [
  null,
  "Depolama birimi oluştur"
 ],
 "Create virtual network": [
  null,
  "Sanal ağ oluştur"
 ],
 "Create volume": [
  null,
  "Birim oluştur"
 ],
 "Creating VM": [
  null,
  "Sanal makine oluşturuluyor"
 ],
 "Creating VM $0": [
  null,
  "$0 sanal makinesi oluşturuluyor"
 ],
 "Creation of VM $0 failed": [
  null,
  "$0 sanal makinesini oluşturma başarısız oldu"
 ],
 "Creation time": [
  null,
  "Oluşturma zamanı"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "Şu anki"
 ],
 "Current allocation": [
  null,
  "Şu anki ayırma"
 ],
 "Custom firmware: $0": [
  null,
  "Özel aygıt yazılımı: $0"
 ],
 "Custom path": [
  null,
  "Özel yol"
 ],
 "DHCP Settings": [
  null,
  "DHCP Ayarları"
 ],
 "Deactivate": [
  null,
  "Devre dışı bırak"
 ],
 "Delete": [
  null,
  "Sil"
 ],
 "Delete $0 VM?": [
  null,
  "$0 sanal makinesi silinsin mi?"
 ],
 "Delete $0 storage pool?": [
  null,
  "$0 depolama havuzu silinsin mi?"
 ],
 "Delete $0 volume": [
  null,
  "$0 birimi sil",
  "$0 birimi sil"
 ],
 "Delete associated storage files:": [
  null,
  "İlişkili depolama dosyalarını sil:"
 ],
 "Delete network?": [
  null,
  "Ağ silinsin mi?"
 ],
 "Delete snapshot?": [
  null,
  "Anlık görüntü silinsin mi?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "Etkin olmayan bir depolama havuzunu silmek, sadece havuzun tanımını kaldıracaktır. İçeriği silinmeyecektir."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "Paylaşılan dizinleri silmek yalnızca konuk kapalı olduğunda mümkündür"
 ],
 "Description": [
  null,
  "Açıklama"
 ],
 "Desktop viewer": [
  null,
  "Masaüstü görüntüleyicisi"
 ],
 "Destination URI": [
  null,
  "Hedef URI"
 ],
 "Destination URI must not be empty": [
  null,
  "Hedef URI boş olmamalıdır"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "Silmeyi denemeden önce bu havuzu kullanan diskleri herhangi bir sanal makineden ayırın."
 ],
 "Details": [
  null,
  "Ayrıntılar"
 ],
 "Device": [
  null,
  "Aygıt"
 ],
 "Devices": [
  null,
  "Aygıtlar"
 ],
 "Disconnect": [
  null,
  "Bağlantıyı kes"
 ],
 "Disconnected": [
  null,
  "Bağlantı kesildi"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "Seri konsoldan bağlantı kesildi. Bağlan düğmesine tıklayın."
 ],
 "Disk $0 could not be removed": [
  null,
  "$0 diski kaldırılamadı"
 ],
 "Disk failed to be attached": [
  null,
  "Diskin bağlanması başarısız oldu"
 ],
 "Disk failed to be created": [
  null,
  "Diskin oluşturulması başarısız oldu"
 ],
 "Disk identifier": [
  null,
  "Disk tanımlayıcısı"
 ],
 "Disk image": [
  null,
  "Disk kalıbı"
 ],
 "Disk image file": [
  null,
  "Disk kalıp dosyası"
 ],
 "Disk image path must not be empty": [
  null,
  "Disk kalıbı yolu boş olmamalıdır"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "Disk kalıpları kullanıcı ev dizininde saklanabilir"
 ],
 "Disk settings could not be saved": [
  null,
  "Disk ayarları kaydedilemedi"
 ],
 "Disk-only snapshot": [
  null,
  "Sadece disk anlık görüntüsü"
 ],
 "Disks": [
  null,
  "Diskler"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "Bu sanal makineyi kaynak ve hedef ana makinede aynı anda çalıştırmayın."
 ],
 "Do nothing": [
  null,
  "Hiçbir şey yapma"
 ],
 "Domain has crashed": [
  null,
  "Etki alanı çöktü"
 ],
 "Domain is blocked on resource": [
  null,
  "Etki alanı, kaynakta engellendi"
 ],
 "Download an OS": [
  null,
  "Bir işletim sistemi indir"
 ],
 "Download progress": [
  null,
  "İndirme ilerlemesi"
 ],
 "Downloading image for VM $0": [
  null,
  "$0 sanal makinesi için kalıp indiriliyor"
 ],
 "Downloading: $0%": [
  null,
  "İndiriliyor: %$0"
 ],
 "Dump core": [
  null,
  "Çekirdek dökümü yap"
 ],
 "Duration": [
  null,
  "Süre"
 ],
 "Dying": [
  null,
  "Sonlanıyor"
 ],
 "Edit": [
  null,
  "Düzenle"
 ],
 "Edit $0 attributes": [
  null,
  "$0 özniteliklerini düzenle"
 ],
 "Edit watchdog device type": [
  null,
  "Gözlemci aygıt türünü düzenle"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "Geçici konukların ağ arayüzlerini düzenlemeye izin verilmiyor"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "Geçici ağ arayüzlerini düzenlemeye izin verilmiyor"
 ],
 "Eject": [
  null,
  "Çıkar"
 ],
 "Eject disc from VM?": [
  null,
  "Disk sanal makineden çıkarılsın mı?"
 ],
 "Emulated machine": [
  null,
  "Benzetilmiş makine"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  ""
 ],
 "End": [
  null,
  "Bitiş"
 ],
 "End should not be empty": [
  null,
  "Bitiş boş olmamalıdır"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "Katılımsız kurulumu etkinleştirmek için root ve/veya kullanıcı bilgilerini girin."
 ],
 "Error checking token": [
  null,
  "Belirteç denetlenirken hata oluştu"
 ],
 "Example, $0": [
  null,
  "Örneğin, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "Anamakinenin dosya sisteminde varolan disk kalıbı"
 ],
 "Expand": [
  null,
  "Genişlet"
 ],
 "Extended attributes": [
  null,
  "Genişletilmiş öznitelikler"
 ],
 "Failed": [
  null,
  "Başarısız oldu"
 ],
 "Failed to add shared directory": [
  null,
  "Paylaşılan dizin ekleme başarısız oldu"
 ],
 "Failed to change firmware": [
  null,
  "Aygıt yazılımını değiştirme başarısız oldu"
 ],
 "Failed to clone VM $0": [
  null,
  "$0 sanal makinesini çoğaltma başarısız oldu"
 ],
 "Failed to configure watchdog": [
  null,
  "Gözlemci yapılandırma başarısız oldu"
 ],
 "Failed to detach watchdog": [
  null,
  "Gözlemci ayırma başarısız oldu"
 ],
 "Failed to fetch some resources": [
  null,
  "Bazı kaynakların alınması başarısız oldu"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "$0 içinde bulunan arayüzlerin IP adreslerinin alınması başarısız oldu"
 ],
 "Failed to rename VM $0": [
  null,
  "$0 sanal makinesini yeniden adlandırma başarısız oldu"
 ],
 "Failed to save network settings": [
  null,
  "Ağ ayarları kaydedilemedi"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Ctrl+Alt+$0 tuş birleşimini $1 sanal makinesine gönderme başarısız oldu"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "En fazla sanal CPU sayısından daha azı etkinleştirilmelidir."
 ],
 "File": [
  null,
  "Dosya"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "$0 dosya sistemi kaldırılamadı"
 ],
 "Filesystem directory": [
  null,
  "Dosya sistemi dizini"
 ],
 "Filter by name": [
  null,
  "Ada göre süz"
 ],
 "Firmware": [
  null,
  "Aygıt yazılımı"
 ],
 "Force eject": [
  null,
  "Çıkarmaya zorla"
 ],
 "Force reboot": [
  null,
  "Yeniden başlatmaya zorla"
 ],
 "Force revert": [
  null,
  "Geri döndürmeye zorla"
 ],
 "Force shut down": [
  null,
  "Kapatmaya zorla"
 ],
 "Format": [
  null,
  "Biçimlendir"
 ],
 "Forward mode": [
  null,
  "Yönlendirme kipi"
 ],
 "Forwarding mode": [
  null,
  "Yönlendirme kipi"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "Tam disk kalıpları ve etki alanının belleği taşınacaktır. Yalnızca paylaşılmayan, yazılabilir disk kalıpları aktarılacaktır. Kullanılmayan depolama, taşınmadan sonra kaynakta kalacaktır."
 ],
 "General": [
  null,
  "Genel"
 ],
 "Generate automatically": [
  null,
  "Otomatik olarak oluştur"
 ],
 "Get a new RHSM token.": [
  null,
  "Yeni bir RHSM belirteci edinin."
 ],
 "GiB": [
  null,
  "GiB"
 ],
 "Go to VMs list": [
  null,
  "Sanal makineler listesine git"
 ],
 "Good choice for desktop virtualization": [
  null,
  "Masaüstü sanallaştırması için iyi seçim"
 ],
 "Gracefully shutdown": [
  null,
  "Düzgün şekilde kapat"
 ],
 "Hide additional options": [
  null,
  "Ek seçenekleri gizle"
 ],
 "Host": [
  null,
  "Anamakine"
 ],
 "Host device": [
  null,
  "Anamakine aygıtı"
 ],
 "Host device could not be attached": [
  null,
  "Anamakine aygıtı eklenemedi"
 ],
 "Host device will be removed from $0:": [
  null,
  "Ana makine $0 sanal makinesinden kaldırılacak:"
 ],
 "Host devices": [
  null,
  "Ana makine aygıtları"
 ],
 "Host name": [
  null,
  "Anamakine adı"
 ],
 "Host should not be empty": [
  null,
  "Anamakine boş olmamalıdır"
 ],
 "Hypervisor details": [
  null,
  "Hipervizör ayrıntıları"
 ],
 "ID": [
  null,
  "Kimlik"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP adresi"
 ],
 "IP address must not be empty": [
  null,
  "IP adresi boş olmamak zorundadır"
 ],
 "IP configuration": [
  null,
  "IP yapılandırması"
 ],
 "IPv4 address": [
  null,
  "IPv4 adresi"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  "IPv4 adresi ağ tanımlayıcısı ile aynı olamaz"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "IPv4 adresi ağın genel yayın adresiyle ile aynı olamaz"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 ve IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4 ağı boş olmamalıdır"
 ],
 "IPv4 only": [
  null,
  "Sadece IPv4"
 ],
 "IPv6 address": [
  null,
  "IPv6 adresi"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6 ağı boş olmamalıdır"
 ],
 "IPv6 only": [
  null,
  "Sadece IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "Sunucu sanal makineleri için uygun"
 ],
 "Ideal networking support": [
  null,
  "Uygun ağ desteği"
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "Tanımlayıcı sessizce $0 karaktere kadar kısaltılabilir "
 ],
 "Idle": [
  null,
  "Boşta"
 ],
 "Ignore": [
  null,
  ""
 ],
 "Import VM": [
  null,
  "Sanal makineyi içe aktar"
 ],
 "Import a virtual machine": [
  null,
  "Bir sanal makineyi içe aktar"
 ],
 "Import and edit": [
  null,
  "İçe aktar ve düzenle"
 ],
 "Import and run": [
  null,
  "İçe aktar ve çalıştır"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "Destek dosyası olan bir kalıbın içe aktarılması desteklenmiyor"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "Çoğu yapılandırmada, anamakineden konuğa ağ iletişimi için macvtap çalışmaz."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  "Öntanımlı 'vepa' modunda, anahtarlama harici anahtar tarafından yapılır. Anahtar VEPA özellikli değilse, konuk sanal makineleri arasında veya konuk ile ana makine arasında iletişim mümkün değildir."
 ],
 "Initiator": [
  null,
  "Başlatıcı"
 ],
 "Initiator IQN should not be empty": [
  null,
  "Başlatıcı IQN boş olmamalıdır"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "Maskelenemez kesme gönder"
 ],
 "Insert": [
  null,
  "Tak"
 ],
 "Insert disc media": [
  null,
  "Disk ortamını tak"
 ],
 "Install": [
  null,
  "Yükle"
 ],
 "Installation source": [
  null,
  "Kurulum kaynağı"
 ],
 "Installation source must not be empty": [
  null,
  "Kurulum kaynağı boş olmamalıdır"
 ],
 "Installation type": [
  null,
  "Kurulum türü"
 ],
 "Interface": [
  null,
  "Arayüz"
 ],
 "Interface type": [
  null,
  "Arayüz türü"
 ],
 "Interface type help": [
  null,
  "Arayüz türü yardımı"
 ],
 "Invalid IPv4 address": [
  null,
  "Geçersiz IPv4 adresi"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "Geçersiz IPv4 maskesi veya ön ek uzunluğu"
 ],
 "Invalid IPv6 address": [
  null,
  "Geçersiz IPv6 adresi"
 ],
 "Invalid IPv6 prefix": [
  null,
  "Geçersiz IPv6 ön eki"
 ],
 "Invalid filename": [
  null,
  "Geçersiz dosya adı"
 ],
 "Isolated network": [
  null,
  "Yalıtılmış ağ"
 ],
 "LVM volume group": [
  null,
  "LVM birimi grubu"
 ],
 "Launch remote viewer": [
  null,
  "Uzak görüntüleyiciyi başlat"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "Bir root hesabının oluşturulmasını istemiyorsanız parolayı boş bırakın"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "Bir kullanıcı hesabının oluşturulmasını istemiyorsanız parolayı boş bırakın"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "Bir root parolası ayarlamak istemiyorsanız parolayı boş bırakın"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt, anamakinede yüklü herhangi bir UEFI/OVMF aygıt yazılımı kalıbı algılamadı"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt veya hipervizör UEFI'yi desteklemiyor"
 ],
 "Loading available network devices": [
  null,
  "Kullanılabilir ağ aygıtları yükleniyor"
 ],
 "Loading resources": [
  null,
  "Kaynaklar yükleniyor"
 ],
 "Loading...": [
  null,
  "Yükleniyor..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "Yerel kurulum ortamı (ISO kalıbı veya dağıtım kurulum ağacı)"
 ],
 "Location": [
  null,
  "Konum"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC adresi"
 ],
 "MAC address must not be empty": [
  null,
  "MAC adresi boş olmamak zorundadır"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "Veri yolu türünü değiştirmeden önce makine kapatılmak zorundadır"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "Önbellek kipini değiştirmeden önce makine kapatılmak zorundadır"
 ],
 "Managing virtual machines": [
  null,
  "Sanal makineleri yönetme"
 ],
 "Manual connection": [
  null,
  "Elle bağlantı"
 ],
 "Mask or prefix length": [
  null,
  "Maske veya ön ek uzunluğu"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "Maske veya ön ek uzunluğu boş olmamalıdır"
 ],
 "Maximum allocation": [
  null,
  "En fazla ayırma"
 ],
 "Maximum memory could not be saved": [
  null,
  "En fazla bellek kaydedilemedi"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "Konuk işletim sistemi için ayrılmış en fazla sanal CPU sayısı"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "1 ile $0 arasında olmak zorunda olan konuk işletim sistemi için ayrılmış en fazla sanal CPU sayısı"
 ],
 "Maximum transmission unit": [
  null,
  "En fazla iletim birimi (MTU)"
 ],
 "Media could not be ejected from $0": [
  null,
  "Ortam $0 sanal makinesinden çıkarılamadı"
 ],
 "Media will be ejected from $0:": [
  null,
  "Ortam $0 sanal makinesinden çıkarılacak:"
 ],
 "Memory": [
  null,
  "Bellek"
 ],
 "Memory could not be saved": [
  null,
  "Bellek kaydedilemedi"
 ],
 "Memory must not be 0": [
  null,
  "Bellek 0 olmamak zorundadır"
 ],
 "MiB": [
  null,
  "MiB"
 ],
 "Migrate": [
  null,
  "Taşı"
 ],
 "Migrate VM to another host": [
  null,
  "Sanal makineyi başka bir ana makineye taşı"
 ],
 "Migration failed": [
  null,
  "Taşıma başarısız oldu"
 ],
 "Mode": [
  null,
  "Kip"
 ],
 "Model": [
  null,
  "Model"
 ],
 "Model type": [
  null,
  "Model türü"
 ],
 "More info for mount tag field": [
  null,
  "Bağlama etiketi alanı için daha fazla bilgi"
 ],
 "More info for source path field": [
  null,
  "Kaynak yolu alanı için daha fazla bilgi"
 ],
 "Mount tag": [
  null,
  "Bağlama etiketi"
 ],
 "Mount tag must not be empty": [
  null,
  "Bağlama etiketi boş olmamalıdır"
 ],
 "NAT to $0": [
  null,
  "$0 ağına NAT yap"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "$1 sanal makinesinin $0 NIC'inin durumunu değiştirme başarısız oldu"
 ],
 "Name": [
  null,
  "Ad"
 ],
 "Name already exists": [
  null,
  "Bu ad zaten var"
 ],
 "Name contains invalid characters": [
  null,
  "Ad geçersiz karakterler içeriyor"
 ],
 "Name must not be empty": [
  null,
  "Ad boş olmamak zorundadır"
 ],
 "Name should not be empty": [
  null,
  "Ad boş olmamalıdır"
 ],
 "Name: ": [
  null,
  "Ad: "
 ],
 "Netmask": [
  null,
  "Ağ maskesi"
 ],
 "Network $0 could not be deleted": [
  null,
  "$0 ağı silinemedi"
 ],
 "Network $0 failed to get activated": [
  null,
  "$0 ağının etkinleştirilmesi başarısız oldu"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "$0 ağının devre dışı bırakılması başarısız oldu"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "$0 ağı kalıcı olarak silinecek."
 ],
 "Network boot (PXE)": [
  null,
  "Ağ üzerinden önyükleme (PXE)"
 ],
 "Network file system": [
  null,
  "Ağ dosya sistemi (NFS)"
 ],
 "Network interface $0 could not be removed": [
  null,
  "$0 ağ arayüzü kaldırılamadı"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "$0 ağ arayüzü $1 sanal makinesinden kaldırılacak"
 ],
 "Network interface settings could not be saved": [
  null,
  "Ağ arayüzü ayarları kaydedilemedi"
 ],
 "Network interfaces": [
  null,
  "Ağ arayüzleri"
 ],
 "Network selection does not support PXE.": [
  null,
  "Ağ seçimi PXE'yi desteklemiyor."
 ],
 "Networks": [
  null,
  "Ağlar"
 ],
 "New name": [
  null,
  "Yeni ad"
 ],
 "New name must not be empty": [
  null,
  "Yeni ad boş olmamalıdır"
 ],
 "New volume name": [
  null,
  "Yeni birim adı"
 ],
 "No VM is running or defined on this host": [
  null,
  "Bu anamakinede çalışan veya tanımlı sanal makine yok"
 ],
 "No boot device found": [
  null,
  "Bulunan önyükleme aygıtı yok"
 ],
 "No connection available": [
  null,
  "Kullanılabilir bağlantı yok"
 ],
 "No description": [
  null,
  "Açıklama yok"
 ],
 "No directories shared between the host and this VM": [
  null,
  "Ana makine ve bu sanal makine arasında paylaşılan dizin yok"
 ],
 "No disks defined for this VM": [
  null,
  "Bu sanal makine için tanımlanan diskler yok"
 ],
 "No host device selected": [
  null,
  "Anamakine aygıtı seçilmedi"
 ],
 "No host devices assigned to this VM": [
  null,
  "Bu sanal makineye atanan ana makine aygıtı yok"
 ],
 "No network devices": [
  null,
  "Ağ aygıtları yok"
 ],
 "No network interfaces defined for this VM": [
  null,
  "Bu sanal makine için tanımlanan ağ arayüzleri yok"
 ],
 "No network is defined on this host": [
  null,
  "Bu anamakinede tanımlı ağ yok"
 ],
 "No networks available": [
  null,
  "Kullanılabilir ağlar yok"
 ],
 "No parent": [
  null,
  "Üst öğe yok"
 ],
 "No snapshots defined for this VM": [
  null,
  "Bu sanal makine için tanımlanan anlık görüntüler yok"
 ],
 "No state": [
  null,
  "Durum yok"
 ],
 "No storage": [
  null,
  "Depolama yok"
 ],
 "No storage pool is defined on this host": [
  null,
  "Bu anamakinede tanımlı depolama havuzu yok"
 ],
 "No storage pools available": [
  null,
  "Kullanılabilir depolama havuzları yok"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "Bu depolama havuzu için tanımlı depolama birimleri yok"
 ],
 "No virtual networks": [
  null,
  "Sanal ağlar yok"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "Bu depolama havuzunda birim yok."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Kalıcı olmayan ağ silinemez. Devre dışı bırakıldığında varlığı sona erer."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "Kalıcı olmayan depolama havuzu silinemez. Devre dışı bırakıldığında varlığı sona erer."
 ],
 "None": [
  null,
  "Yok"
 ],
 "None (isolated network)": [
  null,
  "Yok (yalıtılmış ağ)"
 ],
 "Offline token": [
  null,
  "Çevrim dışı belirteç"
 ],
 "Offline token must not be empty": [
  null,
  "Çevrim dışı belirteç boş olmamalıdır"
 ],
 "Old token expired": [
  null,
  "Eski belirtecin süresi doldu"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "Seçilen bir veya daha fazla birim etki alanları tarafından kullanılıyor. Birimi silmeye izin vermek için önce diskleri ayırın."
 ],
 "Only editable when the guest is shut off": [
  null,
  "Sadece konuk kapatıldığında düzenlenebilir"
 ],
 "Open": [
  null,
  "Açık"
 ],
 "Operating system": [
  null,
  "İşletim sistemi"
 ],
 "Operation is in progress": [
  null,
  "İşlem devam ediyor"
 ],
 "Overview": [
  null,
  "Genel Bakış"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "Üst öğe anlık görüntüsü"
 ],
 "Path": [
  null,
  "Yol"
 ],
 "Path on host's filesystem": [
  null,
  "Anamakinenin dosya sistemi üzerindeki yol"
 ],
 "Path to ISO file on host's file system": [
  null,
  "Anamakinenin dosya sistemi üzerindeki ISO dosyasının yolu"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "Ana makinenin dosya sistemi üzerindeki bulut kalıp dosyasının yolu"
 ],
 "Path to file on host's file system": [
  null,
  "Ana makinenin dosya sistemi üzerindeki dosyanın yolu"
 ],
 "Pause": [
  null,
  "Duraklat"
 ],
 "Paused": [
  null,
  "Duraklatıldı"
 ],
 "Permanent (default)": [
  null,
  "Kalıcı (öntanımlı)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "Ev dizinlerindeki disk kalıpları için izinler reddedildi"
 ],
 "Persistence": [
  null,
  "Kalıcılık"
 ],
 "Persistent": [
  null,
  "Kalıcı"
 ],
 "Physical disk device": [
  null,
  "Fiziksel disk aygıtı"
 ],
 "Physical disk device on host": [
  null,
  "Anamakinedeki fiziksel disk aygıtı"
 ],
 "Please choose a storage pool": [
  null,
  "Lütfen bir depolama havuzu seçin"
 ],
 "Please choose a volume": [
  null,
  "Lütfen bir birim seçin"
 ],
 "Please enter new volume name": [
  null,
  "Lütfen yeni birim adını girin"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "Konsoluna erişmek için lütfen sanal makineyi başlatın."
 ],
 "Pool": [
  null,
  "Havuz"
 ],
 "Pool needs to be active to create volume": [
  null,
  "Birim oluşturmak için havuzun etkin olması gerekir"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "$0 havuz türü birim oluşturmayı desteklemiyor"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "Havuz türü birim oluşturmayı desteklemiyor"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "Havuzun birimleri sanal makineler tarafından kullanılıyor "
 ],
 "Port": [
  null,
  "Bağlantı noktası"
 ],
 "Power off": [
  null,
  "Kapat"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "Konuğa açılacak tercih edilen soket sayısı."
 ],
 "Prefix": [
  null,
  "Ön ek"
 ],
 "Prefix length": [
  null,
  "Ön ek uzunluğu"
 ],
 "Prefix length should not be empty": [
  null,
  "Ön ek uzunluğu boş olmamalıdır"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "Önceden kaydedilmiş anlık görüntüler, bir şeyler ters giderse daha önceki bir duruma geri dönmenizi sağlar"
 ],
 "Private": [
  null,
  "Özel"
 ],
 "Product": [
  null,
  "Ürün"
 ],
 "Profile": [
  null,
  "Profil"
 ],
 "Protocol": [
  null,
  "Protokol"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "Konuk sanal makineden doğrudan LAN'a bir köprü sağlar. Bunun için ana makinede bir veya daha fazla fiziksel NIC'e sahip bir köprü aygıtı gerekir."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "Ayrıntıları adlandırılan ağ tanımıyla açıklanan bir bağlantı sağlar."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "NAT ile dış dünyaya sanal bir LAN sağlar."
 ],
 "Range": [
  null,
  "Aralık"
 ],
 "Read-only": [
  null,
  "Salt-okunur"
 ],
 "Reboot": [
  null,
  "Yeniden başlat"
 ],
 "Remote URL": [
  null,
  "Uzak URL"
 ],
 "Remote viewer details": [
  null,
  "Uzak görüntüleyici ayrıntıları"
 ],
 "Remove": [
  null,
  "Kaldır"
 ],
 "Remove and delete file": [
  null,
  ""
 ],
 "Remove disk from VM?": [
  null,
  "Disk sanal makineden kaldırılsın mı?"
 ],
 "Remove filesystem?": [
  null,
  "Dosya sistemi kaldırılsın mı?"
 ],
 "Remove host device from VM?": [
  null,
  "Anamakine aygıtı sanal makineden kaldırılsın mı?"
 ],
 "Remove network interface?": [
  null,
  "Ağ arayüzü kaldırılsın mı?"
 ],
 "Remove static host from DHCP": [
  null,
  "DHCP'den statik ana makineyi kaldır"
 ],
 "Rename": [
  null,
  "Yeniden adlandır"
 ],
 "Rename VM $0": [
  null,
  "$0 sanal makinesini yeniden adlandır"
 ],
 "Reset": [
  null,
  "Sıfırla"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "Ağ oluşturma (SLIRP tabanlı öykünme) ve PCI aygıt atamasındaki kısıtlamalar"
 ],
 "Resume": [
  null,
  "Devam"
 ],
 "Revert": [
  null,
  "Geri döndür"
 ],
 "Revert to snapshot $0": [
  null,
  "$0 anlık görüntüsüne geri döndür"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "Bu anlık görüntüye geri dönmek, sanal makineyi anlık görüntünün oluşturulduğu zamana geri götürecek ve anlık görüntüde kaydedilmeyen verilerle birlikte şu anki durum kaybedilecektir"
 ],
 "Root password": [
  null,
  "Root parolası"
 ],
 "Route to $0": [
  null,
  "$0 ağına yönlendir"
 ],
 "Routed network": [
  null,
  "Yönlendirilmiş ağ"
 ],
 "Run": [
  null,
  "Çalıştır"
 ],
 "Run when host boots": [
  null,
  "Anamakine önyüklendiğinde çalıştır"
 ],
 "Running": [
  null,
  "Çalışıyor"
 ],
 "SPICE TLS port": [
  null,
  "SPICE TLS bağlantı noktası"
 ],
 "SPICE address": [
  null,
  "SPICE adresi"
 ],
 "SPICE port": [
  null,
  "SPICE bağlantı noktası"
 ],
 "Save": [
  null,
  "Kaydet"
 ],
 "Select console type": [
  null,
  "Konsol türünü seçin"
 ],
 "Send key": [
  null,
  "Tuş gönder"
 ],
 "Send non-maskable interrupt": [
  null,
  "Maskelenemez kesme (NMI) gönder"
 ],
 "Serial": [
  null,
  "Seri"
 ],
 "Serial console": [
  null,
  "Seri konsol"
 ],
 "Serial console ($0)": [
  null,
  "Seri konsol ($0)"
 ],
 "Set DHCP range": [
  null,
  "DHCP aralığını ayarla"
 ],
 "Set manually": [
  null,
  "El ile ayarla"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "Katılımsız kurulum için kullanıcı parolalarının ayarlanması, sanal makinenin oluşturulurken başlatılmasını gerektirir"
 ],
 "Share": [
  null,
  "Paylaş"
 ],
 "Share a host directory with the guest": [
  null,
  "Bir ana makine dizinini konuk ile paylaş"
 ],
 "Shared directories": [
  null,
  "Paylaşılan dizinler"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "Paylaşılan ana makine dizinlerinin sanal makine içinde elle bağlanması gerekir"
 ],
 "Shared storage": [
  null,
  "Paylaşılan depolama"
 ],
 "Show additional options": [
  null,
  "Ek seçenekleri göster"
 ],
 "Shut down": [
  null,
  "Kapat"
 ],
 "Shut off": [
  null,
  "Kapat"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "Aygıt yazılımı yapılandırmasını düzenlemek için sanal makineyi kapatın"
 ],
 "Shutting down": [
  null,
  "Kapatılıyor"
 ],
 "Size": [
  null,
  "Boyut"
 ],
 "Slot": [
  null,
  "Yuva"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "$0 anlık görüntüsü silinemedi"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "$0 anlık görüntüsü, $1 sanal makinesinden silinecek. Kaydedilen tüm içeriği kaybolacaktır."
 ],
 "Snapshot failed to be created": [
  null,
  "Anlık görüntünün oluşturulması başarısız oldu"
 ],
 "Snapshots": [
  null,
  "Anlık görüntüler"
 ],
 "Sockets": [
  null,
  "Soketler"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  ""
 ],
 "Source": [
  null,
  "Kaynak"
 ],
 "Source format": [
  null,
  "Kaynak biçimi"
 ],
 "Source must not be empty": [
  null,
  "Kaynak boş olmamalıdır"
 ],
 "Source path": [
  null,
  "Kaynak yolu"
 ],
 "Source path should not be empty": [
  null,
  "Kaynak yolu boş olmamalıdır"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "Kaynak http, ftp veya nfs protokolüyle başlamalıdır"
 ],
 "Source volume group": [
  null,
  "Kaynak birim grubu"
 ],
 "Start": [
  null,
  "Başlat"
 ],
 "Start pool when host boots": [
  null,
  "Anamakine önyüklendiğinde havuzu başlat"
 ],
 "Start should not be empty": [
  null,
  "Başlangıç boş olmamalıdır"
 ],
 "Startup": [
  null,
  "Başlatma"
 ],
 "State": [
  null,
  "Durum"
 ],
 "Static host entries": [
  null,
  "Statik ana makine girdileri"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "DHCP'den statik ana makine kaldırılamadı"
 ],
 "Storage": [
  null,
  "Depolama"
 ],
 "Storage is at a shared location": [
  null,
  "Depolama, paylaşılan bir konumda"
 ],
 "Storage limit": [
  null,
  "Depolama sınırı"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "$0 depolama havuzunun etkinleştirilmesi başarısız oldu"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "$0 depolama havuzunun devre dışı bırakılması başarısız oldu"
 ],
 "Storage pool failed to be created": [
  null,
  "Depolama havuzunun oluşturulması başarısız oldu"
 ],
 "Storage pool name": [
  null,
  "Depolama havuzu adı"
 ],
 "Storage pools": [
  null,
  "Depolama havuzları"
 ],
 "Storage pools could not be fetched": [
  null,
  "Depolama havuzları alınamadı"
 ],
 "Storage size must not be 0": [
  null,
  "Depolama boyutu 0 olmamak zorundadır"
 ],
 "Storage volume": [
  null,
  "Depolama birimi"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "Depolama birimi boyutu, depolama havuzunun kapasitesini ($0 $1) aşmamak zorundadır"
 ],
 "Storage volumes": [
  null,
  "Depolama birimleri"
 ],
 "Storage volumes could not be deleted": [
  null,
  "Depolama birimleri silinemedi"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "Depolama birimleri, bu ana makine ile hedef ana makine arasında paylaşılmalıdır."
 ],
 "Suspended (PM)": [
  null,
  "Askıya alındı (Güç Yönetimi)"
 ],
 "System": [
  null,
  "Sistem"
 ],
 "Table of selectable host devices": [
  null,
  "Seçilebilir anamakine aygıtları tablosu"
 ],
 "Target": [
  null,
  "Hedef"
 ],
 "Target path": [
  null,
  "Hedef yolu"
 ],
 "Target path should not be empty": [
  null,
  "Hedef yolu boş olmamalıdır"
 ],
 "Temporary": [
  null,
  "Geçici"
 ],
 "Temporary migration": [
  null,
  "Geçici taşıma"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "$0 sanal makinesi çalışıyor ve silinmeden önce kapanmaya zorlanacaktır."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "Bu aygıtı ayırmak için sanal makinenin çalışıyor olması veya kapatılması gerekir"
 ],
 "The directory on the server being exported": [
  null,
  "Dışa aktarılan sunucu üzerindeki dizin"
 ],
 "The host path that is to be exported.": [
  null,
  "Dışa aktarılacak ana makine yolu."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "Taşınan sanal makine yapılandırması kaynak ana makineden kaldırılır. Hedef ana makine, sanal makinenin yeni evi olarak kabul edilir."
 ],
 "The pool is empty": [
  null,
  "Havuz boş"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "Seçilen işletim sisteminin en az $0 $1 bellek gereksinimi var"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "Seçilen işletim sisteminin en az $0 $1 depolama alanı gereksinimi var"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "$0 için statik ana makine girdisi kaldırılacak:"
 ],
 "The storage pool could not be deleted": [
  null,
  "Depolama havuzu silinemedi"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "Konuk tarafından bu dışa aktarma noktasını bağlamak için kullanılacak etiket adı."
 ],
 "Then copy and paste it above.": [
  null,
  "Ardından kopyalayın ve yukarıya yapıştırın."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "Bu sanal makine geçicidir. Silmek istiyorsanız kapatın."
 ],
 "This disk will be removed from $0:": [
  null,
  "Bu disk $0 sanal makinesinden kaldırılacak:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "Bu dosya sistemi $0 sanal makinesinden kaldırılacak:"
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "Bu, dinamik / kablosuz ağ yapılandırmalarına sahip ana makinelerde genel konuk bağlantısı için tavsiye edilen yapılandırmadır."
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "Bu, statik kablolu ağ yapılandırmalarına sahip ana makinelerde genel konuk bağlantısı için tavsiye edilen yapılandırmadır."
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  "Bu, yüksek performans veya gelişmiş güvenlik için tavsiye edilen yapılandırmadır."
 ],
 "This volume is already used by $0.": [
  null,
  "Bu birim zaten $0 tarafından kullanılıyor."
 ],
 "This volume is already used by another VM.": [
  null,
  "Bu birim zaten başka bir sanal makine tarafından kullanılıyor."
 ],
 "Threads per core": [
  null,
  "Çekirdek başına iş parçacığı sayısı"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "Geçici sanal makineler, aygıt yazılımı yapılandırmasını düzenlemeyi desteklemiyor"
 ],
 "Troubleshoot": [
  null,
  "Sorun gider"
 ],
 "Type": [
  null,
  "Tür"
 ],
 "Type ID": [
  null,
  "Tür kimliği"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL (ISO kalıbı veya dağıtım kurulum ağacı)"
 ],
 "USB": [
  null,
  "USB"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "Tanımlanmadı"
 ],
 "Unique name": [
  null,
  "Benzersiz ad"
 ],
 "Unique name, default: $0": [
  null,
  "Benzersiz ad, öntanımlı olarak: $0"
 ],
 "Unique network name": [
  null,
  "Benzersiz ağ adı"
 ],
 "Unit": [
  null,
  "Birim"
 ],
 "Unknown": [
  null,
  "Bilinmiyor"
 ],
 "Unknown firmware": [
  null,
  "Bilinmeyen aygıt yazılımı"
 ],
 "Unspecified": [
  null,
  "Belirtilmedi"
 ],
 "Url": [
  null,
  "URL"
 ],
 "Usage": [
  null,
  "Kullanım"
 ],
 "Use existing": [
  null,
  "Varolanı kullan"
 ],
 "Use extended attributes on files and directories": [
  null,
  "Dosyalarda ve dizinlerde genişletilmiş öznitelikleri kullan"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "Depolama alanınız için hem kaynak hem de hedef ana makinede aynı konumu kullanın. Bu, paylaşılan bir depolama havuzu, NFS veya depolamayı paylaşmanın başka herhangi bir yöntemi olabilir."
 ],
 "Used": [
  null,
  "Kullanılan"
 ],
 "Used by": [
  null,
  "Kullanan"
 ],
 "User login": [
  null,
  "Kullanıcı oturumu açma"
 ],
 "User login must not be empty when user password is set": [
  null,
  "Kullanıcı parolası ayarlandığında kullanıcı oturum açma bilgileri boş olmamalıdır"
 ],
 "User password": [
  null,
  "Kullanıcı parolası"
 ],
 "User password must not be empty when user login is set": [
  null,
  "Kullanıcı oturum açma bilgileri ayarlandığında kullanıcı parolası boş olmamalıdır"
 ],
 "User session": [
  null,
  "Kullanıcı oturumu"
 ],
 "VCPU settings could not be saved": [
  null,
  "VCPU ayarları kaydedilemedi"
 ],
 "VM $0 Host Devices": [
  null,
  "$0 Sanal Makinesi Ana Makine Aygıtları"
 ],
 "VM $0 already exists": [
  null,
  "$0 sanal makinesi zaten var"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "$0 sanal makinesi $1 bağlantısında mevcut değil"
 ],
 "VM $0 failed to force reboot": [
  null,
  "$0 sanal makinesini zorla yeniden başlatma başarısız oldu"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "$0 sanal makinesini zorla kapatma başarısız oldu"
 ],
 "VM $0 failed to get installed": [
  null,
  "$0 sanal makinesinin yüklenmesi başarısız oldu"
 ],
 "VM $0 failed to pause": [
  null,
  "$0 sanal makinesini duraklatma başarısız oldu"
 ],
 "VM $0 failed to reboot": [
  null,
  "$0 sanal makinesini yeniden başlatma başarısız oldu"
 ],
 "VM $0 failed to resume": [
  null,
  "$0 sanal makinesini devam ettirme başarısız oldu"
 ],
 "VM $0 failed to send NMI": [
  null,
  "$0 sanal makinesinin NMI göndermesi başarısız oldu"
 ],
 "VM $0 failed to shutdown": [
  null,
  "$0 sanal makinesini kapatma başarısız oldu"
 ],
 "VM $0 failed to start": [
  null,
  "$0 sanal makinesi başlatılamadı"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "Sanal makine kullanıcı hesabınızın sahip olduğu işlem ve PTY ile ayrıcalıksız sınırlı erişimle başlatıldı"
 ],
 "VM state": [
  null,
  "Sanal Makine durumu"
 ],
 "VM will launch with root permissions": [
  null,
  "Sanal makine root izinleriyle başlatılacak"
 ],
 "VNC TLS port": [
  null,
  "VNC TLS bağlantı noktası"
 ],
 "VNC address": [
  null,
  "VNC adresi"
 ],
 "VNC console": [
  null,
  "VNC konsolu"
 ],
 "VNC port": [
  null,
  "VNC bağlantı noktası"
 ],
 "Valid token": [
  null,
  "Geçerli belirteç"
 ],
 "Vendor": [
  null,
  "Satıcı"
 ],
 "Virtual machines": [
  null,
  "Sanal makineler"
 ],
 "Virtual machines management": [
  null,
  "Sanal makine yönetimi"
 ],
 "Virtual network": [
  null,
  "Sanal ağ"
 ],
 "Virtual network failed to be created": [
  null,
  "Sanal ağ oluşturulması başarısız oldu"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "Sanallaştırma hizmeti (libvirt) etkin değil"
 ],
 "Volume": [
  null,
  "Birim"
 ],
 "Volume failed to be created": [
  null,
  "Birim oluşturulması başarısız oldu"
 ],
 "Volume group name": [
  null,
  "Birim grubu adı"
 ],
 "Volume group name should not be empty": [
  null,
  "Birim grubu adı boş olmamalıdır"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "Gözlemci"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Gözlemciler sistemler yanıt vermeyi bıraktığında harekete geçer. Bu sanal gözlemci aygıtını kullanmak için konuk sistemin ayrıca ek bir sürücüye ve çalışan bir gözlemci hizmetine sahip olması gerekir."
 ],
 "Writeable": [
  null,
  "Yazılabilir"
 ],
 "Writeable and shared": [
  null,
  "Yazılabilir ve paylaşılan"
 ],
 "You can mount the shared folder using:": [
  null,
  "Paylaşılan klasörü şu komutu kullanarak bağlayabilirsiniz:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "En yakından eşleşen işletim sistemini seçmeniz gerekli"
 ],
 "active": [
  null,
  "etkin"
 ],
 "add": [
  null,
  "ekle"
 ],
 "add entry": [
  null,
  "girdi ekle"
 ],
 "bridge": [
  null,
  "köprü"
 ],
 "cdrom": [
  null,
  "cdrom"
 ],
 "custom": [
  null,
  "özel"
 ],
 "direct": [
  null,
  "doğrudan"
 ],
 "disabled": [
  null,
  "etkisizleştirildi"
 ],
 "disk": [
  null,
  "disk"
 ],
 "down": [
  null,
  "kapalı"
 ],
 "edit": [
  null,
  "düzenle"
 ],
 "enabled": [
  null,
  "etkinleştirildi"
 ],
 "ethernet": [
  null,
  "ethernet"
 ],
 "host": [
  null,
  "anamakine"
 ],
 "host device": [
  null,
  "anamakine aygıtı"
 ],
 "host passthrough": [
  null,
  "anamakine geçişi"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "iSCSI doğrudan hedefi"
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI başlatıcı IQN"
 ],
 "iSCSI target": [
  null,
  "iSCSI hedefi"
 ],
 "iSCSI target IQN": [
  null,
  "iSCSI hedefi IQN"
 ],
 "inactive": [
  null,
  "etkin değil"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "daha fazla bilgi"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "bağlama noktası: Konuk içindeki bağlama noktası"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "bağlama etiketi: Dışa aktarılan bağlama noktasıyla ilişkili etiket"
 ],
 "network": [
  null,
  "ağ"
 ],
 "no": [
  null,
  "hayır"
 ],
 "no state saved": [
  null,
  "kaydedilen durum yok"
 ],
 "none": [
  null,
  "yok"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "yönlendirilen aygıt"
 ],
 "remove": [
  null,
  "kaldır"
 ],
 "serial number": [
  null,
  "seri numarası"
 ],
 "server": [
  null,
  "sunucu"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "açık"
 ],
 "user": [
  null,
  "kullanıcı"
 ],
 "vCPU count": [
  null,
  "vCPU sayısı"
 ],
 "vCPU maximum": [
  null,
  "en fazla vCPU"
 ],
 "vCPUs": [
  null,
  "vCPU'lar"
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "daha fazla göster..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "Sanal makineleri çoğaltmak için sistemde virt-install paketinin yüklenmesi gerekir"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "Yeni sanal makineler oluşturmak için sistemde virt-install paketinin yüklenmesi gerekir"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "Bu özniteliği düzenlemek için sistemde virt-install paketinin yüklenmesi gerekir"
 ],
 "vm": [
  null,
  "sanal makine"
 ],
 "yes": [
  null,
  "evet"
 ]
});
