cockpit.locale({
 "": {
  "plural-forms": (n) => n != 1,
  "language": "ka",
  "language-direction": "ltr"
 },
 "$0 $1 available at default location": [
  null,
  "$0 $1 ხელმისაწვდომია ნაგულისხმებ მდებარეობაზე"
 ],
 "$0 $1 available on host": [
  null,
  "ჰოსტზე ხელმისაწვდომია $0 $1"
 ],
 "$0 CPU configuration": [
  null,
  "$0-ე CPU-ის მორგება"
 ],
 "$0 Network": [
  null,
  "$0 ცალი ქსელი",
  "$0 ქსელი"
 ],
 "$0 Storage pool": [
  null,
  "$0 ცალი საცავის პული",
  "$0 საცავის პული"
 ],
 "$0 does not support unattended installation.": [
  null,
  "$0-ს ოპერაციულ სისტემას ავტომატური დაყენების საშუალება არ გააჩნია."
 ],
 "$0 is available for most operating systems. To install it, search for it in GNOME Software or run the following:": [
  null,
  "$0 ხელმისაწვდომია ოპერაციული სისტემების უმრავლესობისთვის. დასაყენებლად მოძებნეთ ის GNOME-ის პროგრამებში ან გაუშვით:"
 ],
 "$0 memory adjustment": [
  null,
  "$0-ის მეხსიერების შესწორება"
 ],
 "$0 network": [
  null,
  "$0 ქსელი"
 ],
 "$0 vCPU": [
  null,
  "$0 ცალი vCPU",
  "$0 vCPU"
 ],
 "$0 vCPU details": [
  null,
  "ინფორმაცია $0-ე vCPU-ის შესახებ"
 ],
 "$0 virtual network interface settings": [
  null,
  "ვირტუალური ქსელის ინტერფეისის მორგება ($0)"
 ],
 "A copy of the VM will run on the destination and will disappear when it is shut off. Meanwhile, the origin host keeps its copy of the VM configuration.": [
  null,
  "VM-ის ასლი გაეშვება სამიზნე მანქანაზე და გაქრება, როცა ის გამოირთვება. ამავე დროს საწყისი ჰოსტს VM-ის კონფიგურაცის საკუთარი ასლი გააჩნია."
 ],
 "Access": [
  null,
  "წვდომა"
 ],
 "Action": [
  null,
  "ქმედება"
 ],
 "Activate": [
  null,
  "აქტივაცია"
 ],
 "Activate the storage pool to administer volumes": [
  null,
  "საცავის პულის აქტივაცია საცავების ადმინისტრირებისთვის"
 ],
 "Add": [
  null,
  "დამატება"
 ],
 "Add a DHCP static host entry": [
  null,
  "ჰოსტის DHCP სტატიკური ელემენტის დამატება"
 ],
 "Add disk": [
  null,
  "დისკის დამატება"
 ],
 "Add host device": [
  null,
  "ჰოსტის მოწყობილობის დამატება"
 ],
 "Add network interface": [
  null,
  "ქსელის ინტერფეისის დამატება"
 ],
 "Add shared directory": [
  null,
  "ზიარი საქაღალდის დამატება"
 ],
 "Add virtual network interface": [
  null,
  "ქსელის ვირტუალური ინტერფეისის დამატება"
 ],
 "Add watchdog device type": [
  null,
  "Watchdog-ის ტიპის მოწყობილობის დამატება"
 ],
 "Adding shared directories is possible only when the guest is shut off": [
  null,
  "გაზიარებული საქაღალდეების დამატება მხოლოდ სტუმრის გამორთულობის დროსაა შესაძლებელი"
 ],
 "Adding this disk will change its access mode to shared.": [
  null,
  "დისკის დამატება წვდომის რეჟიმს გაზიარებულზე გადართავს."
 ],
 "Additional": [
  null,
  "დამატებითი"
 ],
 "Address": [
  null,
  "მისამართი"
 ],
 "Address not within subnet": [
  null,
  "მისამართი დიაპაზონს არ ეკუთვნის"
 ],
 "All": [
  null,
  "ყველა"
 ],
 "All VM activity, including storage, will be temporary. This will result in data loss on the destination host.": [
  null,
  "ვმ-ის ყველა აქტივობა, საცავის ჩათვლით, დროებითი იქნება. ეს სამიზნე ჰოსტზე მონაცემების დაკარგვას გამოიწვევს."
 ],
 "Allowed characters: basic Latin alphabet, numbers, and limited punctuation (-, _, +, .)": [
  null,
  "დაშვებული სიმბოლოები: ძირითადი ლათინური ანბანი, ციფრები და ზოგიერთი სასვენი ნიშანი (-, _, +, .)"
 ],
 "Also delete all volumes inside this pool:": [
  null,
  "ასევე წაიშლება ამ პულში მდებარე საცავებიც:"
 ],
 "Always attach": [
  null,
  "ყოველთვის მიბმა"
 ],
 "Apply": [
  null,
  "გადატარება"
 ],
 "Automated installs are only available when downloading an image or using cloud-init.": [
  null,
  "ავტომატური დაყენება ხელმისაწვდომია მხოლოდ გამოსახულების გადმოწერისას ან cloud-init-ით."
 ],
 "Automatic": [
  null,
  "ავტომატური"
 ],
 "Automation": [
  null,
  "ავტომატიზაცია"
 ],
 "Autostart": [
  null,
  "ავტომატური გაშვება"
 ],
 "Blocked": [
  null,
  "დაბლოკილია"
 ],
 "Boot order": [
  null,
  "ჩატვირთვის მიმდევრობა"
 ],
 "Boot order settings could not be saved": [
  null,
  "ჩატვირთვის მიმდევრობის შენახვის შეცდომა"
 ],
 "Bus": [
  null,
  "მატარებელი"
 ],
 "CD/DVD disc": [
  null,
  "CD/DVD დისკი"
 ],
 "CPU": [
  null,
  "CPU"
 ],
 "CPU configuration could not be saved": [
  null,
  "CPU-ის კონფიგურაციის შენახვის შეცდომა"
 ],
 "CPU type": [
  null,
  "CPU-ის ტიპი"
 ],
 "Cache": [
  null,
  "ქეში"
 ],
 "Cancel": [
  null,
  "გაუქმება"
 ],
 "Capacity": [
  null,
  "მოცულობა"
 ],
 "Change boot order": [
  null,
  "ჩატვირთვის მიმდევრობის შეცვლა"
 ],
 "Change firmware": [
  null,
  "მიკროკოდის შეცვლა"
 ],
 "Changes pending": [
  null,
  "დარჩენილი ცვლილებები"
 ],
 "Changes will take effect after shutting down the VM": [
  null,
  "ცვლილებები ძალაში მხოლოდ ვმ-ის გათიშვის შემდეგ შევა"
 ],
 "Changing BIOS/EFI settings is specific to each manufacturer. It involves pressing a hotkey during boot (ESC, F1, F12, Del). Enable a setting called \"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\", \"VTD\". Consult your computer's manual for details.": [
  null,
  "BIOS/EFI პარამეტრების შეცვლა მწარმოებლიდან მწარმოებლამდე განსხვავდება. ის ჩატვრთვისას კონკრეტული ღილაკის (ESC, F1, F12, del) დაჭერას და ვირტუალიზაციის *\"virtualization\", \"VM\", \"VMX\", \"SVM\", \"VTX\" ან \"VTD\") ჩართვას მოიცავს. მეტი დეტალებისთვის მიმართეთ კომპიუტერის დოკუმენტაციას."
 ],
 "Checking token validity...": [
  null,
  "კოდის სისწორის შემოწმება..."
 ],
 "Choose an operating system": [
  null,
  "აირჩეთ ოპერაციული სისტემა"
 ],
 "Class": [
  null,
  "კლასი"
 ],
 "Clicking \"Launch remote viewer\" will download a .vv file and launch $0.": [
  null,
  "\"დაშორებული დამთვალიერებლის გაშვება\"-ზე დაჭერა გადმოწერს .vv ფაილს და გაუშვებს $0-ს."
 ],
 "Clone": [
  null,
  "კლონი"
 ],
 "Close": [
  null,
  "დახურვა"
 ],
 "Cloud base image": [
  null,
  "ღრუბლოვანი საბაზისო გამოსახულება"
 ],
 "Confirm this action": [
  null,
  "ქმედების დასტური"
 ],
 "Connect": [
  null,
  "დაკავშირება"
 ],
 "Connect with any viewer application for following protocols": [
  null,
  "დაუკავშირდით ნებისმიერი მაყურებლით შემდეგი პროტოკოლებით"
 ],
 "Connecting": [
  null,
  "დაკავშირება"
 ],
 "Connection": [
  null,
  "კავშირი"
 ],
 "Console": [
  null,
  "კონსოლი"
 ],
 "Copy storage": [
  null,
  "საცავის კოპირება"
 ],
 "Cores per socket": [
  null,
  "ბირთვების რაოდენობა თითოეულ სოკეტზე"
 ],
 "Could not delete $0": [
  null,
  "წაშლის შეცდომა: $0"
 ],
 "Could not delete all storage for $0": [
  null,
  "$0-სთვის საცავის სრულად წაშლა შეუძლებელია"
 ],
 "Could not delete disk's storage": [
  null,
  "დისკის საცავის წაშლა შეუძლებელია"
 ],
 "Could not revert to snapshot": [
  null,
  "სწრაფ ასლზე დაბრუნების შეცდომა"
 ],
 "Crashed": [
  null,
  "გაითიშა"
 ],
 "Create": [
  null,
  "შექმნა"
 ],
 "Create VM": [
  null,
  "ვმ-ის შექმნა"
 ],
 "Create VM by importing a disk image of an existing VM installation": [
  null,
  "შექმენით ვმ-ი არსებული ვმ-ის დისკის ასლის შემოტანით"
 ],
 "Create VM from local or network installation medium": [
  null,
  "შექმენით ვმ-ი ლოკალური ან ქსელური დისკით"
 ],
 "Create a clone VM based on $0": [
  null,
  "$0-ის ასლზე დაფუძნებული ვმ-ის შექმნა"
 ],
 "Create and edit": [
  null,
  "შექმნა და ჩასწორება"
 ],
 "Create and run": [
  null,
  "შექმნა და გაშვება"
 ],
 "Create new": [
  null,
  "ახლის შექმნა"
 ],
 "Create new virtual machine": [
  null,
  "ახალი ვირტუალური მანქანის შექმნა"
 ],
 "Create new volume": [
  null,
  "ახალი ტომის შექმნა"
 ],
 "Create snapshot": [
  null,
  "სწრაფი ასლის შექმნა"
 ],
 "Create storage pool": [
  null,
  "საცავის პულის შექმნა"
 ],
 "Create storage volume": [
  null,
  "საცავის ტომის შექმნა"
 ],
 "Create virtual network": [
  null,
  "ვირტუალური ქსელის შექმნა"
 ],
 "Create volume": [
  null,
  "ტომის შექმნა"
 ],
 "Creating VM": [
  null,
  "ვმ-ის შექმნა"
 ],
 "Creating VM $0": [
  null,
  "ვმ-ის შექმნა: $0"
 ],
 "Creation of VM $0 failed": [
  null,
  "ვმ-ის ($0) შექმნის შეცდომა"
 ],
 "Creation time": [
  null,
  "შექმნის დრო"
 ],
 "Ctrl+Alt+$0": [
  null,
  "Ctrl+Alt+$0"
 ],
 "Current": [
  null,
  "მიმდინარე"
 ],
 "Current allocation": [
  null,
  "მიმდინარე განაწილება"
 ],
 "Custom firmware: $0": [
  null,
  "ხელით მითითებული მიკროკოდი: $0"
 ],
 "Custom path": [
  null,
  "ხელით მითითებული ბილიკი"
 ],
 "DHCP Settings": [
  null,
  "DHCP-ის მორგება"
 ],
 "Deactivate": [
  null,
  "დეაქტივაცია"
 ],
 "Delete": [
  null,
  "წაშლა"
 ],
 "Delete $0 VM?": [
  null,
  "წავშალო $0 ვმ-ი?"
 ],
 "Delete $0 storage pool?": [
  null,
  "წავშალო $0 საცავის პული?"
 ],
 "Delete $0 volume": [
  null,
  "$0 ცალი ტომის წაშლა",
  "$0 ტომის წაშლა"
 ],
 "Delete associated storage files:": [
  null,
  "საცავის მიბმული ფაილების წაშლა:"
 ],
 "Delete network?": [
  null,
  "წავშალო ქსელი?"
 ],
 "Delete snapshot?": [
  null,
  "წავშალო სწრაფი ასლი?"
 ],
 "Deleting an inactive storage pool will only undefine the pool. Its content will not be deleted.": [
  null,
  "არააქტიური საცავის პულის წაშლა მხოლოდ პულის განსაზღვრებას მოაშორებს. შიგთავსი არ წაიშლება."
 ],
 "Deleting shared directories is possible only when the guest is shut off": [
  null,
  "გაზიარებული საქაღალდეების წაშლა მხოლოდ სტუმრის გამორთულობის დროსაა შესაძლებელი"
 ],
 "Description": [
  null,
  "აღწერა"
 ],
 "Desktop viewer": [
  null,
  "სამუშაო მაგიდის დამთვალიერებელი"
 ],
 "Destination URI": [
  null,
  "სამიზნე URI"
 ],
 "Destination URI must not be empty": [
  null,
  "სამიზნე URI ცარიელი არ შეიძლება იყოს"
 ],
 "Detach the disks using this pool from any VMs before attempting deletion.": [
  null,
  "წაშლის ცდამდე საჭიროა ამ პულიდან მიბმული დისკების ყველა ვმ-დან მოცილება."
 ],
 "Details": [
  null,
  "დეტალები"
 ],
 "Device": [
  null,
  "მოწყობილობა"
 ],
 "Devices": [
  null,
  "მოწყობილობები"
 ],
 "Disconnect": [
  null,
  "გათიშვა"
 ],
 "Disconnected": [
  null,
  "გათიშულია"
 ],
 "Disconnected from serial console. Click the connect button.": [
  null,
  "სერიული კონსოლი გაითიშა. დააწექით კავშირის ღილაკს."
 ],
 "Disk": [
  null,
  "დისკი"
 ],
 "Disk $0 could not be removed": [
  null,
  "დისკის წაშლის შეცდომა: $0"
 ],
 "Disk failed to be attached": [
  null,
  "დისკის მიბმის შეცდომა"
 ],
 "Disk failed to be created": [
  null,
  "დისკის შექმნის შეცდომა"
 ],
 "Disk identifier": [
  null,
  "დისკის იდენტიფიკატორი"
 ],
 "Disk image": [
  null,
  "დისკის გამოსახულება"
 ],
 "Disk image file": [
  null,
  "დისკის გამოსახეულების ფაილი"
 ],
 "Disk image path must not be empty": [
  null,
  "დისკის გამოსახულების ბილიკი ცარიელი არ შეიძლება იყოს"
 ],
 "Disk images can be stored in user home directory": [
  null,
  "დისკის ასლები შეგიძლიათ მომხმარებლის საქაღლდეში შეინახოთ"
 ],
 "Disk settings could not be saved": [
  null,
  "დისკის პარამეტრების შენახვის შეცდომა"
 ],
 "Disk-only snapshot": [
  null,
  "მხოლოდ-დისკის სწრაფი ასლი"
 ],
 "Disks": [
  null,
  "დისკები"
 ],
 "Do not run this VM on the origin and destination hosts at the same time.": [
  null,
  "არ გაუშვა ეს ვმ-ი ერთდროულად წყარო და სამიზნე ჰოსტზე."
 ],
 "Do nothing": [
  null,
  "არაფრის გაკეთება"
 ],
 "Domain has crashed": [
  null,
  "დომენი გაითიშა"
 ],
 "Domain is blocked on resource": [
  null,
  "დომენი დაბლოკილია რესურსზე"
 ],
 "Download an OS": [
  null,
  "OS-ის გადმოწერა"
 ],
 "Download progress": [
  null,
  "გადმოწერა"
 ],
 "Downloading image for VM $0": [
  null,
  "ასლის გადმოწერა ვმ-სთვის $0"
 ],
 "Downloading: $0%": [
  null,
  "გადმოწერა: $0%"
 ],
 "Dump core": [
  null,
  "ბირთვის დამპი"
 ],
 "Duration": [
  null,
  "ხანგრძილობა"
 ],
 "Dying": [
  null,
  "კვდება"
 ],
 "Edit": [
  null,
  "ჩასწორება"
 ],
 "Edit $0 attributes": [
  null,
  "$0-ის ატრიბუტების ჩასწორება"
 ],
 "Edit watchdog device type": [
  null,
  "Watchdog ტიპის მოწყობილობის ჩასწორება"
 ],
 "Editing network interfaces of transient guests is not allowed": [
  null,
  "დროებით სტუმრებზე ქსელის ინტერფეისების ჩასწორება მხარდაუჭერელია"
 ],
 "Editing transient network interfaces is not allowed": [
  null,
  "ქსელის დროებითი ინტერფეისების ჩასწორება შეუძლებელია"
 ],
 "Eject": [
  null,
  "გამოღება"
 ],
 "Eject disc from VM?": [
  null,
  "გამოვიღო დისკი ვმ-დან?"
 ],
 "Emulated machine": [
  null,
  "ემულირებული მანქანა"
 ],
 "Enable virtualization support in BIOS/EFI settings.": [
  null,
  "ჩართეთ ვირტუალიზაციის მხარდაჭერა BIOS/EFI-ის პარამეტრებში."
 ],
 "End": [
  null,
  "დასასრული"
 ],
 "End should not be empty": [
  null,
  "ბოლო ცარიელი არ შეიძლება იყოს"
 ],
 "Enter root and/or user information to enable unattended installation.": [
  null,
  "ავტომატური დაყენებისთვის შეიყვანეთ root-ის ან/და მომხმარებლის ინფორმაცია."
 ],
 "Error checking token": [
  null,
  "კოდის შემოწმების შეცდომა"
 ],
 "Example, $0": [
  null,
  "მაგალითად, $0"
 ],
 "Existing disk image on host's file system": [
  null,
  "დისკის არსებული გამოსახულების ბილიკი ჰოსტის ფაილურ სისტემაზე"
 ],
 "Expand": [
  null,
  "გაფართოება"
 ],
 "Extended attributes": [
  null,
  "გაფართოებული ატრიბუტები"
 ],
 "Failed": [
  null,
  "შეცდომა"
 ],
 "Failed to add shared directory": [
  null,
  "გაზიარებული საქაღალდის დამატების შეცდომა"
 ],
 "Failed to change firmware": [
  null,
  "მიკროკოდის შეცვლის შეცდომა"
 ],
 "Failed to clone VM $0": [
  null,
  "ვმ-ის ($0) ასლის შექმნის შეცდომა"
 ],
 "Failed to configure watchdog": [
  null,
  "Watchdog-ის მორგების შეცდომა"
 ],
 "Failed to detach watchdog": [
  null,
  "Watchdog-ის მოხსნის შეცდომა"
 ],
 "Failed to fetch some resources": [
  null,
  "ზოგიერთი რესურსების გამოთხოვნის შეცდომა"
 ],
 "Failed to fetch the IP addresses of the interfaces present in $0": [
  null,
  "$0-ში ინტერფეისებზე იმაგრებული IP მისამართების მიღების შეცდომა"
 ],
 "Failed to rename VM $0": [
  null,
  "ვმ-ის ($0) გადარქმევის შეცდომა"
 ],
 "Failed to save network settings": [
  null,
  "ქსელის პარამეტრების შენახვის შეცდომა"
 ],
 "Failed to send key Ctrl+Alt+$0 to VM $1": [
  null,
  "Ctrl+Alt+$0-ის ვმ-თან ($1) გაგზავნის შეცდომა"
 ],
 "Fewer than the maximum number of virtual CPUs should be enabled.": [
  null,
  "ჩართული უნდა იყოს ხელმისაწვდომზე ნაკლები ვირტუალური პროცესორი."
 ],
 "File": [
  null,
  "ფაილი"
 ],
 "Filesystem $0 could not be removed": [
  null,
  "ფაილური სისტემის წაშლის შეცდომა: $0"
 ],
 "Filesystem directory": [
  null,
  "ფაილური სიტემის საქაღალდე"
 ],
 "Filter by name": [
  null,
  "სახელით გაფილტვრა"
 ],
 "Firmware": [
  null,
  "მიკროკოდი"
 ],
 "Force eject": [
  null,
  "ძალით გამოღება"
 ],
 "Force reboot": [
  null,
  "ძალით გადატვირთვა"
 ],
 "Force revert": [
  null,
  "ძალით დაბრუნება"
 ],
 "Force shut down": [
  null,
  "ძალით გამორთვა"
 ],
 "Format": [
  null,
  "ფორმატი"
 ],
 "Forward mode": [
  null,
  "გადაგზავნის რეჟიმი"
 ],
 "Forwarding mode": [
  null,
  "გადაგზავნის რეჟიმი"
 ],
 "Full disk images and the domain's memory will be migrated. Only non-shared, writable disk images will be transferred. Unused storage will remain on the origin after migration.": [
  null,
  "დისკის სრული გამოსახუებები და დომენის მეხსიერება გადაინაცვლებს. გადაიცემა მხოლოდ არაგაზიარებული, ჩასაწერი დისკის გამოსახულებები. გამოუყენებელი საცავი დარჩება საწყისზე მიგრაციის შემდეგ."
 ],
 "General": [
  null,
  "ზოგადი"
 ],
 "Generate automatically": [
  null,
  "ავტომატური გენერაცია"
 ],
 "Get a new RHSM token.": [
  null,
  "ახალი RHSM კოდის მიღება."
 ],
 "GiB": [
  null,
  "გიბ"
 ],
 "Go to VMs list": [
  null,
  "ვმ-ების სიაზე გადასვლა"
 ],
 "Good choice for desktop virtualization": [
  null,
  "კარგი არჩევანი სამუშაო მაგიდის ვირტუალიზაციისთვის"
 ],
 "Gracefully shutdown": [
  null,
  "ძალით გამორთვა"
 ],
 "Hardware virtualization is disabled": [
  null,
  "აპარატურული ვირტუალიზაცია გამორთულია"
 ],
 "Hide additional options": [
  null,
  "დამატებითი პარამეტრების დამალვა"
 ],
 "Host": [
  null,
  "ჰოსტი"
 ],
 "Host device": [
  null,
  "ჰოსტის მოწყობილობა"
 ],
 "Host device could not be attached": [
  null,
  "ჰოსტის მოწყობილობის მიბმის შეცდომა"
 ],
 "Host device will be removed from $0:": [
  null,
  "$0-დან წაიშლება ჰოსტის მოწყობილობა:"
 ],
 "Host devices": [
  null,
  "ჰოსტის მოწყობილობები"
 ],
 "Host name": [
  null,
  "ჰოსტის სახელი"
 ],
 "Host should not be empty": [
  null,
  "ჰოსტი ცარიელი არ შეიძლება იყოს"
 ],
 "Hypervisor details": [
  null,
  "ინფორმაცია ჰაიპერვაიზორის შესახებ"
 ],
 "ID": [
  null,
  "ID"
 ],
 "IP": [
  null,
  "IP"
 ],
 "IP address": [
  null,
  "IP მისამართი"
 ],
 "IP address must not be empty": [
  null,
  "IP მისამართი ცარიელი არ შეიძლება იყოს"
 ],
 "IP configuration": [
  null,
  "IP კონფიგურაცია"
 ],
 "IPv4 address": [
  null,
  "IPv4 მისამართი"
 ],
 "IPv4 address cannot be same as the network identifier": [
  null,
  "IPv4 მისამართი ქსელის იდენტიფიკატორი ვერ იქნება"
 ],
 "IPv4 address cannot be same as the network's broadcast address": [
  null,
  "IPv4 მისამართი და ქსელის გადაცემის მისამართი ერთი და იგივე ვერ იქნება"
 ],
 "IPv4 and IPv6": [
  null,
  "IPv4 და IPv6"
 ],
 "IPv4 network should not be empty": [
  null,
  "IPv4 ქსელი ცარიელი არ შეიძლება იყოს"
 ],
 "IPv4 only": [
  null,
  "მხოლოდ IPv4"
 ],
 "IPv6 address": [
  null,
  "IPv6 მისამართი"
 ],
 "IPv6 network should not be empty": [
  null,
  "IPv6 ქსელი ცარიელი არ შეიძლება იყოს"
 ],
 "IPv6 only": [
  null,
  "მხოლოდ IPv6"
 ],
 "Ideal for server VMs": [
  null,
  "იდეალურია სერვერული ვმ-ებისთვის"
 ],
 "Ideal networking support": [
  null,
  "ქსელის იდეალური მხარდაჭერა"
 ],
 "Identifier may be silently truncated to $0 characters ": [
  null,
  "იდენტიფიკატორს შეიძლება წაეჭრას $0 simbolo "
 ],
 "Idle": [
  null,
  "უქმი"
 ],
 "Ignore": [
  null,
  "იგნორირება"
 ],
 "Import VM": [
  null,
  "ვმ-ის შემოტანა"
 ],
 "Import a virtual machine": [
  null,
  "ვირტუალური მანქანის შემოტანა"
 ],
 "Import and edit": [
  null,
  "შემოტანა და ჩასწორება"
 ],
 "Import and run": [
  null,
  "შემოტანა და გაშვება"
 ],
 "Importing an image with a backing file is unsupported": [
  null,
  "უკანაბოლოს სახით ფაილის მქონე ასლის შემოტანა მხარდაუჭერელია"
 ],
 "In most configurations, macvtap does not work for host to guest network communication.": [
  null,
  "macvtap-ი არ მუშაობს ჰოსტიდან სტუმრამდე ქსელური კომუნიკაციისთვის."
 ],
 "In the default 'vepa' mode, switching is offloaded to the external switch. If the switch is not VEPA-capable, communication between guest virtual machines, or between a guests and the host is not possible.": [
  null,
  "ნაგულისხმებ, \"vepa\" რეჟიმში, სვიჩინგი გადაგდებულია გარე სვიჩზე. თუ სვიჩი VEPA თავსებადი არაა, სტუმრებსა შორის ან სტუმრიდან ჰოსტამდე კავშირი შეუძლებელია."
 ],
 "Initiator": [
  null,
  "ინიციატორი"
 ],
 "Initiator IQN should not be empty": [
  null,
  "ინიციატორის IQN ცარიელი არ შეიძლება იყოს"
 ],
 "Inject a non-maskable interrupt": [
  null,
  "შეუნიღბვადი წყვეტის გაგზავნა"
 ],
 "Insert": [
  null,
  "ჩადება"
 ],
 "Insert disc media": [
  null,
  "დისკის ჩადება"
 ],
 "Install": [
  null,
  "დაყენება"
 ],
 "Installation source": [
  null,
  "დაყენების წყარო"
 ],
 "Installation source must not be empty": [
  null,
  "დაყენების წყარო ცარიელი არ შეიძლება იყოს"
 ],
 "Installation type": [
  null,
  "დაყენების ტიპი"
 ],
 "Interface": [
  null,
  "ინტერფეისი"
 ],
 "Interface type": [
  null,
  "ინტერფეისის ტიპი"
 ],
 "Interface type help": [
  null,
  "ინტერფეისის ტიპის დახმარება"
 ],
 "Invalid IPv4 address": [
  null,
  "არასწორი IPv4 მისამართი"
 ],
 "Invalid IPv4 mask or prefix length": [
  null,
  "არასწორი IPv4 ნიღაბი ან პრეფიქსის სიგრძე"
 ],
 "Invalid IPv6 address": [
  null,
  "არასწორი IPv6 მისამართი"
 ],
 "Invalid IPv6 prefix": [
  null,
  "არასწორი IPv6 პრეფიქსი"
 ],
 "Invalid filename": [
  null,
  "ფაილის არასწორი სახელი"
 ],
 "Isolated network": [
  null,
  "იზოლირებული ქსელი"
 ],
 "LVM volume group": [
  null,
  "LVM ტომების ჯგუფი"
 ],
 "Launch remote viewer": [
  null,
  "დაშორებული მაყურებლის გაშვება"
 ],
 "Leave the password blank if you do not wish to have a root account created": [
  null,
  "root ანგარიშის არ შესაქმნელად დატოვეთ პაროლი ცარიელი"
 ],
 "Leave the password blank if you do not wish to have a user account created": [
  null,
  "მომხმარებლის პაროლის არ შესაქმნელად დატოვეთ პაროლი ცარიელი"
 ],
 "Leave the password blank if you do not wish to set a root password": [
  null,
  "თუ არ გნებავთ პაროლის დაყენება, დატოვეთ ის ცარიელი"
 ],
 "Libvirt did not detect any UEFI/OVMF firmware image installed on the host": [
  null,
  "Libvirt-მა ჰოსტზე დაყენებული ვერცერთი UEFI/OMVF მიკროკოდის გამოსახულება ვერ იპოვა"
 ],
 "Libvirt or hypervisor does not support UEFI": [
  null,
  "Libvirt-ს ან ჰაიპერვაიზორს UEFI-ის მხარდაჭერა არ გააჩნია"
 ],
 "Loading available network devices": [
  null,
  "ხელმისაწვდომი ქსელური მოწყობილობების ჩატვირთვა"
 ],
 "Loading resources": [
  null,
  "რესურსების ჩატვირთვა"
 ],
 "Loading...": [
  null,
  "ჩატვირთვა..."
 ],
 "Local install media (ISO image or distro install tree)": [
  null,
  "დაყენების ლოკალური წყარო (ISO გამოსახულება ან დისტრიბუტივის დასაყენებელი ხე)"
 ],
 "Location": [
  null,
  "მდებარეობა"
 ],
 "MAC": [
  null,
  "MAC"
 ],
 "MAC address": [
  null,
  "MAC მისამართი"
 ],
 "MAC address must not be empty": [
  null,
  "MAC მისამართი ცარიელი არ შეიძლება იყოს"
 ],
 "Machine must be shut off before changing bus type": [
  null,
  "მატარებლის ტიპის შეცვლამდე მანქანა უნდა გამოირთოს"
 ],
 "Machine must be shut off before changing cache mode": [
  null,
  "ქეშის რეჟიმის შეცვლამდე მანქანა უნდა გამოირთოს"
 ],
 "Managing virtual machines": [
  null,
  "ვირტუალური მანქანების მართვა"
 ],
 "Manual connection": [
  null,
  "ხელით მითითებული კავშირი"
 ],
 "Mask or prefix length": [
  null,
  "ნიღაბი ან პრეფიქსის სიგრზე"
 ],
 "Mask or prefix length should not be empty": [
  null,
  "ნიღაბი ან პრეფიქსის სიგრძე ცარიელი არ შეიძლება იყოს"
 ],
 "Maximum allocation": [
  null,
  "მაქსიმალური განაწილება"
 ],
 "Maximum memory could not be saved": [
  null,
  "მაქსიმალური მეხსიერების შენახვის პრობლემა"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS": [
  null,
  "სტუმარი ოპერაციული სისტემისთვის გამოყოფილი ვირტუალური პროცესორების მაქსიმალური რაოდენობა"
 ],
 "Maximum number of virtual CPUs allocated for the guest OS, which must be between 1 and $0": [
  null,
  "ვირტუალური CPU-ების მაქსიმალური რაოდენობა. დიაპაზონი 1-$0"
 ],
 "Maximum transmission unit": [
  null,
  "გადაცემის მაქსიმალური ერთეული"
 ],
 "Media could not be ejected from $0": [
  null,
  "$0-დან დისკის გამოღების შეცდომა"
 ],
 "Media will be ejected from $0:": [
  null,
  "მოხდება დისკის $0-დან ამოღება:"
 ],
 "Memory": [
  null,
  "მეხსიერება"
 ],
 "Memory could not be saved": [
  null,
  "მეხსიერების შენახვის შეცდომა"
 ],
 "Memory must not be 0": [
  null,
  "მეხსიერება არ შეიძლება 0-ის ტოლი იყოს"
 ],
 "MiB": [
  null,
  "მიბ"
 ],
 "Migrate": [
  null,
  "მიგრაცია"
 ],
 "Migrate VM to another host": [
  null,
  "ვმ-ის სხვა ჰოსტზე გადატანა"
 ],
 "Migration failed": [
  null,
  "მიგრაციის შეცდომა"
 ],
 "Mode": [
  null,
  "რეჟიმი"
 ],
 "Model": [
  null,
  "მოდელი"
 ],
 "Model type": [
  null,
  "მოდელის ტიპი"
 ],
 "More info for mount tag field": [
  null,
  "მეტი ინფორმაცია მიმაგრების ჭდის ველის შესახებ"
 ],
 "More info for source path field": [
  null,
  "მეტი ინფორმაცია წყაროს ბილიკის შესახებ"
 ],
 "Mount tag": [
  null,
  "მიბმის ჭდე"
 ],
 "Mount tag must not be empty": [
  null,
  "მიმაგრების ჭდე ცარიელი არ შეიძლება იყოს"
 ],
 "NAT to $0": [
  null,
  "NAT $0მდე"
 ],
 "NIC $0 of VM $1 failed to change state": [
  null,
  "ვმ-ის ($1) ქსელური ინტერფეისის($0) მდგომარეობის შეცვლის შეცდომა"
 ],
 "Name": [
  null,
  "სახელი"
 ],
 "Name already exists": [
  null,
  "სახელი უკვე არსებობს"
 ],
 "Name contains invalid characters": [
  null,
  "სახელი შეიცავს არასწორ სიმბოლოებს"
 ],
 "Name must not be empty": [
  null,
  "სახელი ცარიელი არ შეიძლება იყოს"
 ],
 "Name should not be empty": [
  null,
  "სახელ ცარიელი არ შეიძლება იყოს"
 ],
 "Name: ": [
  null,
  "სახელი: "
 ],
 "Netmask": [
  null,
  "ქსელის ნიღაბი"
 ],
 "Network $0 could not be deleted": [
  null,
  "ქსელის წაშლის შეცდომა: $0"
 ],
 "Network $0 failed to get activated": [
  null,
  "ქსელის ($0) აქტივაციის შეცდომა"
 ],
 "Network $0 failed to get deactivated": [
  null,
  "ქსელის ($0) დეაქტივაციის შეცდომა"
 ],
 "Network $0 will be permanently deleted.": [
  null,
  "ქსელი სამუდამოდ წაიშლება: $0."
 ],
 "Network boot (PXE)": [
  null,
  "ქსელური ჩატვირთვა (PXE)"
 ],
 "Network file system": [
  null,
  "ქსელური ფაილური სისტემა"
 ],
 "Network interface": [
  null,
  "ქსელის ინტერფეისი"
 ],
 "Network interface $0 could not be removed": [
  null,
  "ქსელის ინტერფეისის წაშლის შეცდომა: $0"
 ],
 "Network interface $0 will be removed from $1": [
  null,
  "ქსელის ინტერფეისი $0 წაშლილი იქნება $1-დან"
 ],
 "Network interface settings could not be saved": [
  null,
  "ქსელის ინტერფეისის პარამეტრების შენახვის შეცდომა"
 ],
 "Network interfaces": [
  null,
  "ქსელის ინტერფეისები"
 ],
 "Network selection does not support PXE.": [
  null,
  "არჩეულ ქსელს PXE-ის მხარდაჭერა არ გააჩნია."
 ],
 "Networks": [
  null,
  "ქსელები"
 ],
 "New name": [
  null,
  "ახალი სახელი"
 ],
 "New name must not be empty": [
  null,
  "ახალი სახელი ცარიელი არ შეიძლება იყოს"
 ],
 "New volume name": [
  null,
  "ახალი ტომის სახელი"
 ],
 "No VM is running or defined on this host": [
  null,
  "ამ ჰოსტზე გაშვებული ან აღწერილი ვმ-ი არ არსებობს"
 ],
 "No boot device found": [
  null,
  "ჩასატვირთი მოწყობილობის გარეშე"
 ],
 "No connection available": [
  null,
  "კავშირი ხელმიუწვდომელია"
 ],
 "No description": [
  null,
  "აღწერის გარეშე"
 ],
 "No directories shared between the host and this VM": [
  null,
  "ამ ვმ-სა და ჰოსტს შორის საქაღალდეები გაზიარებული არაა"
 ],
 "No disks defined for this VM": [
  null,
  "ამ ვმ-ს დისკები არ გააჩნია"
 ],
 "No host device selected": [
  null,
  "ჰოსტის მოწყობილობა არჩეული არაა"
 ],
 "No host devices assigned to this VM": [
  null,
  "ამ ვმ-ს არ გააჩნია ჰოსტის მიბმული მოწყობილობები"
 ],
 "No network devices": [
  null,
  "ქსელის მოწყობილობების გარეშე"
 ],
 "No network interfaces defined for this VM": [
  null,
  "ამ ვმ-ს ქსელის ინტერფეისები არ გააჩნია"
 ],
 "No network is defined on this host": [
  null,
  "ამ ჰოსტზე ქსელები აღწერილი არაა"
 ],
 "No networks available": [
  null,
  "ქსელები მიუწვდომელია"
 ],
 "No parent": [
  null,
  "მშობლის გარეშე"
 ],
 "No snapshots defined for this VM": [
  null,
  "ამ ვმ-ს სწრაფი ასლები არ გააჩნია"
 ],
 "No state": [
  null,
  "მდგომარეობის გარეშე"
 ],
 "No storage": [
  null,
  "საცავის გარეშე"
 ],
 "No storage pool is defined on this host": [
  null,
  "ამ ჰოსტზე საცავის პული აღწერილი არაა"
 ],
 "No storage pools available": [
  null,
  "საცავის პულები ხელმიუწვდომელია"
 ],
 "No storage volumes defined for this storage pool": [
  null,
  "საცავის ამ პულში ტომები აღწერილი არაა"
 ],
 "No virtual networks": [
  null,
  "ვირტუალური ქსელების გარეშე"
 ],
 "No volumes exist in this storage pool.": [
  null,
  "საცავის პულში ტომები არ არსებობს."
 ],
 "Non-persistent network cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "დროებითი ქსელის წაშლა შეუძლებელია. ის მისი დეაქტივაციისთანავე გაქრება."
 ],
 "Non-persistent storage pool cannot be deleted. It ceases to exists when it's deactivated.": [
  null,
  "საცავის დროებითი პულის წაშლა შეუძლებელია. ის გაქრება, როცა დეაქტივირდება."
 ],
 "None": [
  null,
  "არცერთი"
 ],
 "None (isolated network)": [
  null,
  "არცერთი (იზოლირებული ქსელი)"
 ],
 "Offline token": [
  null,
  "გათიშული კოდი"
 ],
 "Offline token must not be empty": [
  null,
  "გათიშული კოდი ცარიელი არ შეიძლება იყოს"
 ],
 "Old token expired": [
  null,
  "ძველი კოდის ვადა ამოიწურა"
 ],
 "One or more selected volumes are used by domains. Detach the disks first to allow volume deletion.": [
  null,
  "ერთი ან მეტი არჩეული ტომი დომენების მიერ გამოიყენება. ტომის წასაშლელად ჯერ მოაძრეთ დისკები."
 ],
 "Only editable when the guest is shut off": [
  null,
  "ჩასწორებადია მხოლოდ მაშინ, როცა სტუმარი გათიშულია"
 ],
 "Open": [
  null,
  "გახსნა"
 ],
 "Operating system": [
  null,
  "ოპერაციული სისტემა"
 ],
 "Operation is in progress": [
  null,
  "ოპერაცია მიმდინარეობს"
 ],
 "Overview": [
  null,
  "გადახედვა"
 ],
 "PCI": [
  null,
  "PCI"
 ],
 "Parent snapshot": [
  null,
  "მშობელი სწრაფი ასლი"
 ],
 "Path": [
  null,
  "ბილიკი"
 ],
 "Path on host's filesystem": [
  null,
  "ბილიკი ჰოსტის ფაილურ სისტემაზე"
 ],
 "Path to ISO file on host's file system": [
  null,
  "ბილიკი ISO ფაილამდე ჰოსტის ფაილურ სისტემაზე"
 ],
 "Path to cloud image file on host's file system": [
  null,
  "ღრუბლოვანი გამოსახულების ბილიკი ჰოსტის ფაილურ სისტემაზე"
 ],
 "Path to file on host's file system": [
  null,
  "ბილიკი ფაილამდე ჰოსტის ფალურ სისტემაზე"
 ],
 "Pause": [
  null,
  "შეჩერება"
 ],
 "Paused": [
  null,
  "შეჩერებულია"
 ],
 "Permanent (default)": [
  null,
  "მუდმივი (ნაგულისხმები)"
 ],
 "Permissions denied for disk images in home directories": [
  null,
  "საწყისი საქაღალდეებიდან დისკის ასლების წაკითხვის წვდომა აკრძალულია"
 ],
 "Persistence": [
  null,
  "მუდმივობა"
 ],
 "Persistent": [
  null,
  "მუდმივი"
 ],
 "Physical disk device": [
  null,
  "დისკის ფიზიკური მოწყობილობა"
 ],
 "Physical disk device on host": [
  null,
  "დისკის ფიზიკური მოწყობილობა ჰოსტზე"
 ],
 "Please choose a storage pool": [
  null,
  "აირჩიეთ საცავის პული"
 ],
 "Please choose a volume": [
  null,
  "აირჩიეთ ტომი"
 ],
 "Please enter new volume name": [
  null,
  "შეიყვანეთ ახალი ტომის სახელი"
 ],
 "Please start the virtual machine to access its console.": [
  null,
  "კონსოლზე წვდომისათვის საჭიროა ვირტუალური მანქანა ჯერ გაუშვათ."
 ],
 "Pool": [
  null,
  "პული"
 ],
 "Pool needs to be active to create volume": [
  null,
  "ომის შესაქმნელად საჭიროა, რომ პული აქტიური იყოს"
 ],
 "Pool type $0 does not support volume creation": [
  null,
  "პულის ტიპი ($) მხარს არ უჭერს ტომების შექმნას"
 ],
 "Pool type doesn't support volume creation": [
  null,
  "პულის ტიპს ტომის შექმნის მხარდაჭერა არ გააჩნია"
 ],
 "Pool's volumes are used by VMs ": [
  null,
  "პულის ტომები გამოიყენება ვმ-ების მიერ "
 ],
 "Port": [
  null,
  "პორტი"
 ],
 "Power off": [
  null,
  "გამორთვა"
 ],
 "Preferred number of sockets to expose to the guest.": [
  null,
  "სტუმრისათვის გადასაცემი სოკეტების რაოდენობა."
 ],
 "Prefix": [
  null,
  "პრეფიქსი"
 ],
 "Prefix length": [
  null,
  "პრეფიქსის სიგრძე"
 ],
 "Prefix length should not be empty": [
  null,
  "პრეფიქსის სიგრძე ცარიელი არ შეიძლება იყოს"
 ],
 "Previously taken snapshots allow you to revert to an earlier state if something goes wrong": [
  null,
  "ადრე შექმნილი სწრაფი ასლები საშუალებად გაძლევთ, თუ რამე მოხდა, წინა მდგომარეობას დაუბრუნდეთ"
 ],
 "Private": [
  null,
  "პირადი"
 ],
 "Product": [
  null,
  "პროდუქტი"
 ],
 "Profile": [
  null,
  "პროფილი"
 ],
 "Protocol": [
  null,
  "პროტოკოლი"
 ],
 "Provides a bridge from the guest virtual machine directly onto the LAN. This needs a bridge device on the host with one or more physical NICs.": [
  null,
  "წარმოადგენს ხიდს სტუმრის ვირტუალური მანქანიდან პირდაპირ LAN-ში. საჭიროა ხიდის მოწყობილობა ჰოსტზე, ერთი ან მეტი ფიზიკური NIC-ით."
 ],
 "Provides a connection whose details are described by the named network definition.": [
  null,
  "კავშირი, რომლის დეტალებიც ქსელის აღწერაშია."
 ],
 "Provides a virtual LAN with NAT to the outside world.": [
  null,
  "NAT-ით ვირტუალური ქსელისთვის გარე სამყაროსთან წვდომა."
 ],
 "Range": [
  null,
  "დიაპაზონი"
 ],
 "Read-only": [
  null,
  "მხოლოდ-წასაკითხად"
 ],
 "Reboot": [
  null,
  "გადატვირთვა"
 ],
 "Remote URL": [
  null,
  "დაშორებული URL"
 ],
 "Remote viewer details": [
  null,
  "დაშორებული მაყურებლის დეტალები"
 ],
 "Remove": [
  null,
  "წაშლა"
 ],
 "Remove and delete file": [
  null,
  "ფაილის მოცილება და წაშლა"
 ],
 "Remove disk from VM?": [
  null,
  "წავშალო დისკი ვმ-დან?"
 ],
 "Remove filesystem?": [
  null,
  "წავშალო ფაილური სისტემა?"
 ],
 "Remove host device from VM?": [
  null,
  "წავშალო ჰოსტის მოწყობილობა ვმ-დან?"
 ],
 "Remove network interface?": [
  null,
  "წავშალო ქსელის ინტერფეისი?"
 ],
 "Remove static host from DHCP": [
  null,
  "host-ის სტატიკური ჩანაწერების DHCP-დან წაშლა"
 ],
 "Rename": [
  null,
  "გადარქმევა"
 ],
 "Rename VM $0": [
  null,
  "ვმ-ის გადარქმევა ($0)"
 ],
 "Reset": [
  null,
  "საწყის მნიშვნელობებზე დაბრუნება"
 ],
 "Restrictions in networking (SLIRP-based emulation) and PCI device assignment": [
  null,
  "ქსელის შეზღუდვები (SIRP-ზე ბაზირებული ემულაცია) და PCI მოწყობილობების მინიჭება"
 ],
 "Resume": [
  null,
  "გაგრძელება"
 ],
 "Revert": [
  null,
  "დაბრუნება"
 ],
 "Revert to snapshot $0": [
  null,
  "სწრაფ ასლზე ($0) დაბრუნება"
 ],
 "Reverting to this snapshot will take the VM back to the time of the snapshot and the current state will be lost, along with any data not captured in a snapshot": [
  null,
  "სწრაფ ასლზე დაბრუნება გადაიყვანს ვმ-ს იმ დროზე, როცა ასლის აღება მოხდა. ცვლილებები, რომლებიც ვმ-ში მოხდა ასლის აღების შემდეგ, დაიკარგება"
 ],
 "Root password": [
  null,
  "Root-ის პაროლი"
 ],
 "Route to $0": [
  null,
  "რაუტი $0-მდე"
 ],
 "Routed network": [
  null,
  "დარაუტებული ქსელი"
 ],
 "Run": [
  null,
  "გაშვება"
 ],
 "Run when host boots": [
  null,
  "ჰოსტის ჩატვირთვისას გაშვება"
 ],
 "Running": [
  null,
  "გაშვებულია"
 ],
 "SPICE TLS port": [
  null,
  "SPICE-ის TLS პორტი"
 ],
 "SPICE address": [
  null,
  "SPICE-ის მისამართი"
 ],
 "SPICE port": [
  null,
  "SPICE-ის პორტი"
 ],
 "Save": [
  null,
  "შენახვა"
 ],
 "Select console type": [
  null,
  "აირჩიეთ კონსოლის ტიპი"
 ],
 "Send key": [
  null,
  "ღილაკის გაგზავნა"
 ],
 "Send non-maskable interrupt": [
  null,
  "შეუნიღბვადი წყვეტის გაგზავნა"
 ],
 "Serial": [
  null,
  "სერიული ნომერი"
 ],
 "Serial console": [
  null,
  "სერიული კონსოლი"
 ],
 "Serial console ($0)": [
  null,
  "სერიული კონსოლი ($0)"
 ],
 "Set DHCP range": [
  null,
  "DHCP-ის დიაპაზონის დაყენება"
 ],
 "Set manually": [
  null,
  "ხელით მითითება"
 ],
 "Setting the user passwords for unattended installation requires starting the VM when creating it": [
  null,
  "ავტომატური ინსტალაციისთვის მომხმარებლის პაროლის დაყენება შექმნისას ვმ-ის ჩართვას მოითხოვს"
 ],
 "Share": [
  null,
  "გაზიარება"
 ],
 "Share a host directory with the guest": [
  null,
  "ჰოსტის საქაღალდის სტუმართან გაზიარება"
 ],
 "Shared directories": [
  null,
  "გაზიარებული საქაღალდეები"
 ],
 "Shared host directories need to be manually mounted inside the VM": [
  null,
  "ჰოსტის გაზიარებული საქაღალდე ვმ-ის შიგნით ხელით უნდა მიამაგროთ"
 ],
 "Shared storage": [
  null,
  "გაზიარებული საცავი"
 ],
 "Show additional options": [
  null,
  "დამატებითი პარამეტრების ჩვენება"
 ],
 "Shut down": [
  null,
  "გამორთვა"
 ],
 "Shut off": [
  null,
  "გათიშვა"
 ],
 "Shut off the VM in order to edit firmware configuration": [
  null,
  "მიკროკოდის კონფიგურაციისთვის საჭიროა ვმ-ის გამორთვა"
 ],
 "Shutting down": [
  null,
  "მიმდინარეობს გათიშვა"
 ],
 "Size": [
  null,
  "ზომა"
 ],
 "Slot": [
  null,
  "სლოტი"
 ],
 "Snapshot $0 could not be deleted": [
  null,
  "სწრაფი ასლის წაშლის შეცდომა: $0"
 ],
 "Snapshot $0 will be deleted from $1. All of its captured content will be lost.": [
  null,
  "სწრაფი ასლი $0 წაიშლება $1-დან. შუალედში შეცვლილი ინფორმაცია დაიკარგება."
 ],
 "Snapshot failed to be created": [
  null,
  "სწრაფი ასლის შექმნის შეცდომა"
 ],
 "Snapshots": [
  null,
  "სწრაფი ასლები"
 ],
 "Sockets": [
  null,
  "სოკეტები"
 ],
 "Some configuration changes only take effect after a fresh boot:": [
  null,
  "კონფიგურაციის ზოგიერთი ცვლილება ძალაში მხოლოდ გადატვირთვის შემდეგ შევა:"
 ],
 "Source": [
  null,
  "წყარო"
 ],
 "Source format": [
  null,
  "წყაროს ფორმატი"
 ],
 "Source must not be empty": [
  null,
  "წყარო ცარიელი არ შეიძლება იყოს"
 ],
 "Source path": [
  null,
  "წყაროს ბილიკი"
 ],
 "Source path should not be empty": [
  null,
  "წყაროს ბილიკი ცარიელი არ შეიძლება იყოს"
 ],
 "Source should start with http, ftp or nfs protocol": [
  null,
  "წყარო უნდა იწყებოდეს http, ftp ან nfs-ით"
 ],
 "Source volume group": [
  null,
  "წყარო ტომების ჯგუფი"
 ],
 "Start": [
  null,
  "გაშვება"
 ],
 "Start pool when host boots": [
  null,
  "პულის გაშვება ჰოსტის ჩატვირთვისას"
 ],
 "Start should not be empty": [
  null,
  "დასაწყისი ცარიელი არ შეიძლება იყოს"
 ],
 "Startup": [
  null,
  "გაშვება"
 ],
 "State": [
  null,
  "მდგომარეობა"
 ],
 "Static host entries": [
  null,
  "host-ის სტატიკური ჩანაწერები"
 ],
 "Static host from DHCP could not be removed": [
  null,
  "host-ის სტატიკური ჩანაწერების DHCP-დან წაშლის შეცდომა"
 ],
 "Storage": [
  null,
  "საცავი"
 ],
 "Storage is at a shared location": [
  null,
  "საცავი გაზიარებულ ადგილასაა"
 ],
 "Storage limit": [
  null,
  "საცავის ლიმიტი"
 ],
 "Storage pool $0 failed to get activated": [
  null,
  "საცავის პულის ($) აქტივაციის შეცდომა"
 ],
 "Storage pool $0 failed to get deactivated": [
  null,
  "საცავის პულის ($0) დეაქტივაციის შეცდომა"
 ],
 "Storage pool failed to be created": [
  null,
  "საცავის პულის შექმნის შეცდომა"
 ],
 "Storage pool name": [
  null,
  "საცავის პულის სახელი"
 ],
 "Storage pools": [
  null,
  "საცავის პულები"
 ],
 "Storage pools could not be fetched": [
  null,
  "სტორიჯის პულების გამოთხოვნის შეცდომა"
 ],
 "Storage size must not be 0": [
  null,
  "საცავის ზომა 0 არ შეიძლება იყოს"
 ],
 "Storage volume": [
  null,
  "საცავის ტომი"
 ],
 "Storage volume size must not exceed the storage pool's capacity ($0 $1)": [
  null,
  "საცავის ტომის ზომამ საცავის პულის ზომას არ უნდა გადააჭარბოს ($0 $1)"
 ],
 "Storage volumes": [
  null,
  "საცავის ტომები"
 ],
 "Storage volumes could not be deleted": [
  null,
  "საცავის ტომების წაშლის შეცდომა"
 ],
 "Storage volumes must be shared between this host and the destination host.": [
  null,
  "საცავის ტომები გაზიარებული უნდა იყოს ამ და სამიზნე ჰოსტებს შორის."
 ],
 "Suspended (PM)": [
  null,
  "შეჩერებულია (PM)"
 ],
 "System": [
  null,
  "სისტემა"
 ],
 "Table of selectable host devices": [
  null,
  "ჰოსტის არჩევადი მოწყობილობების ცხრილი"
 ],
 "Target": [
  null,
  "სამიზნე"
 ],
 "Target path": [
  null,
  "სამიზნე ბილიკი"
 ],
 "Target path should not be empty": [
  null,
  "სამიზნე ბილიკი ცარიელი არ შეიძლება იყოს"
 ],
 "Temporary": [
  null,
  "დროებითი"
 ],
 "Temporary migration": [
  null,
  "დროებითი მიგრაცია"
 ],
 "The VM $0 is running and will be forced off before deletion.": [
  null,
  "ვმ-ი გაშვებულია. წაშლის წინ ის გაითიშება: $0."
 ],
 "The VM needs to be running or shut off to detach this device": [
  null,
  "მოწყობილობის მოსაძრობად საჭიროა ვმ-ის გამორთვა"
 ],
 "The directory on the server being exported": [
  null,
  "მიმდინარეობს სერვერის საქაღალდის გატანა"
 ],
 "The host path that is to be exported.": [
  null,
  "ჰოსტის გასატანი ბილიკი."
 ],
 "The migrated VM configuration is removed from the source host. The destination host is considered the new home of the VM.": [
  null,
  "გადატანილი ვმ-ის კონფიგურაცია იშლება საწყისი ჰოსტიდან. სამიზნე ჰოსტი განიხილება, როგორც ვმ-ის ახალი სახლი."
 ],
 "The pool is empty": [
  null,
  "პული ცარიელია"
 ],
 "The selected operating system has minimum memory requirement of $0 $1": [
  null,
  "არჩეული ოპერაციული სისტემის მეხსიერების თეორიული მინიმუმი $0 $1-ს შეადგენს"
 ],
 "The selected operating system has minimum storage size requirement of $0 $1": [
  null,
  "არჩეული ოპერაციული სისტემის დისკის მინიმალური მოთხოვნაა $0 $1"
 ],
 "The static host entry for $0 will be removed:": [
  null,
  "სტატიკური ჰოსტის ჩანაწერი $0-სთვის წაიშლება:"
 ],
 "The storage pool could not be deleted": [
  null,
  "საცავის პულის წაშლის შეცდომა"
 ],
 "The tag name to be used by the guest to mount this export point.": [
  null,
  "ჭდის სახელი, რომელიც სტუმრის მიმართ გატანილი წერტილის მისამაგრებლადაა საჭირო."
 ],
 "Then copy and paste it above.": [
  null,
  "დააკოპირეთ და ზემოთ ჩასვით."
 ],
 "This VM is transient. Shut it down if you wish to delete it.": [
  null,
  "ვმ-ი დროებითია. წასაშლელად გამორთეთ."
 ],
 "This disk will be removed from $0:": [
  null,
  "$0-დან დისკი წაიშლება:"
 ],
 "This filesystem will be removed from $0:": [
  null,
  "ფაილური სისტემა წაიშლება $0-დან:"
 ],
 "This is the recommended config for general guest connectivity on hosts with dynamic / wireless networking configs.": [
  null,
  "რეკომენდებული კონფიგურაცია Wireless/დინამიკური ქსელის კონფიგურაციის მქონე ჰოსტებზე გაშვებული სტუმრებისთვის."
 ],
 "This is the recommended config for general guest connectivity on hosts with static wired networking configs.": [
  null,
  "რეკომენდებული კონფიგურაცია სტატიკური ქსელის კონფიგურაციის მქონე ჰოსტებზე გაშვებული სტუმრებისთვის."
 ],
 "This is the recommended config for high performance or enhanced security.": [
  null,
  "ეს კონფიგურაცია რეკომენდებულია მაღალი წარმადობისა და კარგი უსაფრთხოებისთვის."
 ],
 "This volume is already used by $0.": [
  null,
  "ეს ტომი $0-ის მიერ უკვე გამოიყენება."
 ],
 "This volume is already used by another VM.": [
  null,
  "ეს ტომი უკვე გამოიყენება სხვა ვმ-ის მიერ."
 ],
 "Threads per core": [
  null,
  "ნაკადების რიცხვი თითოეულ ბირთვზე"
 ],
 "Transient VMs don't support editing firmware configuration": [
  null,
  "დროებითი ვმ-ებს მიკროკოდის კონფიგურაციის ჩასწორების მხარდაჭერა არ გააჩნიათ"
 ],
 "Troubleshoot": [
  null,
  "პრობლემების პოვნა"
 ],
 "Type": [
  null,
  "ტიპი"
 ],
 "Type ID": [
  null,
  "ტიპის ID"
 ],
 "URL (ISO image or distro install tree)": [
  null,
  "URL(ISO გამოსახულების ან დისტრიბუტივის დასაყენებელი ხის)"
 ],
 "USB": [
  null,
  "USB მოწყობილობა"
 ],
 "UUID": [
  null,
  "UUID"
 ],
 "Undefined": [
  null,
  "გაუსაზღვრელი"
 ],
 "Unique name": [
  null,
  "უნიკალური სახელი"
 ],
 "Unique name, default: $0": [
  null,
  "უნიკალური სახელი, ნაგულისხმები: $0"
 ],
 "Unique network name": [
  null,
  "ქსელის უნიკალური სახელი"
 ],
 "Unit": [
  null,
  "ერთეული"
 ],
 "Unknown": [
  null,
  "უცნობი"
 ],
 "Unknown firmware": [
  null,
  "უცნობი მიკროკოდი"
 ],
 "Unspecified": [
  null,
  "მიუთითებელი"
 ],
 "Url": [
  null,
  "Url"
 ],
 "Usage": [
  null,
  "გამოყენება"
 ],
 "Use existing": [
  null,
  "არსებულის გამოყენება"
 ],
 "Use extended attributes on files and directories": [
  null,
  "დამატებითი ატრიბუტების გამოყენება ფაილებზე და საქაღალდეებზე"
 ],
 "Use the same location on both the origin and destination hosts for your storage. This can be a shared storage pool, NFS, or any other method of sharing storage.": [
  null,
  "საცავისთვის გამოიყენეთ ერთიდაიგივე მდებარეობა საწყის და სამიზნე ჰოსტებზე. შეიძლება იყოს ზიარი საცავის პული, NFS ან საცავის გაზიარების სხვა ხერხი."
 ],
 "Used": [
  null,
  "გამოყენებულია"
 ],
 "Used by": [
  null,
  "გამოიყენება"
 ],
 "User login": [
  null,
  "მომხმარებლის შესვლა"
 ],
 "User login must not be empty when user password is set": [
  null,
  "როცა პაროლი დაყენებულია, მომხმარებლის სახელი ცარიელი არ შეიძლება იყოს"
 ],
 "User password": [
  null,
  "მომხმარებლის პაროლი"
 ],
 "User password must not be empty when user login is set": [
  null,
  "პაროლი მაშინ, როცა მომხმარებლის სახელი დაყენებულია, ცარიელი არ შეიძლება იყოს"
 ],
 "User session": [
  null,
  "მომხმარებლის სესია"
 ],
 "VCPU settings could not be saved": [
  null,
  "VCPU-ის პარამეტრების შენახვის შეცდომა"
 ],
 "VM $0 Host Devices": [
  null,
  "ვმ $0-ის ჰოსტის მოწყობილობები"
 ],
 "VM $0 already exists": [
  null,
  "ვმ ($0) უკვე არსებობს"
 ],
 "VM $0 does not exist on $1 connection": [
  null,
  "ვმ-ი ($0) არ არსებობს ამ ($1) კავშირდზე"
 ],
 "VM $0 failed to force reboot": [
  null,
  "ვმ-ის ($0) ძალით გადატვირთვის შეცდომა"
 ],
 "VM $0 failed to force shutdown": [
  null,
  "ვმ-ის ($0) ძალით გამორთვის შეცდომა"
 ],
 "VM $0 failed to get installed": [
  null,
  "ვმ-ის ($0) დაყენების შეცდომა"
 ],
 "VM $0 failed to pause": [
  null,
  "ვმ-ის ($0) შეჩერების შეცდომა"
 ],
 "VM $0 failed to reboot": [
  null,
  "ვმ-ის ($0) გადატვირთვის შეცდომა"
 ],
 "VM $0 failed to resume": [
  null,
  "ვმ-ის ($0) გაგრძელების შეცდომა"
 ],
 "VM $0 failed to send NMI": [
  null,
  "ვმ-მა ($0) ვერ შეძლო NMI-ის გაგზავნა"
 ],
 "VM $0 failed to shutdown": [
  null,
  "ვმ-ის ($0) გამორთვის შეცდომა"
 ],
 "VM $0 failed to start": [
  null,
  "ვმ-ის ($0) გაშვების შეცდომა"
 ],
 "VM launched with unprivileged limited access, with the process and PTY owned by your user account": [
  null,
  "VM გაშვებულია არაპრივილეგირებული უფლებებით, პროცესზე და PTY-ზე წვდომა თქვენს ანგარიშს გააჩნია"
 ],
 "VM needs shutdown": [
  null,
  "ვმ-ს გამორთვა სჭირდება"
 ],
 "VM state": [
  null,
  "ვმ-ის მდგომარეობა"
 ],
 "VM will launch with root permissions": [
  null,
  "ვმ-ი root-ის უფლებებით გაეშვება"
 ],
 "VNC TLS port": [
  null,
  "VNC-ის TLS პორტი"
 ],
 "VNC address": [
  null,
  "VNC-ის მისამართი"
 ],
 "VNC console": [
  null,
  "VNC-ის კონსოლი"
 ],
 "VNC port": [
  null,
  "VNC-ის პორტი"
 ],
 "Valid token": [
  null,
  "სწორი კოდი"
 ],
 "Vendor": [
  null,
  "მომწოდებელი"
 ],
 "Virtual machines": [
  null,
  "ვირტუალური მანქანები"
 ],
 "Virtual machines management": [
  null,
  "ვირტუალური მანქანების მართვა"
 ],
 "Virtual network": [
  null,
  "ვირტუალური ქსელი"
 ],
 "Virtual network failed to be created": [
  null,
  "ვირტუალური ქსელის შექმნის შეცდომა"
 ],
 "Virtualization service (libvirt) is not active": [
  null,
  "ვირტუალიზაციის სერვისი (libvirt) აქტიური არაა"
 ],
 "Volume": [
  null,
  "ტომი"
 ],
 "Volume failed to be created": [
  null,
  "ტომის ფაილის შექმნის შეცდომა"
 ],
 "Volume group name": [
  null,
  "ტომების ჯგუფის სახელი"
 ],
 "Volume group name should not be empty": [
  null,
  "ტომების ჯგუფის სახელი ცარიელი არ შეიძლება იყოს"
 ],
 "WWPN": [
  null,
  "WWPN"
 ],
 "Watchdog": [
  null,
  "საკონტროლო ტაიმერი"
 ],
 "Watchdogs act when systems stop responding. To use this virtual watchdog device, the guest system also needs to have an additional driver and a running watchdog service.": [
  null,
  "Watchdog-ები მუშაობენ, როცა სისტემები უპასუხოდ ტოვებენ მათ. ვირტუალური Watchdog-ის გამოსაყენებლად სტუმარ ოპერაციულ სისტემას დამატებითი დრაივერი და გაშვებული სერვისი სჭირდება."
 ],
 "Writeable": [
  null,
  "ჩაწერადი"
 ],
 "Writeable and shared": [
  null,
  "ჩაწერადი და გაზიარებული"
 ],
 "You can mount the shared folder using:": [
  null,
  "შეგიძლიათ მიამაგროთ გაზიარებული საქაღალდე:"
 ],
 "You need to select the most closely matching operating system": [
  null,
  "აირჩიეთ ყველაზე ახლოს მდგომი ოპერაციული სისტემა"
 ],
 "active": [
  null,
  "აქტიური"
 ],
 "add": [
  null,
  "დამატება"
 ],
 "add entry": [
  null,
  "ელემენტის დამატება"
 ],
 "bridge": [
  null,
  "ხიდი"
 ],
 "cdrom": [
  null,
  "CD წამკითხავი"
 ],
 "custom": [
  null,
  "ხელით"
 ],
 "direct": [
  null,
  "პირდაპირი"
 ],
 "disabled": [
  null,
  "გათიშულია"
 ],
 "disk": [
  null,
  "დისკი"
 ],
 "down": [
  null,
  "დაბლა"
 ],
 "edit": [
  null,
  "ჩასწორება"
 ],
 "enabled": [
  null,
  "ჩართულია"
 ],
 "ethernet": [
  null,
  "Ethernet"
 ],
 "host": [
  null,
  "ჰოსტი"
 ],
 "host device": [
  null,
  "ჰოსტის მოწყობილობა"
 ],
 "host passthrough": [
  null,
  "ჰოსტის გამჭოლი მოწყობილობა"
 ],
 "hostdev": [
  null,
  "hostdev"
 ],
 "iSCSI direct target": [
  null,
  "iSCSI target-ის სამიზნე"
 ],
 "iSCSI initiator IQN": [
  null,
  "iSCSI ინიციატორის IQN"
 ],
 "iSCSI target": [
  null,
  "iSCSI სამიზნე"
 ],
 "iSCSI target IQN": [
  null,
  "iSCSI target-ის IQN"
 ],
 "inactive": [
  null,
  "არააქტიური"
 ],
 "iso": [
  null,
  "iso"
 ],
 "libvirt": [
  null,
  "libvirt"
 ],
 "mcast": [
  null,
  "mcast"
 ],
 "more info": [
  null,
  "მეტი ინფორმაცია"
 ],
 "mount point: The mount point inside the guest": [
  null,
  "მიმაგრების წერტილი: მიმაგრების წერტილი სტუმრის შიგნით"
 ],
 "mount tag: The tag associated to the exported mount point": [
  null,
  "მიმაგრების ჭდე: გამოტანილ მიმაგრების წერტილზე მიბმული ჭდე"
 ],
 "network": [
  null,
  "ქსელი"
 ],
 "no": [
  null,
  "არა"
 ],
 "no state saved": [
  null,
  "მდგომარეობა შენახული არაა"
 ],
 "none": [
  null,
  "არცერთი"
 ],
 "pxe": [
  null,
  "pxe"
 ],
 "qcow2": [
  null,
  "qcow2"
 ],
 "qemu": [
  null,
  "qemu"
 ],
 "redirected device": [
  null,
  "გადამისამართებული მოწყობილობა"
 ],
 "remove": [
  null,
  "წაშლა"
 ],
 "serial number": [
  null,
  "სერიული ნომერი"
 ],
 "server": [
  null,
  "სერვერი"
 ],
 "udp": [
  null,
  "udp"
 ],
 "up": [
  null,
  "მაღლა"
 ],
 "user": [
  null,
  "მომხმარებელი"
 ],
 "vCPU count": [
  null,
  "vCPU-ების რაოდენობა"
 ],
 "vCPU maximum": [
  null,
  "vCPU-ის მაქსიმუმი"
 ],
 "vCPUs": [
  null,
  "vCPU-ები"
 ],
 "vhostuser": [
  null,
  "vhostuser"
 ],
 "view more...": [
  null,
  "მეტის ნახვა..."
 ],
 "virt-install package needs to be installed on the system in order to clone VMs": [
  null,
  "ვმ-ების ასლების შესაქმნელად საჭიროა პაკეტი virt-install"
 ],
 "virt-install package needs to be installed on the system in order to create new VMs": [
  null,
  "ახალი ვმ-ების შესაქმნელად საჭიროა პაკეტი virt-install"
 ],
 "virt-install package needs to be installed on the system in order to edit this attribute": [
  null,
  "ამ ატრიბუტის ჩასასწორებლად საჭიროა დაყენებული იყოს პაკეტი virt-install"
 ],
 "vm": [
  null,
  "ვმ"
 ],
 "yes": [
  null,
  "დიახ"
 ]
});
